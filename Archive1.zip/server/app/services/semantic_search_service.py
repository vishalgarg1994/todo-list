"""
Semantic Search Service
Orchestrates vector search and graph enrichment for fault description similarity
"""
import logging
from typing import List, Dict, Any, Optional

from services.embedding_service import EmbeddingService
from data_access.milvusClient import MilvusClient
from data_access.memgraphClient import MemgraphClient
from configs.config import Config


class SemanticSearchService:
    """Service for semantic search over fault descriptions with graph enrichment"""

    def __init__(self, config: Config = None):
        """
        Initialize semantic search service

        Args:
            config: Configuration object
        """
        self.config = config or Config()
        self.embedding_service = EmbeddingService(self.config)
        self.milvus_client = MilvusClient(self.config)
        self.memgraph_client = MemgraphClient(
            uri=self.config.memgraph_uri,
            user=self.config.memgraph_user,
            password=self.config.memgraph_password,
            database=self.config.memgraph_database
        )

        logging.info("Initialized SemanticSearchService")

    async def search_similar_faults(
        self,
        query: str,
        top_k: int = 10,
        min_score: float = 0.7
    ) -> List[Dict[str, Any]]:
        """
        Search for similar fault descriptions (vector search only, no enrichment)

        Args:
            query: Natural language fault description query
            top_k: Number of results to return (default: 10)
            min_score: Minimum similarity score 0.0-1.0 (default: 0.5)

        Returns:
            List of results with fault_description_id and similarity score
        """
        logging.info(f"Searching for similar faults: '{query}' (top_k={top_k}, min_score={min_score})")

        # Step 1: Generate embedding for query
        query_embedding = self.embedding_service.generate_embedding(query)
        if not query_embedding:
            raise ValueError("Failed to generate embedding for query")

        # Step 2: Search Milvus for similar vectors
        vector_results = await self.milvus_client.search(
            query_embedding=query_embedding,
            top_k=top_k
        )

        # Step 3: Filter by minimum score
        filtered_results = [
            {
                "fault_description_id": r["fault_description_id"],
                "fault_description_text": r.get("fault_description_text"),
                "fault_description_summary": r.get("fault_description_summary", ""),
                "similarity_score": r["score"],
                "distance": r["distance"]
            }
            for r in vector_results
            if r["score"] >= min_score
        ]

        logging.info(f"Found {len(filtered_results)} similar faults (filtered from {len(vector_results)})")
        return filtered_results

    async def search_similar_tickets(
        self,
        query: str,
        top_k: int = 10,
        min_score: float = 0.7
    ) -> List[Dict[str, Any]]:
        """
        Search for similar tickets with basic ticket/incident metadata

        Args:
            query: Natural language fault description query
            top_k: Number of results to return
            min_score: Minimum similarity score

        Returns:
            List of results enriched with ticket and incident details
        """
        logging.info(f"Searching for similar tickets: '{query}' (top_k={top_k}, min_score={min_score})")

        # Step 1: Vector search
        vector_results = await self.search_similar_faults(query, top_k, min_score)

        if not vector_results:
            logging.info("No similar tickets found")
            return []

        # Step 2: Enrich with basic ticket metadata
        enriched_results = await self._enrich_with_ticket_metadata(vector_results)

        logging.info(f"Enriched {len(enriched_results)} tickets with metadata")
        return enriched_results

    async def search_similar_resolutions(
        self,
        query: str,
        top_k: int = 10,
        min_score: float = 0.7
    ) -> List[Dict[str, Any]]:
        """
        Search for similar tickets with full resolution details (OutageInfo)

        Args:
            query: Natural language fault description query
            top_k: Number of results to return
            min_score: Minimum similarity score

        Returns:
            List of results enriched with resolution details, MTTR, RFO, etc.
        """
        logging.info(f"Searching for similar resolutions: '{query}' (top_k={top_k}, min_score={min_score})")

        # Step 1: Vector search
        vector_results = await self.search_similar_faults(query, top_k, min_score)

        if not vector_results:
            logging.info("No similar resolutions found")
            return []

        # Step 2: Enrich with full resolution data (includes ticket metadata + outage info)
        enriched_results = await self._enrich_with_resolution_data(vector_results)

        logging.info(f"Enriched {len(enriched_results)} tickets with resolution data")
        return enriched_results

    async def search_similar_services(
        self,
        query: str,
        top_k: int = 10,
        min_score: float = 0.7
    ) -> List[Dict[str, Any]]:
        """
        Search for similar tickets and show affected services

        Args:
            query: Natural language fault description query
            top_k: Number of results to return
            min_score: Minimum similarity score

        Returns:
            List of results enriched with service details
        """
        logging.info(f"Searching for similar services: '{query}' (top_k={top_k}, min_score={min_score})")

        # Step 1: Vector search
        vector_results = await self.search_similar_faults(query, top_k, min_score)

        if not vector_results:
            logging.info("No similar services found")
            return []

        # Step 2: Enrich with service data
        enriched_results = await self._enrich_with_service_data(vector_results)

        logging.info(f"Enriched {len(enriched_results)} tickets with service data")
        return enriched_results

    async def search_similar_maintenance_windows(
        self,
        query: str,
        top_k: int = 10,
        min_score: float = 0.7
    ) -> List[Dict[str, Any]]:
        """
        Search for similar tickets and show maintenance windows

        Args:
            query: Natural language fault description query
            top_k: Number of results to return
            min_score: Minimum similarity score

        Returns:
            List of results enriched with maintenance window details
        """
        logging.info(f"Searching for similar maintenance windows: '{query}' (top_k={top_k}, min_score={min_score})")

        # Step 1: Vector search
        vector_results = await self.search_similar_faults(query, top_k, min_score)

        if not vector_results:
            logging.info("No similar maintenance windows found")
            return []

        # Step 2: Enrich with maintenance window data
        enriched_results = await self._enrich_with_maintenance_window_data(vector_results)

        logging.info(f"Enriched {len(enriched_results)} tickets with maintenance window data")
        return enriched_results

    async def search_similar_engineers(
        self,
        query: str,
        top_k: int = 10,
        min_score: float = 0.7
    ) -> List[Dict[str, Any]]:
        """
        Search for similar tickets and show engineers/users involved

        Args:
            query: Natural language fault description query
            top_k: Number of results to return
            min_score: Minimum similarity score

        Returns:
            List of results enriched with engineer/user details
        """
        logging.info(f"Searching for similar engineers: '{query}' (top_k={top_k}, min_score={min_score})")

        # Step 1: Vector search
        vector_results = await self.search_similar_faults(query, top_k, min_score)

        if not vector_results:
            logging.info("No similar engineers found")
            return []

        # Step 2: Enrich with engineer data
        enriched_results = await self._enrich_with_engineer_data(vector_results)

        logging.info(f"Enriched {len(enriched_results)} tickets with engineer data")
        return enriched_results

    async def search_similar_vendors(
        self,
        query: str,
        top_k: int = 10,
        min_score: float = 0.7
    ) -> List[Dict[str, Any]]:
        """
        Search for similar tickets and show vendors involved

        Args:
            query: Natural language fault description query
            top_k: Number of results to return
            min_score: Minimum similarity score

        Returns:
            List of results enriched with vendor details
        """
        logging.info(f"Searching for similar vendors: '{query}' (top_k={top_k}, min_score={min_score})")

        # Step 1: Vector search
        vector_results = await self.search_similar_faults(query, top_k, min_score)

        if not vector_results:
            logging.info("No similar vendors found")
            return []

        # Step 2: Enrich with vendor data
        enriched_results = await self._enrich_with_vendor_data(vector_results)

        logging.info(f"Enriched {len(enriched_results)} tickets with vendor data")
        return enriched_results

    async def search_similar_client_impacts(
        self,
        query: str,
        top_k: int = 10,
        min_score: float = 0.7
    ) -> List[Dict[str, Any]]:
        """
        Search for similar tickets and show impacted clients

        Args:
            query: Natural language fault description query
            top_k: Number of results to return
            min_score: Minimum similarity score

        Returns:
            List of results enriched with client impact details
        """
        logging.info(f"Searching for similar client impacts: '{query}' (top_k={top_k}, min_score={min_score})")

        # Step 1: Vector search
        vector_results = await self.search_similar_faults(query, top_k, min_score)

        if not vector_results:
            logging.info("No similar client impacts found")
            return []

        # Step 2: Enrich with client data
        enriched_results = await self._enrich_with_client_data(vector_results)

        logging.info(f"Enriched {len(enriched_results)} tickets with client data")
        return enriched_results

    async def find_similar_faults_by_ticket(
        self,
        ticket_id: str,
        top_k: int = 10,
        min_score: float = 0.7
    ) -> List[Dict[str, Any]]:
        """
        Find tickets with similar fault descriptions (vector search only, no enrichment)

        Args:
            ticket_id: The ticket ID to find similar faults for
            top_k: Number of similar tickets to return
            min_score: Minimum similarity score (0.0-1.0)

        Returns:
            List with query ticket info and similar tickets with fault descriptions + similarity scores
        """
        logging.info(f"Finding similar faults for ticket: {ticket_id} (top_k={top_k}, min_score={min_score})")

        # Step 1: Get the embedding vector from Milvus for this ticket_id
        ticket_data = await self.milvus_client.get_vector_by_id(ticket_id)

        if not ticket_data:
            logging.warning(f"Ticket {ticket_id} not found in Milvus")
            return []

        query_embedding = ticket_data["embedding"]
        query_fault_description = ticket_data["fault_description_text"]
        query_fault_summary = ticket_data.get("fault_description_summary", "")

        logging.info(f"Retrieved embedding for ticket {ticket_id}")

        # Step 2: Search Milvus for similar vectors
        vector_results = await self.milvus_client.search(
            query_embedding=query_embedding,
            top_k=top_k + 1  # +1 because the query ticket itself will be in results
        )

        # Step 3: Filter out the query ticket itself and apply min_score
        filtered_results = [
            {
                "fault_description_id": r["fault_description_id"],
                "fault_description_text": r.get("fault_description_text"),
                "fault_description_summary": r.get("fault_description_summary", ""),
                "similarity_score": r["score"],
                "distance": r["distance"]
            }
            for r in vector_results
            if r["fault_description_id"] != ticket_id and r["score"] >= min_score
        ][:top_k]  # Limit to top_k after filtering

        if not filtered_results:
            logging.info(f"No similar faults found for {ticket_id}")
            return []

        logging.info(f"Found {len(filtered_results)} similar faults")

        # Return results with query ticket info
        return {
            "query_ticket": {
                "ticket_id": ticket_id,
                "fault_description": query_fault_description,
                "fault_description_summary": query_fault_summary
            },
            "similar_tickets": filtered_results
        }

    async def get_ticket_resolutions(
        self,
        ticket_ids: List[str]
    ) -> List[Dict[str, Any]]:
        """
        Get resolution details for a list of ticket IDs from Memgraph

        Args:
            ticket_ids: List of ticket IDs to get resolutions for

        Returns:
            List of tickets with resolution details
        """
        logging.info(f"Getting resolutions for {len(ticket_ids)} tickets")

        if not ticket_ids:
            return []

        # Convert ticket_ids to the format expected by enrichment
        vector_results = [
            {
                "fault_description_id": ticket_id,
                "fault_description_text": None,  # Will be fetched from Memgraph if available
                "similarity_score": None,
                "distance": None
            }
            for ticket_id in ticket_ids
        ]

        # Enrich with resolution data from Memgraph
        enriched_results = await self._enrich_with_resolution_data(vector_results)

        logging.info(f"Retrieved resolution data for {len(enriched_results)} tickets")
        return enriched_results

    async def _enrich_with_ticket_metadata(
        self,
        vector_results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Enrich vector search results with basic ticket and fault metadata

        Args:
            vector_results: Results from vector search

        Returns:
            Enriched results with ticket/fault details
        """
        enriched = []

        for result in vector_results:
            ticket_id = result["fault_description_id"]

            try:
                # Cypher query to get basic ticket and fault info
                # Updated to match current schema from batch_graph_loader.py
                cypher = """
                MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: $ticket_id})
                OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
                RETURN
                    t.ticket_id as ticket_id,
                    t.ticket_status as status,
                    t.priority as priority,
                    c.client_name as client_name,
                    t.created_on as created_date,
                    t.closed_on as closed_date,
                    t.assigned_to as assigned_to,
                    f.short_description as fault_description,
                    f.ticket_rfo_group as problem_type,
                    f.is_customer_impacting as is_customer_impacting
                """

                graph_data = await self.memgraph_client.execute(cypher, params={"ticket_id": ticket_id})

                # Extract data from result
                if graph_data and len(graph_data) > 0:
                    row = graph_data[0]

                    enriched_result = {
                        **result,  # Include similarity score, distance
                        "ticket_details": {
                            "ticket_id": row.get("ticket_id"),
                            "status": row.get("status"),
                            "priority": row.get("priority"),
                            "client_name": row.get("client_name"),
                            "created_date": str(row.get("created_date")) if row.get("created_date") else None,
                            "closed_date": str(row.get("closed_date")) if row.get("closed_date") else None,
                            "assigned_to": row.get("assigned_to")
                        },
                        "fault_details": {
                            "short_description": row.get("fault_description"),
                            "problem_type": row.get("problem_type"),
                            "is_customer_impacting": row.get("is_customer_impacting")
                        }
                    }

                    enriched.append(enriched_result)
                else:
                    # If no graph data found, include vector result only
                    logging.warning(f"No graph data found for ticket {ticket_id}")
                    enriched.append({
                        **result,
                        "ticket_details": None,
                        "fault_details": None
                    })

            except Exception as e:
                # If enrichment fails for this ticket, log and continue
                logging.error(f"Failed to enrich ticket {ticket_id}: {e}")
                enriched.append({
                    **result,
                    "ticket_details": None,
                    "fault_details": None,
                    "enrichment_error": str(e)
                })

        return enriched

    async def _enrich_with_resolution_data(
        self,
        vector_results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Enrich vector search results with full resolution data (Outage_Info)

        Args:
            vector_results: Results from vector search

        Returns:
            Enriched results with ticket/fault/resolution details
        """
        enriched = []

        for result in vector_results:
            ticket_id = result["fault_description_id"]

            try:
                # Cypher query to get full context including Outage_Info
                # Updated to match current schema from batch_graph_loader.py
                cypher = """
                MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: $ticket_id})
                OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
                OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
                RETURN
                    t.ticket_id as ticket_id,
                    t.ticket_status as status,
                    t.priority as priority,
                    c.client_name as client_name,
                    t.created_on as created_date,
                    t.closed_on as closed_date,
                    t.assigned_to as assigned_to,
                    f.short_description as fault_description,
                    f.ticket_rfo_group as problem_type,
                    f.is_customer_impacting as is_customer_impacting,
                    o.rfo as rfo,
                    o.mttr as mttr,
                    o.outage_duration as outage_duration
                """

                graph_data = await self.memgraph_client.execute(cypher, params={"ticket_id": ticket_id})

                # Extract data from result
                if graph_data and len(graph_data) > 0:
                    row = graph_data[0]

                    enriched_result = {
                        **result,  # Include similarity score, distance
                        "ticket_details": {
                            "ticket_id": row.get("ticket_id"),
                            "status": row.get("status"),
                            "priority": row.get("priority"),
                            "client_name": row.get("client_name"),
                            "created_date": str(row.get("created_date")) if row.get("created_date") else None,
                            "closed_date": str(row.get("closed_date")) if row.get("closed_date") else None,
                            "assigned_to": row.get("assigned_to")
                        },
                        "fault_details": {
                            "short_description": row.get("fault_description"),
                            "problem_type": row.get("problem_type"),
                            "is_customer_impacting": row.get("is_customer_impacting")
                        },
                        "resolution_details": {
                            "rfo": row.get("rfo"),
                            "mttr": row.get("mttr"),
                            "outage_duration": row.get("outage_duration")
                        }
                    }

                    enriched.append(enriched_result)
                else:
                    # If no graph data found, include vector result only
                    logging.warning(f"No graph data found for ticket {ticket_id}")
                    enriched.append({
                        **result,
                        "ticket_details": None,
                        "fault_details": None,
                        "resolution_details": None
                    })

            except Exception as e:
                # If enrichment fails for this ticket, log and continue
                logging.error(f"Failed to enrich ticket {ticket_id} with resolution data: {e}")
                enriched.append({
                    **result,
                    "ticket_details": None,
                    "fault_details": None,
                    "resolution_details": None,
                    "enrichment_error": str(e)
                })

        return enriched

    async def _enrich_with_service_data(
        self,
        vector_results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Enrich vector search results with service impact information

        Args:
            vector_results: Results from vector search

        Returns:
            Enriched results with service details
        """
        enriched = []

        for result in vector_results:
            ticket_id = result["fault_description_id"]

            try:
                # Cypher query to get service impact information
                # Updated to match current schema from batch_graph_loader.py
                cypher = """
                MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: $ticket_id})
                OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
                OPTIONAL MATCH (t)-[:HAS_SERVICE]->(s:Service)
                RETURN
                    t.ticket_id as ticket_id,
                    t.ticket_status as status,
                    t.priority as priority,
                    f.short_description as fault_description,
                    f.is_customer_impacting as is_customer_impacting,
                    collect(distinct {
                        subcategory: s.subcategory,
                        technology: s.technology
                    }) as services
                """

                graph_data = await self.memgraph_client.execute(cypher, params={"ticket_id": ticket_id})

                if graph_data and len(graph_data) > 0:
                    row = graph_data[0]
                    services = row.get("services", [])
                    # Filter out empty service objects (when no service is matched)
                    services = [s for s in services if s.get("subcategory") or s.get("technology")]

                    enriched_result = {
                        **result,
                        "ticket_details": {
                            "ticket_id": row.get("ticket_id"),
                            "status": row.get("status"),
                            "priority": row.get("priority")
                        },
                        "fault_details": {
                            "short_description": row.get("fault_description"),
                            "is_customer_impacting": row.get("is_customer_impacting")
                        },
                        "service_impact": {
                            "total_services": len(services),
                            "services": services
                        }
                    }

                    enriched.append(enriched_result)
                else:
                    logging.warning(f"No graph data found for ticket {ticket_id}")
                    enriched.append({
                        **result,
                        "ticket_details": None,
                        "fault_details": None,
                        "service_impact": None
                    })

            except Exception as e:
                logging.error(f"Failed to enrich ticket {ticket_id} with service data: {e}")
                enriched.append({
                    **result,
                    "ticket_details": None,
                    "fault_details": None,
                    "service_impact": None,
                    "enrichment_error": str(e)
                })

        return enriched

    async def _enrich_with_maintenance_window_data(
        self,
        vector_results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Enrich vector search results with maintenance window information

        Args:
            vector_results: Results from vector search

        Returns:
            Enriched results with maintenance window details
        """
        enriched = []

        for result in vector_results:
            ticket_id = result["fault_description_id"]

            try:
                # Cypher query to get maintenance window information
                # Updated to match current schema from batch_graph_loader.py
                cypher = """
                MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: $ticket_id})
                OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
                OPTIONAL MATCH (t)-[:DURING_MAINTENANCE]->(mw:MaintenanceWindow)
                RETURN
                    t.ticket_id as ticket_id,
                    t.ticket_status as status,
                    t.priority as priority,
                    f.short_description as fault_description,
                    mw.pw_start as planned_start,
                    mw.pw_end as planned_end,
                    mw.pw_reason as maintenance_reason
                """

                graph_data = await self.memgraph_client.execute(cypher, params={"ticket_id": ticket_id})

                if graph_data and len(graph_data) > 0:
                    row = graph_data[0]

                    enriched_result = {
                        **result,
                        "ticket_details": {
                            "ticket_id": row.get("ticket_id"),
                            "status": row.get("status"),
                            "priority": row.get("priority")
                        },
                        "fault_details": {
                            "short_description": row.get("fault_description")
                        },
                        "maintenance_window": {
                            "planned_start": str(row.get("planned_start")) if row.get("planned_start") else None,
                            "planned_end": str(row.get("planned_end")) if row.get("planned_end") else None,
                            "reason": row.get("maintenance_reason")
                        } if row.get("planned_start") or row.get("planned_end") else None
                    }

                    enriched.append(enriched_result)
                else:
                    logging.warning(f"No graph data found for ticket {ticket_id}")
                    enriched.append({
                        **result,
                        "ticket_details": None,
                        "fault_details": None,
                        "maintenance_window": None
                    })

            except Exception as e:
                logging.error(f"Failed to enrich ticket {ticket_id} with maintenance window data: {e}")
                enriched.append({
                    **result,
                    "ticket_details": None,
                    "fault_details": None,
                    "maintenance_window": None,
                    "enrichment_error": str(e)
                })

        return enriched

    async def _enrich_with_engineer_data(
        self,
        vector_results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Enrich vector search results with engineer/user information

        Args:
            vector_results: Results from vector search

        Returns:
            Enriched results with engineer details
        """
        enriched = []

        for result in vector_results:
            ticket_id = result["fault_description_id"]

            try:
                # Cypher query to get engineer/user information
                # Updated to match current schema - engineers stored as properties on Ticket
                cypher = """
                MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: $ticket_id})
                OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
                RETURN
                    t.ticket_id as ticket_id,
                    t.ticket_status as status,
                    t.priority as priority,
                    t.assigned_to as assigned_to,
                    t.created_by as created_by,
                    t.closed_by as closed_by,
                    t.first_assigned_to as first_assigned_to,
                    f.short_description as fault_description
                """

                graph_data = await self.memgraph_client.execute(cypher, params={"ticket_id": ticket_id})

                if graph_data and len(graph_data) > 0:
                    row = graph_data[0]

                    enriched_result = {
                        **result,
                        "ticket_details": {
                            "ticket_id": row.get("ticket_id"),
                            "status": row.get("status"),
                            "priority": row.get("priority")
                        },
                        "fault_details": {
                            "short_description": row.get("fault_description")
                        },
                        "team": {
                            "assigned_to": row.get("assigned_to"),
                            "created_by": row.get("created_by"),
                            "closed_by": row.get("closed_by"),
                            "first_assigned_to": row.get("first_assigned_to")
                        }
                    }

                    enriched.append(enriched_result)
                else:
                    logging.warning(f"No graph data found for ticket {ticket_id}")
                    enriched.append({
                        **result,
                        "ticket_details": None,
                        "fault_details": None,
                        "team": None
                    })

            except Exception as e:
                logging.error(f"Failed to enrich ticket {ticket_id} with engineer data: {e}")
                enriched.append({
                    **result,
                    "ticket_details": None,
                    "fault_details": None,
                    "team": None,
                    "enrichment_error": str(e)
                })

        return enriched

    async def _enrich_with_vendor_data(
        self,
        vector_results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Enrich vector search results with vendor information

        Args:
            vector_results: Results from vector search

        Returns:
            Enriched results with vendor details
        """
        enriched = []

        for result in vector_results:
            ticket_id = result["fault_description_id"]

            try:
                # Cypher query to get vendor information
                # Updated to match current schema from batch_graph_loader.py
                cypher = """
                MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: $ticket_id})
                OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
                OPTIONAL MATCH (t)-[:INVOLVES_VENDOR]->(v:VendorInfo)
                RETURN
                    t.ticket_id as ticket_id,
                    t.ticket_status as status,
                    t.priority as priority,
                    f.short_description as fault_description,
                    collect(distinct {
                        vendor_name: v.vendor,
                        vendor_downtime: v.vendor_downtime
                    }) as vendors
                """

                graph_data = await self.memgraph_client.execute(cypher, params={"ticket_id": ticket_id})

                if graph_data and len(graph_data) > 0:
                    row = graph_data[0]
                    vendors = row.get("vendors", [])
                    # Filter out empty vendor objects
                    vendors = [v for v in vendors if v.get("vendor_name")]

                    enriched_result = {
                        **result,
                        "ticket_details": {
                            "ticket_id": row.get("ticket_id"),
                            "status": row.get("status"),
                            "priority": row.get("priority")
                        },
                        "fault_details": {
                            "short_description": row.get("fault_description")
                        },
                        "vendor_involvement": {
                            "total_vendors": len(vendors),
                            "vendors": vendors
                        }
                    }

                    enriched.append(enriched_result)
                else:
                    logging.warning(f"No graph data found for ticket {ticket_id}")
                    enriched.append({
                        **result,
                        "ticket_details": None,
                        "fault_details": None,
                        "vendor_involvement": None
                    })

            except Exception as e:
                logging.error(f"Failed to enrich ticket {ticket_id} with vendor data: {e}")
                enriched.append({
                    **result,
                    "ticket_details": None,
                    "fault_details": None,
                    "vendor_involvement": None,
                    "enrichment_error": str(e)
                })

        return enriched

    async def _enrich_with_client_data(
        self,
        vector_results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Enrich vector search results with client impact information

        Args:
            vector_results: Results from vector search

        Returns:
            Enriched results with client details
        """
        enriched = []

        for result in vector_results:
            ticket_id = result["fault_description_id"]

            try:
                # Cypher query to get client information
                # Updated to match current schema from batch_graph_loader.py
                cypher = """
                MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: $ticket_id})
                OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
                OPTIONAL MATCH (t)-[:HAS_SURVEY]->(survey:SurveyInfo)
                RETURN
                    t.ticket_id as ticket_id,
                    t.ticket_status as status,
                    t.priority as priority,
                    t.created_on as created_date,
                    t.closed_on as closed_date,
                    f.short_description as fault_description,
                    f.is_customer_impacting as is_customer_impacting,
                    c.client_name as client_name,
                    survey.survey_score as survey_score,
                    survey.score_reason as score_reason
                """

                graph_data = await self.memgraph_client.execute(cypher, params={"ticket_id": ticket_id})

                if graph_data and len(graph_data) > 0:
                    row = graph_data[0]

                    # Build survey object if data exists
                    survey = None
                    if row.get("survey_score") is not None:
                        survey = {
                            "score": row.get("survey_score"),
                            "reason": row.get("score_reason")
                        }

                    enriched_result = {
                        **result,
                        "ticket_details": {
                            "ticket_id": row.get("ticket_id"),
                            "status": row.get("status"),
                            "priority": row.get("priority"),
                            "created_date": str(row.get("created_date")) if row.get("created_date") else None,
                            "closed_date": str(row.get("closed_date")) if row.get("closed_date") else None
                        },
                        "fault_details": {
                            "short_description": row.get("fault_description"),
                            "is_customer_impacting": row.get("is_customer_impacting")
                        },
                        "client_impact": {
                            "client_name": row.get("client_name"),
                            "customer_satisfaction": survey
                        }
                    }

                    enriched.append(enriched_result)
                else:
                    logging.warning(f"No graph data found for ticket {ticket_id}")
                    enriched.append({
                        **result,
                        "ticket_details": None,
                        "fault_details": None,
                        "client_impact": None
                    })

            except Exception as e:
                logging.error(f"Failed to enrich ticket {ticket_id} with client data: {e}")
                enriched.append({
                    **result,
                    "ticket_details": None,
                    "fault_details": None,
                    "client_impact": None,
                    "enrichment_error": str(e)
                })

        return enriched

    async def connect(self):
        """Connect to all required services (Milvus, Memgraph, Ollama)"""
        logging.info("Connecting to services...")

        # Connect to Milvus
        try:
            self.milvus_client.connect()
            logging.info("✅ Connected to Milvus")
        except Exception as e:
            logging.error(f"❌ Failed to connect to Milvus at {self.config.milvus_host}:{self.config.milvus_port}")
            logging.error(f"   Error: {e}")
            raise ConnectionError(f"Cannot connect to Milvus: {e}")

        # Connect to Memgraph
        try:
            await self.memgraph_client.connect()
            logging.info("✅ Connected to Memgraph")
        except Exception as e:
            logging.error(f"❌ Failed to connect to Memgraph at {self.config.memgraph_uri}")
            logging.error(f"   Error: {e}")
            raise ConnectionError(f"Cannot connect to Memgraph: {e}")

        # Test Ollama connection with detailed error info
        logging.info(f"Testing Ollama connection: {self.config.ollama_embedding_base_url}")
        if not self.embedding_service.test_connection():
            logging.error("❌ Ollama connection test failed")
            logging.error(f"   URL: {self.config.ollama_embedding_base_url}")
            logging.error(f"   Model: {self.config.ollama_embedding_model}")
            logging.error("   Troubleshooting:")
            logging.error("   1. Check if Ollama service is running")
            logging.error("   2. Verify OLLAMA_EMBEDDING_BASE_URL environment variable")
            logging.error("   3. Test manually: curl http://YOUR_OLLAMA_URL/api/tags")
            raise ConnectionError(
                f"Cannot connect to Ollama embedding service at {self.config.ollama_embedding_base_url}. "
                f"Check OLLAMA_EMBEDDING_BASE_URL environment variable."
            )

        logging.info("✅ Connected to Ollama")

    def disconnect(self):
        """Disconnect from services"""
        logging.info("Disconnecting from services...")
        self.milvus_client.disconnect()
        self.memgraph_client.close()
        logging.info("✅ Disconnected from all services")
