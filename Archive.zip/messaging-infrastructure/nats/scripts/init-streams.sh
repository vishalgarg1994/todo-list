#!/bin/bash

# Eva Group Messaging Infrastructure - Stream Initialization
# This script initializes NATS streams for Eva group applications

set -e

# Configuration
NATS_URL="${NATS_URL:-nats://localhost:4222}"
NATS_PUBLISHER_USER="${NATS_PUBLISHER_USER:-ticket-app}"
NATS_PUBLISHER_PASSWORD="${NATS_PUBLISHER_PASSWORD:-changeme-publisher}"

# JetStream Configuration (Environment-specific)
JETSTREAM_MAX_MSGS="${JETSTREAM_MAX_MSGS:-100000}"
JETSTREAM_MAX_BYTES="${JETSTREAM_MAX_BYTES:-104857600}"  # Default: 100MB
JETSTREAM_MAX_AGE="${JETSTREAM_MAX_AGE:-72h}"
JETSTREAM_RETENTION="${JETSTREAM_RETENTION:-workqueue}"

echo "🚀 Initializing Eva Group Messaging Infrastructure streams..."
echo "📡 NATS URL: $NATS_URL"
echo "⚙️  JetStream Config:"
echo "   📊 Max Messages: $JETSTREAM_MAX_MSGS"
echo "   💾 Max Storage: $JETSTREAM_MAX_BYTES"
echo "   ⏳ Max Age: $JETSTREAM_MAX_AGE"
echo "   📝 Retention: $JETSTREAM_RETENTION"
echo ""

# Function to create a stream
create_stream() {
    local stream_name="$1"
    local subjects="$2"
    local description="$3"
    local retention="${4:-$JETSTREAM_RETENTION}"
    local max_age="${5:-$JETSTREAM_MAX_AGE}"
    local max_msgs="${6:-$JETSTREAM_MAX_MSGS}"
    local max_bytes="${7:-$JETSTREAM_MAX_BYTES}"
    
    echo "🏗️  Creating stream: $stream_name"
    echo "   📋 Description: $description"
    echo "   📨 Subjects: $subjects"
    
    nats --server="$NATS_URL" \
         --user="$NATS_PUBLISHER_USER" \
         --password="$NATS_PUBLISHER_PASSWORD" \
         stream add "$stream_name" \
         --subjects="$subjects" \
         --retention="$retention" \
         --storage=file \
         --max-msgs="$max_msgs" \
         --max-bytes="$max_bytes" \
         --max-age="$max_age" \
         --replicas=1 \
         --description="$description"
    
    echo "✅ Stream $stream_name created successfully"
    echo ""
}

# Check NATS connectivity
echo "🔍 Checking NATS connectivity..."
nats --server="$NATS_URL" \
     --user="$NATS_PUBLISHER_USER" \
     --password="$NATS_PUBLISHER_PASSWORD" \
     server ping

echo "✅ NATS connection successful"
echo ""

# Initialize Domain-Based Messaging Streams

# 1. Eva Ticketing System Stream
create_stream "EVA_TICKETING_STREAM" \
    "tickets.*,incidents.*,maintenance.*" \
    "Eva Group Ticketing - tickets, incidents, and maintenance events"

# 2. Eva Analytics Stream (with custom settings)
create_stream "EVA_ANALYTICS_STREAM" \
    "analytics.*,metrics.*,reports.*" \
    "Eva Group Analytics - metrics, reports, and business intelligence" \
    "limits" "30d" "1000000" "1073741824"


# Summary
echo "📊 Stream initialization completed!"
echo ""
echo "🎯 Created Streams:"
nats --server="$NATS_URL" \
     --user="$NATS_PUBLISHER_USER" \
     --password="$NATS_PUBLISHER_PASSWORD" \
     stream list

echo ""
echo "🔧 Stream Details:"
for stream in "EVA_TICKETING_STREAM" "EVA_ANALYTICS_STREAM"; do
    echo "📋 $stream:"
    nats --server="$NATS_URL" \
         --user="$NATS_PUBLISHER_USER" \
         --password="$NATS_PUBLISHER_PASSWORD" \
         stream info "$stream" --json | jq -r '.config | "   Subjects: \(.subjects | join(", "))"'
done

echo ""
echo "🎉 Eva Group Messaging Infrastructure is ready!"
echo ""
echo "🔗 Connection Details:"
echo "   NATS URL: $NATS_URL"
echo "   Monitoring: http://localhost:8222"
echo "   Network: eva-messaging"
echo ""
echo "📚 Next Steps:"
echo "1. Configure your Eva group applications with NATS_URL=$NATS_URL"
echo "2. Use appropriate subjects for your messages (ticketing.*, analytics.*, etc.)"
echo "3. Monitor streams via the web UI at http://localhost:8222"