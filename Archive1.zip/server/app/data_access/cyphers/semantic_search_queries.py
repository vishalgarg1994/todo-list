"""
Cypher queries for semantic search enrichment
Used by SemanticSearchService to enrich vector search results with Memgraph data

Updated to match current schema from batch_graph_loader.py:
- Ticket nodes with ticket_id property
- Fault nodes via [:HAS_FAULT] relationship
- Service nodes via [:HAS_SERVICE] relationship
- Outage_Info nodes via [:HAS_OUTAGE] relationship
- Client nodes via [:HAS_TICKET] relationship
"""

# Query to get basic ticket and fault metadata
GET_TICKET_METADATA = """
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: $ticket_id})
OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
RETURN
    t.ticket_id as ticket_id,
    t.ticket_status as status,
    t.priority as priority,
    c.client_name as client_name,
    t.created_on as created_date,
    t.closed_on as closed_date,
    t.assigned_to as assigned_to,
    f.short_description as fault_description,
    f.ticket_rfo_group as problem_type,
    f.is_customer_impacting as is_customer_impacting
"""

# Query to get full resolution details including Outage_Info
GET_RESOLUTION_DATA = """
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: $ticket_id})
OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
RETURN
    t.ticket_id as ticket_id,
    t.ticket_status as status,
    t.priority as priority,
    c.client_name as client_name,
    t.created_on as created_date,
    t.closed_on as closed_date,
    t.assigned_to as assigned_to,
    f.short_description as fault_description,
    f.ticket_rfo_group as problem_type,
    f.is_customer_impacting as is_customer_impacting,
    o.rfo as rfo,
    o.mttr as mttr,
    o.outage_duration as outage_duration
"""

# Batch query to get ticket metadata for multiple tickets (optimization)
BATCH_GET_TICKET_METADATA = """
UNWIND $ticket_ids as tid
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: tid})
OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
RETURN
    tid as ticket_id,
    t.ticket_status as status,
    t.priority as priority,
    c.client_name as client_name,
    t.assigned_to as assigned_to,
    f.short_description as fault_description,
    f.is_customer_impacting as is_customer_impacting
"""

# Query to get full ticket context with services and vendors
GET_FULL_TICKET_CONTEXT = """
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: $ticket_id})
OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
OPTIONAL MATCH (t)-[:HAS_SERVICE]->(s:Service)
OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
OPTIONAL MATCH (t)-[:INVOLVES_VENDOR]->(v:VendorInfo)
OPTIONAL MATCH (t)-[:DURING_MAINTENANCE]->(mw:MaintenanceWindow)
OPTIONAL MATCH (t)-[:HAS_SURVEY]->(survey:SurveyInfo)
RETURN
    c, t, f, s, o,
    collect(DISTINCT v) as vendors,
    collect(DISTINCT mw) as maintenance_windows,
    survey
"""
