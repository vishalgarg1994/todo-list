#!/usr/bin/env python3
"""
Check Milvus collection count
"""
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent / "app"))

from configs.config import Config
from data_access.milvusClient import MilvusClient

def check_count():
    """Check how many embeddings are in Milvus"""
    config = Config()

    client = MilvusClient(
        host=config.milvus_host,
        port=config.milvus_port,
        collection_name=config.milvus_collection_name
    )

    try:
        client.connect()
        print(f"✅ Connected to Milvus")

        # Get collection stats
        stats = client.collection.num_entities
        print(f"\n📊 Collection: {config.milvus_collection_name}")
        print(f"   Total entities: {stats}")

        client.disconnect()

    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    check_count()
