#!/usr/bin/env python3
"""
Simple TSM Test - Tests the TSM schema directly against Memgraph
Only requires neo4j driver (pip3 install neo4j)
"""

import json
import sys
from pathlib import Path

try:
    from neo4j import GraphDatabase
except ImportError:
    print("Please install neo4j: pip3 install neo4j --user")
    sys.exit(1)


class SimpleTSMTest:
    """Simple test using neo4j driver directly"""

    def __init__(self, uri="bolt://localhost:7687"):
        self.driver = GraphDatabase.driver(uri)
        self.test_data = None

    def close(self):
        self.driver.close()

    def load_test_data(self):
        """Load TSM test data"""
        test_file = Path(__file__).parent.parent / "data" / "tsm_ticket_payload.json"
        with open(test_file, 'r') as f:
            self.test_data = json.load(f)
        print(f"Loaded test data with {len(self.test_data.get('operational_status', []))} tickets")

    def clear_database(self):
        """Clear all nodes and relationships"""
        with self.driver.session() as session:
            session.run("MATCH (n) DETACH DELETE n")
        print("Database cleared")

    def create_client_node(self):
        """Create Client node from test data"""
        client_info = self.test_data.get("client_info", {})
        with self.driver.session() as session:
            session.run("""
                MERGE (c:Client {cl_id: $cl_id})
                SET c.client_id = $client_id,
                    c.client_name = $client_name,
                    c.client_group = $client_group,
                    c.client_tier = $client_tier,
                    c.channel = $channel,
                    c.sales_division = $sales_division,
                    c.market_segment = $market_segment
            """, **client_info)
        print(f"Created Client: {client_info.get('client_name')}")

    def create_ticket_nodes(self):
        """Create Ticket nodes with ticket_type property"""
        for op_status in self.test_data.get("operational_status", []):
            ticket_info = op_status.get("ticket_info", {})
            ticket_type = op_status.get("ticket_type", "unknown")
            ticket_sys_id = op_status.get("ticket_sys_id")

            with self.driver.session() as session:
                session.run(
                    """
                    MERGE (t:Ticket {tkt_id: $tkt_id})
                    SET t.ticket_id = $ticket_id,
                        t.ticket_type = $ticket_type,
                        t.ticket_sys_id = $ticket_sys_id,
                        t.ticket_status = $ticket_status,
                        t.ticket_category = $ticket_category,
                        t.priority = $priority,
                        t.created_on = $created_on,
                        t.created_by = $created_by
                    """,
                    tkt_id=ticket_info.get("tkt_id"),
                    ticket_id=ticket_info.get("ticket_id"),
                    ticket_type=ticket_type,
                    ticket_sys_id=ticket_sys_id,
                    ticket_status=ticket_info.get("ticket_status"),
                    ticket_category=ticket_info.get("ticket_category"),
                    priority=ticket_info.get("priority"),
                    created_on=ticket_info.get("created_on"),
                    created_by=ticket_info.get("created_by"),
                )
            print(f"Created Ticket: {ticket_info.get('ticket_id')} (type: {ticket_type})")

    def create_fault_nodes(self):
        """Create Fault nodes (renamed from Incident)"""
        for op_status in self.test_data.get("operational_status", []):
            fault_info = op_status.get("fault_info", {})
            ticket_sys_id = op_status.get("ticket_sys_id")

            if not fault_info.get("fault_description_ref"):
                continue

            fault_id = f"fault_{ticket_sys_id}"
            with self.driver.session() as session:
                session.run(
                    """
                    MERGE (f:Fault {fault_id: $fault_id})
                    SET f.fault_description_ref = $fault_description_ref,
                        f.fault_description = $fault_description,
                        f.short_description = $short_description,
                        f.fault_occured_date = $fault_occured_date,
                        f.is_customer_impacting = $is_customer_impacting,
                        f.rfo = $rfo,
                        f.ticket_rfo_group = $ticket_rfo_group
                    """,
                    fault_id=fault_id,
                    fault_description_ref=fault_info.get("fault_description_ref"),
                    fault_description=fault_info.get("fault_description"),
                    short_description=fault_info.get("short_description"),
                    fault_occured_date=fault_info.get("fault_occured_date"),
                    is_customer_impacting=fault_info.get("is_customer_impacting", False),
                    rfo=fault_info.get("rfo"),
                    ticket_rfo_group=fault_info.get("ticket_rfo_group"),
                )
            print(f"Created Fault: {fault_id}")

    def create_service_nodes(self):
        """Create Service nodes"""
        for op_status in self.test_data.get("operational_status", []):
            service = op_status.get("service_entity", {})

            if not service.get("svc_id"):
                continue

            with self.driver.session() as session:
                session.run(
                    """
                    MERGE (s:Service {svc_id: $svc_id})
                    SET s.subcategory = $subcategory,
                        s.technology = $technology
                    """,
                    svc_id=service.get("svc_id"),
                    subcategory=service.get("subcategory"),
                    technology=service.get("technology"),
                )
            print(f"Created Service: {service.get('svc_id')}")

    def create_outage_nodes(self):
        """Create Outage_Info nodes"""
        for op_status in self.test_data.get("operational_status", []):
            outage = op_status.get("outage_info", {})

            if not outage.get("oi_id"):
                continue

            with self.driver.session() as session:
                session.run(
                    """
                    MERGE (o:Outage_Info {oi_id: $oi_id})
                    SET o.resolution = $resolution,
                        o.customer_resolution = $customer_resolution,
                        o.rfo = $rfo,
                        o.mttr = $mttr,
                        o.is_worked_ticket = $is_worked_ticket
                    """,
                    oi_id=outage.get("oi_id"),
                    resolution=outage.get("resolution"),
                    customer_resolution=outage.get("customer_resolution"),
                    rfo=outage.get("rfo"),
                    mttr=outage.get("mttr"),
                    is_worked_ticket=outage.get("is_worked_ticket", False),
                )
            print(f"Created Outage: {outage.get('oi_id')}")

    def create_task_nodes(self):
        """Create Task nodes"""
        for op_status in self.test_data.get("operational_status", []):
            tasks = op_status.get("tasks", [])

            for task in tasks:
                if not task.get("task_sys_id"):
                    continue

                with self.driver.session() as session:
                    session.run(
                        """
                        MERGE (t:Task {task_sys_id: $task_sys_id})
                        SET t.task_number = $task_number,
                            t.task_state = $task_state,
                            t.task_type = $task_type,
                            t.short_description = $short_description,
                            t.priority = $priority,
                            t.assigned_to = $assigned_to,
                            t.assignment_group = $assignment_group
                        """,
                        task_sys_id=task.get("task_sys_id"),
                        task_number=task.get("task_number"),
                        task_state=task.get("task_state"),
                        task_type=task.get("task_type"),
                        short_description=task.get("short_description"),
                        priority=task.get("priority"),
                        assigned_to=task.get("assigned_to"),
                        assignment_group=task.get("assignment_group"),
                    )
                print(f"Created Task: {task.get('task_number')}")

    def create_relationships(self):
        """Create all relationships"""
        client_id = self.test_data.get("client_info", {}).get("cl_id")

        for op_status in self.test_data.get("operational_status", []):
            ticket_info = op_status.get("ticket_info", {})
            tkt_id = ticket_info.get("tkt_id")
            ticket_sys_id = op_status.get("ticket_sys_id")
            service = op_status.get("service_entity", {})
            outage = op_status.get("outage_info", {})

            with self.driver.session() as session:
                # HAS_TICKET: Client -> Ticket
                session.run("""
                    MATCH (c:Client {cl_id: $cl_id}), (t:Ticket {tkt_id: $tkt_id})
                    MERGE (c)-[:HAS_TICKET]->(t)
                """, cl_id=client_id, tkt_id=tkt_id)

                # HAS_FAULT: Ticket -> Fault
                fault_id = f"fault_{ticket_sys_id}"
                session.run("""
                    MATCH (t:Ticket {tkt_id: $tkt_id}), (f:Fault {fault_id: $fault_id})
                    MERGE (t)-[:HAS_FAULT]->(f)
                """, tkt_id=tkt_id, fault_id=fault_id)

                # HAS_SERVICE: Ticket -> Service
                if service.get("svc_id"):
                    session.run("""
                        MATCH (t:Ticket {tkt_id: $tkt_id}), (s:Service {svc_id: $svc_id})
                        MERGE (t)-[:HAS_SERVICE]->(s)
                    """, tkt_id=tkt_id, svc_id=service.get("svc_id"))

                # HAS_OUTAGE: Ticket -> Outage_Info
                if outage.get("oi_id"):
                    session.run("""
                        MATCH (t:Ticket {tkt_id: $tkt_id}), (o:Outage_Info {oi_id: $oi_id})
                        MERGE (t)-[:HAS_OUTAGE]->(o)
                    """, tkt_id=tkt_id, oi_id=outage.get("oi_id"))

                # HAS_TASK: Ticket -> Task
                for task in op_status.get("tasks", []):
                    if task.get("task_sys_id"):
                        session.run("""
                            MATCH (t:Ticket {tkt_id: $tkt_id}), (task:Task {task_sys_id: $task_sys_id})
                            MERGE (t)-[:HAS_TASK]->(task)
                        """, tkt_id=tkt_id, task_sys_id=task.get("task_sys_id"))

        print("Created core relationships")

    def create_fk_relationships(self):
        """Create FK relationships between ticket types"""
        for op_status in self.test_data.get("operational_status", []):
            ticket_type = op_status.get("ticket_type")
            ticket_info = op_status.get("ticket_info", {})
            tkt_id = ticket_info.get("tkt_id")

            with self.driver.session() as session:
                # Case -> Incident (RAISED_BY_INCIDENT)
                if ticket_type == "case":
                    case_fields = op_status.get("case_fields", {})
                    inc_sys_id = case_fields.get("incident_sys_id")
                    if inc_sys_id:
                        session.run("""
                            MATCH (c:Ticket {tkt_id: $case_id}), (i:Ticket {ticket_sys_id: $inc_sys_id})
                            MERGE (c)-[:RAISED_BY_INCIDENT]->(i)
                        """, case_id=tkt_id, inc_sys_id=inc_sys_id)
                        print(f"Created RAISED_BY_INCIDENT: {tkt_id} -> {inc_sys_id}")

                # Request -> Case (BELONGS_TO_CASE)
                if ticket_type == "request":
                    req_fields = op_status.get("request_fields", {})
                    case_sys_id = req_fields.get("case_sys_id")
                    if case_sys_id:
                        session.run("""
                            MATCH (r:Ticket {tkt_id: $req_id}), (c:Ticket {ticket_sys_id: $case_sys_id})
                            MERGE (r)-[:BELONGS_TO_CASE]->(c)
                        """, req_id=tkt_id, case_sys_id=case_sys_id)
                        print(f"Created BELONGS_TO_CASE: {tkt_id} -> {case_sys_id}")

                # Incident -> Problem (RELATED_TO_PROBLEM)
                if ticket_type == "incident":
                    inc_fields = op_status.get("incident_fields", {})
                    prob_sys_id = inc_fields.get("related_problem_sys_id")
                    if prob_sys_id:
                        session.run("""
                            MATCH (i:Ticket {tkt_id: $inc_id}), (p:Ticket {ticket_sys_id: $prob_sys_id})
                            MERGE (i)-[:RELATED_TO_PROBLEM]->(p)
                        """, inc_id=tkt_id, prob_sys_id=prob_sys_id)
                        print(f"Created RELATED_TO_PROBLEM: {tkt_id} -> {prob_sys_id}")

    def validate_results(self):
        """Validate the graph was created correctly"""
        print("\n--- VALIDATION ---")

        with self.driver.session() as session:
            # Node counts
            result = session.run("MATCH (n) RETURN labels(n) AS label, count(*) AS cnt ORDER BY cnt DESC")
            print("\nNode counts:")
            for record in result:
                print(f"  {record['label']}: {record['cnt']}")

            # Relationship counts
            result = session.run("MATCH ()-[r]->() RETURN type(r) AS rel, count(*) AS cnt ORDER BY cnt DESC")
            print("\nRelationship counts:")
            for record in result:
                print(f"  {record['rel']}: {record['cnt']}")

            # Ticket types
            result = session.run("MATCH (t:Ticket) RETURN t.ticket_type AS type, count(*) AS cnt")
            print("\nTicket types:")
            for record in result:
                print(f"  {record['type']}: {record['cnt']}")

            # FK relationships
            print("\nFK relationships:")
            for rel_type in ['RAISED_BY_INCIDENT', 'BELONGS_TO_CASE', 'RELATED_TO_PROBLEM']:
                result = session.run(f"MATCH ()-[r:{rel_type}]->() RETURN count(r) AS cnt")
                cnt = result.single()['cnt']
                print(f"  {rel_type}: {cnt}")

    def run_tests(self):
        """Run all tests"""
        print("=" * 60)
        print("TSM SIMPLE TEST")
        print("=" * 60)

        try:
            self.load_test_data()
            self.clear_database()

            print("\n--- CREATING NODES ---")
            self.create_client_node()
            self.create_ticket_nodes()
            self.create_fault_nodes()
            self.create_service_nodes()
            self.create_outage_nodes()
            self.create_task_nodes()

            print("\n--- CREATING RELATIONSHIPS ---")
            self.create_relationships()
            self.create_fk_relationships()

            self.validate_results()

            print("\n" + "=" * 60)
            print("TEST COMPLETED SUCCESSFULLY")
            print("=" * 60)
            return True

        except Exception as e:
            print(f"\nTEST FAILED: {e}")
            import traceback
            traceback.print_exc()
            return False
        finally:
            self.close()


def main():
    test = SimpleTSMTest()
    success = test.run_tests()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
