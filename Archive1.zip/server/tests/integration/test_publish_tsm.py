#!/usr/bin/env python3
"""
Publish TSM test data to NATS for E2E testing
"""

import os
import json
import gzip
import base64
import asyncio
from pathlib import Path

import nats


async def publish_test_data():
    """Publish TSM test data to NATS"""
    print("=" * 60)
    print("PUBLISH TSM TEST DATA")
    print("=" * 60)

    # Load test data
    test_file = Path(__file__).parent.parent / "data" / "tsm_ticket_payload.json"
    with open(test_file, 'r') as f:
        test_data = json.load(f)
    print(f"Loaded test data: {test_file}")

    # Compress the data (same as ticketing_etl does)
    json_str = json.dumps(test_data)
    compressed = gzip.compress(json_str.encode('utf-8'))
    b64_data = base64.b64encode(compressed).decode('utf-8')

    message = {
        "compressed": True,
        "encoding": "gzip+base64",
        "data": b64_data
    }
    payload = json.dumps(message).encode('utf-8')
    print(f"Compressed payload size: {len(payload)} bytes")

    # Connect to NATS
    nats_url = os.environ.get("NATS_URL", "nats://localhost:4222")
    nats_user = os.environ.get("NATS_PUBLISHER_USER", "ticket-app")
    nats_pass = os.environ.get("NATS_PUBLISHER_PASSWORD", "changeme-publisher")

    nc = await nats.connect(nats_url, user=nats_user, password=nats_pass)
    js = nc.jetstream()
    print(f"Connected to NATS: {nats_url}")

    # Publish to stream
    subject = os.environ.get("TICKET_PUBLISH_SUBJECT", "tickets.created")

    try:
        ack = await js.publish(subject, payload)
        print(f"Published to {subject}")
        print(f"  Stream: {ack.stream}")
        print(f"  Sequence: {ack.seq}")
        print("SUCCESS: Test data published")
    except Exception as e:
        print(f"ERROR: Failed to publish: {e}")

    await nc.close()


def main():
    asyncio.run(publish_test_data())


if __name__ == "__main__":
    main()
