# Memgraph Knowledge Graph Query Examples
# Ticket System Analytics and Insights

## =========================
## LIFECYCLE QUERIES (via Ticket Properties)
## =========================

# Find all tickets assigned to a specific user
MATCH (t:Ticket)
WHERE t.assigned_to_id = "123"
RETURN t;

# Find all tickets closed by a specific user
MATCH (t:Ticket)
WHERE t.closed_by_id = "456"
RETURN t;

# Find all tickets created by a specific user
MATCH (t:Ticket)
WHERE t.created_by = "John Doe"
RETURN t;

# Find open tickets assigned to a user
MATCH (t:Ticket)
WHERE t.assigned_to_id = "123"
  AND t.ticket_status <> "Closed"
RETURN t;

# Find tickets a user closed in the last 30 days
MATCH (t:Ticket)
WHERE t.closed_by_id = "456"
  AND t.closed_on >= date_sub(current_date(), interval 30 day)
RETURN t;

## =========================
## TEAM/ROLE QUERIES (via UserInfo Relationships)
## =========================

# Find all tickets where a user was the incident manager
MATCH (t:Ticket)-[r:HAS_USER {role: "incident_manager"}]->(u:UserInfo {user_id: "123"})
RETURN t, u;

# Find all tickets where a user was the operations specialist
MATCH (t:Ticket)-[r:HAS_USER {role: "operations_specialist"}]->(u:UserInfo {user_id: "456"})
RETURN t, u;

# Find all tickets handled by specific service desk engineer (stored as property)
MATCH (t:Ticket)
WHERE t.service_desk_engineer = "John Smith"
RETURN t;

# Find all tickets escalated to specific tier 2 engineer (stored as property)
MATCH (t:Ticket)
WHERE t.tier2_engineer = "Jane Doe"
RETURN t;

# Get all team members who worked on a specific ticket
MATCH (t:Ticket {ticket_id: "INC123"})-[r:HAS_USER]->(u:UserInfo)
RETURN t.ticket_id, r.role as role, u.name, u.user_id;

# Find tickets assigned to a specific user (via relationship)
MATCH (t:Ticket)-[:HAS_USER {role: "assigned_to"}]->(u:UserInfo {user_id: "789"})
RETURN t.ticket_id, t.ticket_status, u.name;

# Find tickets closed by a specific user (via relationship)
MATCH (t:Ticket)-[:HAS_USER {role: "closed_by"}]->(u:UserInfo {user_id: "101"})
RETURN t.ticket_id, t.closed_on, u.name;

# Find users who worked on the most tickets as incident manager
MATCH (t:Ticket)-[:HAS_USER {role: "incident_manager"}]->(u:UserInfo)
RETURN u.name, u.user_id, count(t) as ticket_count
ORDER BY ticket_count DESC
LIMIT 10;

## =========================
## CLIENT & SERVICE QUERIES
## =========================

# Find all tickets for a specific client
MATCH (c:Client {client_name: "ACME Corp"})-[:HAS_TICKET]->(t:Ticket)
RETURN c, t;

# Find high priority tickets for a client
MATCH (c:Client {client_id: "789"})-[:HAS_TICKET]->(t:Ticket)
WHERE t.priority <= 2
RETURN c.client_name, t.ticket_id, t.priority, t.ticket_status;

# Find services impacted by incidents
MATCH (t:Ticket)-[:TRIGGERED_BY]->(i:Incident)-[:IMPACTS]->(s:Service)
RETURN t.ticket_id, i.short_description, s.subcategory, s.technology;

# Find customer-impacting incidents
MATCH (t:Ticket)-[:TRIGGERED_BY]->(i:Incident)
WHERE i.is_customer_impacting = true
RETURN t.ticket_id, i.short_description, t.created_on;

## =========================
## TICKET HIERARCHY QUERIES
## =========================

# Find all child tickets of a master ticket
MATCH (child:Ticket)-[:CHILD_OF]->(master:Ticket {ticket_id: "INC123"})
RETURN master.ticket_id, child.ticket_id, child.ticket_status;

# Find the master ticket for a child ticket
MATCH (child:Ticket {ticket_id: "INC456"})-[:CHILD_OF]->(master:Ticket)
RETURN child.ticket_id, master.ticket_id;

# Find all tickets linked to a specific ticket
MATCH (t1:Ticket {ticket_id: "INC123"})-[:LINKED_TO]->(t2:Ticket)
RETURN t1.ticket_id, t2.ticket_id, t2.ticket_category;

# Get full ticket hierarchy (master and all children)
MATCH (master:Ticket {ticket_id: "INC123"})
OPTIONAL MATCH (master)<-[:CHILD_OF]-(child:Ticket)
RETURN master, collect(child) as children;

# Count child tickets per master ticket
MATCH (master:Ticket)<-[:CHILD_OF]-(child:Ticket)
RETURN master.ticket_id, master.ticket_status, count(child) as child_count
ORDER BY child_count DESC;

## =========================
## OUTAGE & RESOLUTION QUERIES
## =========================

# Find tickets with outage information
MATCH (t:Ticket)-[:HAS_OUTAGE_INFO]->(o:Outage_Info)
WHERE o.outage_total > 0
RETURN t.ticket_id, o.outage_total, o.mttr, o.resolution;

# Find tickets with high MTTR (Mean Time To Repair)
MATCH (t:Ticket)-[:HAS_OUTAGE_INFO]->(o:Outage_Info)
WHERE o.mttr > 240  -- More than 4 hours
RETURN t.ticket_id, t.client_name, o.mttr, o.rfo
ORDER BY o.mttr DESC;

# Find tickets by RFO (Reason For Outage)
MATCH (t:Ticket)-[:HAS_OUTAGE_INFO]->(o:Outage_Info)
WHERE o.rfo = "Hardware Failure"
RETURN t.ticket_id, t.created_on, o.outage_duration;

## =========================
## VENDOR & CONTACT QUERIES
## =========================

# Find all tickets involving a specific vendor
MATCH (t:Ticket)-[:INVOLVES_VENDOR]->(v:VendorInfo {vendor: "AT&T"})
RETURN t.ticket_id, t.ticket_status, v.vendor_downtime;

# Find vendors with the most tickets
MATCH (t:Ticket)-[:INVOLVES_VENDOR]->(v:VendorInfo)
RETURN v.vendor, count(t) as ticket_count
ORDER BY ticket_count DESC;

# Find client contacts
MATCH (c:Client)-[:HAS_CONTACT]->(contact:ContactInfo)
RETURN c.client_name, contact.name, contact.email, contact.contact_type;

# Find tickets with specific contact involvement
MATCH (t:Ticket)-[:HAS_CONTACT]->(contact:ContactInfo {email: "john@example.com"})
RETURN t.ticket_id, t.ticket_status;

## =========================
## MAINTENANCE WINDOW QUERIES
## =========================

# Find tickets during maintenance windows
MATCH (t:Ticket)-[:DURING_MAINTENANCE]->(mw:MaintenanceWindow)
RETURN t.ticket_id, mw.pw_start, mw.pw_end, mw.pw_reason;

# Find maintenance windows in a date range
MATCH (t:Ticket)-[:DURING_MAINTENANCE]->(mw:MaintenanceWindow)
WHERE mw.pw_start >= "2025-09-01" AND mw.pw_end <= "2025-09-30"
RETURN t.ticket_id, mw.pw_start, mw.pw_location, mw.pw_reason;

# Find services with maintenance windows
MATCH (s:Service)-[:HAS_MAINTENANCE]->(mw:MaintenanceWindow)
RETURN s.subcategory, s.technology, mw.pw_start, mw.pw_duration;

## =========================
## SURVEY & CUSTOMER SATISFACTION
## =========================

# Find tickets with survey responses
MATCH (t:Ticket)-[:HAS_SURVEY]->(s:SurveyInfo)
RETURN t.ticket_id, s.survey_score, s.score_reason;

# Find low-rated tickets (poor customer satisfaction)
MATCH (t:Ticket)-[:HAS_SURVEY]->(s:SurveyInfo)
WHERE s.survey_score < 3
RETURN t.ticket_id, t.client_name, s.survey_score, s.score_reason
ORDER BY s.survey_score ASC;

# Average survey score by client
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)-[:HAS_SURVEY]->(s:SurveyInfo)
RETURN c.client_name, avg(s.survey_score) as avg_score, count(s) as survey_count
ORDER BY avg_score DESC;

## =========================
## NOC (Network Operations Center) QUERIES
## =========================

# Find all tickets for clients assigned to a specific NOC (NOC is Client-level property)
MATCH (c:Client {default_noc: "NOC_EMEA"})-[:HAS_TICKET]->(t:Ticket)
RETURN c.client_name, c.default_noc, c.default_noc_queue, t.ticket_id, t.ticket_status;

# Find all clients monitored by a specific NOC
MATCH (c:Client {default_noc: "NOC_AMER"})
RETURN c.client_name, c.default_noc, c.default_noc_queue, count{(c)-[:HAS_TICKET]->()} as ticket_count;

# Count tickets by NOC
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
RETURN c.default_noc, count(t) as ticket_count, collect(DISTINCT c.client_name) as clients
ORDER BY ticket_count DESC;

## =========================
## ANALYTICS & INSIGHTS
## =========================

# Ticket volume by status
MATCH (t:Ticket)
RETURN t.ticket_status, count(t) as count
ORDER BY count DESC;

# Ticket volume by priority
MATCH (t:Ticket)
RETURN t.priority, count(t) as count
ORDER BY t.priority;

# Average resolution time by priority
MATCH (t:Ticket)-[:HAS_OUTAGE_INFO]->(o:Outage_Info)
WHERE t.priority IS NOT NULL AND o.mttr IS NOT NULL
RETURN t.priority, avg(o.mttr) as avg_mttr
ORDER BY t.priority;

# Top 10 clients by ticket volume
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
RETURN c.client_name, count(t) as ticket_count
ORDER BY ticket_count DESC
LIMIT 10;

# Tickets by technology type
MATCH (t:Ticket)-[:TRIGGERED_BY]->(i:Incident)-[:IMPACTS]->(s:Service)
RETURN s.technology, count(t) as ticket_count
ORDER BY ticket_count DESC;

# Escalation patterns (tickets with tier2 involvement)
MATCH (t:Ticket)
WHERE t.tier2_engineer IS NOT NULL
RETURN t.ticket_escalation_level, count(t) as escalated_tickets
ORDER BY t.ticket_escalation_level;

## =========================
## TIME-BASED QUERIES
## =========================

# Tickets created in the last 7 days
MATCH (t:Ticket)
WHERE t.created_on >= date_sub(current_date(), interval 7 day)
RETURN t.ticket_id, t.created_on, t.ticket_status;

# Tickets resolved in the last 30 days
MATCH (t:Ticket)
WHERE t.first_resolved_on >= date_sub(current_date(), interval 30 day)
RETURN t.ticket_id, t.first_resolved_on, t.assigned_to;

# Long-running open tickets (older than 30 days)
MATCH (t:Ticket)
WHERE t.ticket_status <> "Closed"
  AND t.created_on <= date_sub(current_date(), interval 30 day)
RETURN t.ticket_id, t.created_on, t.assigned_to, t.ticket_status
ORDER BY t.created_on ASC;

## =========================
## COMBINED/COMPLEX QUERIES
## =========================

# Full ticket context (ticket + incident + service + outage + team)
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
MATCH (t)-[:TRIGGERED_BY]->(i:Incident)-[:IMPACTS]->(s:Service)
MATCH (t)-[:HAS_OUTAGE_INFO]->(o:Outage_Info)
OPTIONAL MATCH (t)-[r]->(u:UserInfo)
WHERE t.ticket_id = "INC123"
RETURN c.client_name, t.ticket_id, t.ticket_status,
       i.short_description, s.technology,
       o.mttr, o.rfo,
       collect({role: type(r), user: u.name}) as team;

# Client health dashboard (tickets, avg MTTR, survey scores)
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
OPTIONAL MATCH (t)-[:HAS_OUTAGE_INFO]->(o:Outage_Info)
OPTIONAL MATCH (t)-[:HAS_SURVEY]->(s:SurveyInfo)
RETURN c.client_name,
       count(t) as total_tickets,
       sum(CASE WHEN t.ticket_status = "Closed" THEN 1 ELSE 0 END) as closed_tickets,
       avg(o.mttr) as avg_mttr,
       avg(s.survey_score) as avg_survey_score
ORDER BY total_tickets DESC;

# Problem tickets (high priority, long MTTR, low survey score)
MATCH (t:Ticket)-[:HAS_OUTAGE_INFO]->(o:Outage_Info)
MATCH (t)-[:HAS_SURVEY]->(s:SurveyInfo)
WHERE t.priority <= 2 AND o.mttr > 240 AND s.survey_score < 3
RETURN t.ticket_id, t.priority, o.mttr, s.survey_score, t.assigned_to
ORDER BY o.mttr DESC;
