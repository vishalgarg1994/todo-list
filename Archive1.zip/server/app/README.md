# Enhanced MCP Ticket System

A production-ready ticket analytics system built with FastMCP, Memgraph Database, and NATS JetStream messaging.

## 🚀 Quick Start

### Environment-Based Deployment
Use the deployment script for different environments:

```bash
# Development (default)
./deploy.sh development up

# Staging
./deploy.sh staging up

# Production
./deploy.sh production up

# Other actions: down, restart, logs, status, health, build
./deploy.sh development logs
```

### Manual Docker Compose
```bash
# Development (default)
docker-compose up -d

# Staging
docker-compose -f docker-compose.staging.yml --env-file .env.staging up -d

# Production
docker-compose -f docker-compose.production.yml --env-file .env.production up -d
```

### Health Check
```bash
python system_health_check.py
```

## 📁 Project Structure

```
├── services/                  # Core business logic
│   ├── message_handler.py     # Ticket message processing
│   ├── ticket_loader.py       # Data ingestion orchestration
│   └── register_mcp_components.py
├── data_access/              # Data layer
│   ├── memgraphClient.py     # Graph database client
│   └── cyphers/              # Database schemas
├── tools/                    # FastMCP tools
│   └── tickets/              # Ticket query tools
├── utils/                    # Utilities and helpers
├── configs/                  # Configuration management
├── tests/                    # Test suites
│   ├── unit/                 # Unit tests
│   └── integration/          # Integration tests
├── k8s/                      # Kubernetes manifests
├── scripts/                  # Deployment scripts
└── docs/                     # Documentation
```

## 🎯 Key Features

- **Enterprise Graph Database**: TSM model with 11 node types, 15 relationships
  - Supports 4 ticket types: incident, case, problem, request
  - TSM FK relationships: RAISED_BY_INCIDENT, BELONGS_TO_CASE, RELATED_TO_PROBLEM
  - Task nodes for incident and problem tasks
- **FastMCP Integration**: Natural language ticket queries
- **NATS JetStream**: Reliable message processing with compression
- **Kubernetes Ready**: Production deployment with auto-scaling
- **Comprehensive Testing**: Unit and integration test suites
- **Health Monitoring**: Built-in health checks and observability

## 📚 Documentation

- **[System Status](../docs/guides/README_SYSTEM_STATUS.md)** - Architecture overview
- **[Deployment Guide](../docs/guides/DEPLOYMENT_GUIDE.md)** - Complete deployment instructions
- **[Docker & K8s Setup](../docs/guides/DOCKER_K8S_COMPLETE.md)** - Containerization guide
- **[Maturity Assessment](../docs/guides/MATURITY_ASSESSMENT.md)** - Production readiness analysis
- **[Cleanup Analysis](../docs/guides/CLEANUP_ANALYSIS.md)** - Code optimization insights

## 🧪 Testing

```bash
# Run all tests
python -m pytest tests/ -v

# Run unit tests only
python -m pytest tests/unit/ -v

# Run integration tests
python -m pytest tests/integration/ -v

# Run health check
python system_health_check.py
```

## 🛠️ Development

### Prerequisites
- Python 3.13+
- Docker & Docker Compose
- NATS Server (for local development)

### Setup
```bash
# Install dependencies
pip install -r requirements.txt

# Start local services
docker-compose up -d nats

# Run the application
python main.py
```

## 🔧 Configuration

Configuration is managed through:
- `configs/config.py` - Main configuration
- Environment variables
- Docker/K8s ConfigMaps

## 📊 System Health

**Maturity Level**: Level 4 - Production Ready (86.5/100)

- ✅ Enterprise-grade deployment
- ✅ Comprehensive documentation
- ✅ Clean architecture
- ✅ Security best practices
- ✅ Auto-scaling capabilities

## 📈 Architecture

**Hybrid Architecture**:
- **Part 1** (✅ Complete): Knowledge Graph with Memgraph
- **Part 2** (🔄 Planned): Vector Database for fault descriptions

**Data Flow**:
```
ticket_etl → [gzip+base64] → NATS → Ticket Loader → Message Handler → Memgraph Graph DB
                                                                           ↑
User → FastMCP → Natural Language Queries ←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←
```

## 🎉 Status

**Production Ready** - Successfully deployed and tested in enterprise environments.

For detailed documentation, see the `../docs/` directory.