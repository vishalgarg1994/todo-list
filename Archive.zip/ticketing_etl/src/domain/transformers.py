"""
Ticket Transformer - UNION approach for CMD and TSM data

This transformer:
1. Processes ALL CMD records (CMD-only or CMD+TSM merged)
2. Processes TSM records that don't exist in CMD (TSM-only)
3. Builds TicketSummary with OperationalStatus
4. Groups by client_id

UNION approach:
- CMD can exist without TSM (core network tickets)
- TSM can exist without CMD
- When both exist, merge TSM entity-specific fields + CMD enrichment
"""

import logging
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime

from classes.data_model import (
    TicketSummary,
    ClientInfo,
    OperationalStatus,
    ServiceEntity,
    FaultInfo,
    TicketInfo,
    OutageInfo,
    UserInfo,
    MaintenanceWindow,
    VendorInfo,
    NOCInfo,
    SurveyInfo,
    FaultDescription,
    FaultDescriptionSummary,
    IncidentFields,
    CaseFields,
    ProblemFields,
    RequestFields,
    ConfigurationItem,
    # Task-specific models
    IncidentTaskInfo,
    CaseTaskInfo,
    ProblemTaskInfo,
    ChangeTaskInfo,
    # Change-related models
    ChangeFields,
    ChangeRecord,
    ChangeBatch,
    CHANGE_BATCH_SIZE,
)
from utils.data_sanitizer import sanitize_text_for_json


class TicketTransformer:
    """Transforms CMD and TSM data into TicketSummary messages using UNION approach"""

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def transform(
        self, extracted_data: Dict[str, Any]
    ) -> Tuple[List[str], List[str], int]:
        """
        Transform extracted data into TicketSummary JSON messages

        UNION approach:
        1. Process ALL CMD records (with TSM enrichment if available)
        2. Process TSM-only records (no CMD match)

        Args:
            extracted_data: Dict from Extractor.extract_all() containing:
                - cmd_records, cmd_by_sys_id
                - incidents, cases, problems, requests
                - incident_tasks, problem_tasks
                - tsm_by_sys_id

        Returns:
            Tuple of (ticket_messages, fault_description_messages, processed_count)
        """
        cmd_records = extracted_data.get("cmd_records", [])
        # _cmd_by_sys_id = extracted_data.get("cmd_by_sys_id", {})  # If needed
        tsm_by_sys_id = extracted_data.get("tsm_by_sys_id", {})
        incidents = extracted_data.get("incidents", [])
        cases = extracted_data.get("cases", [])
        problems = extracted_data.get("problems", [])
        requests = extracted_data.get("requests", [])
        incident_tasks = extracted_data.get("incident_tasks", [])
        case_tasks = extracted_data.get("case_tasks", [])
        problem_tasks = extracted_data.get("problem_tasks", [])
        ci_by_task_sys_id = extracted_data.get("ci_by_task_sys_id", {})
        case_tasks_by_case = extracted_data.get("case_tasks_by_case", {})

        # Index tasks by parent sys_id for fast lookup
        incident_tasks_by_parent = self._index_by_field(
            incident_tasks, "incident_sys_id"
        )
        problem_tasks_by_parent = self._index_by_field(problem_tasks, "problem_sys_id")
        # Use pre-indexed case_tasks_by_case if available, otherwise index
        if not case_tasks_by_case and case_tasks:
            case_tasks_by_case = self._index_by_field(case_tasks, "parent_case_sys_id")

        # Dictionary to store TicketSummary objects, keyed by client_id
        client_summaries: Dict[str, TicketSummary] = {}
        # Dictionary to store fault descriptions by client_id
        fault_descriptions_by_client: Dict[str, List[FaultDescription]] = {}
        # Track processed sys_ids to avoid duplicates
        processed_sys_ids: set = set()
        # Count processed tickets
        processed_count = 0

        # =====================================================================
        # STEP 1: Process ALL CMD records (with TSM enrichment if available)
        # =====================================================================
        for cmd in cmd_records:
            try:
                sys_id = cmd.get("servicenow_task_sys_id")
                client_id = cmd.get("client_id")
                ticket_id = cmd.get("ticket_id")

                if not client_id:
                    continue

                # Check if TSM data exists for this ticket
                tsm_match = tsm_by_sys_id.get(sys_id)

                # Get CIs for this ticket
                cis = ci_by_task_sys_id.get(sys_id, [])

                if tsm_match:
                    # MERGED: CMD + TSM
                    tsm_type = tsm_match["type"]
                    tsm_data = tsm_match["data"]

                    if tsm_type == "incident":
                        tasks = incident_tasks_by_parent.get(sys_id, [])
                        op_status = self._build_incident_operational_status(
                            tsm_data, cmd, tasks, cis
                        )
                    elif tsm_type == "case":
                        tasks = case_tasks_by_case.get(sys_id, [])
                        op_status = self._build_case_operational_status(
                            tsm_data, cmd, tasks, cis
                        )
                    elif tsm_type == "problem":
                        tasks = problem_tasks_by_parent.get(sys_id, [])
                        op_status = self._build_problem_operational_status(
                            tsm_data, cmd, tasks, cis
                        )
                    elif tsm_type == "request":
                        op_status = self._build_request_operational_status(
                            tsm_data, cmd, cis
                        )
                    else:
                        op_status = self._build_cmd_only_operational_status(cmd, cis)
                else:
                    # CMD-ONLY: No TSM match
                    op_status = self._build_cmd_only_operational_status(cmd, cis)

                self._add_to_client_summary(client_summaries, client_id, cmd, op_status)

                # Extract fault description from CMD
                self._extract_fault_description(
                    fault_descriptions_by_client, client_id, ticket_id, cmd
                )

                processed_sys_ids.add(sys_id)
                processed_count += 1

            except Exception as e:
                self.logger.error(
                    f"Error processing CMD record {cmd.get('ticket_id')}: {e}"
                )

        # =====================================================================
        # STEP 2: Process TSM-only records (no CMD match)
        # =====================================================================
        # Process incidents without CMD
        for inc in incidents:
            try:
                sys_id = inc.get("incident_sys_id")
                if sys_id in processed_sys_ids:
                    continue  # Already processed with CMD

                client_id = inc.get("client_id")
                if not client_id:
                    continue

                tasks = incident_tasks_by_parent.get(sys_id, [])
                cis = ci_by_task_sys_id.get(sys_id, [])
                op_status = self._build_incident_operational_status(inc, {}, tasks, cis)
                self._add_to_client_summary(client_summaries, client_id, inc, op_status)

                # Extract fault description from incident
                ticket_id = inc.get("incident_number")
                self._extract_fault_description(
                    fault_descriptions_by_client, client_id, ticket_id, inc
                )

                processed_sys_ids.add(sys_id)
                processed_count += 1
            except Exception as e:
                self.logger.error(
                    f"Error processing TSM-only incident {inc.get('incident_number')}: {e}"
                )

        # Process cases without CMD
        for case in cases:
            try:
                sys_id = case.get("case_sys_id")
                if sys_id in processed_sys_ids:
                    continue

                client_id = case.get("client_id")
                if not client_id:
                    continue

                tasks = case_tasks_by_case.get(sys_id, [])
                cis = ci_by_task_sys_id.get(sys_id, [])
                op_status = self._build_case_operational_status(case, {}, tasks, cis)
                self._add_to_client_summary(
                    client_summaries, client_id, case, op_status
                )

                # Extract fault description from case
                ticket_id = case.get("case_number")
                self._extract_fault_description(
                    fault_descriptions_by_client, client_id, ticket_id, case
                )

                processed_sys_ids.add(sys_id)
                processed_count += 1
            except Exception as e:
                self.logger.error(
                    f"Error processing TSM-only case {case.get('case_number')}: {e}"
                )

        # Process problems without CMD
        for prob in problems:
            try:
                sys_id = prob.get("problem_sys_id")
                if sys_id in processed_sys_ids:
                    continue

                client_id = prob.get("client_id")
                if not client_id:
                    continue

                tasks = problem_tasks_by_parent.get(sys_id, [])
                cis = ci_by_task_sys_id.get(sys_id, [])
                op_status = self._build_problem_operational_status(prob, {}, tasks, cis)
                self._add_to_client_summary(
                    client_summaries, client_id, prob, op_status
                )

                processed_sys_ids.add(sys_id)
                processed_count += 1
            except Exception as e:
                self.logger.error(
                    f"Error processing TSM-only problem {prob.get('problem_number')}: {e}"
                )

        # Process requests without CMD
        for req in requests:
            try:
                sys_id = req.get("req_task_sys_id")
                if sys_id in processed_sys_ids:
                    continue

                client_id = req.get("client_id")
                if not client_id:
                    continue

                cis = ci_by_task_sys_id.get(sys_id, [])
                op_status = self._build_request_operational_status(req, {}, cis)
                self._add_to_client_summary(client_summaries, client_id, req, op_status)

                processed_sys_ids.add(sys_id)
                processed_count += 1
            except Exception as e:
                self.logger.error(
                    f"Error processing TSM-only request {req.get('req_task_number')}: {e}"
                )

        # Convert to JSON
        ticket_messages = [
            summary.model_dump_json() for summary in client_summaries.values()
        ]
        fault_description_messages = self._group_fault_descriptions(
            fault_descriptions_by_client
        )

        self.logger.info(
            f"Transformed {processed_count} tickets into "
            f"{len(ticket_messages)} client summaries and "
            f"{len(fault_description_messages)} fault description summaries"
        )

        return ticket_messages, fault_description_messages, processed_count

    def _index_by_field(self, records: List[Dict], field: str) -> Dict[str, List[Dict]]:
        """Index records by a field value for fast lookup"""
        index = {}
        for record in records:
            key = record.get(field)
            if key:
                if key not in index:
                    index[key] = []
                index[key].append(record)
        return index

    def _add_to_client_summary(
        self,
        client_summaries: Dict[str, TicketSummary],
        client_id: str,
        record: Dict[str, Any],
        op_status: OperationalStatus,
    ):
        """Add operational status to client summary, creating if needed"""
        client_id_str = str(client_id)

        if client_id_str not in client_summaries:
            client_summaries[client_id_str] = TicketSummary(
                client_info=ClientInfo(
                    client_id=int(client_id) if client_id else None,
                    client_name=record.get("client_name")
                    or record.get("customer_name"),
                    client_group=record.get("customer_group"),
                ),
                operational_status=[op_status],
            )
        else:
            client_summaries[client_id_str].operational_status.append(op_status)

    # =========================================================================
    # Build OperationalStatus for each ticket type
    # =========================================================================

    def _build_incident_operational_status(
        self, inc: Dict, cmd: Dict, tasks: List[Dict], cis: List[Dict] = None
    ) -> OperationalStatus:
        """Build OperationalStatus for an incident"""

        return OperationalStatus(
            # TSM extension fields
            ticket_type="incident",
            ticket_sys_id=inc.get("incident_sys_id"),
            # Common nested objects
            service_entity=self._build_service_entity(inc, cmd),
            fault_info=self._build_fault_info(inc, cmd),
            ticket_info=self._build_ticket_info_from_incident(inc, cmd),
            outage_info=self._build_outage_info(cmd, inc),
            noc_info=self._build_noc_info(cmd),
            # Knowledge graph nodes from CMD
            users=self._build_users(cmd),
            maintenance_window=self._build_maintenance_window(cmd),
            contacts=None,  # Not in current data
            vendors=self._build_vendors(cmd),
            survey_info=self._build_survey_info(cmd),
            # Incident-specific fields
            incident_fields=IncidentFields(
                category=inc.get("category"),
                subcategory=inc.get("subcategory"),
                # Configuration Item
                ci_sys_id=inc.get("ci_sys_id"),
                ci_class=inc.get("ci_class"),
                ci_name=inc.get("ci_name"),
                circuit_id=str(inc.get("circuit_id"))
                if inc.get("circuit_id")
                else None,
                major_incident_state=inc.get("major_incident_state"),
                parent_incident_number=inc.get("parent_incident_number"),
                related_parent_incident_sys_id=inc.get(
                    "related_parent_incident_sys_id"
                ),
                related_parent_incident_number=inc.get(
                    "related_parent_incident_number"
                ),
                cause=inc.get("cause"),
                business_impact=inc.get("business_impact"),
                escalation_level=self._to_int(inc.get("escalation_level")),
                support_area=inc.get("support_area"),
                is_customer_impacted=self._to_bool(inc.get("is_customer_impacted")),
                is_stranded=self._to_bool(inc.get("is_stranded")),
                related_problem_sys_id=inc.get("related_problem_sys_id"),
                related_problem_number=inc.get("related_problem_number"),
                related_change_sys_id=inc.get("related_change_sys_id"),
                related_change_number=inc.get("related_change_number"),
                caused_by_change_sys_id=inc.get("caused_by_change_sys_id"),
                caused_by_change_number=inc.get("caused_by_change_number"),
                customer_close_notes=sanitize_text_for_json(
                    inc.get("customer_close_notes")
                ),
                internal_resolution_notes=sanitize_text_for_json(
                    inc.get("internal_resolution_note")
                ),
                # Resolution
                close_code=inc.get("close_code"),
                hold_reason=inc.get("hold_reason"),
                resolved_at=self._to_datetime(inc.get("resolved_at")),
                responsible_party=inc.get("responsible_party"),
            ),
            case_fields=None,
            problem_fields=None,
            request_fields=None,
            # Tasks
            tasks=self._build_incident_tasks(tasks) if tasks else None,
            # Configuration Items
            configuration_items=self._build_configuration_items(cis) if cis else None,
        )

    def _build_case_operational_status(
        self, case: Dict, cmd: Dict, tasks: List[Dict] = None, cis: List[Dict] = None
    ) -> OperationalStatus:
        """Build OperationalStatus for a case"""

        return OperationalStatus(
            ticket_type="case",
            ticket_sys_id=case.get("case_sys_id"),
            service_entity=self._build_service_entity(case, cmd),
            fault_info=self._build_fault_info(case, cmd),
            ticket_info=self._build_ticket_info_from_case(case, cmd),
            outage_info=self._build_outage_info(cmd, case),
            noc_info=self._build_noc_info(cmd),
            users=self._build_users(cmd),
            maintenance_window=self._build_maintenance_window(cmd),
            contacts=None,
            vendors=self._build_vendors(cmd),
            survey_info=self._build_survey_info(cmd),
            incident_fields=None,
            case_fields=CaseFields(
                category=case.get("category"),
                subcategory=case.get("subcategory"),
                # Configuration Item
                ci_sys_id=case.get("ci_sys_id"),
                ci_class=case.get("ci_class"),
                ci_name=case.get("ci_name"),
                circuit_id=str(case.get("circuit_id"))
                if case.get("circuit_id")
                else None,
                segment_id=case.get("segment_id"),
                related_circuit_id=case.get("related_circuit_id"),
                resolution_code=case.get("resolution_code"),
                contact_type=case.get("contact_type"),
                snow_release_name=case.get("snow_release_name"),
                case_type=case.get("case_type"),
                sub_state=case.get("sub_state"),
                needs_attention=self._to_bool(case.get("needs_attention")),
                is_customer_updated=self._to_bool(case.get("is_customer_updated")),
                first_response_time=self._to_datetime(case.get("first_response_time")),
                reassignment_count=self._to_int(case.get("reassignment_count")),
                escalation_number=self._to_int(case.get("escalation_number")),
                adjusted_business_elapsed_time=case.get(
                    "adjusted_business_elapsed_time"
                ),
                # FK fields for relationships
                incident_sys_id=case.get("incident_sys_id"),
                incident_number=case.get("incident_number"),
                problem_sys_id=case.get("problem_sys_id"),
                problem_number=case.get("problem_number"),
                caused_by_change_sys_id=case.get("caused_by_change_sys_id"),
                caused_by_change_number=case.get("caused_by_change_number"),
                parent_sys_id=case.get("parent_sys_id"),
                parent_number=case.get("parent_number"),
                contact_name=case.get("contact_name"),
                contact_sys_id=case.get("contact_sys_id"),
                # Resolution
                internal_resolution_notes=sanitize_text_for_json(
                    case.get("internal_resolution_notes")
                ),
                responsible_party=case.get("responsible_party"),
            ),
            problem_fields=None,
            request_fields=None,
            # Case tasks
            tasks=self._build_case_tasks(tasks) if tasks else None,
            # Configuration Items
            configuration_items=self._build_configuration_items(cis) if cis else None,
        )

    def _build_problem_operational_status(
        self, prob: Dict, cmd: Dict, tasks: List[Dict], cis: List[Dict] = None
    ) -> OperationalStatus:
        """Build OperationalStatus for a problem"""

        return OperationalStatus(
            ticket_type="problem",
            ticket_sys_id=prob.get("problem_sys_id"),
            service_entity=self._build_service_entity(prob, cmd),
            fault_info=self._build_fault_info(prob, cmd),
            ticket_info=self._build_ticket_info_from_problem(prob, cmd),
            outage_info=self._build_outage_info(cmd, prob),
            noc_info=self._build_noc_info(cmd),
            users=self._build_users(cmd),
            maintenance_window=self._build_maintenance_window(cmd),
            contacts=None,
            vendors=self._build_vendors(cmd),
            survey_info=self._build_survey_info(cmd),
            incident_fields=None,
            case_fields=None,
            problem_fields=ProblemFields(
                category=prob.get("category"),
                subcategory=prob.get("subcategory"),
                ci_class=prob.get("ci_class"),
                segment_id=prob.get("segment_id"),
                resolution_code=prob.get("resolution_code"),
                problem_source=prob.get("problem_source"),
                problem_type=prob.get("problem_type"),
                problem_duration=prob.get("problem_duration"),
                problem_duration_minutes=self._to_int(
                    prob.get("problem_duration_minutes")
                ),
                is_on_hold=self._to_bool(prob.get("is_on_hold")),
                on_hold_reason=prob.get("on_hold_reason"),
                fix_notes=sanitize_text_for_json(prob.get("fix_notes")),
                internal_fix_notes=sanitize_text_for_json(
                    prob.get("internal_fix_notes")
                ),
                fixed_on=self._to_datetime(prob.get("fixed_on")),
                is_customer_visible=self._to_bool(prob.get("is_customer_visible")),
                first_reported_by_task_sys_id=prob.get("first_reported_by_task_sys_id"),
                first_reported_by_task_number=prob.get("first_reported_by_task_number"),
            ),
            request_fields=None,
            tasks=self._build_problem_tasks(tasks) if tasks else None,
            # Configuration Items
            configuration_items=self._build_configuration_items(cis) if cis else None,
        )

    def _build_request_operational_status(
        self, req: Dict, cmd: Dict, cis: List[Dict] = None
    ) -> OperationalStatus:
        """Build OperationalStatus for a request (SCTASK is the ticket)"""

        return OperationalStatus(
            ticket_type="request",
            ticket_sys_id=req.get("req_task_sys_id"),
            service_entity=self._build_service_entity(req, cmd),
            fault_info=self._build_fault_info(req, cmd),
            ticket_info=self._build_ticket_info_from_request(req, cmd),
            outage_info=self._build_outage_info(cmd, req),
            noc_info=self._build_noc_info(cmd),
            users=self._build_users(cmd),
            maintenance_window=self._build_maintenance_window(cmd),
            contacts=None,
            vendors=self._build_vendors(cmd),
            survey_info=self._build_survey_info(cmd),
            incident_fields=None,
            case_fields=None,
            problem_fields=None,
            request_fields=RequestFields(
                # Reference metadata (parent records)
                req_number=req.get("req_number"),
                ritm_number=req.get("req_item_number"),
                case_number=req.get("case_number"),
                # Request item details
                request_item_name=req.get("request_item_name"),
                request_item_form=req.get("request_item_form"),
                request_item_type=req.get("request_item_type"),
            ),
            tasks=None,  # SCTASK is the ticket, no nested tasks
            # Configuration Items
            configuration_items=self._build_configuration_items(cis) if cis else None,
        )

    def _build_cmd_only_operational_status(
        self, cmd: Dict, cis: List[Dict] = None
    ) -> OperationalStatus:
        """Build OperationalStatus for CMD-only ticket (no TSM match)"""

        # Infer ticket_type from ticket_id prefix
        ticket_id = cmd.get("ticket_id", "")
        if ticket_id.startswith("INC"):
            ticket_type = "incident"
        elif ticket_id.startswith("CS"):
            ticket_type = "case"
        elif ticket_id.startswith("PRB"):
            ticket_type = "problem"
        elif ticket_id.startswith("SCTASK"):
            ticket_type = "request"
        else:
            ticket_type = "cmd"  # CMD-only record with unknown TSM type

        return OperationalStatus(
            ticket_type=ticket_type,
            ticket_sys_id=cmd.get("servicenow_task_sys_id"),
            # Build from CMD data only
            service_entity=ServiceEntity(
                subcategory=cmd.get("subcategory"),
                technology=cmd.get("technology"),
                service_restored_date=self._to_datetime(
                    cmd.get("service_restored_date")
                ),
                related_circuit_id=self._to_int(cmd.get("related_circuit_id")),
            ),
            fault_info=FaultInfo(
                fault_description_ref=str(cmd.get("ticket_id")),
                fault_description=sanitize_text_for_json(cmd.get("fault_description")),
                fault_occured_date=self._to_datetime(cmd.get("fault_occured_date")),
                short_description=sanitize_text_for_json(cmd.get("short_description")),
                is_customer_impacting=self._to_bool(cmd.get("is_customer_impacting")),
                rfo=cmd.get("rfo"),
                ticket_rfo_group=cmd.get("ticket_rfo_group"),
            ),
            ticket_info=TicketInfo(
                ticket_id=cmd.get("ticket_id"),
                ticket_queue=cmd.get("default_noc_queue"),
                ticket_status=cmd.get("ticket_status"),
                ticket_substatus=cmd.get("ticket_substatus"),
                ticket_category=cmd.get("ticket_category"),
                priority=self._to_int(cmd.get("priority")),
                is_worked_ticket=self._to_bool(cmd.get("is_worked_ticket")),
                created_by=cmd.get("created_by"),
                created_on=self._to_datetime(cmd.get("created_on")),
                updated_on=self._to_datetime(cmd.get("updated_on")),
                closed_by=cmd.get("closed_by"),
                closed_by_id=cmd.get("closed_by_id"),
                closed_on=self._to_datetime(cmd.get("closed_on")),
                assigned_to=cmd.get("assigned_to"),
                assigned_to_id=cmd.get("assigned_to_id"),
            ),
            outage_info=self._build_outage_info(cmd),
            noc_info=self._build_noc_info(cmd),
            users=self._build_users(cmd),
            maintenance_window=self._build_maintenance_window(cmd),
            contacts=None,
            vendors=self._build_vendors(cmd),
            survey_info=self._build_survey_info(cmd),
            # No TSM data = no entity-specific fields or tasks
            incident_fields=None,
            case_fields=None,
            problem_fields=None,
            request_fields=None,
            tasks=None,
            # Configuration Items
            configuration_items=self._build_configuration_items(cis) if cis else None,
        )

    # =========================================================================
    # Build common nested objects
    # =========================================================================

    def _build_service_entity(self, record: Dict, cmd: Dict) -> ServiceEntity:
        """Build ServiceEntity from TSM record and CMD enrichment"""
        return ServiceEntity(
            subcategory=record.get("subcategory") or cmd.get("subcategory"),
            technology=cmd.get("technology"),
            service_restored_date=self._to_datetime(cmd.get("service_restored_date")),
            related_circuit_id=self._to_int(
                record.get("related_circuit_id") or record.get("circuit_id")
            ),
        )

    def _build_fault_info(self, record: Dict, cmd: Dict) -> FaultInfo:
        """Build FaultInfo from TSM record and CMD enrichment"""
        return FaultInfo(
            fault_description_ref=str(
                record.get("incident_number")
                or record.get("case_number")
                or record.get("problem_number")
                or record.get("req_task_number")
            ),
            fault_description=sanitize_text_for_json(cmd.get("fault_description")),
            fault_occured_date=self._to_datetime(cmd.get("fault_occured_date")),
            short_description=sanitize_text_for_json(
                record.get("short_description")
                or record.get("req_task_short_description")
            ),
            is_customer_impacting=self._to_bool(
                cmd.get("is_customer_impacting") or record.get("is_customer_impacted")
            ),
            rfo=cmd.get("rfo"),
            ticket_rfo_group=cmd.get("ticket_rfo_group"),
        )

    def _build_ticket_info_from_incident(self, inc: Dict, cmd: Dict) -> TicketInfo:
        """Build TicketInfo from incident record"""
        return TicketInfo(
            ticket_id=inc.get("incident_number"),
            ticket_queue=inc.get("assignment_group"),
            ticket_status=inc.get("incident_state"),
            priority=self._to_int(inc.get("priority_number")),
            is_worked_ticket=self._to_bool(inc.get("is_worked_ticket")),
            created_by=inc.get("created_by"),
            created_on=self._to_datetime(inc.get("created_on")),
            updated_on=self._to_datetime(inc.get("updated_on")),
            closed_by=inc.get("closed_by"),
            closed_by_id=inc.get("closed_by_sys_id"),
            closed_on=self._to_datetime(inc.get("closed_on")),
            assigned_to=inc.get("assigned_to"),
            assigned_to_id=inc.get("assigned_to_sys_id"),
        )

    def _build_ticket_info_from_case(self, case: Dict, cmd: Dict) -> TicketInfo:
        """Build TicketInfo from case record"""
        return TicketInfo(
            ticket_id=case.get("case_number"),
            ticket_queue=case.get("assignment_group"),
            ticket_status=case.get("case_state"),
            priority=self._to_int(case.get("priority_number")),
            is_worked_ticket=self._to_bool(case.get("is_worked_ticket")),
            created_by=case.get("created_by"),
            created_on=self._to_datetime(case.get("created_on")),
            updated_on=self._to_datetime(case.get("updated_on")),
            closed_by=case.get("closed_by"),
            closed_by_id=case.get("closed_by_sys_id"),
            closed_on=self._to_datetime(case.get("closed_on")),
            assigned_to=case.get("assigned_to"),
            assigned_to_id=case.get("assigned_to_sys_id"),
        )

    def _build_ticket_info_from_problem(self, prob: Dict, cmd: Dict) -> TicketInfo:
        """Build TicketInfo from problem record"""
        return TicketInfo(
            ticket_id=prob.get("problem_number"),
            ticket_queue=prob.get("assignment_group"),
            ticket_status=prob.get("problem_state"),
            priority=self._to_int(prob.get("priority_number")),
            is_worked_ticket=self._to_bool(prob.get("is_worked_ticket")),
            created_by=prob.get("created_by"),
            created_on=self._to_datetime(prob.get("created_on")),
            updated_on=self._to_datetime(prob.get("updated_on")),
            closed_by=prob.get("closed_by"),
            closed_by_id=prob.get("closed_by_sys_id"),
            closed_on=self._to_datetime(prob.get("closed_on")),
            assigned_to=prob.get("assigned_to"),
            assigned_to_id=prob.get("assigned_to_sys_id"),
        )

    def _build_ticket_info_from_request(self, req: Dict, cmd: Dict) -> TicketInfo:
        """Build TicketInfo from request record (snow_tsm_request columns)"""
        return TicketInfo(
            ticket_id=req.get("req_task_number"),
            ticket_queue=req.get("assignment_group"),
            ticket_status=req.get("req_task_state"),
            priority=self._to_int(req.get("priority_number")),
            is_worked_ticket=self._to_bool(req.get("is_worked_ticket")),
            created_by=req.get("created_by"),
            created_on=self._to_datetime(req.get("created_on")),
            updated_on=self._to_datetime(req.get("updated_on")),
            closed_by=req.get("closed_by"),
            closed_by_id=req.get("closed_by_sys_id"),
            closed_on=self._to_datetime(req.get("closed_on")),
            assigned_to=req.get("assigned_to"),
            assigned_to_id=req.get("assigned_to_sys_id"),
        )

    def _build_outage_info(self, cmd: Dict, tsm: Dict = None) -> OutageInfo:
        """
        Build OutageInfo from CMD enrichment, with TSM fallback for API data.

        For API-sourced data (no CMD), mttr comes from the case/incident record
        where it's been pre-parsed from business_elapsed string.
        """
        tsm = tsm or {}

        # Use CMD mttr first, fallback to TSM mttr (parsed from business_elapsed)
        mttr = self._to_int(cmd.get("mttr"))
        if mttr is None:
            mttr = self._to_int(tsm.get("mttr"))

        # Resolution notes fallback
        resolution = cmd.get("resolution")
        if not resolution:
            resolution = tsm.get("resolution_notes")

        return OutageInfo(
            customer_resolution=cmd.get("customer_resolution"),
            resolution=resolution,
            rfo=cmd.get("rfo"),
            outage_duration=cmd.get("outage_duration"),
            internal_mttr=cmd.get("internal_mttr"),
            mttr=mttr,
            closure_quality=cmd.get("closure_quality"),
            first_email_from_customer_on=self._to_datetime(
                cmd.get("first_email_from_customer_on")
            ),
            first_customer_note_on=self._to_datetime(cmd.get("first_customer_note_on")),
            first_supplier_dispatch_event_on=self._to_datetime(
                cmd.get("first_supplier_dispatch_event_on")
            ),
            first_tech_dispatch_event_on=self._to_datetime(
                cmd.get("first_tech_dispatch_event_on")
            ),
        )

    def _build_noc_info(self, cmd: Dict) -> NOCInfo:
        """Build NOCInfo from CMD enrichment"""
        return NOCInfo(
            default_noc=cmd.get("default_noc"),
            default_noc_queue=cmd.get("default_noc_queue"),
        )

    def _build_users(self, cmd: Dict) -> Optional[List[UserInfo]]:
        """Build user list from CMD enrichment"""
        users = []
        if cmd.get("incident_manager"):
            users.append(
                UserInfo(
                    name=cmd["incident_manager"],
                    user_id=str(cmd.get("incident_manager_id"))
                    if cmd.get("incident_manager_id")
                    else None,
                    role="incident_manager",
                )
            )
        if cmd.get("operations_specialist"):
            users.append(
                UserInfo(
                    name=cmd["operations_specialist"],
                    user_id=str(cmd.get("operations_specialist_id"))
                    if cmd.get("operations_specialist_id")
                    else None,
                    role="operations_specialist",
                )
            )
        if cmd.get("service_desk_engineer"):
            users.append(
                UserInfo(
                    name=cmd["service_desk_engineer"], role="service_desk_engineer"
                )
            )
        if cmd.get("tier2_engineer"):
            users.append(UserInfo(name=cmd["tier2_engineer"], role="tier2_engineer"))
        return users if users else None

    def _build_maintenance_window(self, cmd: Dict) -> Optional[MaintenanceWindow]:
        """Build MaintenanceWindow from CMD enrichment"""
        if not cmd.get("pw_start") and not cmd.get("pw_end"):
            return None
        return MaintenanceWindow(
            pw_start=self._to_datetime(cmd.get("pw_start")),
            pw_end=self._to_datetime(cmd.get("pw_end")),
            pw_duration=cmd.get("pw_duration"),
            pw_location=cmd.get("pw_location"),
            pw_reason=cmd.get("pw_reason"),
        )

    def _build_vendors(self, cmd: Dict) -> Optional[List[VendorInfo]]:
        """Build vendor list from CMD enrichment"""
        if not cmd.get("vendor"):
            return None
        return [
            VendorInfo(
                vendor_id=str(cmd.get("vendor_id")) if cmd.get("vendor_id") else None,
                vendor=cmd["vendor"],
                vendor_downtime=self._to_float(cmd.get("vendor_downtime")),
            )
        ]

    def _build_survey_info(self, cmd: Dict) -> Optional[SurveyInfo]:
        """Build SurveyInfo from CMD enrichment"""
        if not any(cmd.get(f) for f in ["score_id", "survey_score", "survey_ref"]):
            return None
        return SurveyInfo(
            score_id=cmd.get("score_id"),
            score_reason=cmd.get("score_reason"),
            survey_score=cmd.get("survey_score"),
            survey_ref=cmd.get("survey_ref"),
            survey_created_on=self._to_datetime(cmd.get("survey_created_on")),
        )

    # =========================================================================
    # Build configuration items
    # =========================================================================

    def _build_configuration_items(
        self, cis: List[Dict]
    ) -> Optional[List[ConfigurationItem]]:
        """Build ConfigurationItem list from CI service records"""
        if not cis:
            return None
        return [
            ConfigurationItem(
                ci_sys_id=ci["ci_sys_id"],
                ci_name=ci.get("ci_name"),
                is_manually_added=self._to_bool(ci.get("is_manually_added")),
            )
            for ci in cis
            if ci.get("ci_sys_id")
        ]

    # =========================================================================
    # Build tasks
    # =========================================================================

    def _build_incident_tasks(self, tasks: List[Dict]) -> List[IncidentTaskInfo]:
        """Build IncidentTaskInfo list for incident tasks (TASK*)"""
        return [
            IncidentTaskInfo(
                task_sys_id=t["incident_task_sys_id"],
                task_number=t["incident_task_number"],
                # task_type is auto-set to "task" by Literal default
                task_state=t.get("incident_task_state"),
                short_description=sanitize_text_for_json(t.get("short_description")),
                priority=self._to_int(t.get("priority_number")),
                assigned_to=t.get("assigned_to"),
                assigned_to_sys_id=t.get("assigned_to_sys_id"),
                assignment_group=t.get("assignment_group"),
                created_on=self._to_datetime(t.get("created_on")),
                closed_on=self._to_datetime(t.get("closed_on")),
                # Incident task specific
                closure_code=t.get("closure_code"),
                third_party_name=t.get("third_party_name"),
                third_party_ticket=t.get("third_party_ticket"),
                vendor_id=str(t.get("vendor_id")) if t.get("vendor_id") else None,
            )
            for t in tasks
            if t.get("incident_task_sys_id")
        ]

    def _build_problem_tasks(self, tasks: List[Dict]) -> List[ProblemTaskInfo]:
        """Build ProblemTaskInfo list for problem tasks (PTASK*)"""
        return [
            ProblemTaskInfo(
                task_sys_id=t["problem_task_sys_id"],
                task_number=t["problem_task_number"],
                # task_type is auto-set to "ptask" by Literal default
                task_state=t.get("problem_task_state"),
                short_description=sanitize_text_for_json(t.get("short_description")),
                priority=self._to_int(t.get("priority_number")),
                assigned_to=t.get("assigned_to"),
                assigned_to_sys_id=t.get("assigned_to_sys_id"),
                assignment_group=t.get("assignment_group"),
                created_on=self._to_datetime(t.get("created_on")),
                closed_on=self._to_datetime(t.get("closed_on")),
                # Problem task specific
                close_notes=sanitize_text_for_json(t.get("close_notes")),
                cause_code=t.get("cause_code"),
                cause_notes=sanitize_text_for_json(t.get("cause_notes")),
                is_pending=self._to_bool(t.get("is_pending")),
                started_on=self._to_datetime(t.get("started_on")),
            )
            for t in tasks
            if t.get("problem_task_sys_id")
        ]

    def _build_case_tasks(self, tasks: List[Dict]) -> List[CaseTaskInfo]:
        """Build CaseTaskInfo list for case tasks (CSTASK*)"""
        return [
            CaseTaskInfo(
                task_sys_id=t["task_sys_id"],
                task_number=t["task_number"],
                # task_type is auto-set to "cstask" by Literal default
                parent_case_sys_id=t["parent_case_sys_id"],
                parent_case_number=t["parent_case_number"],
                short_description=sanitize_text_for_json(t.get("short_description")),
                state=t.get("state"),
                priority=self._to_int(t.get("priority_number")),
                # Case task specific
                service_type=t.get("service_type"),
                third_party_sys_id=t.get("third_party_sys_id"),
                third_party_name=t.get("third_party_name"),
                third_party_ticket=t.get("third_party_ticket"),
                third_party_score=t.get("third_party_score"),
                # Assignment
                assignment_group=t.get("assignment_group"),
                assigned_to=t.get("assigned_to"),
                assigned_to_sys_id=t.get("assigned_to_sys_id"),
                # Vendor
                vendor_id=str(t.get("vendor_id")) if t.get("vendor_id") else None,
                vendor_name=t.get("vendor_name"),
                # Lifecycle
                created_on=self._to_datetime(t.get("created_on")),
                created_by=t.get("created_by"),
                updated_on=self._to_datetime(t.get("updated_on")),
                closed_on=self._to_datetime(t.get("closed_on")),
                closed_by=t.get("closed_by"),
                closed_by_sys_id=t.get("closed_by_sys_id"),
            )
            for t in tasks
            if t.get("task_sys_id")
        ]

    # =========================================================================
    # Change processing (tickets.change stream - infrastructure level)
    # =========================================================================

    def process_changes(self, extracted_data: Dict[str, Any]) -> Tuple[List[str], int]:
        """
        Process changes into ChangeBatch messages for tickets.change topic.

        Changes are infrastructure-level (no client_id) and batched.

        Args:
            extracted_data: Dict from Extractor.extract_all() containing:
                - changes: List of change records
                - change_tasks_by_change: Dict mapping change_sys_id -> tasks
                - ci_by_task_sys_id: Dict mapping sys_id -> CIs

        Returns:
            Tuple of (change_batch_messages, processed_count)
        """
        changes = extracted_data.get("changes", [])
        change_tasks_by_change = extracted_data.get("change_tasks_by_change", {})
        ci_by_task_sys_id = extracted_data.get("ci_by_task_sys_id", {})

        if not changes:
            return [], 0

        # Build ChangeRecord objects
        change_records: List[ChangeRecord] = []
        for change in changes:
            try:
                change_sys_id = change.get("change_sys_id")
                if not change_sys_id:
                    continue

                tasks = change_tasks_by_change.get(change_sys_id, [])
                cis = ci_by_task_sys_id.get(change_sys_id, [])

                record = self._build_change_record(change, tasks, cis)
                change_records.append(record)
            except Exception as e:
                self.logger.error(
                    f"Error processing change {change.get('change_number')}: {e}"
                )

        # Batch the records
        batches = self._batch_changes(change_records)

        # Convert to JSON messages
        messages = [batch.model_dump_json() for batch in batches]

        self.logger.info(
            f"Processed {len(change_records)} changes into {len(batches)} batches"
        )

        return messages, len(change_records)

    def _build_change_record(
        self, change: Dict, tasks: List[Dict], cis: List[Dict]
    ) -> ChangeRecord:
        """Build a ChangeRecord from raw change data"""
        return ChangeRecord(
            change_sys_id=change["change_sys_id"],
            change_number=change["change_number"],
            short_description=sanitize_text_for_json(change.get("short_description")),
            description=sanitize_text_for_json(change.get("description")),
            # Status
            change_state=change.get("change_state"),
            category=change.get("category"),
            subcategory=change.get("subcategory"),
            reason=change.get("reason"),
            # Change-specific fields
            change_fields=self._build_change_fields(change),
            # Tasks (filter out tasks without task_sys_id)
            tasks=[
                self._build_change_task_info(t) for t in tasks if t.get("task_sys_id")
            ],
            # Assignment
            assignment_group=change.get("assignment_group"),
            assigned_to=change.get("assigned_to"),
            assigned_to_sys_id=change.get("assigned_to_sys_id"),
            # Lifecycle
            created_on=self._to_datetime(change.get("created_on")),
            created_by=change.get("created_by"),
            updated_on=self._to_datetime(change.get("updated_on")),
            closed_on=self._to_datetime(change.get("closed_on")),
            closed_by=change.get("closed_by"),
            closed_by_sys_id=change.get("closed_by_sys_id"),
            close_code=change.get("close_code"),
            close_notes=sanitize_text_for_json(change.get("close_notes")),
            # Work tracking
            time_worked_minutes=self._to_int(change.get("time_worked_minutes")),
            support_area=change.get("support_area"),
            contact_type=change.get("contact_type"),
            # Configuration Items
            configuration_items=self._build_configuration_items(cis) if cis else [],
        )

    def _build_change_fields(self, change: Dict) -> ChangeFields:
        """Build ChangeFields from raw change data"""
        return ChangeFields(
            # Type
            change_type=change.get("change_type"),
            work_type=change.get("work_type"),
            source=change.get("source"),
            # Planned work
            planned_start_date=self._to_datetime(change.get("planned_start_date")),
            planned_end_date=self._to_datetime(change.get("planned_end_date")),
            backup_start_date=self._to_datetime(change.get("backup_start_date")),
            backup_end_date=self._to_datetime(change.get("backup_end_date")),
            impact_duration=change.get("impact_duration"),
            impact_duration_minutes=self._to_int(change.get("impact_duration_minutes")),
            # Plans
            implementation_plan=sanitize_text_for_json(
                change.get("implementation_plan")
            ),
            backout_plan=sanitize_text_for_json(change.get("backout_plan")),
            test_plan=sanitize_text_for_json(change.get("test_plan")),
            risk_impact_analysis=sanitize_text_for_json(
                change.get("risk_impact_analysis")
            ),
            justification=sanitize_text_for_json(change.get("justification")),
            # Location
            country=change.get("country"),
            city=change.get("city"),
            planned_work_location=change.get("planned_work_location"),
            # Risk flags (Y/N fields)
            risk=change.get("risk"),
            security_risk=self._parse_yn_bool(change.get("security_risk_y_n")),
            modification_of_access=self._parse_yn_bool(
                change.get("modification_of_access_y_n")
            ),
            core_network=self._parse_yn_bool(change.get("core_network_y_n")),
            critical_systems=self._parse_yn_bool(change.get("critical_systems_y_n")),
            # CAB
            cab_date_time=self._to_datetime(change.get("cab_date_time")),
            is_cab_required=self._parse_yn_bool(change.get("is_cab_required_y_n")),
            is_postponed=self._parse_yn_bool(change.get("is_postponed_y_n")),
            # Supplier
            supplier_sys_id=change.get("supplier_sys_id"),
            supplier_name=change.get("supplier_name"),
            supplier_reference=change.get("supplier_reference"),
            vendor_id=str(change.get("vendor_id")) if change.get("vendor_id") else None,
            # Implementation
            implemented_by_sys_ids=change.get("implemented_by_sys_ids"),
            implemented_by_names=change.get("implemented_by_names"),
            requested_by_sys_id=change.get("requested_by_sys_id"),
            requested_by=change.get("requested_by"),
            requested_by_date=self._to_datetime(change.get("requested_by_date")),
            # Impact metrics
            impacted_services_count=self._to_int(change.get("impacted_services_count")),
            planned_work_reason=change.get("planned_work_reason"),
            # Second backup window
            second_backup_start_date=self._to_datetime(
                change.get("second_backup_start_date")
            ),
            second_backup_end_date=self._to_datetime(
                change.get("second_backup_end_date")
            ),
            # Additional flags
            is_inside_blackout_schedule=self._parse_yn_bool(
                change.get("is_inside_blackout_schedule")
            ),
            is_suppress_client_notifications=self._parse_yn_bool(
                change.get("is_suppress_client_notifications")
            ),
            modification_of_cryptographic=self._parse_yn_bool(
                change.get("modification_of_cryptographic_y_n")
            ),
        )

    def _build_change_task_info(self, task: Dict) -> ChangeTaskInfo:
        """Build ChangeTaskInfo from raw task data"""
        return ChangeTaskInfo(
            task_sys_id=task["task_sys_id"],
            task_number=task["task_number"],
            change_sys_id=task["change_sys_id"],
            change_number=task["change_number"],
            short_description=sanitize_text_for_json(task.get("short_description")),
            state=task.get("state"),
            priority=self._to_int(task.get("priority_number")),
            # Change task specific
            change_category=task.get("change_category"),
            change_subcategory=task.get("change_subcategory"),
            fulfillment=self._parse_yn_bool(task.get("fulfillment_y_n")),
            follow_up_needed=self._parse_yn_bool(task.get("follow_up_needed_y_n")),
            implemented_in_timeframe=self._parse_yn_bool(
                task.get("implemented_in_timeframe_y_n")
            ),
            unexpected_consequences=self._parse_yn_bool(
                task.get("unexpected_consequences_y_n")
            ),
            closure_responsibility=task.get("closure_responsibility"),
            responsible_team=task.get("responsible_team"),
            # Assignment
            assignment_group=task.get("assignment_group"),
            assigned_to=task.get("assigned_to"),
            assigned_to_sys_id=task.get("assigned_to_sys_id"),
            # Lifecycle
            created_on=self._to_datetime(task.get("created_on")),
            created_by=task.get("created_by"),
            updated_on=self._to_datetime(task.get("updated_on")),
            closed_on=self._to_datetime(task.get("closed_on")),
            closed_by=task.get("closed_by"),
            closed_by_sys_id=task.get("closed_by_sys_id"),
        )

    def _build_case_task_info(self, task: Dict) -> CaseTaskInfo:
        """Build CaseTaskInfo from raw task data"""
        return CaseTaskInfo(
            task_sys_id=task["task_sys_id"],
            task_number=task["task_number"],
            parent_case_sys_id=task["parent_case_sys_id"],
            parent_case_number=task["parent_case_number"],
            short_description=sanitize_text_for_json(task.get("short_description")),
            state=task.get("state"),
            priority=self._to_int(task.get("priority_number")),
            # Case task specific
            service_type=task.get("service_type"),
            third_party_sys_id=task.get("third_party_sys_id"),
            third_party_name=task.get("third_party_name"),
            third_party_ticket=task.get("third_party_ticket"),
            third_party_score=task.get("third_party_score"),
            # Assignment
            assignment_group=task.get("assignment_group"),
            assigned_to=task.get("assigned_to"),
            assigned_to_sys_id=task.get("assigned_to_sys_id"),
            # Vendor
            vendor_id=str(task.get("vendor_id")) if task.get("vendor_id") else None,
            vendor_name=task.get("vendor_name"),
            # Lifecycle
            created_on=self._to_datetime(task.get("created_on")),
            created_by=task.get("created_by"),
            updated_on=self._to_datetime(task.get("updated_on")),
            closed_on=self._to_datetime(task.get("closed_on")),
            closed_by=task.get("closed_by"),
            closed_by_sys_id=task.get("closed_by_sys_id"),
        )

    def _batch_changes(self, changes: List[ChangeRecord]) -> List[ChangeBatch]:
        """Split changes into batches of CHANGE_BATCH_SIZE"""
        from datetime import datetime as dt

        if not changes:
            return []

        batches = []
        total_changes = len(changes)
        total_batches = (total_changes + CHANGE_BATCH_SIZE - 1) // CHANGE_BATCH_SIZE
        extraction_time = dt.utcnow()

        for i in range(0, total_changes, CHANGE_BATCH_SIZE):
            batch_changes = changes[i : i + CHANGE_BATCH_SIZE]
            batch_number = (i // CHANGE_BATCH_SIZE) + 1

            batch = ChangeBatch(
                changes=batch_changes,
                batch_number=batch_number,
                total_batches=total_batches,
                total_changes=total_changes,
                extraction_time=extraction_time,
            )
            batches.append(batch)

        return batches

    # =========================================================================
    # Fault descriptions
    # =========================================================================

    def _extract_fault_description(
        self,
        fault_descriptions_by_client: Dict[str, List[FaultDescription]],
        client_id: str,
        ticket_id: str,
        cmd: Dict,
    ):
        """Extract fault description from CMD if present"""
        fault_desc_text = cmd.get("fault_description")
        if fault_desc_text and fault_desc_text.strip():
            client_id_str = str(client_id)
            if client_id_str not in fault_descriptions_by_client:
                fault_descriptions_by_client[client_id_str] = []

            fault_descriptions_by_client[client_id_str].append(
                FaultDescription(
                    fault_description_id=str(ticket_id),
                    ticket_id=str(ticket_id),
                    fault_description=sanitize_text_for_json(fault_desc_text),
                    fault_occured_date=self._to_datetime(cmd.get("fault_occured_date")),
                )
            )

    def _group_fault_descriptions(
        self, fault_descriptions_by_client: Dict[str, List[FaultDescription]]
    ) -> List[str]:
        """Group fault descriptions by client into FaultDescriptionSummary messages"""
        messages = []
        for client_id, fault_descriptions in fault_descriptions_by_client.items():
            if not fault_descriptions:
                continue
            summary = FaultDescriptionSummary(
                fault_description_summary_id=f"{client_id}_part_1_of_1",
                client_id=client_id,
                part_number=1,
                total_parts=1,
                fault_descriptions=fault_descriptions,
            )
            messages.append(summary.model_dump_json())
        return messages

    # =========================================================================
    # Type conversion helpers
    # =========================================================================

    def _parse_yn_bool(self, value: Any) -> Optional[bool]:
        """Parse Y/N string to boolean (for ServiceNow Y/N fields)"""
        if value is None or value == "":
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.upper() in ("Y", "YES", "TRUE", "1")
        return bool(value)

    def _to_int(self, value: Any) -> Optional[int]:
        """Convert value to int, handling strings and floats"""
        if value is None or value == "":
            return None
        try:
            return int(float(value))
        except (ValueError, TypeError):
            return None

    def _to_float(self, value: Any) -> Optional[float]:
        """Convert value to float"""
        if value is None or value == "":
            return None
        try:
            return float(value)
        except (ValueError, TypeError):
            return None

    def _to_bool(self, value: Any) -> Optional[bool]:
        """Convert value to bool"""
        if value is None or value == "":
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ("true", "1", "yes", "t")
        return bool(value)

    def _to_datetime(self, value: Any) -> Optional[datetime]:
        """Convert value to datetime"""
        if value is None or value == "":
            return None
        if isinstance(value, datetime):
            return value
        # If string, try parsing common formats
        if isinstance(value, str):
            for fmt in ["%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"]:
                try:
                    return datetime.strptime(value, fmt)
                except ValueError:
                    continue
        return None
