import pytest
from unittest.mock import AsyncMock, MagicMock, patch
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from utils.db import TicketDatabase


class TestTicketDatabase:
    @pytest.fixture
    def mock_connection_manager(self):
        """Create a mock connection manager"""
        manager = MagicMock()
        mock_pool = AsyncMock()
        manager.get_database_pool.return_value = mock_pool
        return manager, mock_pool

    @pytest.fixture
    def ticket_db(self, mock_connection_manager):
        """Create a TicketDatabase instance with mocked connection manager"""
        manager, pool = mock_connection_manager
        return TicketDatabase(manager), pool

    def test_initialization(self, mock_connection_manager):
        """Test TicketDatabase initialization"""
        manager, pool = mock_connection_manager
        db = TicketDatabase(manager)

        assert db.connection_manager == manager
        assert hasattr(db, "logger")

    def test_pool_property(self, ticket_db):
        """Test pool property returns correct pool from connection manager"""
        db, mock_pool = ticket_db

        assert db.pool == mock_pool

    @pytest.mark.asyncio
    async def test_execute_query_no_pool(self, mock_connection_manager):
        """Test query execution with no pool raises exception"""
        manager, pool = mock_connection_manager
        manager.get_database_pool.return_value = None

        db = TicketDatabase(manager)

        with pytest.raises(
            Exception, match="Database connection pool is not initialized"
        ):
            await db.execute_query("SELECT 1")

    @pytest.mark.asyncio
    async def test_fetch_data_basic_structure(self, ticket_db):
        """Test fetch_data method structure and SQL generation"""
        db, mock_pool = ticket_db

        # Mock the execute_query method to avoid async context complexity
        with patch.object(db, "execute_query") as mock_execute:
            mock_execute.return_value = [
                {"id": 1, "title": "Test Ticket 1"},
                {"id": 2, "title": "Test Ticket 2"},
            ]

            table_name = "tickets"
            columns = ["id", "title"]

            result = await db.fetch_data(table_name, columns)

            assert len(result) == 2
            assert result[0]["id"] == 1
            assert result[1]["title"] == "Test Ticket 2"

            # Verify execute_query was called with the expected SQL
            expected_query = "SELECT id, title FROM tickets;"
            mock_execute.assert_called_once_with(expected_query)

    @pytest.mark.asyncio
    async def test_fetch_data_with_time_filter(self, ticket_db):
        """Test fetch_data with time-based filter"""
        db, mock_pool = ticket_db

        with patch.object(db, "execute_query") as mock_execute:
            mock_execute.return_value = [{"id": 1, "title": "Recent Ticket"}]

            table_name = "tickets"
            columns = ["id", "title"]
            filters = {"updated_on": "2024-01-01 00:00:00"}

            result = await db.fetch_data(table_name, columns, filters)

            assert len(result) == 1
            assert result[0]["id"] == 1

            # Verify the SQL query includes WHERE clause
            expected_query = "SELECT id, title FROM tickets WHERE updated_on >= $1;"
            mock_execute.assert_called_once_with(expected_query, "2024-01-01 00:00:00")

    @pytest.mark.asyncio
    async def test_fetch_data_no_columns(self, ticket_db):
        """Test fetch_data with no specific columns (SELECT *)"""
        db, mock_pool = ticket_db

        with patch.object(db, "execute_query") as mock_execute:
            mock_execute.return_value = [
                {"id": 1, "title": "Test", "description": "Test desc"}
            ]

            table_name = "tickets"
            columns = []  # Empty list should result in SELECT *

            result = await db.fetch_data(table_name, columns)

            assert len(result) == 1

            # Verify the SQL query uses *
            expected_query = "SELECT * FROM tickets;"
            mock_execute.assert_called_once_with(expected_query)

    @pytest.mark.asyncio
    async def test_fetch_data_filters_without_updated_on(self, ticket_db):
        """Test fetch_data with filters that don't include updated_on"""
        db, mock_pool = ticket_db

        with patch.object(db, "execute_query") as mock_execute:
            mock_execute.return_value = [{"id": 1, "status": "open"}]

            table_name = "tickets"
            columns = ["id", "status"]
            filters = {"status": "open"}  # No updated_on filter

            result = await db.fetch_data(table_name, columns, filters)

            assert len(result) == 1

            # Verify the SQL query has no WHERE clause (only updated_on filter is implemented)
            expected_query = "SELECT id, status FROM tickets;"
            mock_execute.assert_called_once_with(expected_query)

    @pytest.mark.asyncio
    async def test_fetch_data_empty_result(self, ticket_db):
        """Test fetch_data with empty result set"""
        db, mock_pool = ticket_db

        with patch.object(db, "execute_query") as mock_execute:
            mock_execute.return_value = []

            table_name = "tickets"
            columns = ["id", "title"]

            result = await db.fetch_data(table_name, columns)

            assert result == []

    @pytest.mark.asyncio
    async def test_fetch_data_database_error(self, ticket_db):
        """Test fetch_data with database error"""
        db, mock_pool = ticket_db

        with patch.object(db, "execute_query") as mock_execute:
            mock_execute.side_effect = Exception("Database error")

            table_name = "tickets"
            columns = ["id", "title"]

            with pytest.raises(Exception, match="Database error"):
                await db.fetch_data(table_name, columns)

    @pytest.mark.asyncio
    async def test_fetch_data_sql_query_construction(self, ticket_db):
        """Test that fetch_data constructs SQL queries correctly"""
        db, mock_pool = ticket_db

        with patch.object(db, "execute_query") as mock_execute:
            mock_execute.return_value = []

            # Test with schema.table name
            table_name = "schema.tickets"
            columns = ["id", "title"]
            filters = {"updated_on": "2024-01-01"}

            await db.fetch_data(table_name, columns, filters)

            # Verify the query structure
            expected_query = (
                "SELECT id, title FROM schema.tickets WHERE updated_on >= $1;"
            )
            mock_execute.assert_called_once_with(expected_query, "2024-01-01")

    @pytest.mark.asyncio
    async def test_fetch_data_complex_columns(self, ticket_db):
        """Test fetch_data with various column names"""
        db, mock_pool = ticket_db

        with patch.object(db, "execute_query") as mock_execute:
            mock_execute.return_value = []

            table_name = "tickets"
            columns = ["ticket_id", "client_name", "created_on", "updated_on", "status"]

            await db.fetch_data(table_name, columns)

            # Verify all columns are included in the query
            expected_query = "SELECT ticket_id, client_name, created_on, updated_on, status FROM tickets;"
            mock_execute.assert_called_once_with(expected_query)

    def test_no_close_method(self, ticket_db):
        """Test that TicketDatabase doesn't have a close method (managed by ConnectionManager)"""
        db, mock_pool = ticket_db

        # Should not have a close method
        assert not hasattr(db, "close")

    @pytest.mark.asyncio
    async def test_logging_on_fetch_data(self, ticket_db):
        """Test that logging occurs during fetch_data"""
        db, mock_pool = ticket_db

        with patch.object(db, "execute_query") as mock_execute:
            mock_execute.return_value = []

            # Mock the logger
            with patch.object(db.logger, "debug") as mock_debug:
                columns = ["id", "title"]
                filters = {"updated_on": "2024-01-01"}

                await db.fetch_data("tickets", columns, filters)

                # Verify debug logging was called for columns, filters, and query
                assert any(
                    "The columns:" in str(call) for call in mock_debug.call_args_list
                )
                assert any(
                    "The filters:" in str(call) for call in mock_debug.call_args_list
                )
                assert any(
                    "Executing query:" in str(call)
                    for call in mock_debug.call_args_list
                )

    @pytest.mark.asyncio
    async def test_fetch_data_row_to_dict_conversion(self, ticket_db):
        """Test that fetch_data converts rows to dictionaries"""
        db, mock_pool = ticket_db

        # Mock row objects that have dict() method
        class MockRow:
            def __init__(self, data):
                self._data = data

            def __iter__(self):
                return iter(self._data.items())

            def __getitem__(self, key):
                return self._data[key]

            def keys(self):
                return self._data.keys()

            def values(self):
                return self._data.values()

            def items(self):
                return self._data.items()

        mock_rows = [
            MockRow({"id": 1, "title": "Test 1"}),
            MockRow({"id": 2, "title": "Test 2"}),
        ]

        with patch.object(db, "execute_query") as mock_execute:
            mock_execute.return_value = mock_rows

            result = await db.fetch_data("tickets", ["id", "title"])

            # Should convert rows to dictionaries
            assert isinstance(result, list)
            assert len(result) == 2
            assert isinstance(result[0], dict)
            assert result[0]["id"] == 1
            assert result[0]["title"] == "Test 1"
            assert result[1]["id"] == 2
            assert result[1]["title"] == "Test 2"
