# MCP Ticket System - Technical Architecture
**Version:** 3.0 (Async Performance + Semantic Search)
**Date:** October 30, 2025
**Document Type:** Technical Design Specification

---

## Technology Stack

### Core Runtime
- **Language**: Python 3.13
- **Async Framework**: asyncio (native)
- **Package Manager**: pip (requirements.txt)

### Key Dependencies
| Package | Version | Purpose |
|---------|---------|---------|
| `fastmcp` | 0.2.1+ | MCP protocol server implementation |
| `neo4j` | ≥5.17.0 | **Async** Memgraph driver (Bolt protocol) |
| `nats-py` | 2.10.0+ | NATS JetStream client |
| `baml-py` | 0.210.0 | LLM abstraction layer |
| `polars` | 1.0.0+ | High-performance dataframes |
| `fastapi` | 0.115.0+ | HTTP server (health checks) |
| `pydantic` | 2.0.0+ | Data validation |
| `uvicorn` | 0.34.0+ | ASGI server |
| `pymilvus` | 2.4.0+ | Milvus vector database client |

---

## Async Performance Architecture

### Performance Characteristics
- **Processing Speed**: 0.098s/msg (43× faster than sync baseline of 4.224s/msg)
- **Reliability**: 100% success rate with strategic locking
- **Concurrency**: Configurable 3-10 concurrent database write operations
- **Throughput**: Up to 600+ messages/minute at concurrency=5

### Async/Await Implementation

**Migration to AsyncGraphDatabase:**
```python
# Before (sync)
from neo4j import GraphDatabase
session = driver.session()
result = session.run(query, params)

# After (async)
from neo4j import AsyncGraphDatabase
async with driver.session() as session:
    result = await session.run(query, params)
```

**Key Files:**
- `server/app/data_access/memgraphClient.py` - Async database client
- `server/app/services/batch_graph_loader.py` - Async batch operations
- `server/app/services/message_handler.py` - Async message processing with locks

### Strategic Locking for Shared Resources

**Problem**: High concurrency causes transaction conflicts on shared graph nodes (UserInfo, VendorInfo).

**Solution**: Selective serialization using `asyncio.Lock()` for operations on shared resources only.

**Global Locks Implemented:**
```python
# server/app/services/message_handler.py
_user_node_lock = asyncio.Lock()           # UserInfo node creation
_user_relationship_lock = asyncio.Lock()   # UserInfo relationships
_vendor_relationship_lock = asyncio.Lock() # VendorInfo relationships
```

**Performance Impact**:
| Operation | Parallel/Serial | % of Work | Time Impact |
|-----------|----------------|-----------|-------------|
| Client, Service, Incident nodes | Parallel | 40% | Scales with concurrency |
| Ticket, Outage_Info nodes | Parallel | 20% | Scales with concurrency |
| UserInfo node creation | **Serial** | 5% | Fixed overhead |
| User relationships | **Serial** | 10% | Fixed overhead |
| Vendor relationships | **Serial** | 5% | Fixed overhead |
| Other relationships | Parallel | 20% | Scales with concurrency |

**Result**: 80% of work remains parallel, 20% serialized for conflict prevention.

### Concurrency Configuration

**Environment Variable**: `MEMGRAPH_MAX_CONCURRENT`
```bash
# Development (docker-compose.override.yml)
MEMGRAPH_MAX_CONCURRENT=5  # Recommended

# Production (Helm values.yaml)
env:
  - name: MEMGRAPH_MAX_CONCURRENT
    value: "5"
```

**Performance by Concurrency Level:**
| Concurrency | Avg Time/Msg | Success Rate | Throughput | Notes |
|-------------|--------------|--------------|------------|-------|
| 1 (sync) | 4.224s | 100% | 14 msg/min | Baseline |
| 3 (async + locks) | 0.110s | 100% | 545 msg/min | Safe starting point |
| 5 (async + locks) | 0.098s | 100% | 612 msg/min | **Recommended** |
| 10 (async + locks) | 0.107s | 100% | 560 msg/min | Diminishing returns |
| 10 (async, no locks) | 0.069s | 73-90% | N/A | ❌ High failure rate |

### Retry Logic

**Configuration** (`server/app/services/batch_graph_loader.py`):
```python
self.max_retries = 5      # Increased from 3 for extra safety
self.base_delay = 0.1     # 100ms base delay

# Exponential backoff
delays = [100ms, 200ms, 400ms, 800ms]  # Total: 1.5s max retry time
```

**Purpose**:
- Safety net for rare transient database errors
- Handles network hiccups and memory pressure
- With locks in place, retries rarely trigger

### Monitoring Commands

**Check Performance:**
```bash
# Processing speed
docker logs mcp_ticket_server 2>&1 | grep "Processed.*messages" | tail -10

# Error rates
echo "Transient errors: $(docker logs mcp_ticket_server 2>&1 | grep 'Transient error' | wc -l)"
echo "Total failures: $(docker logs mcp_ticket_server 2>&1 | grep 'Failed to batch' | wc -l)"

# User relationship failures (should be 0 with locks)
docker logs mcp_ticket_server 2>&1 | grep 'Failed to batch load user' | wc -l
```

**Detailed Implementation**: See `server/docs/ASYNC_PERFORMANCE_ARCHITECTURE.md` for complete architecture, visual diagrams, and tuning guidelines.

---

## Network Architecture

### Port Mapping
```
┌────────────────────────────────────────────────────┐
│  Service          │ Port  │ Protocol │ Exposure    │
├───────────────────┼───────┼──────────┼─────────────┤
│  MCP Server       │ 8003  │ HTTP/SSE │ External    │
│  Memgraph (Bolt)  │ 7687  │ Bolt     │ Internal    │
│  Memgraph Lab     │ 7444  │ HTTP     │ Development │
│  NATS Client      │ 4222  │ TCP      │ Internal    │
│  Ollama           │ 11434 │ HTTP     │ Internal    │
│  Milvus           │ 19530 │ gRPC     │ Internal    │
│  MinIO (Milvus)   │ 9000  │ HTTP     │ Internal    │
│  etcd (Milvus)    │ 2379  │ HTTP     │ Internal    │
└────────────────────────────────────────────────────┘
```

**Semantic Search Stack** (Phase 3):
- **Milvus**: Vector database for fault description embeddings
- **Ollama**: nomic-embed-text model for generating embeddings
- **Integration**: See `server/docs/PHASE3_SEMANTIC_SEARCH_ARCHITECTURE.md` for complete vector search architecture

### Communication Protocols

#### 1. MCP (Model Context Protocol)
```
AI Assistant → MCP Server
├─ Transport: HTTP (SSE for streaming)
├─ Format: JSON-RPC 2.0
├─ Content-Type: application/json
└─ Methods:
   ├─ tools/list
   ├─ tools/call
   ├─ resources/list
   └─ resources/read
```

#### 2. Bolt Protocol (Memgraph)
```
Application → Memgraph
├─ Transport: TCP (Bolt over port 7687)
├─ Driver: neo4j-python-driver 5.17+
├─ Session Mode: READ/WRITE
├─ Transaction: Auto-commit or explicit
└─ Auth: Username/Password (optional)
```

#### 3. NATS JetStream
```
Consumer → NATS Server
├─ Transport: TCP (port 4222)
├─ Pattern: Pull-based subscription
├─ ACK Mode: Explicit acknowledgment
├─ Durable: ticket_consumer_durable
└─ Subject: tickets.created
```

---

## Data Storage

### Graph Database (Memgraph)

#### Schema Definition
```cypher
-- Node Types
CREATE (:Client {cl_id, client_id, client_name});
CREATE (:Ticket {tkt_id, ticket_id, ticket_status, priority, ...});
CREATE (:Incident {inc_id, fault_description, fault_occured_date, ...});
CREATE (:Service {svc_id, subcategory, technology, ...});
CREATE (:Outage_Info {oi_id, rfo, mttr, outage_total, ...});
CREATE (:UserInfo {user_id, name, email, role});
CREATE (:ContactInfo {contact_id, name, email, contact_type});
CREATE (:VendorInfo {vendor_id, vendor, vendor_downtime});
CREATE (:MaintenanceWindow {mw_id, pw_start, pw_end, pw_reason});
CREATE (:SurveyInfo {survey_id, survey_score, score_reason});
CREATE (:NOCInfo {noc_id, default_noc, default_noc_queue});

-- Relationships
CREATE (:Client)-[:HAS_TICKET]->(:Ticket);
CREATE (:Ticket)-[:TRIGGERED_BY]->(:Incident);
CREATE (:Ticket)-[:HAS_OUTAGE_INFO]->(:Outage_Info);
CREATE (:Incident)-[:IMPACTS]->(:Service);
CREATE (:Ticket)-[:HAS_INCIDENT_MANAGER]->(:UserInfo);
CREATE (:Ticket)-[:HAS_OPS_SPECIALIST]->(:UserInfo);
CREATE (:Ticket)-[:HAS_SD_ENGINEER]->(:UserInfo);
CREATE (:Ticket)-[:HAS_TIER2_ENGINEER]->(:UserInfo);
CREATE (:Ticket)-[:HAS_CONTACT]->(:ContactInfo);
CREATE (:Ticket)-[:INVOLVES_VENDOR]->(:VendorInfo);
CREATE (:Ticket)-[:DURING_MAINTENANCE]->(:MaintenanceWindow);
CREATE (:Ticket)-[:HAS_SURVEY]->(:SurveyInfo);
CREATE (:Service)-[:MONITORED_BY_NOC]->(:NOCInfo);
CREATE (:Ticket)-[:CHILD_OF]->(:Ticket);  -- Master-child relationship
CREATE (:Ticket)-[:LINKED_TO]->(:Ticket);  -- Ticket linking
```

#### Indexing Strategy
```cypher
-- Primary keys
CREATE INDEX ON :Client(cl_id);
CREATE INDEX ON :Ticket(tkt_id);
CREATE INDEX ON :Incident(inc_id);

-- Query optimization
CREATE INDEX ON :Ticket(ticket_status);
CREATE INDEX ON :Ticket(priority);
CREATE INDEX ON :Client(client_name);
```

#### Connection Configuration
```python
# server/app/configs/config.yml
memgraph:
  uri: "bolt://localhost:7687"
  user: ""
  password: ""
  database: "memgraph"

# Connection Pool Settings (Neo4j driver defaults)
max_connection_lifetime: 3600  # seconds
max_connection_pool_size: 50
connection_acquisition_timeout: 60
```

---

## API Specifications

### MCP Tool Definitions

#### Natural Language Query Tool
```python
@mcp.tool(name="ask_tickets_question")
async def ask_tickets_question(
    user_query: str,
    services: dict
) -> dict:
    """
    Translate natural language question to Cypher query.

    Args:
        user_query: Plain English question about tickets

    Returns:
        {
            "cypher_query": str,
            "execution_time_ms": float,
            "results": List[dict],
            "row_count": int
        }
    """
```

#### Lookup Tool Example
```python
@mcp.tool(name="get_ticket_details")
async def get_ticket_details(
    ticket_id: str,
    services: dict
) -> dict:
    """
    Retrieve comprehensive ticket information.

    Args:
        ticket_id: Ticket identifier (e.g., "Ticket_8709441")

    Returns:
        {
            "ticket": dict,
            "client": dict,
            "incident": dict,
            "services": List[dict],
            "outage_info": dict,
            "contacts": List[dict],
            "vendors": List[dict],
            "team_members": List[dict]
        }
    """
```

### Health Check API
```
GET /health
Response:
{
    "status": "healthy" | "unhealthy",
    "service": "mcp_ticket_server",
    "memgraph_connected": boolean,
    "timestamp": "2025-10-13T10:20:30Z"
}
```

---

## BAML Configuration

### LLM Client Setup
```yaml
# server/app/baml_src/clients.baml
client<llm> OllamaGemma {
  provider "openai-generic"
  options {
    model env.OLLAMA_MODEL           # llama3.1-cypher:8b
    base_url env.OLLAMA_BASE_URL     # http://10.250.99.61:11434/v1
  }
}
```

### Retry Policies
```yaml
# server/app/baml_src/clients.baml
retry_policy Constant {
  max_retries 3
  strategy {
    type constant_delay
    delay_ms 200
  }
}

retry_policy Exponential {
  max_retries 2
  strategy {
    type exponential_backoff
    delay_ms 300
    multiplier 1.5
    max_delay_ms 10000
  }
}
```

### Query Translation Function
```python
# server/app/baml_src/graph_helper.baml
function TranslateToCypher(
    question: string,
    schema_description: string
) -> string {
    client OllamaGemma
    prompt #"
        You are an expert Memgraph database engineer.

        Graph Schema:
        {{ schema_description }}

        Constraints:
        - Only generate Cypher query (no explanations)
        - Use WHERE clauses with LOWER() and CONTAINS
        - Verify relationships exist

        User Question: {{ question }}
        Cypher Query:
    "#
}
```

---

## Message Queue Architecture

### NATS JetStream Configuration

#### Stream Definition
```yaml
# Created by messaging-infrastructure
Stream Name: DATA_INJESTION_STREAM
Subjects: ["tickets.created"]
Retention Policy: WorkQueue
Max Message Age: 24 hours
Storage: File
Replication: 1
```

#### Consumer Configuration
```python
# server/app/data_access/messaging/ticket_consumer.py
consumer_config = {
    "durable": "ticket_consumer_durable",
    "ack_policy": "explicit",
    "max_deliver": 5,
    "ack_wait": 30,  # seconds
    "max_ack_pending": 100
}

# Pull Subscription
batch_size = 10
fetch_timeout = 2.0  # seconds
```

### Message Format

#### Compressed Message
```json
{
  "compressed": true,
  "encoding": "gzip+base64",
  "data": "H4sIAA...base64_encoded_gzip_data...=="
}
```

#### Decompressed Payload
```json
{
  "client_info": {
    "client_id": 96757,
    "client_name": "ACME Corporation"
  },
  "operational_status": [
    {
      "service_entity": {
        "subcategory": "Internet",
        "technology": "Fiber"
      },
      "incident_info": {
        "fault_description": "Circuit down",
        "fault_occured_date": "2025-01-15"
      },
      "ticket_info": {
        "ticket_id": 8709441,
        "ticket_status": "Closed",
        "priority": 2
      },
      "outage_info": {
        "rfo": "Hardware Failure",
        "mttr": 120,
        "outage_total": 1
      }
    }
  ]
}
```

---

## Data Processing Pipeline

### Ingestion Flow
```python
# server/app/services/message_handler.py

async def process_ticket_message(msg):
    # 1. Decompress
    payload = Helpers.decompress_message(msg.data)

    # 2. Normalize
    ticket_summary = Helpers.normalise_None(payload)

    # 3. Generate IDs
    ticket_summary = Helpers.graph_json_adapter(ticket_summary)

    # 4. Load Cypher templates
    cypher_queries = load_cypher_configs("load_tickets_cypher.yaml")

    # 5. Batch Insert
    for operational_status in ticket_summary["operational_status"]:
        # Create Client, Ticket, Incident, Service nodes
        # Create relationships
        memgraph_client.execute(cypher_query, params=operational_status)

    # 6. ACK message
    await msg.ack()
```

### Batch Processing
```python
# server/app/data_access/memgraphClient.py

def execute_with_dataframe(self, dataframe, query_template):
    records = dataframe.to_dicts()
    batch_size = 1000

    for i in range(0, len(records), batch_size):
        batch = records[i:i + batch_size]
        batch_query = f"""
            UNWIND $batch AS row
            {query_template}
        """
        session.run(batch_query, {"batch": batch})
```

---

## Security Architecture

### Authentication & Authorization
```python
# Current State: No authentication (internal network only)
# Recommended: API Key or OAuth2

# Future Implementation
@app.middleware("http")
async def verify_api_key(request: Request, call_next):
    api_key = request.headers.get("X-API-Key")
    if not verify_key(api_key):
        return JSONResponse(
            status_code=401,
            content={"error": "Unauthorized"}
        )
    return await call_next(request)
```

### Environment Variables (Secrets)
```bash
# Docker Compose (.env)
MEMGRAPH_URI=bolt://memgraph:7687
MEMGRAPH_USER=
MEMGRAPH_PASSWORD=
NATS_URL=nats://nats-server:4222
OLLAMA_BASE_URL=http://ollama:11434/v1
OLLAMA_MODEL=llama3.1-cypher:8b
LLM_TEMPERATURE=0.2
```

### Kubernetes Secrets
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: mcp-ticket-secrets
  namespace: mcp-ticket-system
type: Opaque
stringData:
  MEMGRAPH_PASSWORD: ""
  NATS_TOKEN: ""
```

---

## Performance Optimization

### Connection Pooling
```python
# Neo4j Driver (automatic pooling)
driver = GraphDatabase.driver(
    uri="bolt://memgraph:7687",
    auth=None,
    max_connection_pool_size=50,
    connection_timeout=30
)
```

### Query Optimization
```cypher
-- Use indexes for WHERE clauses
MATCH (c:Client) WHERE c.cl_id = 'Client_96757'  -- Index hit

-- Prefer CONTAINS over regex
WHERE LOWER(c.client_name) CONTAINS LOWER('acme')  -- Fast

-- Limit result sets
RETURN t LIMIT 100

-- Use EXPLAIN for query planning
EXPLAIN MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket) RETURN t
```

### Caching Strategy
```python
# BAML client caches schema descriptions
# No application-level caching (rely on Memgraph)
```

---

## Monitoring & Observability

### Logging Configuration
```python
# server/app/main.py
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("/app/logs/mcp_server.log"),
        logging.StreamHandler()
    ]
)
```

### Log Levels
```
DEBUG: Query execution details, BAML prompts
INFO: Tool invocations, connection status
WARNING: Retry attempts, missing data
ERROR: Query failures, connection errors
```

### Health Check Implementation
```python
# server/app/main.py
@http_app.get("/health")
async def health_check():
    try:
        memgraph_client.checkConnection()
        return {
            "status": "healthy",
            "service": "mcp_ticket_server",
            "memgraph_connected": True
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "service": "mcp_ticket_server",
            "memgraph_connected": False,
            "error": str(e)
        }
```

---

## Deployment Configurations

### Docker Compose (Development)
```yaml
# server/docker-compose.yml
version: '3.8'

services:
  mcp-ticket-server:
    build: .
    ports:
      - "8000:8000"
    environment:
      - MEMGRAPH_URI=bolt://memgraph:7687
      - NATS_URL=nats://10.250.99.61:4222
    depends_on:
      - memgraph
    volumes:
      - ./app:/app  # Hot reload

  memgraph:
    image: memgraph/memgraph-platform:latest
    ports:
      - "7687:7687"
      - "7444:7444"
    volumes:
      - memgraph-data:/var/lib/memgraph
```

### Kubernetes (Production)
```yaml
# server/k8s/mcp-ticket-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mcp-ticket-deployment
  namespace: mcp-ticket-system
spec:
  replicas: 3
  selector:
    matchLabels:
      app: mcp-ticket-server
  template:
    spec:
      containers:
      - name: mcp-ticket-server
        image: mcp-ticket-server:v2.0
        ports:
        - containerPort: 8000
        resources:
          requests:
            cpu: "500m"
            memory: "1Gi"
          limits:
            cpu: "2000m"
            memory: "4Gi"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 5
        envFrom:
        - configMapRef:
            name: mcp-ticket-config
        - secretRef:
            name: mcp-ticket-secrets
```

### HPA (Horizontal Pod Autoscaler)
```yaml
# server/k8s/hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: mcp-ticket-hpa
  namespace: mcp-ticket-system
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: mcp-ticket-deployment
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

---

## Error Handling

### Retry Logic
```python
# NATS Consumer
consecutive_errors = 0
max_consecutive_errors = 5

while True:
    try:
        msgs = await self.sub.fetch(batch=10, timeout=2.0)
        consecutive_errors = 0  # Reset on success
    except TimeoutError:
        continue  # Normal timeout
    except Exception as e:
        consecutive_errors += 1
        if consecutive_errors >= max_consecutive_errors:
            break
        await asyncio.sleep(min(consecutive_errors * 2, 10))
```

### Memgraph Connection Recovery
```python
# server/app/data_access/memgraphClient.py
def execute(self, query, params=None):
    max_retries = 3
    for attempt in range(max_retries):
        try:
            return session.run(query, params)
        except ServiceUnavailable:
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)
                continue
            raise
```

---

## Document Version Control
- **Version:** 3.0
- **Last Updated:** October 30, 2025
- **Next Review:** January 30, 2026
- **Change Log**:
  - v3.0 (Oct 30, 2025): **Async Performance Architecture** (43× speedup with strategic locking), **Semantic Search Integration** (Milvus vector database)
  - v2.0 (Oct 13, 2025): Memgraph migration (Bolt protocol, neo4j driver)
  - v1.0 (Sep 26, 2025): Initial architecture with Kuzu (file-based)

---

## Related Documentation
- **[Async Performance Architecture](../server/docs/ASYNC_PERFORMANCE_ARCHITECTURE.md)** - Detailed async implementation, locking strategy, visual diagrams, and tuning guidelines
- **[Phase 3 Semantic Search](../server/docs/PHASE3_SEMANTIC_SEARCH_ARCHITECTURE.md)** - Complete vector search architecture with Milvus integration
- **[System Specification](SYSTEM_SPECIFICATION.md)** - Functional and non-functional requirements
- **[Logical Architecture](LOGICAL_ARCHITECTURE.md)** - High-level component model and data flow
