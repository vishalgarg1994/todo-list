#!/usr/bin/env python3
"""
Load synthetic fault descriptions into Milvus for testing semantic search
"""
import asyncio
import json
import logging
from pathlib import Path

from configs.config import Config
from services.embedding_service import EmbeddingService
from data_access.milvusClient import MilvusClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def load_synthetic_data():
    """Load synthetic fault descriptions into Milvus"""

    # Load synthetic data
    data_file = Path("test_data/synthetic_fault_descriptions.json")
    if not data_file.exists():
        logger.error(f"Synthetic data file not found: {data_file}")
        return

    logger.info(f"Loading synthetic data from {data_file}")
    with open(data_file, 'r') as f:
        summaries = json.load(f)

    # Extract all fault descriptions
    all_faults = []
    for summary in summaries:
        all_faults.extend(summary['fault_descriptions'])

    logger.info(f"Found {len(all_faults)} fault descriptions")

    # Initialize services
    config = Config()
    embedding_service = EmbeddingService(config)
    milvus_client = MilvusClient(config)

    # Connect to Milvus
    milvus_client.connect()
    logger.info("Connected to Milvus")

    # Test Ollama connection
    if not embedding_service.test_connection():
        logger.error("Ollama service not available")
        return

    logger.info("Ollama service ready")

    # Process in batches
    batch_size = 10
    total_inserted = 0

    for i in range(0, len(all_faults), batch_size):
        batch = all_faults[i:i + batch_size]
        batch_num = (i // batch_size) + 1
        total_batches = (len(all_faults) + batch_size - 1) // batch_size

        logger.info(f"Processing batch {batch_num}/{total_batches} ({len(batch)} faults)")

        # Extract texts and IDs
        texts = [f['fault_description'] for f in batch]
        ids = [f['fault_description_id'] for f in batch]

        # Generate embeddings
        logger.info(f"  Generating embeddings for batch {batch_num}...")
        embeddings = embedding_service.generate_embeddings_batch(texts, batch_size=len(texts))

        if not embeddings or len(embeddings) != len(texts):
            logger.error(f"  Failed to generate embeddings for batch {batch_num}")
            continue

        # Insert into Milvus
        logger.info(f"  Inserting {len(embeddings)} embeddings into Milvus...")
        count = milvus_client.insert(ids, embeddings)
        total_inserted += count

        logger.info(f"  ✅ Batch {batch_num} complete ({count} inserted)")

    # Verify final count
    stats = milvus_client.get_collection_stats()
    logger.info(f"\n✅ Loading complete!")
    logger.info(f"   Total faults loaded: {total_inserted}")
    logger.info(f"   Collection stats: {stats}")

    milvus_client.disconnect()


if __name__ == "__main__":
    asyncio.run(load_synthetic_data())
