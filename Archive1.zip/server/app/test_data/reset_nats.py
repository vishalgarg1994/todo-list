"""
Reset NATS stream by deleting and recreating it
"""
import asyncio
from nats import connect
from nats.js import api

async def main():
    nc = await connect("nats://localhost:4222")
    js = nc.jetstream()

    try:
        # Try to delete the stream
        await js.delete_stream("TICKETS")
        print("✅ Deleted stream TICKETS")
    except Exception as e:
        print(f"Stream might not exist: {e}")

    # Recreate the stream
    await js.add_stream(
        name="TICKETS",
        subjects=["tickets.*"],
        storage=api.StorageType.FILE,
        retention=api.RetentionPolicy.WORK_QUEUE
    )
    print("✅ Recreated stream TICKETS")

    await nc.close()

if __name__ == "__main__":
    asyncio.run(main())
