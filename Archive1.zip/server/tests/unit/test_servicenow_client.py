"""
Tests for ServiceNowClient (WS-C Step 2)
"""
import pytest
from unittest.mock import MagicMock
import xml.etree.ElementTree as ET

from services.servicenow_client import (
    ServiceNowClient,
    NoteRecord,
    EmailRecord,
    FieldChangeRecord,
    TicketNotesData
)


class TestServiceNowClient:
    """Test suite for ServiceNowClient"""

    @pytest.fixture
    def mock_config(self):
        """Create a mock config"""
        config = MagicMock()
        config.servicenow_base_url = "https://test.service-now.com/api/v1"
        config.servicenow_username = "test_user"
        config.servicenow_password = "test_pass"
        config.servicenow_timeout = 30
        config.servicenow_max_concurrent = 5
        return config

    @pytest.fixture
    def client(self, mock_config):
        """Create client with mock config"""
        return ServiceNowClient(mock_config)

    def test_get_endpoints_case(self, client):
        """Test endpoint generation for case tickets"""
        endpoints = client._get_endpoints("case", "abc123")

        assert "/cases/abc123/notes" in endpoints["notes"]
        assert "/cases/abc123/emails" in endpoints["emails"]
        assert "/cases/abc123/field_changes" in endpoints["field_changes"]

    def test_get_endpoints_incident(self, client):
        """Test endpoint generation for incident tickets"""
        endpoints = client._get_endpoints("incident", "def456")

        assert "/incidents/def456/notes" in endpoints["notes"]
        assert "/incidents/def456/emails" in endpoints["emails"]
        assert "/incidents/def456/field_changes" in endpoints["field_changes"]

    def test_get_endpoints_unknown_type(self, client):
        """Test that unknown ticket type raises ValueError"""
        with pytest.raises(ValueError, match="Unknown ticket type"):
            client._get_endpoints("unknown", "abc123")

    def test_parse_notes_empty(self, client):
        """Test parsing empty notes response"""
        result = client._parse_notes(None)
        assert result == []

    def test_parse_notes_with_data(self, client):
        """Test parsing notes XML response"""
        xml_str = """
        <response>
            <data>
                <note>This is a work note</note>
                <created_on>2024-01-15 10:30:00</created_on>
                <element>work_notes</element>
            </data>
            <data>
                <note>Resolution note here</note>
                <created_on>2024-01-15 11:00:00</created_on>
                <element>resolution_notes</element>
            </data>
        </response>
        """
        xml_root = ET.fromstring(xml_str)
        notes = client._parse_notes(xml_root)

        assert len(notes) == 2
        assert notes[0].note_text == "This is a work note"
        assert notes[0].element_type == "work_notes"
        assert notes[1].element_type == "resolution_notes"

    def test_parse_emails_with_data(self, client):
        """Test parsing emails XML response"""
        xml_str = """
        <response>
            <data>
                <subject>Re: Ticket Update</subject>
                <from>tech@company.com</from>
                <to>customer@client.com</to>
                <body>Here is an update on your ticket.</body>
                <created_on>2024-01-15 12:00:00</created_on>
                <type>sent</type>
            </data>
        </response>
        """
        xml_root = ET.fromstring(xml_str)
        emails = client._parse_emails(xml_root)

        assert len(emails) == 1
        assert emails[0].subject == "Re: Ticket Update"
        assert emails[0].from_address == "tech@company.com"
        assert emails[0].email_type == "sent"

    def test_parse_field_changes_with_data(self, client):
        """Test parsing field_changes XML response"""
        xml_str = """
        <response>
            <data>
                <field>state</field>
                <old_value>In Progress</old_value>
                <new_value>Resolved</new_value>
                <created_on>2024-01-15 14:00:00</created_on>
            </data>
            <data>
                <field>resolution_code</field>
                <old_value>null</old_value>
                <new_value>Solved</new_value>
                <created_on>2024-01-15 14:00:00</created_on>
            </data>
        </response>
        """
        xml_root = ET.fromstring(xml_str)
        changes = client._parse_field_changes(xml_root)

        assert len(changes) == 2
        assert changes[0].field_name == "state"
        assert changes[0].old_value == "In Progress"
        assert changes[0].new_value == "Resolved"
        # "null" string should be converted to None
        assert changes[1].old_value is None

    def test_strip_html_tags(self, client):
        """Test HTML tag stripping"""
        html = "<html><body><p>Hello <b>World</b></p></body></html>"
        result = client._strip_html_tags(html)
        assert "Hello" in result
        assert "World" in result
        assert "<" not in result

    def test_combine_for_extraction(self, client):
        """Test combining ticket data for LLM extraction"""
        data = TicketNotesData(
            ticket_sys_id="abc123",
            ticket_id="CS0012345",
            ticket_type="case",
            notes=[
                NoteRecord(
                    note_text="Customer reported issue",
                    created_on="2024-01-15 10:00:00",
                    element_type="work_notes"
                )
            ],
            emails=[
                EmailRecord(
                    subject="Issue resolved",
                    from_address="tech@company.com",
                    to_address="customer@client.com",
                    body="Your issue has been resolved.",
                    created_on="2024-01-15 12:00:00",
                    email_type="sent"
                )
            ],
            field_changes=[
                FieldChangeRecord(
                    field_name="state",
                    old_value="Open",
                    new_value="Resolved",
                    created_on="2024-01-15 12:00:00"
                )
            ]
        )

        result = client.combine_for_extraction(data)

        assert "CS0012345" in result
        assert "case" in result
        assert "NOTES" in result
        assert "Customer reported issue" in result
        assert "EMAILS" in result
        assert "Issue resolved" in result
        assert "KEY FIELD CHANGES" in result
        assert "state" in result

    @pytest.mark.asyncio
    async def test_fetch_ticket_notes_unknown_type(self, client):
        """Test fetching notes for unknown ticket type"""
        result = await client.fetch_ticket_notes("abc123", "UNK0001", "unknown_type")

        assert result.fetch_success is False
        assert "Unknown ticket type" in result.error_message


class TestDataclasses:
    """Test the data classes"""

    def test_note_record_creation(self):
        """Test creating a NoteRecord"""
        note = NoteRecord(
            note_text="Test note",
            created_on="2024-01-15",
            element_type="work_notes"
        )
        assert note.note_text == "Test note"

    def test_email_record_creation(self):
        """Test creating an EmailRecord"""
        email = EmailRecord(
            subject="Test",
            from_address="a@b.com",
            to_address="c@d.com",
            body="Body",
            created_on="2024-01-15",
            email_type="sent"
        )
        assert email.subject == "Test"

    def test_field_change_record_creation(self):
        """Test creating a FieldChangeRecord"""
        change = FieldChangeRecord(
            field_name="state",
            old_value="Open",
            new_value="Closed",
            created_on="2024-01-15"
        )
        assert change.field_name == "state"

    def test_ticket_notes_data_defaults(self):
        """Test TicketNotesData default values"""
        data = TicketNotesData(
            ticket_sys_id="abc",
            ticket_id="INC001",
            ticket_type="incident"
        )
        assert data.notes == []
        assert data.emails == []
        assert data.field_changes == []
        assert data.fetch_success is True
        assert data.error_message is None
