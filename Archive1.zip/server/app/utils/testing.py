"""
Testing Hooks - Phase 1 Architecture

This module provides extensibility points for testing infrastructure, including
test doubles, fixtures, and dependency injection for tests.

Design Philosophy:
- Protocol-based: Define clear interfaces for dependencies
- Dependency injection: Easy to swap real implementations with test doubles
- Fixture factories: Reusable test data generation
- Isolation: Tests don't depend on external services

Usage:
    # In tests/test_tools.py:
    import pytest
    from utils.testing import TestDependencies

    @pytest.fixture
    def test_services():
        return {
            "memgraph_client": TestDependencies.create_mock_db(),
            "config": TestDependencies.create_test_config(),
        }

    async def test_get_ticket_details(test_services):
        # Mock returns known data
        test_services["memgraph_client"].execute.return_value = [
            {"id": "T1", "title": "Test Ticket"}
        ]

        result = await get_ticket_details("T1", services=test_services)
        assert result["id"] == "T1"

Future Implementation (Phase 2):
    - pytest fixtures in tests/conftest.py
    - Integration tests with test containers
    - E2E tests with real Memgraph test instance
    - Performance benchmarks
"""

from typing import Protocol, Dict, Any, List, Optional, runtime_checkable
from dataclasses import dataclass
from datetime import datetime
from unittest.mock import Mock, AsyncMock, MagicMock
import os


# ============================================================================
# Database Provider Protocol
# ============================================================================

@runtime_checkable
class DatabaseProvider(Protocol):
    """
    Protocol for database clients (Memgraph, Neo4j, etc.)

    This protocol defines the interface that MemgraphClient must implement,
    allowing tests to substitute mock implementations.
    """

    def execute(self, query: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """
        Execute a Cypher query.

        Args:
            query: Cypher query string
            params: Optional query parameters

        Returns:
            Query result (implementation-specific)
        """
        ...

    def close(self) -> None:
        """Close database connection."""
        ...

    def shutdown(self) -> None:
        """Shutdown database client."""
        ...


# ============================================================================
# Messaging Provider Protocol
# ============================================================================

@runtime_checkable
class MessagingProvider(Protocol):
    """
    Protocol for messaging systems (NATS, Kafka, RabbitMQ, etc.)

    This protocol defines the interface for message brokers, allowing
    tests to substitute mock implementations.
    """

    async def publish(self, subject: str, data: bytes) -> None:
        """
        Publish a message to a subject/topic.

        Args:
            subject: Message subject/topic
            data: Message payload (bytes)
        """
        ...

    async def subscribe(self, subject: str) -> Any:
        """
        Subscribe to a subject/topic.

        Args:
            subject: Message subject/topic

        Returns:
            Subscription object
        """
        ...

    async def close(self) -> None:
        """Close messaging connection."""
        ...


# ============================================================================
# LLM Provider Protocol
# ============================================================================

@runtime_checkable
class LLMProvider(Protocol):
    """
    Protocol for LLM clients (BAML, LangChain, etc.)

    This protocol defines the interface for LLM interactions, allowing
    tests to substitute mock implementations with predictable outputs.
    """

    async def generate_cypher(self, question: str, schema: str) -> str:
        """
        Generate Cypher query from natural language question.

        Args:
            question: User's natural language question
            schema: Database schema description

        Returns:
            Generated Cypher query
        """
        ...


# ============================================================================
# Test Fixture Factories
# ============================================================================

@dataclass
class TestTicket:
    """Test fixture for a ticket."""
    id: str = "TEST-001"
    title: str = "Test Ticket"
    description: str = "This is a test ticket"
    status: str = "Open"
    priority: str = "High"
    created_date: str = "2025-01-01T00:00:00Z"
    client_name: str = "Test Client"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary (as returned by database)."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "status": self.status,
            "priority": self.priority,
            "created_date": self.created_date,
            "client_name": self.client_name
        }


@dataclass
class TestClient:
    """Test fixture for a client."""
    name: str = "Test Client"
    industry: str = "Technology"
    total_tickets: int = 10
    open_tickets: int = 3
    closed_tickets: int = 7

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary (as returned by database)."""
        return {
            "name": self.name,
            "industry": self.industry,
            "total_tickets": self.total_tickets,
            "open_tickets": self.open_tickets,
            "closed_tickets": self.closed_tickets
        }


class TestDependencies:
    """
    Factory class for creating test doubles and fixtures.

    This class provides static methods to create mock implementations
    of all system dependencies, making it easy to write isolated unit tests.
    """

    @staticmethod
    def create_mock_db() -> Mock:
        """
        Create a mock database client.

        Returns:
            Mock database client with common methods stubbed
        """
        mock_db = Mock(spec=DatabaseProvider)
        mock_db.execute = Mock(return_value=[])
        mock_db.close = Mock()
        mock_db.shutdown = Mock()
        mock_db.connect = Mock()

        # Add common helper attributes
        mock_db.uri = "bolt://test:7687"
        mock_db.database = "test"

        return mock_db

    @staticmethod
    def create_mock_messaging() -> AsyncMock:
        """
        Create a mock messaging client.

        Returns:
            AsyncMock messaging client with common methods stubbed
        """
        mock_messaging = AsyncMock(spec=MessagingProvider)
        mock_messaging.publish = AsyncMock()
        mock_messaging.subscribe = AsyncMock()
        mock_messaging.close = AsyncMock()

        return mock_messaging

    @staticmethod
    def create_mock_llm() -> AsyncMock:
        """
        Create a mock LLM client.

        Returns:
            AsyncMock LLM client that returns predictable Cypher queries
        """
        mock_llm = AsyncMock(spec=LLMProvider)

        # Default behavior: return a simple MATCH query
        mock_llm.generate_cypher = AsyncMock(
            return_value="MATCH (t:Ticket {id: $ticket_id}) RETURN t"
        )

        return mock_llm

    @staticmethod
    def create_test_config() -> Mock:
        """
        Create a test configuration object.

        Returns:
            Mock Config with test values
        """
        mock_config = Mock()

        # Database config
        mock_config.memgraph_uri = os.getenv("TEST_MEMGRAPH_URI", "bolt://localhost:7688")
        mock_config.memgraph_user = ""
        mock_config.memgraph_password = ""
        mock_config.memgraph_database = "test"

        # Messaging config
        mock_config.nats_url = os.getenv("TEST_NATS_URL", "nats://localhost:4223")
        mock_config.jetstream_stream_name = "TEST_STREAM"
        mock_config.ticket_publish_subject = "tickets.test"
        mock_config.ticket_subscribe_subject = "tickets.test"

        # File paths
        mock_config.schema_desc_path = "/app/data_access/cyphers/ticket_schema_description.yaml"

        # LLM config
        mock_config.llm_temperature = 0.0  # Deterministic for testing

        # Environment
        mock_config.environment = "test"
        mock_config.enable_test_fixtures = True

        # Observability (disabled in tests by default)
        mock_config.observability_enabled = False
        mock_config.metrics_provider = "noop"
        mock_config.tracing_provider = "noop"

        # Security (disabled in tests by default)
        mock_config.auth_enabled = False
        mock_config.auth_provider = "noop"
        mock_config.audit_enabled = False

        return mock_config

    @staticmethod
    def create_test_services() -> Dict[str, Any]:
        """
        Create a complete test services dictionary.

        This provides all the dependencies that would normally be in
        app.state.services, but with mock implementations.

        Returns:
            Dictionary of test services
        """
        return {
            "memgraph_client": TestDependencies.create_mock_db(),
            "baml_client": TestDependencies.create_mock_llm(),
            "http_client": AsyncMock(),
            "ticket_schema_description": {"nodes": [], "relationships": []},
            "config": TestDependencies.create_test_config(),
            "background_tasks": []
        }

    @staticmethod
    def create_test_ticket(
        ticket_id: str = "TEST-001",
        title: str = "Test Ticket",
        status: str = "Open",
        priority: str = "High",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Create a test ticket fixture.

        Args:
            ticket_id: Ticket ID
            title: Ticket title
            status: Ticket status
            priority: Ticket priority
            **kwargs: Additional ticket attributes

        Returns:
            Ticket dictionary
        """
        ticket = TestTicket(
            id=ticket_id,
            title=title,
            status=status,
            priority=priority
        )

        ticket_dict = ticket.to_dict()
        ticket_dict.update(kwargs)
        return ticket_dict

    @staticmethod
    def create_test_client(
        name: str = "Test Client",
        industry: str = "Technology",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Create a test client fixture.

        Args:
            name: Client name
            industry: Client industry
            **kwargs: Additional client attributes

        Returns:
            Client dictionary
        """
        client = TestClient(name=name, industry=industry)

        client_dict = client.to_dict()
        client_dict.update(kwargs)
        return client_dict

    @staticmethod
    def create_test_database_result(records: List[Dict[str, Any]]) -> Mock:
        """
        Create a mock database result.

        Args:
            records: List of record dictionaries

        Returns:
            Mock result object that behaves like Memgraph result
        """
        mock_result = Mock()
        mock_result.__iter__ = Mock(return_value=iter(records))
        mock_result.data = Mock(return_value=records)

        # For individual record access
        mock_records = []
        for record in records:
            mock_record = Mock()
            mock_record.data = Mock(return_value=record)
            mock_records.append(mock_record)

        mock_result.records = mock_records
        return mock_result


# ============================================================================
# In-Memory Test Database (Future Phase 2)
# ============================================================================

class InMemoryGraphDB:
    """
    Simple in-memory graph database for testing.

    This is a placeholder for Phase 2 implementation. In Phase 2, this would
    provide a lightweight in-memory graph structure that supports basic
    Cypher queries for fast unit tests.

    For now, tests should use mocks (TestDependencies.create_mock_db()).
    """

    def __init__(self):
        self.nodes: Dict[str, Dict[str, Any]] = {}
        self.relationships: List[Dict[str, Any]] = []

    def add_node(self, label: str, properties: Dict[str, Any]) -> str:
        """Add a node and return its ID."""
        node_id = f"{label}_{len(self.nodes)}"
        self.nodes[node_id] = {"label": label, **properties}
        return node_id

    def add_relationship(self, from_id: str, to_id: str, rel_type: str, properties: Dict[str, Any] = None):
        """Add a relationship between two nodes."""
        self.relationships.append({
            "from": from_id,
            "to": to_id,
            "type": rel_type,
            "properties": properties or {}
        })

    def clear(self):
        """Clear all nodes and relationships."""
        self.nodes.clear()
        self.relationships.clear()


# ============================================================================
# Test Utilities
# ============================================================================

def assert_cypher_contains(cypher: str, *keywords: str) -> None:
    """
    Assert that a Cypher query contains specific keywords.

    Args:
        cypher: The Cypher query string
        *keywords: Keywords that must be present (case-insensitive)

    Raises:
        AssertionError: If any keyword is missing
    """
    cypher_upper = cypher.upper()
    for keyword in keywords:
        assert keyword.upper() in cypher_upper, f"Cypher query missing keyword: {keyword}"


def assert_cypher_valid_syntax(cypher: str) -> None:
    """
    Perform basic syntax validation on a Cypher query.

    Args:
        cypher: The Cypher query string

    Raises:
        AssertionError: If query has obvious syntax issues
    """
    # Check for balanced parentheses
    assert cypher.count("(") == cypher.count(")"), "Unbalanced parentheses in Cypher query"

    # Check for balanced brackets
    assert cypher.count("[") == cypher.count("]"), "Unbalanced brackets in Cypher query"

    # Check for balanced braces
    assert cypher.count("{") == cypher.count("}"), "Unbalanced braces in Cypher query"

    # Check for at least one clause
    cypher_upper = cypher.upper()
    has_clause = any(
        clause in cypher_upper
        for clause in ["MATCH", "CREATE", "MERGE", "DELETE", "RETURN", "WITH"]
    )
    assert has_clause, "Cypher query missing any valid clause (MATCH, CREATE, etc.)"


def is_test_environment() -> bool:
    """
    Check if running in test environment.

    Returns:
        True if ENVIRONMENT=test or pytest is running
    """
    import sys
    return (
        os.getenv("ENVIRONMENT", "").lower() == "test"
        or "pytest" in sys.modules
        or "unittest" in sys.modules
    )
