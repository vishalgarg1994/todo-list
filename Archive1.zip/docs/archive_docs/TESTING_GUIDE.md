# Testing Guide

## Overview

This guide provides comprehensive documentation for testing the MCP Ticket System, covering all test suites from unit tests to end-to-end integration tests. The system uses pytest as the primary testing framework with support for both synchronous and asynchronous tests.

## Quick Start

### Running All Tests

```bash
# From server directory
cd /Users/aklilugebreyesus/projects/eva/mcp_ticket/server

# Run all tests (requires services running)
pytest tests/ -v

# Run only unit tests (no services needed)
pytest tests/unit/ -v

# Run only integration tests (requires services)
pytest tests/integration/ -v -m integration
```

### Running Specific Test Suites

```bash
# Phase 3 vector search tests
pytest tests/unit/test_embedding_service.py -v
pytest tests/unit/test_milvus_client.py -v
pytest tests/integration/test_fault_description_consumer.py -v

# Enhanced schema tests
pytest tests/integration/test_enhanced_ingestion.py -v
pytest tests/integration/test_schema_validation.py -v

# MCP server tests
pytest tests/unit/test_mcp_client.py -v
pytest tests/unit/test_serialization.py -v
```

### Using the Test Runner Script

```bash
# Run unit tests in Docker (default)
./tests/run_tests.sh

# Run unit tests locally (creates venv)
./tests/run_tests.sh --local

# Run integration tests
./tests/run_tests.sh tests/integration/ -v -m integration

# Run specific test file
./tests/run_tests.sh tests/unit/test_embedding_service.py -v
```

## Test Organization

### Directory Structure

```
tests/
├── conftest.py                              # Shared pytest fixtures
├── fixtures/                                # Test data and fixtures
├── data/                                    # Test data files (JSON)
│   ├── enhanced_ticket_payload.json        # Complete test data
│   ├── minimal_ticket_payload.json         # Minimal required fields
│   └── edge_case_payload.json              # Edge cases and nulls
├── unit/                                    # Unit tests (mocked dependencies)
│   ├── test_embedding_service.py           # Ollama embedding service
│   ├── test_milvus_client.py               # Milvus client
│   ├── test_mcp_client.py                  # MCP client
│   ├── test_serialization.py               # Data serialization
│   └── test_subscription.py                # Subscription handling
├── integration/                             # Integration tests (require services)
│   ├── test_fault_description_consumer.py  # End-to-end consumer tests
│   ├── test_enhanced_ingestion.py          # Enhanced schema ingestion
│   └── test_schema_validation.py           # Schema structure validation
├── run_tests.sh                            # Test runner script
├── run_enhanced_tests.py                   # Enhanced schema test runner
└── README_PHASE3.md                        # Phase 3 test documentation
```

### Test Categories

**Unit Tests** (`tests/unit/`)
- No external dependencies - all services mocked
- Fast execution (<1s total)
- Can run anywhere (CI, local, Docker)
- Focus on logic and error handling
- Test individual components in isolation

**Integration Tests** (`tests/integration/`)
- Require real services - Milvus, Ollama, Memgraph
- Slower execution (~30s total)
- Test actual service integration
- Validate end-to-end workflows
- Test component interactions

**Test Markers:**
- `@pytest.mark.integration` - Requires external services
- `@pytest.mark.asyncio` - Async test requiring event loop

## Unit Tests

### What's Covered

#### Embedding Service Tests (`test_embedding_service.py`)

**Coverage**: ~95% of `embedding_service.py`
**Test Count**: 15 tests

**Key Tests:**
- Service initialization
- Successful embedding generation (768-dimensional vectors)
- Long text truncation (>25K characters)
- Invalid response handling
- Wrong dimension handling (expects 768)
- Timeout handling
- HTTP error handling
- Batch embedding generation
- Partial batch failures
- Connection testing
- Model info retrieval

**Example:**
```python
def test_generate_embedding_success(mock_post, service):
    """Verifies 768-dim embeddings are generated correctly"""
    # All external dependencies are mocked
```

#### Milvus Client Tests (`test_milvus_client.py`)

**Coverage**: ~90% of `milvusClient.py`
**Test Count**: 18 tests

**Key Tests:**
- Client initialization
- Connection to existing collection
- Collection creation if not exists
- Schema validation (id, fault_description_id, embedding)
- Index creation (IVF_FLAT, COSINE)
- Successful insertion
- Mismatched ID/embedding lengths
- Insertion without connection
- Successful search
- Custom nprobe parameter
- Search without connection
- Collection count
- Deletion by IDs
- Disconnection

**Example:**
```python
def test_search_success(client):
    """Verifies vector search returns correct results"""
    # Milvus client is mocked
```

### How to Run

```bash
# Run all unit tests
pytest tests/unit/ -v

# Run specific test file
pytest tests/unit/test_embedding_service.py -v

# Run with coverage report
pytest tests/unit/ --cov=app --cov-report=html

# Run specific test
pytest tests/unit/test_embedding_service.py::test_generate_embedding_success -v
```

### How to Write New Tests

**1. Create test file in `tests/unit/`**

```python
# tests/unit/test_my_component.py
import pytest
from unittest.mock import Mock, patch
from app.services.my_component import MyComponent

@pytest.fixture
def component():
    """Fixture for component under test"""
    return MyComponent()

def test_my_feature(component):
    """Test description"""
    # Arrange
    expected = "result"

    # Act
    result = component.do_something()

    # Assert
    assert result == expected
```

**2. Use mocks for external dependencies**

```python
@patch('services.my_component.external_api')
def test_with_mock(mock_api, component):
    """Test with mocked external API"""
    mock_api.return_value = {"status": "success"}

    result = component.call_api()

    assert result["status"] == "success"
    mock_api.assert_called_once()
```

**3. Follow naming conventions**

- Test files: `test_*.py`
- Test functions: `test_*`
- Fixtures: Descriptive names (e.g., `component`, `sample_data`)

## Integration Tests

### Server Integration Tests

#### Enhanced Schema Ingestion (`test_enhanced_ingestion.py`)

**Purpose**: Test end-to-end ingestion of tickets into Memgraph with the enhanced schema

**Test Count**: 6+ tests

**Key Tests:**
- Complete ticket ingestion (all knowledge graph entities)
- Minimal ticket ingestion (sparse data)
- Edge case ingestion (nulls, empty arrays, invalid data)
- Node count validation
- Relationship count validation
- Data integrity verification

**Example:**
```bash
# Run enhanced ingestion tests
python tests/integration/test_enhanced_ingestion.py

# Or using pytest
pytest tests/integration/test_enhanced_ingestion.py -v
```

**Expected Output:**
```
✅ Enhanced ticket processed successfully
✅ Minimal ticket processed successfully
✅ Edge case ticket processed successfully
✅ All expected node types found
✅ Relationships created successfully
✅ Data integrity verified
```

#### Schema Validation (`test_schema_validation.py`)

**Purpose**: Validate enhanced schema structure in Memgraph

**Test Count**: 5+ tests

**Key Tests:**
- Enhanced schema creation
- Node table validation (11 types)
- Relationship table validation (18 types)
- Data type validation (STRING, INT64, BOOLEAN, DOUBLE)
- Sample analytics queries
- Schema statistics

**Node Types Validated (11):**
1. Client - Enterprise client management
2. Service - Enhanced service tracking
3. Incident - Impact and description tracking
4. Ticket - Complete lifecycle management
5. Outage_Info - Communication timeline
6. UserInfo - User attribution and roles
7. ContactInfo - Multi-type contact management
8. VendorInfo - Vendor/supplier tracking
9. MaintenanceWindow - Scheduled maintenance
10. SurveyInfo - Customer satisfaction
11. NOCInfo - Operations center assignment

**Relationship Types Validated (18):**
- Core: HAS_TICKET, HAS_OUTAGE_INFO, TRIGGERED_BY, IMPACTS, CHILD_OF
- Tickets: LINKED_TO
- Users: CREATED_BY, ASSIGNED_TO, CLOSED_BY, FIRST_ASSIGNED_TO
- Contacts: HAS_CONTACT, TICKET_CONTACT
- Vendors: HANDLED_BY, SUPPLIED_BY
- Maintenance: HAS_MAINTENANCE, DURING_MAINTENANCE
- Survey: HAS_SURVEY
- NOC: ASSIGNED_TO_NOC, MONITORED_BY_NOC

### Database Integration Tests

**Prerequisites:**
- Memgraph running on `bolt://localhost:7687`
- Enhanced schema loaded

**Run Tests:**
```bash
# Ensure Memgraph is running
docker ps | grep memgraph

# Run schema tests
python tests/integration/test_schema_validation.py

# Or using pytest
pytest tests/integration/ -v
```

### MCP Tool Tests

Tests for semantic search MCP tools are located in the integration test suite.

**Test Script**: `tests/test_semantic_search_tools.py`

**Manual Testing with curl:**

```bash
# Test 1: List tools (verify registration)
curl -X POST http://localhost:8003/mcp/v1/tools/list | jq '.tools[] | select(.name | contains("search_similar"))'

# Test 2: search_similar_faults
curl -X POST http://localhost:8003/mcp/v1/tools/call \
  -H "Content-Type: application/json" \
  -d '{"name": "search_similar_faults", "arguments": {"query": "fiber cable cut", "top_k": 5}}'

# Test 3: search_similar_tickets
curl -X POST http://localhost:8003/mcp/v1/tools/call \
  -H "Content-Type: application/json" \
  -d '{"name": "search_similar_tickets", "arguments": {"query": "BGP routing problem", "top_k": 5}}'

# Test 4: search_similar_resolutions
curl -X POST http://localhost:8003/mcp/v1/tools/call \
  -H "Content-Type: application/json" \
  -d '{"name": "search_similar_resolutions", "arguments": {"query": "power outage", "top_k": 5}}'
```

## Phase 3 Semantic Search Tests

### Vector Search Tests

#### Fault Description Consumer Tests (`test_fault_description_consumer.py`)

**Coverage**: Full end-to-end workflows
**Test Count**: 10 tests + 1 end-to-end test

**Requirements:**
- Milvus running on localhost:19530
- Ollama running on localhost:11434 with `nomic-embed-text:latest` model

**Key Tests:**
- Milvus connection verification
- Ollama connection verification
- Generate embeddings and search (full flow)
- Process fault description batch
- TEST_MODE with synthetic data (505 fault descriptions)
- Similarity scoring validation (cable vs BGP faults)
- Empty batch handling
- Partial embedding failures
- End-to-end search workflow (4 test cases)

**End-to-End Test:**
```python
@pytest.mark.integration
@pytest.mark.asyncio
async def test_end_to_end_search_workflow():
    """
    Complete workflow:
    1. Insert 4 different fault types (fiber, MPLS, BGP, cable)
    2. Search for "cable damage" → returns fiber + cable faults
    3. Search for "BGP problem" → returns BGP fault
    4. Search for "packet drops" → returns MPLS fault

    Validates semantic search accuracy.
    """
```

**Run Tests:**
```bash
# Start required services
docker-compose up -d milvus ollama

# Wait for services to be ready
sleep 30

# Run integration tests
pytest tests/integration/test_fault_description_consumer.py -v -m integration

# Or run specific test
pytest tests/integration/test_fault_description_consumer.py::test_end_to_end_search_workflow -v
```

### Embedding Tests

Located in `tests/unit/test_embedding_service.py`

**Key Tests:**
- 768-dimensional embedding generation
- Text truncation for long inputs (>25K chars)
- Batch processing with error recovery
- Connection verification
- Model information retrieval

**All tests use mocks** - no external dependencies required.

### End-to-End Semantic Search

**Service Dependencies:**
All containers must be running:
- mcp_ticket_server
- milvus-standalone
- mcp-ollama
- memgraph
- milvus-etcd
- milvus-minio

**Performance Expectations:**

| Tool | Expected Latency | What It Returns |
|------|-----------------|-----------------|
| search_similar_faults | < 200ms | Similarity scores only |
| search_similar_tickets | < 300ms | + Ticket/incident metadata |
| search_similar_resolutions | < 400ms | + Full OutageInfo (MTTR, RFO) |

**Expected Behavior:**
- If Milvus is empty: tools return "No similar faults found" with suggestions
- If Ollama is down: tools return ToolError with troubleshooting hints
- If Memgraph enrichment fails: vector results still returned with null metadata

## Client Tests

### Client-Specific Testing

**Location**: `/Users/aklilugebreyesus/projects/eva/mcp_ticket/client/TESTING.md`

#### Test All Tools

```bash
cd client/app
python test_tools.py
```

#### Test Single Tool

```bash
python test_tools.py --tool get_client_summary --params '{"client_name": "Acme Corp"}'
```

#### Test with Natural Language

```bash
python ask_eva.py "How many open tickets are there?"
```

### Available Tools for Testing

| Tool Name | Purpose | Example Parameters |
|-----------|---------|-------------------|
| `ask_tickets_question` | Natural language queries | `{"user_query": "Show me all P1 tickets"}` |
| `get_ticket_details` | Complete ticket graph | `{"ticket_id": "INC123"}` |
| `get_client_tickets` | All tickets for client | `{"client_name": "Acme"}` |
| `get_ticket_timeline` | Lifecycle timeline | `{"ticket_id": "INC123"}` |
| `get_client_summary` | Client statistics | `{"client_name": "Acme"}` |
| `get_tickets_by_status` | Filter by status | `{"status": "Open"}` |
| `get_high_priority_tickets` | Urgent tickets | `{"priority_threshold": 2}` |
| `get_ticket_relationships` | Related tickets | `{"ticket_id": "INC123"}` |
| `trace_ticket_root_cause` | Root cause tracer | `{"ticket_id": "INC123"}` |
| `get_vendor_tickets` | Vendor analysis | `{"vendor_name": "Vendor X"}` |
| `get_service_outages` | Service outages | `{"technology": "Fiber"}` |
| `get_tickets_by_date_range` | Date filtering | `{"start_date": "2024-01-01", "end_date": "2024-12-31"}` |
| `get_ticket_contacts` | Contact lookup | `{"ticket_id": "INC123"}` |

### Client Configuration

Edit `client/app/config.yaml`:
- **Server URL**: `http://localhost:8003` (default)
- **Ollama**: Optional, only needed for natural language queries

## Performance Tests

### Load Testing

Performance benchmarks based on local testing (M1 Mac, no GPU):

- **Embedding generation**: ~10 embeddings/sec
- **Milvus insertion**: ~1000 embeddings/sec
- **Vector search**: <10ms for 500K vectors (IVF_FLAT)

### Benchmarking

**Integration Test Duration:**
- `test_milvus_connection`: <1s
- `test_ollama_connection`: ~1s
- `test_generate_and_search_embeddings`: ~5s
- `test_end_to_end_search_workflow`: ~8s
- **Total integration suite**: ~30s

**Unit Test Duration:**
- All unit tests: <1s total
- Individual test: <0.1s

### Performance Testing Script

```bash
# Run integration tests with timing
pytest tests/integration/ -v --durations=10

# Run with profiling
pytest tests/integration/ --profile

# Load testing (requires 100K+ test data)
python tests/integration/test_fault_description_consumer.py --load-test
```

## CI/CD Testing

### Automated Test Runs

**GitHub Actions Example:**

```yaml
name: MCP Ticket Tests

on: [push, pull_request]

jobs:
  unit-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - run: pip install -r app/requirements.txt
      - run: pytest tests/unit/ -v --cov=app --cov-report=xml
      - uses: codecov/codecov-action@v3

  integration-tests:
    runs-on: ubuntu-latest
    services:
      memgraph:
        image: memgraph/memgraph:latest
        ports:
          - 7687:7687
      milvus:
        image: milvusdb/milvus:v2.3.3
        ports:
          - 19530:19530
      ollama:
        image: ollama/ollama:latest
        ports:
          - 11434:11434
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - run: pip install -r app/requirements.txt
      - run: pytest tests/integration/ -v -m integration
```

### Pre-commit Checks

**Install pre-commit hooks:**

```bash
# Install pre-commit
pip install pre-commit

# Install hooks
pre-commit install

# Run manually
pre-commit run --all-files
```

**Example `.pre-commit-config.yaml`:**

```yaml
repos:
  - repo: local
    hooks:
      - id: pytest-unit
        name: Run Unit Tests
        entry: pytest tests/unit/ -v
        language: system
        pass_filenames: false
        always_run: true
```

### Docker-based CI

```bash
# Run tests in Docker container
docker-compose run --rm mcp_ticket_server pytest tests/unit/ -v

# Run with coverage
docker-compose run --rm mcp_ticket_server pytest tests/unit/ --cov=app --cov-report=term
```

## Test Data

### Synthetic Data Usage

**Location**: `/Users/aklilugebreyesus/projects/eva/mcp_ticket/server/test_data/`

**Files:**
- `synthetic_fault_descriptions.py` - Generator script
- `synthetic_fault_descriptions.json` - 10 clients, ~500 fault descriptions
- `long_fault_descriptions_obfuscated.json` - Realistic samples with length distribution

**Regenerate Synthetic Data:**

```bash
cd /Users/aklilugebreyesus/projects/eva/mcp_ticket/server/test_data
python3 synthetic_fault_descriptions.py
```

**Output:**
```json
{
  "fault_description_summaries": [
    {
      "fault_description_summary_id": "CLIENT001_part_1_of_1",
      "client_id": "CLIENT001",
      "fault_descriptions": [
        {
          "fault_description_id": "FD001",
          "fault_description": "Fiber optic cable damaged at junction...",
          "fault_code": "FIBER_CUT",
          ...
        }
      ]
    }
  ]
}
```

### Test Fixtures

**Shared Fixtures in `conftest.py`:**

```python
@pytest.fixture(scope="session")
def event_loop():
    """Create event loop for async tests"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture
def sample_fault_descriptions():
    """Sample fault descriptions for testing"""
    return [
        {
            "fault_description_id": "TEST001",
            "fault_description": "Fiber cable cut at Main Street intersection...",
            "fault_code": "FIBER_CUT"
        },
        {
            "fault_description_id": "TEST002",
            "fault_description": "BGP routing issue causing packet loss...",
            "fault_code": "BGP_ISSUE"
        }
    ]
```

**Enhanced Schema Test Data:**

```
tests/data/
├── enhanced_ticket_payload.json    # Complete test data with all entities
├── minimal_ticket_payload.json     # Minimal required fields only
└── edge_case_payload.json          # Nulls, empty arrays, edge cases
```

**Enhanced Ticket Payload** includes:
- Client with enterprise fields (client_group, client_tier)
- Service with operational fields (related_circuit_id, source_system)
- Incident with impact tracking (is_customer_impacting)
- Ticket with lifecycle tracking (priority, escalation_level, dates)
- Outage with communication timeline (email times, dispatch events)
- Users array (created_by, assigned_to, first_assigned_to roles)
- Contacts array (customer, poc_a_end, poc_z_end types)
- Vendors array (with vendor_downtime floats)
- Maintenance window (scheduled work details)
- Survey info (customer satisfaction feedback)
- NOC info (operations center assignment)

## Troubleshooting

### Common Test Failures

#### 1. Module Import Errors

**Symptom:**
```
ModuleNotFoundError: No module named 'app'
```

**Solution:**
```bash
# Ensure app is in Python path
export PYTHONPATH=/Users/aklilugebreyesus/projects/eva/mcp_ticket/server/app:$PYTHONPATH

# Or run from server directory
cd /Users/aklilugebreyesus/projects/eva/mcp_ticket/server
pytest tests/
```

#### 2. Service Connection Errors

**Symptom:**
```
ConnectionError: Cannot connect to Milvus
```

**Solution:**
```bash
# Check if services are running
docker-compose ps

# Start required services
docker-compose up -d milvus ollama memgraph

# Wait for startup
sleep 30

# Verify connections
curl http://localhost:9091/healthz  # Milvus
curl http://localhost:11434/api/tags  # Ollama
```

#### 3. Ollama Service Not Available

**Symptom:**
```
ERROR: Ollama service not available
```

**Solution:**
```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# Start Ollama
docker-compose up -d ollama

# Pull model if not loaded
docker exec mcp-ollama ollama pull nomic-embed-text:latest

# Verify model is loaded
curl http://localhost:11434/api/tags | jq '.models[] | select(.name | contains("nomic-embed"))'
```

#### 4. Memgraph Database Errors

**Symptom:**
```
neo4j.exceptions.ServiceUnavailable: Could not connect to bolt://localhost:7687
```

**Solution:**
```bash
# Check if Memgraph is running
docker ps | grep memgraph

# Start Memgraph
docker-compose up -d memgraph

# Verify connection
docker exec memgraph mgconsole --use-ssl=False -e "MATCH (n) RETURN count(n);"
```

#### 5. Test Collection Already Exists

**Symptom:**
```
Error: Collection 'test_fault_descriptions' already exists
```

**Solution:**
```bash
# Tests should cleanup automatically, but if tests crash:

# Option 1: Restart Milvus
docker-compose restart milvus

# Option 2: Drop collection manually (requires Milvus CLI)
# milvus_cli > drop collection -c test_fault_descriptions
```

#### 6. Schema Errors

**Symptom:**
```
FileNotFoundError: enhanced schema file not found
```

**Solution:**
```bash
# Verify enhanced schema file exists
ls -la /Users/aklilugebreyesus/projects/eva/mcp_ticket/server/app/data_access/cyphers/load_tickets_cypher.yaml

# If missing, check git status
git status
```

#### 7. Slow Integration Tests

**Cause**: Embedding generation is the bottleneck (~10 embeddings/sec)

**Solutions:**
1. Use GPU for Ollama (10-100x faster)
2. Reduce batch sizes in tests
3. Mock embedding service in some integration tests
4. Run only unit tests during development

#### 8. Client Connection Refused

**Symptom:**
```
Connection refused: http://localhost:8003
```

**Solution:**
```bash
# Check server is running
docker ps | grep mcp_ticket

# Start server
docker-compose up -d mcp_ticket_server

# Check port
curl http://localhost:8003/health/live

# Check logs
docker-compose logs mcp_ticket_server
```

#### 9. Tool Not Found

**Symptom:**
```
Error: Tool 'search_similar_faults' not found
```

**Solution:**
```bash
# Restart server
docker-compose restart mcp_ticket_server

# Check logs for tool registration
docker-compose logs mcp_ticket_server | grep "Registered tool"

# Verify tools are listed
curl http://localhost:8003/mcp/v1/tools/list | jq '.tools[].name'
```

### Debug Techniques

#### 1. Enable Debug Logging

**In test files:**
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

**In pytest:**
```bash
pytest tests/ -v --log-cli-level=DEBUG
```

#### 2. Run Single Test with Verbose Output

```bash
pytest tests/unit/test_embedding_service.py::test_generate_embedding_success -vv -s
```

#### 3. Use pytest Debugger

```bash
# Drop into debugger on failure
pytest tests/ --pdb

# Drop into debugger at start of test
pytest tests/ --trace
```

#### 4. Check Service Logs

```bash
# Milvus logs
docker-compose logs milvus

# Ollama logs
docker-compose logs ollama

# Memgraph logs
docker-compose logs memgraph

# MCP Server logs
docker-compose logs mcp_ticket_server
```

#### 5. Verify Test Data

```bash
# Check test data files exist
ls -la tests/data/*.json

# Validate JSON
cat tests/data/enhanced_ticket_payload.json | jq .

# Check synthetic data
cat test_data/synthetic_fault_descriptions.json | jq '.fault_description_summaries | length'
```

#### 6. Clean Up Test Artifacts

```bash
# Remove test collections from Milvus
docker-compose restart milvus

# Clear Memgraph test data
docker exec memgraph mgconsole --use-ssl=False -e "MATCH (n) DETACH DELETE n;"

# Remove pytest cache
rm -rf .pytest_cache/
rm -rf tests/__pycache__/
```

## Test Coverage Summary

| Component | Unit Tests | Integration Tests | Coverage |
|-----------|------------|-------------------|----------|
| `embedding_service.py` | 15 tests | Included in consumer | ~95% |
| `milvusClient.py` | 18 tests | Included in consumer | ~90% |
| `fault_description_consumer.py` | 0 tests (TODO) | 11 tests | ~80% |
| Enhanced schema ingestion | N/A | 6+ tests | ~85% |
| Schema validation | N/A | 5+ tests | ~90% |
| MCP tools | TBD | Manual + automated | TBD |
| **Total** | **33+ tests** | **22+ tests** | **~85%** |

### Coverage Reports

**Generate HTML Coverage Report:**

```bash
# Run tests with coverage
pytest tests/unit/ --cov=app --cov-report=html

# Open report
open htmlcov/index.html
```

**Generate Terminal Coverage Report:**

```bash
pytest tests/unit/ --cov=app --cov-report=term-missing
```

**Expected Output:**
```
Name                                  Stmts   Miss  Cover   Missing
-------------------------------------------------------------------
app/services/embedding_service.py       120      6    95%   45-48
app/services/milvusClient.py            150     15    90%   89-92, 156-160
app/data_access/message_handler.py      200     30    85%   ...
-------------------------------------------------------------------
TOTAL                                  1500    150    90%
```

## Best Practices

### Writing New Tests

1. **Unit tests**: Mock all external dependencies
   ```python
   @patch('services.embedding_service.requests.post')
   def test_something(mock_post):
       # Test logic here
   ```

2. **Integration tests**: Mark with `@pytest.mark.integration`
   ```python
   @pytest.mark.integration
   @pytest.mark.asyncio
   async def test_something():
       # Test logic here
   ```

3. **Always cleanup**: Use fixtures with `yield` for teardown
   ```python
   @pytest.fixture
   async def consumer():
       c = FaultDescriptionConsumer()
       yield c
       await c.stop()  # Cleanup
   ```

4. **Use descriptive names**: Test names should describe what they verify
   ```python
   def test_consumer_handles_empty_batch()  # Good
   def test_consumer_1()                    # Bad
   ```

### Test Data Management

- Use fixtures for reusable test data (see `conftest.py`)
- Keep test data small (3-5 samples for unit tests)
- Use synthetic data for integration tests
- Always cleanup test data from databases after integration tests
- Version control test data files

### Running Tests Efficiently

```bash
# Run only failed tests from last run
pytest --lf

# Run tests in parallel (requires pytest-xdist)
pytest -n auto

# Stop on first failure
pytest -x

# Run specific marker
pytest -m integration

# Skip specific marker
pytest -m "not integration"
```

## Next Steps

### Remaining Test Gaps

1. **Unit tests for consumer** - Add mocked unit tests for `FaultDescriptionConsumer`
2. **Performance tests** - Load testing with 100K+ embeddings
3. **NATS mode tests** - Integration tests for NATS message consumption
4. **Error recovery tests** - Test consumer restart and state recovery
5. **MCP tool unit tests** - Add unit tests for semantic search tools

### Future Enhancements

1. **Security testing** - Auth, rate limiting, input validation
2. **Stress testing** - High concurrency, memory leaks
3. **Chaos engineering** - Service failures, network partitions
4. **End-to-end user workflows** - Complete AI assistant scenarios
5. **Performance benchmarking** - Automated regression detection

## References

- **Pytest Documentation**: https://docs.pytest.org/
- **Pytest-asyncio**: https://pytest-asyncio.readthedocs.io/
- **Mocking Guide**: https://docs.python.org/3/library/unittest.mock.html
- **Milvus Python SDK**: https://milvus.io/docs/install-pymilvus.md
- **Memgraph Python Driver**: https://memgraph.com/docs/client-libraries/python
- **Coverage.py**: https://coverage.readthedocs.io/

---

**Last Updated**: October 22, 2025
**Maintained By**: Development Team
**Version**: 1.0
