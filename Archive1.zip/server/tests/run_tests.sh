#!/bin/bash
# Test runner script for Phase 3 tests
# Can run tests either locally (with venv) or in Docker container

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVER_DIR="$(dirname "$SCRIPT_DIR")"

echo "=================================================="
echo "Phase 3 Test Runner"
echo "=================================================="

# Function to run tests in Docker
run_in_docker() {
    echo "Running tests in Docker container..."
    cd "$SERVER_DIR"

    # Check if services are running
    if ! docker ps | grep -q mcp_ticket_server; then
        echo "Starting mcp_ticket_server..."
        docker-compose up -d mcp_ticket_server
        sleep 5
    fi

    # Run tests
    docker exec mcp_ticket_server pytest "$@"
}

# Function to run tests locally
run_locally() {
    echo "Running tests locally..."
    cd "$SERVER_DIR"

    # Check if venv exists
    if [ ! -d "venv" ]; then
        echo "Creating virtual environment..."
        python3 -m venv venv
        source venv/bin/activate
        pip install -r app/requirements.txt -q
    else
        source venv/bin/activate
    fi

    # Run tests
    pytest "$@"

    deactivate
}

# Parse arguments
MODE="docker"  # Default to docker
TEST_ARGS=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --local)
            MODE="local"
            shift
            ;;
        --docker)
            MODE="docker"
            shift
            ;;
        *)
            TEST_ARGS="$TEST_ARGS $1"
            shift
            ;;
    esac
done

# Default test args if none provided
if [ -z "$TEST_ARGS" ]; then
    TEST_ARGS="tests/unit/ -v"
fi

# Run tests
case $MODE in
    docker)
        run_in_docker $TEST_ARGS
        ;;
    local)
        run_locally $TEST_ARGS
        ;;
esac

echo ""
echo "=================================================="
echo "✅ Tests complete!"
echo "=================================================="
