"""
Change-specific tools for infrastructure change management.
Provides tools for querying and analyzing Change records (CHG*):
- Change details lookup
- Change tasks (CTASK*)
- Tickets affected by changes
- Service affecting changes
- Changes by supplier/date range
"""
import logging
import polars as pl
from typing import Any, Optional, List
from fastmcp.exceptions import ToolError
from utils.utilities import Helpers


async def get_change_details(
    change_number: str,
    services: dict
) -> Any:
    """
    Get detailed information about a specific change by CHG number.

    Returns change details including type, work type, planned dates,
    supplier info, tasks, and affected configuration items.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_change_details change={change_number}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (c:Change {change_number: $change_number})
            OPTIONAL MATCH (c)-[:HAS_TASK]->(task:ChangeTask)
            OPTIONAL MATCH (c)-[:IMPACTS_CI]->(ci:ConfigurationItem)
            WITH c,
                 collect(DISTINCT {
                     task_number: task.task_number,
                     task_sys_id: task.task_sys_id,
                     state: task.state,
                     short_description: task.short_description,
                     assignment_group: task.assignment_group,
                     assigned_to: task.assigned_to,
                     fulfillment: task.fulfillment
                 }) as tasks,
                 collect(DISTINCT {
                     ci_sys_id: ci.ci_sys_id,
                     ci_name: ci.ci_name
                 }) as cis
            RETURN c.change_sys_id as change_sys_id,
                   c.change_number as change_number,
                   c.short_description as short_description,
                   c.description as description,
                   c.change_state as change_state,
                   c.change_type as change_type,
                   c.work_type as work_type,
                   c.category as category,
                   c.subcategory as subcategory,
                   c.risk as risk,
                   c.planned_start_date as planned_start_date,
                   c.planned_end_date as planned_end_date,
                   c.impact_duration as impact_duration,
                   c.impact_duration_minutes as impact_duration_minutes,
                   c.impacted_services_count as impacted_services_count,
                   c.assignment_group as assignment_group,
                   c.assigned_to as assigned_to,
                   c.created_on as created_on,
                   c.closed_on as closed_on,
                   c.supplier_name as supplier_name,
                   c.supplier_reference as supplier_reference,
                   c.core_network as core_network,
                   c.critical_systems as critical_systems,
                   c.is_cab_required as is_cab_required,
                   c.country as country,
                   c.planned_work_location as planned_work_location,
                   tasks,
                   cis
        """

        result = await memgraph_client.execute(cypher_query, {"change_number": change_number})
        records = [record.data() for record in result]

        if not records:
            return {"message": f"No change found with number: {change_number}"}

        change_data = records[0]

        # Filter out empty task/ci entries
        change_data["tasks"] = [t for t in change_data.get("tasks", []) if t.get("task_number")]
        change_data["configuration_items"] = [ci for ci in change_data.get("cis", []) if ci.get("ci_sys_id")]
        del change_data["cis"]

        return Helpers.recursive_serialize({
            "change": change_data,
            "task_count": len(change_data["tasks"]),
            "ci_count": len(change_data["configuration_items"])
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_change_details: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve change details: {e}")


async def get_change_tasks(
    change_number: str,
    services: dict
) -> Any:
    """
    Get all tasks (CTASK*) for a specific change.

    Returns task details including state, fulfillment status, and assignments.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_change_tasks change={change_number}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (c:Change {change_number: $change_number})-[:HAS_TASK]->(task:ChangeTask)
            RETURN c.change_number as change_number,
                   c.change_state as change_state,
                   task.task_sys_id as task_sys_id,
                   task.task_number as task_number,
                   task.short_description as short_description,
                   task.state as state,
                   task.priority as priority,
                   task.change_category as change_category,
                   task.fulfillment as fulfillment,
                   task.follow_up_needed as follow_up_needed,
                   task.implemented_in_timeframe as implemented_in_timeframe,
                   task.assignment_group as assignment_group,
                   task.assigned_to as assigned_to,
                   task.created_on as created_on,
                   task.closed_on as closed_on
            ORDER BY task.created_on DESC
        """

        result = await memgraph_client.execute(cypher_query, {"change_number": change_number})
        records = [record.data() for record in result]

        if not records:
            # Check if change exists
            check_query = """
                MATCH (c:Change {change_number: $change_number})
                RETURN c.change_number as change_number
            """
            check_result = await memgraph_client.execute(check_query, {"change_number": change_number})
            check_records = [r.data() for r in check_result]

            if not check_records:
                return {"message": f"No change found with number: {change_number}"}
            else:
                return {
                    "change_number": change_number,
                    "message": "No tasks found for this change",
                    "task_count": 0,
                    "tasks": []
                }

        return Helpers.recursive_serialize({
            "change_number": change_number,
            "change_state": records[0].get("change_state"),
            "task_count": len(records),
            "tasks": records
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_change_tasks: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve change tasks: {e}")


async def get_tickets_affected_by_change(
    change_number: str,
    services: dict,
    limit: Optional[int] = 50
) -> Any:
    """
    Get all tickets affected by a specific change.

    Traverses AFFECTED_BY_CHANGE relationship to find tickets
    that were caused by or related to this change.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_tickets_affected_by_change change={change_number}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (change:Change {change_number: $change_number})
            MATCH (ticket:Ticket)-[:AFFECTED_BY_CHANGE]->(change)
            MATCH (c:Client)-[:HAS_TICKET]->(ticket)
            OPTIONAL MATCH (ticket)-[:HAS_FAULT]->(f:Fault)
            RETURN change.change_number as change_number,
                   change.change_type as change_type,
                   change.work_type as work_type,
                   c.client_name as client_name,
                   ticket.ticket_id as ticket_id,
                   ticket.ticket_type as ticket_type,
                   ticket.ticket_status as ticket_status,
                   ticket.priority as priority,
                   ticket.created_on as ticket_created_on,
                   ticket.closed_on as ticket_closed_on,
                   f.short_description as fault_description
            ORDER BY ticket.created_on DESC
        """

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute(cypher_query, {"change_number": change_number})
        records = [record.data() for record in result]

        if not records:
            # Check if change exists
            check_query = """
                MATCH (c:Change {change_number: $change_number})
                RETURN c.change_number as change_number
            """
            check_result = await memgraph_client.execute(check_query, {"change_number": change_number})
            check_records = [r.data() for r in check_result]

            if not check_records:
                return {"message": f"No change found with number: {change_number}"}
            else:
                return {
                    "change_number": change_number,
                    "message": "No tickets found affected by this change",
                    "ticket_count": 0,
                    "tickets": []
                }

        return Helpers.recursive_serialize({
            "change_number": change_number,
            "ticket_count": len(records),
            "affected_tickets": records
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_tickets_affected_by_change: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve tickets affected by change: {e}")


async def get_service_affecting_changes(
    services: dict,
    change_state: Optional[str] = None,
    core_network_only: Optional[bool] = False,
    limit: Optional[int] = 100
) -> Any:
    """
    Get service affecting changes, optionally filtered by state or core network.

    Service affecting changes are infrastructure changes that may cause service interruptions.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_service_affecting_changes state={change_state}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        where_clauses = ["c.work_type = 'Service Affecting'"]
        params = {}

        if change_state:
            where_clauses.append("c.change_state = $change_state")
            params["change_state"] = change_state

        if core_network_only:
            where_clauses.append("c.core_network = true")

        where_clause = " AND ".join(where_clauses)

        cypher_query = f"""
            MATCH (c:Change)
            WHERE {where_clause}
            RETURN c.change_sys_id as change_sys_id,
                   c.change_number as change_number,
                   c.short_description as short_description,
                   c.change_state as change_state,
                   c.change_type as change_type,
                   c.work_type as work_type,
                   c.risk as risk,
                   c.planned_start_date as planned_start_date,
                   c.planned_end_date as planned_end_date,
                   c.impact_duration as impact_duration,
                   c.impact_duration_minutes as impact_duration_minutes,
                   c.impacted_services_count as impacted_services_count,
                   c.supplier_name as supplier_name,
                   c.core_network as core_network,
                   c.critical_systems as critical_systems,
                   c.country as country,
                   c.assignment_group as assignment_group
            ORDER BY c.planned_start_date DESC
            LIMIT {limit}
        """

        result = await memgraph_client.execute(cypher_query, params)
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": "No service affecting changes found"}

        return Helpers.recursive_serialize({
            "filters": {
                "work_type": "Service Affecting",
                "change_state": change_state,
                "core_network_only": core_network_only
            },
            "change_count": len(response_data),
            "changes": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_service_affecting_changes: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve service affecting changes: {e}")


async def get_changes_by_supplier(
    supplier_name: str,
    services: dict,
    limit: Optional[int] = 100
) -> Any:
    """
    Get all changes from a specific supplier.

    Useful for tracking maintenance and changes from vendor/supplier partners.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_changes_by_supplier supplier={supplier_name}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (c:Change)
            WHERE c.supplier_name CONTAINS $supplier_name
            RETURN c.change_sys_id as change_sys_id,
                   c.change_number as change_number,
                   c.short_description as short_description,
                   c.change_state as change_state,
                   c.change_type as change_type,
                   c.work_type as work_type,
                   c.supplier_name as supplier_name,
                   c.supplier_reference as supplier_reference,
                   c.planned_start_date as planned_start_date,
                   c.planned_end_date as planned_end_date,
                   c.impact_duration as impact_duration,
                   c.country as country,
                   c.created_on as created_on
            ORDER BY c.created_on DESC
        """

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute(cypher_query, {"supplier_name": supplier_name})
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No changes found from supplier containing: {supplier_name}"}

        return Helpers.recursive_serialize({
            "supplier_search": supplier_name,
            "change_count": len(response_data),
            "changes": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_changes_by_supplier: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve changes by supplier: {e}")


async def get_changes_by_date_range(
    start_date: str,
    end_date: str,
    services: dict,
    change_type: Optional[str] = None,
    work_type: Optional[str] = None,
    limit: Optional[int] = 200
) -> Any:
    """
    Get changes with planned dates within a date range.

    Date format: YYYY-MM-DD (e.g., '2026-01-01')
    Optionally filter by change_type (Normal, Standard, Emergency) or
    work_type (Service Affecting, Non-Service Affecting).
    """
    try:
        logging.info(f"FastMCP Tool Call: get_changes_by_date_range {start_date} to {end_date}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        where_clauses = [
            "c.planned_start_date >= $start_date",
            "c.planned_start_date <= $end_date"
        ]
        params = {
            "start_date": start_date,
            "end_date": end_date
        }

        if change_type:
            where_clauses.append("c.change_type = $change_type")
            params["change_type"] = change_type

        if work_type:
            where_clauses.append("c.work_type = $work_type")
            params["work_type"] = work_type

        where_clause = " AND ".join(where_clauses)

        cypher_query = f"""
            MATCH (c:Change)
            WHERE {where_clause}
            RETURN c.change_sys_id as change_sys_id,
                   c.change_number as change_number,
                   c.short_description as short_description,
                   c.change_state as change_state,
                   c.change_type as change_type,
                   c.work_type as work_type,
                   c.risk as risk,
                   c.planned_start_date as planned_start_date,
                   c.planned_end_date as planned_end_date,
                   c.impact_duration as impact_duration,
                   c.impact_duration_minutes as impact_duration_minutes,
                   c.impacted_services_count as impacted_services_count,
                   c.supplier_name as supplier_name,
                   c.core_network as core_network,
                   c.country as country,
                   c.assignment_group as assignment_group
            ORDER BY c.planned_start_date ASC
            LIMIT {limit}
        """

        result = await memgraph_client.execute(cypher_query, params)
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No changes found between {start_date} and {end_date}"}

        return Helpers.recursive_serialize({
            "date_range": {"start": start_date, "end": end_date},
            "filters": {"change_type": change_type, "work_type": work_type},
            "change_count": len(response_data),
            "changes": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_changes_by_date_range: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve changes by date range: {e}")


async def get_change_cis(
    change_number: str,
    services: dict
) -> Any:
    """
    Get all Configuration Items (circuits/services) affected by a change.

    Returns the list of CIs that will be impacted by the change.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_change_cis change={change_number}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (c:Change {change_number: $change_number})-[:IMPACTS_CI]->(ci:ConfigurationItem)
            RETURN c.change_number as change_number,
                   c.change_state as change_state,
                   ci.ci_sys_id as ci_sys_id,
                   ci.ci_name as ci_name,
                   ci.is_manually_added as is_manually_added
            ORDER BY ci.ci_name
        """

        result = await memgraph_client.execute(cypher_query, {"change_number": change_number})
        records = [record.data() for record in result]

        if not records:
            # Check if change exists
            check_query = """
                MATCH (c:Change {change_number: $change_number})
                RETURN c.change_number as change_number
            """
            check_result = await memgraph_client.execute(check_query, {"change_number": change_number})
            check_records = [r.data() for r in check_result]

            if not check_records:
                return {"message": f"No change found with number: {change_number}"}
            else:
                return {
                    "change_number": change_number,
                    "message": "No Configuration Items linked to this change",
                    "ci_count": 0,
                    "configuration_items": []
                }

        return Helpers.recursive_serialize({
            "change_number": change_number,
            "ci_count": len(records),
            "configuration_items": records
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_change_cis: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve change CIs: {e}")


async def get_clients_affected_by_change(
    change_number: str,
    services: dict
) -> Any:
    """
    Get all clients affected by a specific change.

    Traces the path: Change <- Ticket <- Client
    Returns unique clients with their affected tickets.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_clients_affected_by_change change={change_number}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (change:Change {change_number: $change_number})
            MATCH (ticket:Ticket)-[:AFFECTED_BY_CHANGE]->(change)
            MATCH (client:Client)-[:HAS_TICKET]->(ticket)
            WITH change, client, collect({
                ticket_id: ticket.ticket_id,
                ticket_type: ticket.ticket_type,
                ticket_status: ticket.ticket_status,
                priority: ticket.priority,
                created_on: ticket.created_on
            }) as affected_tickets
            RETURN change.change_number as change_number,
                   change.change_type as change_type,
                   change.work_type as work_type,
                   change.impacted_services_count as impacted_services_count,
                   client.client_id as client_id,
                   client.client_name as client_name,
                   client.client_tier as client_tier,
                   size(affected_tickets) as ticket_count,
                   affected_tickets
            ORDER BY size(affected_tickets) DESC
        """

        result = await memgraph_client.execute(cypher_query, {"change_number": change_number})
        records = [record.data() for record in result]

        if not records:
            # Check if change exists
            check_query = """
                MATCH (c:Change {change_number: $change_number})
                RETURN c.change_number as change_number
            """
            check_result = await memgraph_client.execute(check_query, {"change_number": change_number})
            check_records = [r.data() for r in check_result]

            if not check_records:
                return {"message": f"No change found with number: {change_number}"}
            else:
                return {
                    "change_number": change_number,
                    "message": "No clients affected by this change",
                    "client_count": 0,
                    "clients": []
                }

        return Helpers.recursive_serialize({
            "change_number": change_number,
            "change_type": records[0].get("change_type"),
            "work_type": records[0].get("work_type"),
            "impacted_services_count": records[0].get("impacted_services_count"),
            "client_count": len(records),
            "total_tickets_affected": sum(r.get("ticket_count", 0) for r in records),
            "clients": records
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_clients_affected_by_change: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve clients affected by change: {e}")


async def get_clients_sharing_ci_with_change(
    change_number: str,
    services: dict
) -> Any:
    """
    Get all clients who share Configuration Items (circuits) with a change.

    This finds the blast radius: all clients whose services use the same
    infrastructure affected by the change.

    Path: Change -[:IMPACTS_CI]-> CI <-[:IMPACTS_CI]- Ticket <-[:HAS_TICKET]- Client
    """
    try:
        logging.info(f"FastMCP Tool Call: get_clients_sharing_ci_with_change change={change_number}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (change:Change {change_number: $change_number})-[:IMPACTS_CI]->(ci:ConfigurationItem)
            MATCH (ticket:Ticket)-[:IMPACTS_CI]->(ci)
            MATCH (client:Client)-[:HAS_TICKET]->(ticket)
            WITH change, ci, client, collect(DISTINCT ticket.ticket_id) as ticket_ids
            RETURN change.change_number as change_number,
                   change.change_type as change_type,
                   change.impacted_services_count as impacted_services_count,
                   ci.ci_sys_id as ci_sys_id,
                   ci.ci_name as ci_name,
                   client.client_id as client_id,
                   client.client_name as client_name,
                   client.client_tier as client_tier,
                   ticket_ids
            ORDER BY client.client_name, ci.ci_name
        """

        result = await memgraph_client.execute(cypher_query, {"change_number": change_number})
        records = [record.data() for record in result]

        if not records:
            # Check if change exists and has CIs
            check_query = """
                MATCH (c:Change {change_number: $change_number})
                OPTIONAL MATCH (c)-[:IMPACTS_CI]->(ci:ConfigurationItem)
                RETURN c.change_number as change_number, count(ci) as ci_count
            """
            check_result = await memgraph_client.execute(check_query, {"change_number": change_number})
            check_records = [r.data() for r in check_result]

            if not check_records:
                return {"message": f"No change found with number: {change_number}"}
            elif check_records[0].get("ci_count", 0) == 0:
                return {
                    "change_number": change_number,
                    "message": "Change has no Configuration Items linked",
                    "client_count": 0,
                    "clients": []
                }
            else:
                return {
                    "change_number": change_number,
                    "message": "No clients share CIs with this change",
                    "client_count": 0,
                    "clients": []
                }

        # Group by client
        clients_map = {}
        for r in records:
            client_id = r.get("client_id")
            if client_id not in clients_map:
                clients_map[client_id] = {
                    "client_id": client_id,
                    "client_name": r.get("client_name"),
                    "client_tier": r.get("client_tier"),
                    "shared_cis": [],
                    "affected_tickets": set()
                }
            clients_map[client_id]["shared_cis"].append({
                "ci_sys_id": r.get("ci_sys_id"),
                "ci_name": r.get("ci_name")
            })
            clients_map[client_id]["affected_tickets"].update(r.get("ticket_ids", []))

        # Convert sets to lists for serialization
        clients = []
        for c in clients_map.values():
            c["affected_tickets"] = list(c["affected_tickets"])
            c["ticket_count"] = len(c["affected_tickets"])
            c["ci_count"] = len(c["shared_cis"])
            clients.append(c)

        # Sort by ticket count descending
        clients.sort(key=lambda x: x["ticket_count"], reverse=True)

        return Helpers.recursive_serialize({
            "change_number": change_number,
            "change_type": records[0].get("change_type"),
            "impacted_services_count": records[0].get("impacted_services_count"),
            "client_count": len(clients),
            "clients": clients
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_clients_sharing_ci_with_change: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve clients sharing CI with change: {e}")
