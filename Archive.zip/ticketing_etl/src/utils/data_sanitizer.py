from bs4 import BeautifulSoup
from pydantic import BaseModel, field_validator
import html

""" Various functions to sanitize data befor publishing """


def remove_html_tags(content: str) -> str:
    """# Extract text with newlines,
    remove leading/trailing whitespace"""
    if not content:
        return ""
    soup = BeautifulSoup(content, "html.parser")
    return soup.get_text(separator=" ").strip()


def unescape_html_entities(content: str) -> str:
    if not content:
        return ""
    return html.unescape(content)


def handle_escaped_characters(content: str) -> str:
    if not content:
        return ""
    # Basic handling of common escaped sequences for JSON
    return content.replace("\\n", "\n").replace('\\"', '"').replace("\\\\", "\\")


def sanitize_for_json(content: str) -> str:
    if not content:
        return ""
    # Ensure double quotes are escaped for JSON safety
    return content.replace('"', '\\"')


def sanitize_text_for_json(raw_text: str) -> str:
    """Apply all the sanitization steps to the raw text"""
    if not raw_text:
        return ""

    # 1. Unescape HTML entities first (if present)
    unescaped = unescape_html_entities(raw_text)
    # 2. Remove HTML tags and get plain text
    text_only = remove_html_tags(unescaped)
    # 3. Handle escaped characters that might be problematic in JSON
    processed_escapes = handle_escaped_characters(text_only)
    # 4. Ensure the final string is safe to embed in JSON
    json_safe = sanitize_for_json(processed_escapes)

    return json_safe


class ContentModel(BaseModel):
    """Represents a model for processing sanitized content."""

    content: str

    @field_validator("content", mode="before")
    @classmethod
    def process_content(cls, value: str) -> str:
        return sanitize_text_for_json(value)
