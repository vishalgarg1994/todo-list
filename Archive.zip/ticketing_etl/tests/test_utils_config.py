import pytest
import os
import sys
from unittest.mock import patch, mock_open

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

from utils.config import Config, ConfigurationError


class TestConfig:

    def test_config_initialization_default(self):
        """Test Config initialization with default environment"""
        with patch.dict(os.environ, {}, clear=True):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.env == "dev"

    def test_config_initialization_custom_environment(self):
        """Test Config initialization with custom environment"""
        with patch.dict(os.environ, {'CONFIG_ENV': 'prod'}):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.env == "prod"

    def test_config_initialization_with_env_file(self):
        """Test Config initialization loads .env file"""
        env_content = "TEST_KEY=test_value\nANOTHER_KEY=another_value"

        with patch('builtins.open', mock_open(read_data=env_content)):
            with patch('os.path.exists', return_value=True):
                with patch('utils.config.Config._validate_required_config'):
                    config = Config()
                    assert config.dotenv_config is not None

    def test_get_existing_key(self):
        """Test getting existing configuration key"""
        with patch.dict(os.environ, {'TEST_KEY': 'test_value'}):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.get('TEST_KEY') == 'test_value'

    def test_get_nonexistent_key_with_default(self):
        """Test getting non-existent key with default value"""
        with patch('utils.config.Config._validate_required_config'):
            config = Config()
            assert config.get('NONEXISTENT_KEY', 'default') == 'default'

    def test_get_nonexistent_key_without_default(self):
        """Test getting non-existent key without default value"""
        with patch('utils.config.Config._validate_required_config'):
            config = Config()
            assert config.get('NONEXISTENT_KEY') is None

    def test_get_nats_url(self):
        """Test getting NATS URL"""
        with patch.dict(os.environ, {'NATS_URL': 'nats://localhost:4222'}):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.get_nats_url() == 'nats://localhost:4222'

    def test_get_jetstream_stream_name(self):
        """Test getting JetStream stream name"""
        with patch.dict(os.environ, {'JETSTREAM_STREAM_NAME': 'test_stream'}):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.get_jetstream_stream_name() == 'test_stream'

    def test_get_ticket_publish_subject_custom(self):
        """Test getting ticket publish subject with custom value"""
        with patch.dict(os.environ, {'TICKET_PUBLISH_SUBJECT': 'custom.tickets'}):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.get_ticket_publish_subject() == 'custom.tickets'

    def test_get_ticket_subscribe_subject_custom(self):
        """Test getting ticket subscribe subject with custom value"""
        with patch.dict(os.environ, {'TICKET_SUBSCRIBE_SUBJECT': 'custom.subscribe'}):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.get_ticket_subscribe_subject() == 'custom.subscribe'

    def test_get_db_uri(self):
        """Test getting database URI"""
        with patch.dict(os.environ, {'DATABASE_URL': 'postgresql://localhost/test'}):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.get_db_uri() == 'postgresql://localhost/test'

    def test_get_scheduler_interval_default(self):
        """Test getting scheduler interval with default"""
        with patch('utils.config.Config._validate_required_config'):
            config = Config()
            assert config.get_scheduler_interval() == 86400  # 24 hours for daily scheduling

    def test_get_scheduler_interval_custom(self):
        """Test getting scheduler interval with custom value"""
        with patch.dict(os.environ, {'SCHEDULER_INTERVAL': '600'}):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.get_scheduler_interval() == 600

    def test_get_scheduler_interval_invalid(self):
        """Test getting scheduler interval with invalid value"""
        with patch.dict(os.environ, {'SCHEDULER_INTERVAL': 'invalid'}):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.get_scheduler_interval() == 86400  # 24 hours for daily scheduling
                # Should fallback to default

    def test_get_lookup_interval_minutes_default(self):
        """Test getting lookup interval with default"""
        with patch.dict(os.environ, {}, clear=True):  # Clear environment for clean test
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.get_lookup_interval_minutes() == 1440  # 24 hours for daily scheduling

    def test_get_lookup_interval_minutes_custom(self):
        """Test getting lookup interval with custom value"""
        with patch.dict(os.environ, {'LOOKUP_INTERVAL_MINUTES': '10'}):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.get_lookup_interval_minutes() == 10

    def test_get_lookup_interval_minutes_invalid(self):
        """Test getting lookup interval with invalid value"""
        with patch.dict(os.environ, {'LOOKUP_INTERVAL_MINUTES': 'invalid'}, clear=True):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                assert config.get_lookup_interval_minutes() == 1440  # Should fallback to default

    def test_load_env_file_none_exists(self):
        """Test behavior when no .env file exists"""
        with patch('os.path.exists', return_value=False):
            with patch('utils.config.Config._validate_required_config'):
                config = Config()
                # Should have empty dotenv_config
                assert config.dotenv_config == {}

    def test_validate_required_config_success(self):
        """Test validation passes when required config is present"""
        required_env = {
            'DATABASE_URL': 'postgresql://localhost/test',
            'NATS_URL': 'nats://localhost:4222',
            'JETSTREAM_STREAM_NAME': 'test_stream'
        }

        with patch.dict(os.environ, required_env):
            # Should not raise exception
            config = Config()
            assert config.get_db_uri() == 'postgresql://localhost/test'

    def test_validate_required_config_missing(self):
        """Test validation fails when required config is missing"""
        with patch.dict(os.environ, {}, clear=True):
            with patch('os.path.exists', return_value=False):  # No .env file
                with pytest.raises(ConfigurationError) as exc_info:
                    Config()

                assert "Missing required configuration" in str(exc_info.value)
                assert "DATABASE_URL" in str(exc_info.value)
                assert "NATS_URL" in str(exc_info.value)
                assert "JETSTREAM_STREAM_NAME" in str(exc_info.value)

    def test_config_hierarchy_env_over_dotenv(self):
        """Test that environment variables take precedence over .env file"""
        env_content = "TEST_KEY=dotenv_value"

        with patch('builtins.open', mock_open(read_data=env_content)):
            with patch('os.path.exists', return_value=True):
                with patch.dict(os.environ, {'TEST_KEY': 'env_value'}):
                    with patch('utils.config.Config._validate_required_config'):
                        config = Config()
                        # Environment variable should take precedence
                        assert config.get('TEST_KEY') == 'env_value'


class TestConfigurationError:

    def test_configuration_error_creation(self):
        """Test ConfigurationError exception creation"""
        error_msg = "Test configuration error"
        error = ConfigurationError(error_msg)

        assert str(error) == error_msg
        assert isinstance(error, Exception)

    def test_configuration_error_inheritance(self):
        """Test ConfigurationError inherits from Exception"""
        error = ConfigurationError("Test error")
        assert isinstance(error, Exception)
