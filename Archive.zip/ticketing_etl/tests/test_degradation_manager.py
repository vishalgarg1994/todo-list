import pytest
from datetime import datetime, timezone
from unittest.mock import AsyncMock, patch
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from utils.degradation_manager import DegradationManager, ServiceState, ServiceStatus


class TestServiceStatus:
    def test_service_status_creation(self):
        """Test ServiceStatus dataclass creation"""
        now = datetime.now(timezone.utc)
        status = ServiceStatus(
            name="test_service",
            state=ServiceState.HEALTHY,
            last_check=now,
            error_count=5,
            consecutive_failures=2,
            last_error="Connection timeout",
        )

        assert status.name == "test_service"
        assert status.state == ServiceState.HEALTHY
        assert status.last_check == now
        assert status.error_count == 5
        assert status.consecutive_failures == 2
        assert status.last_error == "Connection timeout"

    def test_service_status_defaults(self):
        """Test ServiceStatus default values"""
        now = datetime.now(timezone.utc)
        status = ServiceStatus(
            name="test_service", state=ServiceState.DEGRADED, last_check=now
        )

        assert status.error_count == 0
        assert status.consecutive_failures == 0
        assert status.last_error is None


class TestServiceState:
    def test_service_state_enum(self):
        """Test ServiceState enum values"""
        assert ServiceState.HEALTHY.value == "healthy"
        assert ServiceState.DEGRADED.value == "degraded"
        assert ServiceState.UNAVAILABLE.value == "unavailable"


class TestDegradationManager:
    @pytest.fixture
    def manager(self):
        return DegradationManager()

    def test_init(self, manager):
        """Test DegradationManager initialization"""
        assert isinstance(manager.services, dict)
        assert len(manager.services) == 0
        assert isinstance(manager.degradation_handlers, dict)
        assert isinstance(manager.fallback_handlers, dict)
        assert manager.max_consecutive_failures == 3
        assert manager.health_check_interval == 30
        assert manager.degradation_timeout == 300

    def test_register_service_basic(self, manager):
        """Test basic service registration"""
        manager.register_service("test_service")

        assert "test_service" in manager.services
        service = manager.services["test_service"]
        assert service.name == "test_service"
        assert service.state == ServiceState.HEALTHY
        assert isinstance(service.last_check, datetime)
        assert service.error_count == 0
        assert service.consecutive_failures == 0

    def test_register_service_with_health_check(self, manager):
        """Test service registration with health check handler"""
        health_check_handler = AsyncMock(return_value=True)

        manager.register_service("test_service", health_check_handler)

        assert "test_service" in manager.services
        assert "test_service" in manager.degradation_handlers
        assert manager.degradation_handlers["test_service"] == health_check_handler

    def test_register_fallback_handler(self, manager):
        """Test registering fallback handler"""
        fallback_handler = AsyncMock()

        manager.register_fallback_handler("test_service", fallback_handler)

        assert "test_service" in manager.fallback_handlers
        assert manager.fallback_handlers["test_service"] == fallback_handler

    @pytest.mark.asyncio
    async def test_check_service_health_unknown_service(self, manager):
        """Test health check for unknown service"""
        result = await manager.check_service_health("unknown_service")
        assert result == ServiceState.UNAVAILABLE

    @pytest.mark.asyncio
    async def test_check_service_health_with_custom_handler_success(self, manager):
        """Test health check with custom handler returning healthy"""
        health_check = AsyncMock(return_value=True)
        manager.register_service("test_service", health_check)

        result = await manager.check_service_health("test_service")

        assert result == ServiceState.HEALTHY
        health_check.assert_called_once()

        service = manager.services["test_service"]
        assert service.state == ServiceState.HEALTHY
        assert service.consecutive_failures == 0
        assert service.last_error is None

    @pytest.mark.asyncio
    async def test_check_service_health_with_custom_handler_failure(self, manager):
        """Test health check with custom handler returning degraded"""
        health_check = AsyncMock(return_value=False)
        manager.register_service("test_service", health_check)

        result = await manager.check_service_health("test_service")

        assert result == ServiceState.DEGRADED

        service = manager.services["test_service"]
        assert service.state == ServiceState.DEGRADED
        assert service.consecutive_failures == 1
        assert service.error_count == 1
        assert service.last_error == "Health check failed"

    @pytest.mark.asyncio
    async def test_check_service_health_with_custom_handler_exception(self, manager):
        """Test health check with custom handler raising exception"""
        health_check = AsyncMock(side_effect=Exception("Health check error"))
        manager.register_service("test_service", health_check)

        result = await manager.check_service_health("test_service")

        assert result == ServiceState.UNAVAILABLE

        service = manager.services["test_service"]
        assert service.state == ServiceState.UNAVAILABLE
        assert service.consecutive_failures == 1
        assert service.error_count == 1
        assert service.last_error == "Health check error"

    @pytest.mark.asyncio
    async def test_check_service_health_default_logic_healthy(self, manager):
        """Test default health check logic with healthy service"""
        manager.register_service("test_service")
        service = manager.services["test_service"]
        service.consecutive_failures = 1  # Below threshold

        result = await manager.check_service_health("test_service")

        assert result == ServiceState.HEALTHY
        assert service.consecutive_failures == 0  # Reset on healthy

    @pytest.mark.asyncio
    async def test_check_service_health_default_logic_degraded(self, manager):
        """Test default health check logic with degraded service"""
        manager.register_service("test_service")
        service = manager.services["test_service"]
        service.consecutive_failures = 3  # At threshold

        result = await manager.check_service_health("test_service")

        assert result == ServiceState.DEGRADED
        assert service.consecutive_failures == 4  # Incremented

    def test_mark_service_healthy(self, manager):
        """Test marking service as healthy"""
        manager.register_service("test_service")
        service = manager.services["test_service"]

        # Set some unhealthy state
        service.state = ServiceState.DEGRADED
        service.consecutive_failures = 5
        service.error_count = 10
        service.last_error = "Some error"

        manager._mark_service_healthy("test_service")

        assert service.state == ServiceState.HEALTHY
        assert service.consecutive_failures == 0
        assert service.last_error is None
        assert isinstance(service.last_check, datetime)
        # error_count should not be reset (historical count)
        assert service.error_count == 10

    def test_mark_service_degraded(self, manager):
        """Test marking service as degraded"""
        manager.register_service("test_service")
        service = manager.services["test_service"]
        initial_error_count = service.error_count
        initial_failures = service.consecutive_failures

        manager._mark_service_degraded("test_service", "Test degradation")

        assert service.state == ServiceState.DEGRADED
        assert service.consecutive_failures == initial_failures + 1
        assert service.error_count == initial_error_count + 1
        assert service.last_error == "Test degradation"
        assert isinstance(service.last_check, datetime)

    def test_mark_service_unavailable(self, manager):
        """Test marking service as unavailable"""
        manager.register_service("test_service")
        service = manager.services["test_service"]
        initial_error_count = service.error_count
        initial_failures = service.consecutive_failures

        manager._mark_service_unavailable("test_service", "Service down")

        assert service.state == ServiceState.UNAVAILABLE
        assert service.consecutive_failures == initial_failures + 1
        assert service.error_count == initial_error_count + 1
        assert service.last_error == "Service down"
        assert isinstance(service.last_check, datetime)

    @pytest.mark.asyncio
    async def test_execute_with_fallback_healthy_service_success(self, manager):
        """Test execute with fallback when service is healthy and operation succeeds"""
        manager.register_service("test_service")

        async def primary_operation(arg1, arg2, kwarg1=None):
            return f"primary_{arg1}_{arg2}_{kwarg1}"

        with patch.object(
            manager, "check_service_health", return_value=ServiceState.HEALTHY
        ):
            result = await manager.execute_with_fallback(
                "test_service", primary_operation, "a", "b", kwarg1="c"
            )

        assert result == "primary_a_b_c"
        # Service should remain healthy after success
        service = manager.services["test_service"]
        assert service.state == ServiceState.HEALTHY
        assert service.consecutive_failures == 0

    @pytest.mark.asyncio
    async def test_execute_with_fallback_degraded_service_success(self, manager):
        """Test execute with fallback when service is degraded but operation succeeds"""
        manager.register_service("test_service")

        async def primary_operation():
            return "primary_success"

        with patch.object(
            manager, "check_service_health", return_value=ServiceState.DEGRADED
        ):
            result = await manager.execute_with_fallback(
                "test_service", primary_operation
            )

        assert result == "primary_success"

    @pytest.mark.asyncio
    async def test_execute_with_fallback_sync_function(self, manager):
        """Test execute with fallback using synchronous function"""
        manager.register_service("test_service")

        def sync_primary_operation():
            return "sync_primary_success"

        with patch.object(
            manager, "check_service_health", return_value=ServiceState.HEALTHY
        ):
            result = await manager.execute_with_fallback(
                "test_service", sync_primary_operation
            )

        assert result == "sync_primary_success"

    @pytest.mark.asyncio
    async def test_execute_with_fallback_primary_fails_use_fallback(self, manager):
        """Test fallback is used when primary operation fails"""
        manager.register_service("test_service")

        async def failing_primary():
            raise ConnectionError("Primary failed")

        async def fallback_operation():
            return "fallback_success"

        manager.register_fallback_handler("test_service", fallback_operation)

        with patch.object(
            manager, "check_service_health", return_value=ServiceState.HEALTHY
        ):
            result = await manager.execute_with_fallback(
                "test_service", failing_primary
            )

        assert result == "fallback_success"

        # Service should be marked as unavailable after primary failure
        service = manager.services["test_service"]
        assert service.state == ServiceState.UNAVAILABLE

    @pytest.mark.asyncio
    async def test_execute_with_fallback_sync_fallback(self, manager):
        """Test using synchronous fallback handler"""
        manager.register_service("test_service")

        async def failing_primary():
            raise ValueError("Primary failed")

        def sync_fallback():
            return "sync_fallback_success"

        manager.register_fallback_handler("test_service", sync_fallback)

        with patch.object(
            manager, "check_service_health", return_value=ServiceState.HEALTHY
        ):
            result = await manager.execute_with_fallback(
                "test_service", failing_primary
            )

        assert result == "sync_fallback_success"

    @pytest.mark.asyncio
    async def test_execute_with_fallback_unavailable_service_uses_fallback(
        self, manager
    ):
        """Test fallback is used when service is unavailable"""
        manager.register_service("test_service")

        primary_call_count = 0

        async def primary_operation():
            nonlocal primary_call_count
            primary_call_count += 1
            return "primary_success"

        async def fallback_operation():
            return "fallback_for_unavailable"

        manager.register_fallback_handler("test_service", fallback_operation)

        with patch.object(
            manager, "check_service_health", return_value=ServiceState.UNAVAILABLE
        ):
            result = await manager.execute_with_fallback(
                "test_service", primary_operation
            )

        assert result == "fallback_for_unavailable"
        assert primary_call_count == 0  # Primary should not be called

    @pytest.mark.asyncio
    async def test_execute_with_fallback_no_fallback_handler(self, manager):
        """Test error when no fallback handler is available"""
        manager.register_service("test_service")

        async def failing_primary():
            raise RuntimeError("Primary failed")

        with patch.object(
            manager, "check_service_health", return_value=ServiceState.HEALTHY
        ):
            with pytest.raises(RuntimeError) as exc_info:
                await manager.execute_with_fallback("test_service", failing_primary)

            assert (
                "Service test_service is unavailable and no fallback is configured"
                in str(exc_info.value)
            )

    @pytest.mark.asyncio
    async def test_execute_with_fallback_fallback_fails(self, manager):
        """Test behavior when fallback handler also fails"""
        manager.register_service("test_service")

        async def failing_primary():
            raise ConnectionError("Primary failed")

        async def failing_fallback():
            raise RuntimeError("Fallback also failed")

        manager.register_fallback_handler("test_service", failing_fallback)

        with patch.object(
            manager, "check_service_health", return_value=ServiceState.HEALTHY
        ):
            with pytest.raises(RuntimeError) as exc_info:
                await manager.execute_with_fallback("test_service", failing_primary)

            assert "Fallback also failed" in str(exc_info.value)

    def test_get_service_status(self, manager):
        """Test getting service status"""
        manager.register_service("test_service")

        status = manager.get_service_status("test_service")

        assert status is not None
        assert status.name == "test_service"
        assert status.state == ServiceState.HEALTHY

        # Test non-existent service
        assert manager.get_service_status("nonexistent") is None

    def test_get_all_service_status(self, manager):
        """Test getting all service statuses"""
        manager.register_service("service1")
        manager.register_service("service2")

        all_statuses = manager.get_all_service_status()

        assert len(all_statuses) == 2
        assert "service1" in all_statuses
        assert "service2" in all_statuses
        assert all_statuses["service1"].name == "service1"
        assert all_statuses["service2"].name == "service2"

        # Should be a copy, not the original
        all_statuses["service1"] = None
        assert manager.services["service1"] is not None

    def test_get_unhealthy_services(self, manager):
        """Test getting unhealthy services"""
        manager.register_service("healthy_service")
        manager.register_service("degraded_service")
        manager.register_service("unavailable_service")

        # Mark some services as unhealthy
        manager.services["degraded_service"].state = ServiceState.DEGRADED
        manager.services["unavailable_service"].state = ServiceState.UNAVAILABLE

        unhealthy = manager.get_unhealthy_services()

        assert len(unhealthy) == 2
        assert "degraded_service" in unhealthy
        assert "unavailable_service" in unhealthy
        assert "healthy_service" not in unhealthy

    def test_is_system_degraded(self, manager):
        """Test system degradation detection"""
        # Empty system should not be degraded
        assert not manager.is_system_degraded()

        # All healthy services
        manager.register_service("service1")
        manager.register_service("service2")
        assert not manager.is_system_degraded()

        # One degraded service
        manager.services["service1"].state = ServiceState.DEGRADED
        assert manager.is_system_degraded()

        # All healthy again
        manager.services["service1"].state = ServiceState.HEALTHY
        assert not manager.is_system_degraded()

    @pytest.mark.asyncio
    async def test_handle_database_degradation(self, manager):
        """Test database degradation handler"""
        # Mock sleep to speed up test
        with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            result = await manager.handle_database_degradation()

            assert result is True
            mock_sleep.assert_called_once_with(5)

    @pytest.mark.asyncio
    async def test_handle_nats_degradation(self, manager):
        """Test NATS degradation handler"""
        result = await manager.handle_nats_degradation()
        assert result is True

    @pytest.mark.asyncio
    async def test_monitor_services(self, manager):
        """Test continuous service monitoring"""
        manager.register_service("service1")
        manager.register_service("service2")

        # Mock the health check to simulate some state changes
        check_count = 0

        async def mock_health_check(service_name):
            nonlocal check_count
            check_count += 1
            if check_count <= 2:  # First two checks
                return ServiceState.HEALTHY
            else:  # Stop monitoring after 2 iterations
                raise KeyboardInterrupt("Stop monitoring")

        with patch.object(
            manager, "check_service_health", side_effect=mock_health_check
        ):
            with patch("asyncio.sleep", new_callable=AsyncMock):
                with pytest.raises(KeyboardInterrupt):
                    await manager.monitor_services()

        # Should have checked services (may be 3 or 4 due to race conditions)
        assert check_count >= 3  # At least 3 checks (might be interrupted mid-cycle)

    @pytest.mark.asyncio
    async def test_monitor_services_handles_exceptions(self, manager):
        """Test that service monitoring handles exceptions gracefully"""
        manager.register_service("test_service")

        # Mock health check to fail first, then stop monitoring
        call_count = 0

        async def mock_health_check(service_name):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise Exception("Health check failed")
            else:
                raise KeyboardInterrupt("Stop monitoring")

        with patch.object(
            manager, "check_service_health", side_effect=mock_health_check
        ):
            with patch("asyncio.sleep", new_callable=AsyncMock):
                with pytest.raises(KeyboardInterrupt):
                    await manager.monitor_services()

        # Should have attempted 2 checks (one failed, one to stop)
        assert call_count == 2


class TestGlobalDegradationManager:
    def test_global_instance_exists(self):
        """Test that global degradation manager instance exists"""
        from utils.degradation_manager import degradation_manager

        assert isinstance(degradation_manager, DegradationManager)
        assert len(degradation_manager.services) == 0
