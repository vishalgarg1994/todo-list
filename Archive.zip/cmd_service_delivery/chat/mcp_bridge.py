"""
Bridge between the MCP server and LangChain/LangGraph.

Connects to the CMD MCP server via StreamableHTTP, discovers all tools,
and converts them into LangChain StructuredTools for use with LangGraph agents.
"""

import json
import logging
from typing import Any, Dict, List, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, create_model

logger = logging.getLogger(__name__)

JSON_TYPE_MAP = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
}


INTERNAL_PARAMS = {"services", "_placeholder"}


def _build_args_model(name: str, schema: dict) -> type[BaseModel]:
    """Dynamically create a Pydantic model from a JSON Schema."""
    props = schema.get("properties", {})
    required = set(schema.get("required", []))
    fields: Dict[str, Any] = {}

    for prop_name, prop_def in props.items():
        if prop_name in INTERNAL_PARAMS:
            continue
        prop_type = prop_def.get("type", "string")
        py_type = JSON_TYPE_MAP.get(prop_type, str)

        if prop_name in required:
            fields[prop_name] = (py_type, ...)
        else:
            default = prop_def.get("default")
            fields[prop_name] = (Optional[py_type], default)

    return create_model(f"{name}_Args", **fields)


class MCPToolBridge:
    """
    Connects to an MCP server, discovers tools, and exposes them as
    LangChain StructuredTools for use with LangGraph agents.
    """

    def __init__(self, mcp_url: str):
        self.mcp_url = mcp_url
        self.tools: List[StructuredTool] = []
        self.tool_metadata: List[dict] = []
        self._session = None
        self._read = None
        self._write = None
        self._cm = None
        self._session_cm = None

    async def connect(self):
        from mcp.client.streamable_http import streamablehttp_client
        from mcp import ClientSession

        self._cm = streamablehttp_client(self.mcp_url)
        self._read, self._write, _ = await self._cm.__aenter__()

        self._session_cm = ClientSession(self._read, self._write)
        self._session = await self._session_cm.__aenter__()
        await self._session.initialize()

        result = await self._session.list_tools()
        logger.info("Discovered %d MCP tools from %s", len(result.tools), self.mcp_url)

        for mcp_tool in result.tools:
            lc_tool = self._make_tool(mcp_tool)
            self.tools.append(lc_tool)

            category = mcp_tool.name.split("_")[0] if "_" in mcp_tool.name else "general"
            clean_schema = dict(mcp_tool.inputSchema or {})
            if "properties" in clean_schema:
                clean_schema["properties"] = {
                    k: v for k, v in clean_schema["properties"].items()
                    if k not in INTERNAL_PARAMS
                }
            self.tool_metadata.append({
                "name": mcp_tool.name,
                "description": mcp_tool.description or "",
                "category": category,
                "parameters": clean_schema,
            })

        logger.info("Created %d LangChain tools", len(self.tools))

    def _make_tool(self, mcp_tool) -> StructuredTool:
        session = self._session
        tool_name = mcp_tool.name
        input_schema = mcp_tool.inputSchema or {"type": "object", "properties": {}}

        args_model = _build_args_model(tool_name, input_schema)

        async def invoke(**kwargs):
            for k in list(kwargs):
                if k in INTERNAL_PARAMS or kwargs[k] is None:
                    kwargs.pop(k)
            try:
                result = await session.call_tool(tool_name, kwargs)
                parts = []
                for c in (result.content or []):
                    if hasattr(c, "text"):
                        parts.append(c.text)
                return "\n".join(parts) if parts else "No result"
            except Exception as e:
                logger.error("Tool %s failed: %s", tool_name, e)
                return f"Error calling {tool_name}: {e}"

        return StructuredTool(
            name=tool_name,
            description=mcp_tool.description or tool_name,
            coroutine=invoke,
            args_schema=args_model,
        )

    async def disconnect(self):
        if self._session_cm:
            try:
                await self._session_cm.__aexit__(None, None, None)
            except Exception:
                pass
        if self._cm:
            try:
                await self._cm.__aexit__(None, None, None)
            except Exception:
                pass
        logger.info("MCP bridge disconnected")
