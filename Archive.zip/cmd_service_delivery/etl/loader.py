"""
ETL Loader: loads OrderPayload data into Memgraph (graph) and Milvus (vectors).
"""

import logging
from typing import List

from models import OrderPayload

logger = logging.getLogger(__name__)


class GraphLoader:
    """Loads CMD order data into Memgraph as a property graph."""

    def __init__(self, memgraph_client):
        self.mg = memgraph_client

    async def create_indexes(self):
        """Create indexes and constraints for efficient queries."""
        index_queries = [
            "CREATE INDEX ON :Order(id);",
            "CREATE INDEX ON :Service(id);",
            "CREATE INDEX ON :Segment(id);",
            "CREATE INDEX ON :Vendor(id);",
            "CREATE INDEX ON :Task(task_id);",
            "CREATE INDEX ON :Client(id);",
            "CREATE INDEX ON :OrderStatus(label);",
        ]
        for q in index_queries:
            try:
                await self.mg.execute(q)
            except Exception as e:
                if "already exists" not in str(e).lower():
                    logger.warning("Index creation warning: %s", e)

    async def load_payloads(self, payloads: List[OrderPayload]):
        """Load all order payloads into the graph."""
        await self.create_indexes()
        loaded = 0
        for payload in payloads:
            try:
                await self._load_single(payload)
                loaded += 1
            except Exception as e:
                logger.error("Failed to load order %d: %s", payload.order.id, e)

        logger.info("Loaded %d/%d order payloads into Memgraph", loaded, len(payloads))

    async def _load_single(self, payload: OrderPayload):
        order = payload.order

        # 1. Create Order node
        await self.mg.execute("""
            MERGE (o:Order {id: $id})
            SET o.latest_status = $latest_status,
                o.comments = $comments,
                o.client_id = $client_id,
                o.status_label = $status_label,
                o.status_main = $status_main
        """, {
            "id": order.id,
            "latest_status": order.latest_status,
            "comments": order.comments,
            "client_id": order.qj_client_id,
            "status_label": order.service_order_status.label if order.service_order_status else None,
            "status_main": order.service_order_status.main if order.service_order_status else None,
        })

        # 2. Create Client node + relationship
        if order.qj_client_id:
            await self.mg.execute("""
                MERGE (c:Client {id: $client_id})
                WITH c
                MATCH (o:Order {id: $order_id})
                MERGE (o)-[:BELONGS_TO_CLIENT]->(c)
            """, {"client_id": order.qj_client_id, "order_id": order.id})

        # 3. Create Service node + relationship
        if order.service and order.service.id:
            svc = order.service
            await self.mg.execute("""
                MERGE (s:Service {id: $id})
                SET s.service_type = $service_type,
                    s.gtt_foc_ready = $gtt_foc_ready,
                    s.foc_status_date = $foc_status_date,
                    s.gii_foc_date = $gii_foc_date
                WITH s
                MATCH (o:Order {id: $order_id})
                MERGE (o)-[:HAS_SERVICE]->(s)
            """, {
                "id": svc.id,
                "service_type": svc.service_type.name if svc.service_type else None,
                "gtt_foc_ready": svc.gtt_foc_ready,
                "foc_status_date": svc.foc_status_date,
                "gii_foc_date": svc.gii_foc_date,
                "order_id": order.id,
            })

        # 4. Create Segment nodes + relationships
        for seg in payload.segments:
            await self.mg.execute("""
                MERGE (seg:Segment {id: $id})
                SET seg.product_type = $product_type,
                    seg.comments = $comments,
                    seg.category = $category,
                    seg.created_on = $created_on,
                    seg.foc_date = $foc_date,
                    seg.service_start_date = $service_start_date,
                    seg.order_confirmed_date = $order_confirmed_date,
                    seg.a_company_name = $a_company_name,
                    seg.a_demarc = $a_demarc,
                    seg.a_city = $a_city,
                    seg.a_state = $a_state,
                    seg.z_company_name = $z_company_name,
                    seg.z_demarc = $z_demarc,
                    seg.z_city = $z_city,
                    seg.z_state = $z_state,
                    seg.vendor_circuit_id = $vendor_circuit_id,
                    seg.vendor_order_id = $vendor_order_id
            """, {
                "id": seg.id,
                "product_type": seg.product_type,
                "comments": seg.comments,
                "category": seg.category,
                "created_on": seg.created_on,
                "foc_date": seg.foc_date,
                "service_start_date": seg.service_start_date,
                "order_confirmed_date": seg.order_confirmed_date,
                "a_company_name": seg.a_company_name,
                "a_demarc": seg.a_demarc,
                "a_city": seg.a_city,
                "a_state": seg.a_state,
                "z_company_name": seg.z_company_name,
                "z_demarc": seg.z_demarc,
                "z_city": seg.z_city,
                "z_state": seg.z_state,
                "vendor_circuit_id": seg.vendor_circuit_id,
                "vendor_order_id": seg.vendor_order_id,
            })

            # Link segment to service
            if order.service and order.service.id:
                await self.mg.execute("""
                    MATCH (s:Service {id: $service_id})
                    MATCH (seg:Segment {id: $segment_id})
                    MERGE (s)-[:HAS_SEGMENT]->(seg)
                """, {"service_id": order.service.id, "segment_id": seg.id})

            # Link segment to order (direct shortcut)
            await self.mg.execute("""
                MATCH (o:Order {id: $order_id})
                MATCH (seg:Segment {id: $segment_id})
                MERGE (o)-[:HAS_SEGMENT]->(seg)
            """, {"order_id": order.id, "segment_id": seg.id})

            # Link segment to A-vendor
            if seg.a_vendor_id:
                await self.mg.execute("""
                    MATCH (seg:Segment {id: $segment_id})
                    MERGE (v:Vendor {id: $vendor_id})
                    MERGE (seg)-[:HAS_A_VENDOR]->(v)
                """, {"segment_id": seg.id, "vendor_id": seg.a_vendor_id})

            # Link segment to Z-vendor
            if seg.z_vendor_id:
                await self.mg.execute("""
                    MATCH (seg:Segment {id: $segment_id})
                    MERGE (v:Vendor {id: $vendor_id})
                    MERGE (seg)-[:HAS_Z_VENDOR]->(v)
                """, {"segment_id": seg.id, "vendor_id": seg.z_vendor_id})

        # 5. Create Vendor nodes (with names)
        for vendor in payload.vendors:
            await self.mg.execute("""
                MERGE (v:Vendor {id: $id})
                SET v.name = $name, v.legal_name = $legal_name
            """, {"id": vendor.id, "name": vendor.name, "legal_name": vendor.legal_name})

        # 6. Create Task nodes + relationships
        for task in order.tasks:
            await self.mg.execute("""
                MERGE (t:Task {task_id: $task_id})
                SET t.status = $status, t.summary = $summary
                WITH t
                MATCH (o:Order {id: $order_id})
                MERGE (o)-[:HAS_TASK]->(t)
            """, {
                "task_id": task.task_id,
                "status": task.status,
                "summary": task.summary,
                "order_id": order.id,
            })

        # 7. Create Note nodes + relationships (using index-based IDs since notes lack unique IDs)
        for i, note in enumerate(order.notes):
            note_id = f"{order.id}_{i}"
            await self.mg.execute("""
                MERGE (n:Note {note_id: $note_id})
                SET n.subject = $subject,
                    n.body = $body,
                    n.created_on = $created_on,
                    n.created_by_name = $created_by_name,
                    n.order_id = $order_id
                WITH n
                MATCH (o:Order {id: $order_id})
                MERGE (o)-[:HAS_NOTE]->(n)
            """, {
                "note_id": note_id,
                "subject": note.subject,
                "body": note.body,
                "created_on": note.created_on,
                "created_by_name": note.created_by_name,
                "order_id": order.id,
            })


class VectorLoader:
    """Loads note text embeddings into Milvus for semantic search."""

    def __init__(self, milvus_client, embedding_service):
        self.milvus = milvus_client
        self.embedding = embedding_service

    async def load_payloads(self, payloads: List[OrderPayload]):
        """Embed and upsert all order notes into Milvus."""
        note_ids = []
        note_texts = []
        note_subjects = []

        for payload in payloads:
            order = payload.order
            for i, note in enumerate(order.notes):
                if not note.body or len(note.body.strip()) < 10:
                    continue
                note_id = f"{order.id}_{i}"
                text = f"Order {order.id} | {note.subject or ''}: {note.body}"
                note_ids.append(note_id)
                note_texts.append(text)
                note_subjects.append(note.subject or "")

        if not note_ids:
            logger.info("No notes to embed")
            return

        logger.info("Embedding %d notes...", len(note_ids))

        batch_size = 32
        total_upserted = 0
        for start in range(0, len(note_ids), batch_size):
            end = start + batch_size
            batch_ids = note_ids[start:end]
            batch_texts = note_texts[start:end]
            batch_subjects = note_subjects[start:end]

            embeddings = await self.embedding.embed_batch(batch_texts)
            count = await self.milvus.insert(
                note_ids=batch_ids,
                embeddings=embeddings,
                note_texts=batch_texts,
                note_subjects=batch_subjects,
            )
            total_upserted += count

        logger.info("Upserted %d note embeddings into Milvus", total_upserted)
