import json
import pytest
from unittest.mock import AsyncMock, MagicMock
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'app'))

from data_access.messaging.ticket_consumer import TicketConsumer  # noqa: E402


@pytest.fixture
def mock_nats_client():
    """Mock NATS Client with JetStream simulation."""
    nats_mock = AsyncMock()
    jetstream_mock = MagicMock()

    # Simulate a missing stream (forcing setup)
    nats_mock.jetstream.return_value = jetstream_mock
    jetstream_mock.stream_info.side_effect = Exception

    return nats_mock


@pytest.fixture
def subscriber(mock_nats_client):
    """Create a mock NATS subscriber instance."""
    return TicketConsumer(
        nats_url="nats://test-server:4222",
        stream_name="DATA_INJESTION_STREAM",
        subject="tickets.created",
        max_concurrent=5
    )


async def test_ensure_stream(subscriber):
    """Test JetStream stream setup process."""
    # Mock the connection and jetstream objects
    subscriber.js = AsyncMock()
    subscriber.js.stream_info.side_effect = Exception("Stream not found")

    # Test that RuntimeError is raised when stream doesn't exist
    with pytest.raises(RuntimeError, match="Stream 'DATA_INJESTION_STREAM' does not exist"):
        await subscriber.ensure_stream()


async def test_ticket_message_processing():
    """Test ticket message processing logic."""
    mock_msg = MagicMock()
    mock_msg.data = json.dumps({
        "operational_status": [
            {"ticket_id": 1234, "status": "Open"}
        ]
    }).encode("utf-8")
    mock_msg.ack = AsyncMock()

    # Simple callback that just acknowledges
    async def simple_callback(msg):
        await msg.ack()

    await simple_callback(mock_msg)

    # Assertions to verify message handling
    assert mock_msg.data is not None, "Expected message data to exist"
    assert isinstance(json.loads(mock_msg.data.decode()), dict), "Expected valid JSON"

    mock_msg.ack.assert_called_once()
