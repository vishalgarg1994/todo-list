# 🚀 Eva Platform Quick Start

**Complete setup guide for Eva messaging infrastructure and ticketing application**

---

## ⚡ 5-Minute Setup

### 🏗️ Step 1: Start Eva Messaging Infrastructure

```bash
# Navigate to messaging infrastructure project directory
cd /path/to/messaging-infrastructure

# Start NATS with JetStream and Stream Manager API
docker compose up -d

# Streams are automatically initialized on startup
# (eva-stream-init container handles this)

# ✅ Verify: NATS Monitor should be accessible
open http://localhost:8222
```

### 🎫 Step 2: Configure & Start Ticketing App

```bash
# Navigate to ticketing_etl project directory
cd /path/to/ticketing_etl

# Create database configuration (one-time setup)
cat > docker-compose.override.yml << 'EOF'
version: '3.8'
services:
  app:
    environment:
      # 🔗 Replace with your PostgreSQL connection
      - DATABASE_URL=postgresql://user:password@host:port/database_name
EOF

# Start ticketing application
docker-compose up -d

# ✅ Verify: Application health should show "healthy"
curl http://localhost:8080/health | jq '.status'
```

### 🎛️ Step 3: Access Monitoring UIs

| Service | URL | Purpose |
|---------|-----|---------|
| **Application Health** | http://localhost:8080/health | Ticketing app status |
| **NATS Monitor** | http://localhost:8222 | Infrastructure health |
| **Message Viewer** | http://localhost:3001 | Real-time message streaming |

---

## 🧪 Test the Integration

```bash
# Send a test message through NATS
nats --server=nats://localhost:4222 \
     --user=ticket-app \
     --password=ticket-app-2024 \
     pub tickets.test '{"test": "Hello Eva", "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'"}'

# View the message in the UI
open http://localhost:3001
```

---

## 🐳 Docker Development Setup

### Local Development Environment

```bash
# Copy the override template for local development
cp docker-compose.override.yml.template docker-compose.override.yml

# Edit with your local database credentials
nano docker-compose.override.yml
```

### Build and Run
```bash
# Build and start services
docker-compose up --build

# Run in background
docker-compose up -d --build

# View logs
docker-compose logs -f app
```

### Development Workflow
```bash
# Stop services
docker-compose down

# Rebuild after code changes
docker-compose up --build

# Run tests inside container
docker-compose exec app python -m pytest
```

### Environment Configuration Options

#### Production
Set environment variables directly or use external secrets:
```bash
export DATABASE_URL="postgresql://user:pass@db:5432/prod_db"
export NATS_URL="nats://nats-cluster:4222"
docker-compose up -d
```

#### Staging
Create `docker-compose.staging.yml`:
```bash
docker-compose -f docker-compose.yml -f docker-compose.staging.yml up -d
```

### Docker Development Features

#### Remote Debugging
Uncomment the debugpy command in `docker-compose.override.yml` and connect your IDE to `localhost:5678`.

#### Container Access
```bash
# Access container shell
docker-compose exec app bash

# View NATS monitoring
open http://localhost:8222
```

#### Network Architecture
- `backend` - Internal communication between app and NATS
- `mock_data_generator_tdp_network` - External network for mock data integration

#### Security Features
- ✅ Non-root user in container (`tdpuser`)
- ✅ Credentials via environment variables (not in images)
- ✅ Local overrides ignored by git
- ⚠️ Remove any committed credential files from git history

---

## 🛠️ Common Operations

### Check System Health
```bash
# NATS infrastructure
curl http://localhost:8222/varz | jq '.server_name'

# Ticketing application
curl http://localhost:8080/health/live

# Message viewer UI
curl http://localhost:3001/api/health
```

### View Logs
```bash
# Eva NATS logs
docker logs eva-nats

# Ticketing app logs (from ticketing_etl directory)
docker-compose logs -f app

# Message viewer logs (from messaging-infrastructure directory)
cd /path/to/messaging-infrastructure && docker-compose logs simple-ui
```

### Restart Services
```bash
# Restart messaging infrastructure
cd /path/to/messaging-infrastructure && docker-compose restart

# Restart ticketing app
cd /path/to/ticketing_etl && docker-compose restart

# Restart just NATS container
docker restart eva-nats

# Restart just ticketing app container
cd /path/to/ticketing_etl && docker-compose restart app
```

---

## 🔧 Troubleshooting

### 🔴 "Connection refused" errors
```bash
# Check if Eva NATS is running
docker ps | grep eva-nats

# If not running, start Eva infrastructure first
cd /path/to/messaging-infrastructure
docker-compose up -d
```

### 🐳 Docker Troubleshooting

#### "No such file or directory" errors
Ensure all required directories exist in `src/`:
- `domain/`, `infrastructure/`, `services/`, `utils/`, `classes/`, `messaging/`

#### NATS connection issues
1. Check NATS is healthy: `docker-compose ps`
2. Verify network connectivity: `docker-compose exec app nc -z nats 4222`
3. Check NATS logs: `docker-compose logs nats`

#### Permission errors
The container runs as non-root user. Ensure your local directories are readable:
```bash
chmod -R 755 src/ config/
```

### 🟡 "Stream not found" errors
```bash
# Re-initialize streams
cd /path/to/messaging-infrastructure
./nats/scripts/init-streams.sh
```

### 🟠 Ticketing app fails to start
```bash
# Check database connection in docker-compose.override.yml
# Ensure Eva NATS is running first
# Check logs: docker-compose logs app
```

### 🔵 No messages in viewer
```bash
# Check if message viewer is running
curl http://localhost:3001/api/health

# Restart message viewer
cd /path/to/messaging-infrastructure
docker-compose restart simple-ui
```

---

## 📁 Project Structure

```
eva/
├── messaging-infrastructure/              # 🚀 Eva messaging backbone
│   ├── docker-compose.yml                # NATS infrastructure
│   ├── nats/scripts/init-streams.sh      # Stream initialization (optional)
│   └── simple-ui/                        # Message viewer UI
└── ticketing_etl/                        # 🎫 Ticketing application
    ├── docker-compose.yml                # App deployment
    ├── docker-compose.override.yml       # Local config (create this)
    └── src/                               # Application code
```

---

## 🔗 URLs Quick Reference

| Component | URL | Purpose |
|-----------|-----|---------|
| **Ticketing App Health** | http://localhost:8080/health | App status & components |
| **Ticketing App Live** | http://localhost:8080/health/live | K8s liveness probe |
| **Ticketing App Ready** | http://localhost:8080/health/ready | K8s readiness probe |
| **NATS Monitor** | http://localhost:8222 | Server stats & connections |
| **Message Viewer** | http://localhost:3001 | Real-time message streaming |

---

## ⚙️ Environment Variables

### Required (Database)
```bash
DATABASE_URL=postgresql://user:password@host:port/database
```

### Pre-configured (NATS)
```bash
NATS_URL=nats://localhost:4222
NATS_PUBLISHER_USER=ticket-app
NATS_PUBLISHER_PASSWORD=ticket-app-2024
JETSTREAM_STREAM_NAME=EVA_TICKETING_STREAM
```

### Optional (Scheduling)
```bash
DAILY_SCHEDULE_TIME=02:00                    # UTC time for daily processing
RUN_ON_STARTUP=true                          # Process data on startup
LOOKUP_INTERVAL_MINUTES=1440                 # 24 hours between runs
```

---

**🎉 Eva Platform is now running! Your applications can communicate through enterprise-grade messaging.**

For detailed documentation:
- **Messaging Infrastructure**: [../messaging-infrastructure/README.md](../messaging-infrastructure/README.md)
- **Ticketing Application**: [README.md](README.md)