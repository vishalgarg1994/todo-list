# MCP Ticket Local Testing

Test mcp_ticket independently without NATS pipeline.

## Quick Start

### 1. Generate Test Data (if not already done)
```bash
python3 test_data/generate_dummy_data.py
```

This creates `test_data/dummy_tickets.json` with:
- **20 tickets** across **2 clients**
- **1 master ticket** + **3 child tickets** (tests CHILD_OF relationship)
- Realistic timestamps over last 30 days
- Mix of statuses, priorities, and knowledge graph data

### 2. Run Test
```bash
# Make sure Memgraph is running
docker-compose up -d memgraph

# Run the test
python3 scripts/test_local.py
```

The script will:
1. Ask if you want to clear the database
2. Load all 20 tickets from `dummy_tickets.json`
3. Process each ticket through `process_ticket()` (bypasses NATS)
4. Show statistics on nodes and relationships created

### 3. Verify in Memgraph

Connect to Memgraph and run queries:

```cypher
# Count all nodes
MATCH (n) RETURN labels(n) AS type, count(n) AS count;

# Count all relationships
MATCH ()-[r]->() RETURN type(r) AS type, count(r) AS count;

# Verify master/child tickets
MATCH (child:Ticket)-[:CHILD_OF]->(master:Ticket)
RETURN master.ticket_id, child.ticket_id;

# Verify HAS_USER with role property
MATCH (t:Ticket)-[r:HAS_USER]->(u:UserInfo)
RETURN t.ticket_id, r.role, u.name
LIMIT 10;

# Verify NOC info is on Client
MATCH (c:Client)
RETURN c.client_name, c.default_noc, c.default_noc_queue;
```

## Test Data Structure

### Clients (2)
- **TechCorp Industries** (C001) - 12 tickets, NOC_AMER
- **Global Services Ltd** (C002) - 8 tickets, NOC_EMEA

### Ticket Mix
- **Statuses**: Open, Closed, In Progress, Resolved
- **Priorities**: P1-P5
- **Master/Child**: INC-001 (master) → INC-002, INC-003, INC-004 (children)
- **Knowledge Graph**:
  - 70% have UserInfo (incident_manager, operations_specialist)
  - 30% have surveys (SurveyInfo)
  - 15% have maintenance windows (MaintenanceWindow)
  - 30% have vendors (VendorInfo)
  - 100% have contacts (ContactInfo)

## Files

- `dummy_tickets.json` - Generated test data (20 tickets)
- `generate_dummy_data.py` - Script to regenerate test data
- `../scripts/test_local.py` - Test runner script

## Customization

Edit `generate_dummy_data.py` to change:
- Number of tickets
- Client names/properties
- Date ranges
- Mix of knowledge graph data

Then regenerate:
```bash
python3 test_data/generate_dummy_data.py
```

## KISS Principle

This bypasses NATS compression/decompression - we test the **core schema logic** directly.
- ✅ Simple JSON → `process_ticket()`
- ✅ No NATS dependency
- ✅ Easy to edit test data
- ✅ Fast iteration
