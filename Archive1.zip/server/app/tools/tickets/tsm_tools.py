"""
TSM-specific tools for ticket system
Provides navigation through TSM ticket type relationships:
- Incident, Case, Problem, Request ticket types
- RAISED_BY_INCIDENT, BELONGS_TO_CASE, RELATED_TO_PROBLEM relationships
- Task relationships (HAS_TASK)
"""
import logging
import polars as pl
from typing import Any, Optional, List
from fastmcp.exceptions import ToolError
from utils.utilities import Helpers


async def get_tickets_by_type(
    services: dict,
    ticket_type: str,
    client_name: Optional[str] = None,
    status: Optional[str] = None,
    limit: Optional[int] = 100
) -> Any:
    """
    Get tickets filtered by ticket_type (incident, case, problem, request).

    TSM tickets have a ticket_type property that identifies the ticket category.
    Optionally filter by client_name and status.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_tickets_by_type type={ticket_type}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Validate ticket_type
        valid_types = ["incident", "case", "problem", "request"]
        if ticket_type.lower() not in valid_types:
            raise ToolError(f"Invalid ticket_type. Must be one of: {valid_types}")

        # Build WHERE clause
        where_clauses = ["t.ticket_type = $ticket_type"]
        params = {"ticket_type": ticket_type.lower()}

        if client_name:
            where_clauses.append("c.client_name = $client_name")
            params["client_name"] = client_name

        if status:
            where_clauses.append("t.ticket_status = $status")
            params["status"] = status.lower()

        where_clause = " AND ".join(where_clauses)

        cypher_query = f"""
            MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
            WHERE {where_clause}
            OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
            OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
            RETURN c.client_name as client_name,
                   t.ticket_id as ticket_id,
                   t.ticket_type as ticket_type,
                   t.ticket_sys_id as ticket_sys_id,
                   t.ticket_status as status,
                   t.ticket_category as category,
                   t.priority as priority,
                   t.created_on as created_on,
                   t.closed_on as closed_on,
                   f.short_description as fault_description,
                   o.rfo as rfo,
                   o.mttr as mttr
            ORDER BY t.created_on DESC
            LIMIT {limit}
        """

        result = await memgraph_client.execute(cypher_query, params)
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No {ticket_type} tickets found"}

        return Helpers.recursive_serialize({
            "ticket_type": ticket_type,
            "filters": {"client_name": client_name, "status": status},
            "ticket_count": len(response_data),
            "tickets": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_tickets_by_type: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve tickets by type: {e}")


async def get_cases_by_incident(
    incident_id: str,
    services: dict,
    limit: Optional[int] = 50
) -> Any:
    """
    Get all cases raised by a specific incident.

    Traverses RAISED_BY_INCIDENT relationship from Case to Incident.
    In TSM, cases are created when an incident requires customer communication.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_cases_by_incident for incident: {incident_id}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (incident:Ticket {ticket_id: $incident_id, ticket_type: "incident"})
            MATCH (case_ticket:Ticket)-[:RAISED_BY_INCIDENT]->(incident)
            MATCH (c:Client)-[:HAS_TICKET]->(case_ticket)
            OPTIONAL MATCH (case_ticket)-[:HAS_OUTAGE]->(o:Outage_Info)
            RETURN incident.ticket_id as incident_id,
                   incident.ticket_status as incident_status,
                   c.client_name as client_name,
                   case_ticket.ticket_id as case_id,
                   case_ticket.ticket_sys_id as case_sys_id,
                   case_ticket.ticket_status as case_status,
                   case_ticket.created_on as case_created_on,
                   case_ticket.closed_on as case_closed_on,
                   o.resolution as resolution
            ORDER BY case_ticket.created_on DESC
        """

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute(cypher_query, {"incident_id": incident_id})
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            # Check if incident exists
            check_query = """
                MATCH (t:Ticket {ticket_id: $incident_id})
                RETURN t.ticket_id as ticket_id, t.ticket_type as ticket_type
            """
            check_result = await memgraph_client.execute(check_query, {"incident_id": incident_id})
            check_records = [r.data() for r in check_result]

            if not check_records:
                return {"message": f"No ticket found with ID: {incident_id}"}
            elif check_records[0].get("ticket_type") != "incident":
                return {"message": f"Ticket {incident_id} is not an incident (type: {check_records[0].get('ticket_type')})"}
            else:
                return {"message": f"No cases found raised by incident: {incident_id}"}

        return Helpers.recursive_serialize({
            "incident_id": incident_id,
            "case_count": len(response_data),
            "cases": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_cases_by_incident: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve cases by incident: {e}")


async def get_requests_by_case(
    case_id: str,
    services: dict,
    limit: Optional[int] = 50
) -> Any:
    """
    Get all requests belonging to a specific case.

    Traverses BELONGS_TO_CASE relationship from Request to Case.
    In TSM, requests (SCTASKs) are work items within a case.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_requests_by_case for case: {case_id}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (case_ticket:Ticket {ticket_id: $case_id, ticket_type: "case"})
            MATCH (request:Ticket)-[:BELONGS_TO_CASE]->(case_ticket)
            MATCH (c:Client)-[:HAS_TICKET]->(request)
            RETURN case_ticket.ticket_id as case_id,
                   case_ticket.ticket_status as case_status,
                   c.client_name as client_name,
                   request.ticket_id as request_id,
                   request.ticket_sys_id as request_sys_id,
                   request.ticket_status as request_status,
                   request.priority as priority,
                   request.created_on as request_created_on,
                   request.closed_on as request_closed_on
            ORDER BY request.created_on DESC
        """

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute(cypher_query, {"case_id": case_id})
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            # Check if case exists
            check_query = """
                MATCH (t:Ticket {ticket_id: $case_id})
                RETURN t.ticket_id as ticket_id, t.ticket_type as ticket_type
            """
            check_result = await memgraph_client.execute(check_query, {"case_id": case_id})
            check_records = [r.data() for r in check_result]

            if not check_records:
                return {"message": f"No ticket found with ID: {case_id}"}
            elif check_records[0].get("ticket_type") != "case":
                return {"message": f"Ticket {case_id} is not a case (type: {check_records[0].get('ticket_type')})"}
            else:
                return {"message": f"No requests found belonging to case: {case_id}"}

        return Helpers.recursive_serialize({
            "case_id": case_id,
            "request_count": len(response_data),
            "requests": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_requests_by_case: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve requests by case: {e}")


async def get_ticket_tasks(
    ticket_id: str,
    services: dict
) -> Any:
    """
    Get all tasks for a specific ticket.

    Traverses HAS_TASK relationship from Ticket to Task.
    Task types: TASK (incident), CSTASK (case), PTASK (problem), CTASK (change).
    Note: Request tickets (SCTASK) are tickets themselves, not tasks.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_ticket_tasks for ticket: {ticket_id}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (t:Ticket {ticket_id: $ticket_id})-[:HAS_TASK]->(task:Task)
            RETURN t.ticket_id as ticket_id,
                   t.ticket_type as ticket_type,
                   task.task_sys_id as task_sys_id,
                   task.task_number as task_number,
                   task.task_state as task_state,
                   task.task_type as task_type,
                   task.short_description as description,
                   task.priority as priority,
                   task.assigned_to as assigned_to,
                   task.assigned_to_sys_id as assigned_to_sys_id,
                   task.assignment_group as assignment_group,
                   task.created_on as created_on,
                   task.created_by as created_by,
                   task.closed_on as closed_on,
                   task.closed_by as closed_by,
                   task.closure_code as closure_code,
                   task.third_party_name as third_party_name,
                   task.third_party_ticket as third_party_ticket,
                   task.third_party_sys_id as third_party_sys_id,
                   task.vendor_id as vendor_id,
                   task.vendor_name as vendor_name,
                   task.service_type as service_type
            ORDER BY task.created_on DESC
        """

        result = await memgraph_client.execute(cypher_query, {"ticket_id": ticket_id})
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            # Check if ticket exists
            check_query = """
                MATCH (t:Ticket {ticket_id: $ticket_id})
                RETURN t.ticket_id as ticket_id, t.ticket_type as ticket_type
            """
            check_result = await memgraph_client.execute(check_query, {"ticket_id": ticket_id})
            check_records = [r.data() for r in check_result]

            if not check_records:
                return {"message": f"No ticket found with ID: {ticket_id}"}
            else:
                return {
                    "ticket_id": ticket_id,
                    "ticket_type": check_records[0].get("ticket_type"),
                    "message": "No tasks found for this ticket",
                    "task_count": 0,
                    "tasks": []
                }

        ticket_type = response_data[0].get("ticket_type") if response_data else None

        return Helpers.recursive_serialize({
            "ticket_id": ticket_id,
            "ticket_type": ticket_type,
            "task_count": len(response_data),
            "tasks": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_ticket_tasks: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve ticket tasks: {e}")


async def get_related_problem(
    incident_id: str,
    services: dict
) -> Any:
    """
    Get the problem related to a specific incident.

    Traverses RELATED_TO_PROBLEM relationship from Incident to Problem.
    In TSM, incidents can be linked to a root cause problem.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_related_problem for incident: {incident_id}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (incident:Ticket {ticket_id: $incident_id, ticket_type: "incident"})
            MATCH (incident)-[:RELATED_TO_PROBLEM]->(problem:Ticket)
            MATCH (c:Client)-[:HAS_TICKET]->(problem)
            OPTIONAL MATCH (problem)-[:HAS_FAULT]->(f:Fault)
            OPTIONAL MATCH (problem)-[:HAS_OUTAGE]->(o:Outage_Info)
            RETURN incident.ticket_id as incident_id,
                   incident.ticket_status as incident_status,
                   c.client_name as client_name,
                   problem.ticket_id as problem_id,
                   problem.ticket_sys_id as problem_sys_id,
                   problem.ticket_status as problem_status,
                   problem.created_on as problem_created_on,
                   problem.closed_on as problem_closed_on,
                   f.short_description as problem_description,
                   f.rfo as rfo,
                   o.resolution as resolution
        """

        result = await memgraph_client.execute(cypher_query, {"incident_id": incident_id})
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            # Check if incident exists
            check_query = """
                MATCH (t:Ticket {ticket_id: $incident_id})
                RETURN t.ticket_id as ticket_id, t.ticket_type as ticket_type
            """
            check_result = await memgraph_client.execute(check_query, {"incident_id": incident_id})
            check_records = [r.data() for r in check_result]

            if not check_records:
                return {"message": f"No ticket found with ID: {incident_id}"}
            elif check_records[0].get("ticket_type") != "incident":
                return {"message": f"Ticket {incident_id} is not an incident (type: {check_records[0].get('ticket_type')})"}
            else:
                return {"message": f"No related problem found for incident: {incident_id}"}

        return Helpers.recursive_serialize({
            "incident_id": incident_id,
            "related_problem": response_data[0]
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_related_problem: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve related problem: {e}")


async def get_incident_children(
    incident_id: str,
    services: dict,
    limit: Optional[int] = 50
) -> Any:
    """
    Get child incidents of a parent incident.

    Traverses CHILD_OF relationship from child Incident to parent Incident.
    In TSM, major incidents can have child incidents.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_incident_children for incident: {incident_id}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (parent:Ticket {ticket_id: $incident_id, ticket_type: "incident"})
            MATCH (child:Ticket)-[:CHILD_OF]->(parent)
            MATCH (c:Client)-[:HAS_TICKET]->(child)
            OPTIONAL MATCH (child)-[:HAS_FAULT]->(f:Fault)
            RETURN parent.ticket_id as parent_incident_id,
                   parent.ticket_status as parent_status,
                   c.client_name as client_name,
                   child.ticket_id as child_incident_id,
                   child.ticket_sys_id as child_sys_id,
                   child.ticket_type as child_type,
                   child.ticket_status as child_status,
                   child.priority as priority,
                   child.created_on as created_on,
                   child.closed_on as closed_on,
                   f.short_description as fault_description
            ORDER BY child.created_on DESC
        """

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute(cypher_query, {"incident_id": incident_id})
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            # Check if incident exists
            check_query = """
                MATCH (t:Ticket {ticket_id: $incident_id})
                RETURN t.ticket_id as ticket_id, t.ticket_type as ticket_type
            """
            check_result = await memgraph_client.execute(check_query, {"incident_id": incident_id})
            check_records = [r.data() for r in check_result]

            if not check_records:
                return {"message": f"No ticket found with ID: {incident_id}"}
            elif check_records[0].get("ticket_type") != "incident":
                return {"message": f"Ticket {incident_id} is not an incident (type: {check_records[0].get('ticket_type')})"}
            else:
                return {
                    "parent_incident_id": incident_id,
                    "message": "No child incidents found",
                    "child_count": 0,
                    "children": []
                }

        return Helpers.recursive_serialize({
            "parent_incident_id": incident_id,
            "child_count": len(response_data),
            "children": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_incident_children: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve incident children: {e}")


async def get_ticket_hierarchy(
    ticket_id: str,
    services: dict
) -> Any:
    """
    Get the full TSM ticket hierarchy for a ticket.

    Shows all relationships: parent/child incidents, cases raised by incident,
    requests in case, related problems, and tasks.
    Provides a complete view of how tickets are connected.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_ticket_hierarchy for ticket: {ticket_id}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # First get the ticket and its type
        base_query = """
            MATCH (t:Ticket {ticket_id: $ticket_id})
            MATCH (c:Client)-[:HAS_TICKET]->(t)
            RETURN t.ticket_id as ticket_id,
                   t.ticket_type as ticket_type,
                   t.ticket_sys_id as ticket_sys_id,
                   t.ticket_status as status,
                   c.client_name as client_name
        """

        result = await memgraph_client.execute(base_query, {"ticket_id": ticket_id})
        records = [record.data() for record in result]

        if not records:
            return {"message": f"No ticket found with ID: {ticket_id}"}

        ticket_info = records[0]
        ticket_type = ticket_info.get("ticket_type")

        hierarchy = {
            "ticket": ticket_info,
            "relationships": {}
        }

        # Get relationships based on ticket type
        if ticket_type == "incident":
            # Child incidents
            children_query = """
                MATCH (child:Ticket)-[:CHILD_OF]->(t:Ticket {ticket_id: $ticket_id})
                RETURN child.ticket_id as ticket_id, child.ticket_type as type, child.ticket_status as status
            """
            children_result = await memgraph_client.execute(children_query, {"ticket_id": ticket_id})
            hierarchy["relationships"]["child_incidents"] = [r.data() for r in children_result]

            # Parent incident
            parent_query = """
                MATCH (t:Ticket {ticket_id: $ticket_id})-[:CHILD_OF]->(parent:Ticket)
                RETURN parent.ticket_id as ticket_id, parent.ticket_type as type, parent.ticket_status as status
            """
            parent_result = await memgraph_client.execute(parent_query, {"ticket_id": ticket_id})
            parent_records = [r.data() for r in parent_result]
            hierarchy["relationships"]["parent_incident"] = parent_records[0] if parent_records else None

            # Cases raised by this incident
            cases_query = """
                MATCH (case_t:Ticket)-[:RAISED_BY_INCIDENT]->(t:Ticket {ticket_id: $ticket_id})
                RETURN case_t.ticket_id as ticket_id, case_t.ticket_type as type, case_t.ticket_status as status
            """
            cases_result = await memgraph_client.execute(cases_query, {"ticket_id": ticket_id})
            hierarchy["relationships"]["cases_raised"] = [r.data() for r in cases_result]

            # Related problem
            problem_query = """
                MATCH (t:Ticket {ticket_id: $ticket_id})-[:RELATED_TO_PROBLEM]->(problem:Ticket)
                RETURN problem.ticket_id as ticket_id, problem.ticket_type as type, problem.ticket_status as status
            """
            problem_result = await memgraph_client.execute(problem_query, {"ticket_id": ticket_id})
            problem_records = [r.data() for r in problem_result]
            hierarchy["relationships"]["related_problem"] = problem_records[0] if problem_records else None

        elif ticket_type == "case":
            # Incident that raised this case
            incident_query = """
                MATCH (t:Ticket {ticket_id: $ticket_id})-[:RAISED_BY_INCIDENT]->(incident:Ticket)
                RETURN incident.ticket_id as ticket_id, incident.ticket_type as type, incident.ticket_status as status
            """
            incident_result = await memgraph_client.execute(incident_query, {"ticket_id": ticket_id})
            incident_records = [r.data() for r in incident_result]
            hierarchy["relationships"]["raised_by_incident"] = incident_records[0] if incident_records else None

            # Requests in this case
            requests_query = """
                MATCH (request:Ticket)-[:BELONGS_TO_CASE]->(t:Ticket {ticket_id: $ticket_id})
                RETURN request.ticket_id as ticket_id, request.ticket_type as type, request.ticket_status as status
            """
            requests_result = await memgraph_client.execute(requests_query, {"ticket_id": ticket_id})
            hierarchy["relationships"]["requests"] = [r.data() for r in requests_result]

        elif ticket_type == "request":
            # Case this request belongs to
            case_query = """
                MATCH (t:Ticket {ticket_id: $ticket_id})-[:BELONGS_TO_CASE]->(case_t:Ticket)
                RETURN case_t.ticket_id as ticket_id, case_t.ticket_type as type, case_t.ticket_status as status
            """
            case_result = await memgraph_client.execute(case_query, {"ticket_id": ticket_id})
            case_records = [r.data() for r in case_result]
            hierarchy["relationships"]["belongs_to_case"] = case_records[0] if case_records else None

        elif ticket_type == "problem":
            # Incidents related to this problem
            incidents_query = """
                MATCH (incident:Ticket)-[:RELATED_TO_PROBLEM]->(t:Ticket {ticket_id: $ticket_id})
                RETURN incident.ticket_id as ticket_id, incident.ticket_type as type, incident.ticket_status as status
            """
            incidents_result = await memgraph_client.execute(incidents_query, {"ticket_id": ticket_id})
            hierarchy["relationships"]["related_incidents"] = [r.data() for r in incidents_result]

        # Tasks (all ticket types can have tasks)
        tasks_query = """
            MATCH (t:Ticket {ticket_id: $ticket_id})-[:HAS_TASK]->(task:Task)
            RETURN task.task_number as task_number, task.task_state as state, task.task_type as type
        """
        tasks_result = await memgraph_client.execute(tasks_query, {"ticket_id": ticket_id})
        hierarchy["relationships"]["tasks"] = [r.data() for r in tasks_result]

        return Helpers.recursive_serialize(hierarchy)

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_ticket_hierarchy: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve ticket hierarchy: {e}")


# =============================================================================
# Configuration Item (CI) Tools
# =============================================================================

async def get_tickets_by_ci(
    ci_name: str,
    services: dict,
    limit: Optional[int] = 50
) -> Any:
    """
    Get all tickets that affected a specific Configuration Item (circuit/service).

    Configuration Items represent circuits or services (e.g., GTT/002605906, IR/ethernet/01273501).
    Use this to find all tickets related to a specific circuit.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_tickets_by_ci ci_name={ci_name}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (t:Ticket)-[:RELATES_TO_CI]->(ci:ConfigurationItem)
            WHERE ci.ci_name CONTAINS $ci_name
            MATCH (c:Client)-[:HAS_TICKET]->(t)
            OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
            RETURN ci.ci_name as ci_name,
                   ci.ci_sys_id as ci_sys_id,
                   c.client_name as client_name,
                   t.ticket_id as ticket_id,
                   t.ticket_type as ticket_type,
                   t.ticket_status as status,
                   t.priority as priority,
                   t.created_on as created_on,
                   t.closed_on as closed_on,
                   f.short_description as fault_description
            ORDER BY t.created_on DESC
        """

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute(cypher_query, {"ci_name": ci_name})
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No tickets found affecting CI containing: {ci_name}"}

        return Helpers.recursive_serialize({
            "ci_search": ci_name,
            "ticket_count": len(response_data),
            "tickets": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_tickets_by_ci: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve tickets by CI: {e}")


async def get_ticket_cis(
    ticket_id: str,
    services: dict
) -> Any:
    """
    Get all Configuration Items (circuits/services) affected by a ticket.

    Returns the list of circuits or services that were impacted by the ticket.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_ticket_cis ticket={ticket_id}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (t:Ticket {ticket_id: $ticket_id})-[:RELATES_TO_CI]->(ci:ConfigurationItem)
            RETURN ci.ci_sys_id as ci_sys_id,
                   ci.ci_name as ci_name,
                   ci.is_manually_added as is_manually_added
            ORDER BY ci.ci_name
        """

        result = await memgraph_client.execute(cypher_query, {"ticket_id": ticket_id})
        records = [record.data() for record in result]

        if not records:
            # Check if ticket exists
            check_query = """
                MATCH (t:Ticket {ticket_id: $ticket_id})
                RETURN t.ticket_id as ticket_id
            """
            check_result = await memgraph_client.execute(check_query, {"ticket_id": ticket_id})
            check_records = [r.data() for r in check_result]

            if not check_records:
                return {"message": f"No ticket found with ID: {ticket_id}"}
            else:
                return {
                    "ticket_id": ticket_id,
                    "message": "No Configuration Items linked to this ticket",
                    "ci_count": 0,
                    "configuration_items": []
                }

        return Helpers.recursive_serialize({
            "ticket_id": ticket_id,
            "ci_count": len(records),
            "configuration_items": records
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_ticket_cis: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve ticket CIs: {e}")


async def get_ci_ticket_history(
    ci_name: str,
    services: dict,
    limit: Optional[int] = 100
) -> Any:
    """
    Get the complete ticket history for a Configuration Item (circuit/service).

    Shows all tickets that affected this CI over time, with ticket details and fault information.
    Useful for identifying recurring issues on a circuit.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_ci_ticket_history ci_name={ci_name}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (ci:ConfigurationItem)
            WHERE ci.ci_name CONTAINS $ci_name
            MATCH (t:Ticket)-[:RELATES_TO_CI]->(ci)
            MATCH (c:Client)-[:HAS_TICKET]->(t)
            OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
            OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
            WITH ci, t, c, f, o
            ORDER BY t.created_on DESC
            RETURN ci.ci_name as ci_name,
                   c.client_name as client_name,
                   t.ticket_id as ticket_id,
                   t.ticket_type as ticket_type,
                   t.ticket_status as status,
                   t.priority as priority,
                   t.created_on as created_on,
                   t.closed_on as closed_on,
                   f.short_description as fault_description,
                   f.rfo as rfo,
                   o.mttr as mttr,
                   o.resolution as resolution
        """

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute(cypher_query, {"ci_name": ci_name})
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No ticket history found for CI containing: {ci_name}"}

        # Get unique CI names from results
        ci_names = list(set([r.get("ci_name") for r in response_data if r.get("ci_name")]))

        return Helpers.recursive_serialize({
            "ci_search": ci_name,
            "matching_cis": ci_names,
            "ticket_count": len(response_data),
            "ticket_history": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_ci_ticket_history: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve CI ticket history: {e}")


# =============================================================================
# Normalized Field Tools (Jan 2026)
# Tools that leverage unified/normalized field structure
# =============================================================================

async def get_escalated_tickets(
    services: dict,
    min_escalation_level: Optional[int] = 2,
    ticket_type: Optional[str] = None,
    status: Optional[str] = None,
    limit: Optional[int] = 100
) -> Any:
    """
    Get tickets filtered by escalation level.

    Escalation levels indicate severity/priority escalation:
    - Level 1: Initial handling
    - Level 2: Team lead escalation
    - Level 3: Management escalation
    - Level 4+: Executive escalation

    Optionally filter by ticket_type (incident, case, problem) and status.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_escalated_tickets min_level={min_escalation_level}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        where_clauses = ["t.escalation_level >= $min_level"]
        params = {"min_level": min_escalation_level}

        if ticket_type:
            valid_types = ["incident", "case", "problem", "request"]
            if ticket_type.lower() not in valid_types:
                raise ToolError(f"Invalid ticket_type. Must be one of: {valid_types}")
            where_clauses.append("t.ticket_type = $ticket_type")
            params["ticket_type"] = ticket_type.lower()

        if status:
            where_clauses.append("t.ticket_status = $status")
            params["status"] = status.lower()

        where_clause = " AND ".join(where_clauses)

        cypher_query = f"""
            MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
            WHERE {where_clause}
            OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
            RETURN c.client_name as client_name,
                   t.ticket_id as ticket_id,
                   t.ticket_type as ticket_type,
                   t.ticket_status as status,
                   t.priority as priority,
                   t.escalation_level as escalation_level,
                   t.created_on as created_on,
                   t.closed_on as closed_on,
                   t.assignment_group as assignment_group,
                   t.assigned_to as assigned_to,
                   f.short_description as fault_description
            ORDER BY t.escalation_level DESC, t.created_on DESC
            LIMIT {limit}
        """

        result = await memgraph_client.execute(cypher_query, params)
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No escalated tickets found with level >= {min_escalation_level}"}

        return Helpers.recursive_serialize({
            "filters": {
                "min_escalation_level": min_escalation_level,
                "ticket_type": ticket_type,
                "status": status
            },
            "ticket_count": len(response_data),
            "escalated_tickets": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_escalated_tickets: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve escalated tickets: {e}")


async def get_tickets_by_resolution(
    resolution_code: str,
    services: dict,
    ticket_type: Optional[str] = None,
    limit: Optional[int] = 100
) -> Any:
    """
    Get tickets filtered by resolution code.

    Common resolution codes include:
    - Resolved: Issue fixed
    - Cancelled: Request cancelled
    - Duplicate: Duplicate of another ticket
    - No Fault Found: Investigation found no issue
    - Workaround: Temporary fix applied

    Optionally filter by ticket_type.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_tickets_by_resolution code={resolution_code}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        where_clauses = ["t.resolution_code CONTAINS $resolution_code"]
        params = {"resolution_code": resolution_code}

        if ticket_type:
            valid_types = ["incident", "case", "problem", "request"]
            if ticket_type.lower() not in valid_types:
                raise ToolError(f"Invalid ticket_type. Must be one of: {valid_types}")
            where_clauses.append("t.ticket_type = $ticket_type")
            params["ticket_type"] = ticket_type.lower()

        where_clause = " AND ".join(where_clauses)

        cypher_query = f"""
            MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
            WHERE {where_clause}
            OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
            OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
            RETURN c.client_name as client_name,
                   t.ticket_id as ticket_id,
                   t.ticket_type as ticket_type,
                   t.ticket_status as status,
                   t.resolution_code as resolution_code,
                   t.created_on as created_on,
                   t.closed_on as closed_on,
                   f.short_description as fault_description,
                   o.resolution as resolution_notes
            ORDER BY t.closed_on DESC
            LIMIT {limit}
        """

        result = await memgraph_client.execute(cypher_query, params)
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No tickets found with resolution code containing: {resolution_code}"}

        return Helpers.recursive_serialize({
            "resolution_search": resolution_code,
            "ticket_type_filter": ticket_type,
            "ticket_count": len(response_data),
            "tickets": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_tickets_by_resolution: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve tickets by resolution: {e}")


async def get_change_caused_incidents(
    services: dict,
    change_number: Optional[str] = None,
    status: Optional[str] = None,
    limit: Optional[int] = 100
) -> Any:
    """
    Get incidents that were caused by infrastructure changes.

    Returns tickets where caused_by_change_sys_id is set, indicating
    the ticket was a result of a change implementation.

    Optionally filter by specific change_number or ticket status.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_change_caused_incidents change={change_number}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        where_clauses = ["t.caused_by_change_sys_id IS NOT NULL"]
        params = {}

        if change_number:
            where_clauses.append("change.change_number = $change_number")
            params["change_number"] = change_number

        if status:
            where_clauses.append("t.ticket_status = $status")
            params["status"] = status.lower()

        where_clause = " AND ".join(where_clauses)

        cypher_query = f"""
            MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
            WHERE {where_clause}
            OPTIONAL MATCH (t)-[:AFFECTED_BY_CHANGE]->(change:Change)
            OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
            RETURN c.client_name as client_name,
                   t.ticket_id as ticket_id,
                   t.ticket_type as ticket_type,
                   t.ticket_status as status,
                   t.priority as priority,
                   t.caused_by_change_sys_id as caused_by_change_sys_id,
                   change.change_number as change_number,
                   change.change_type as change_type,
                   change.work_type as work_type,
                   change.short_description as change_description,
                   t.created_on as ticket_created_on,
                   t.closed_on as ticket_closed_on,
                   f.short_description as fault_description
            ORDER BY t.created_on DESC
            LIMIT {limit}
        """

        result = await memgraph_client.execute(cypher_query, params)
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            msg = "No incidents found caused by changes"
            if change_number:
                msg += f" (filtered by change {change_number})"
            return {"message": msg}

        return Helpers.recursive_serialize({
            "filters": {
                "change_number": change_number,
                "status": status
            },
            "ticket_count": len(response_data),
            "change_caused_incidents": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_change_caused_incidents: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve change-caused incidents: {e}")
