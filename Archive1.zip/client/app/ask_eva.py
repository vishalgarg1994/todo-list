# Standard library imports
import httpx
import asyncio
import json
import argparse
import yaml
from pathlib import Path
import sys
import re
from typing import Dict, Any, Optional # Import Dict, Any, and Optional for type hinting

# --- Configuration Loading ---
DEFAULT_CONFIG_PATH = "config.yaml"

def load_config(config_path=DEFAULT_CONFIG_PATH):
    """Loads configuration from the YAML file."""
    path_to_check = Path(config_path)
    if not path_to_check.exists():
        # Try looking in the parent directory if run from within app/
        parent_path = Path(__file__).parent.parent / config_path
        if parent_path.exists():
            path_to_check = parent_path
        else:
             raise FileNotFoundError(f"Config file not found at {config_path} or {parent_path}")

    try:
        with open(path_to_check, "r") as f:
            config = yaml.safe_load(f)
            if not config:
                raise ValueError(f"Config file '{path_to_check}' is empty or invalid.")

            # Validate essential keys for the server
            if "server" not in config or "url" not in config["server"] or "timeout" not in config["server"]:
                raise ValueError(f"Missing 'server.url' or 'server.timeout' in {path_to_check}")
            # Validate Ollama config as it's now needed
            required_ollama_keys = ["url", "model", "timeout", "prompt_template"]
            if "ollama" not in config or not all(key in config["ollama"] for key in required_ollama_keys):
                 missing_keys = [key for key in required_ollama_keys if "ollama" not in config or key not in config["ollama"]]
                 raise ValueError(f"Missing required Ollama config keys in {path_to_check}: {', '.join(missing_keys)}")

            return config
    except yaml.YAMLError as e:
        raise ValueError(f"Error parsing {path_to_check}: {e}")
    except Exception as e:
        raise RuntimeError(f"Failed to load configuration from {path_to_check}: {e}")


# --- Server Interaction ---
async def ask_server(server_url: str, question: str, timeout_seconds: float, debug: bool = False) -> Optional[Dict[str, Any]]:
    """
    Sends a question to the server's ask_tickets_question tool,
    optionally prints the SSE stream details if debug is True,
    and returns the collected data.
    """
    # FastMCP 2.9.x uses Streamable HTTP - direct tool endpoint
    tool_url = f"{server_url}/mcp/tools/ask_tickets_question"

    # FastMCP HTTP mode requires JSON-RPC format
    headers = {"Accept": "application/json, text/event-stream"}
    jsonrpc_request = {
        "jsonrpc": "2.0",
        "method": "tools/call",
        "params": {
            "name": "ask_tickets_question",
            "arguments": {"user_query": question}
        },
        "id": 1
    }

    collected_data = {"query": None, "rows": [], "messages": [], "status": None}
    # Note: httpx timeout applies to read inactivity on the stream
    timeout_config = httpx.Timeout(timeout_seconds, connect=10.0)

    if debug:
        print("--- Server Response Stream ---")
    try:
        async with httpx.AsyncClient(timeout=timeout_config) as client:
            async with client.stream("POST", tool_url, json=jsonrpc_request, headers=headers) as response:
                # Check for non-200 status codes before attempting to stream
                if response.status_code != 200:
                    # Attempt to read the body for error details
                    error_body = await response.aread()
                    try:
                        error_detail = json.loads(error_body.decode())
                        print(f"Error from server ({response.status_code}): {error_detail.get('detail', error_body.decode())}", file=sys.stderr)
                    except json.JSONDecodeError:
                        print(f"Error from server ({response.status_code}): {error_body.decode()}", file=sys.stderr)
                    return None # Stop processing on error

                # Process the SSE stream
                stream_successful = True # Assume success unless error occurs
                async for line in response.aiter_lines():
                    if line.startswith("data:"):
                        data_str = line[len("data:"):].strip()
                        if data_str: # Ensure data is not empty
                            try:
                                data_json = json.loads(data_str)
                                # Process, print, and collect based on content
                                # Process and collect based on content
                                if "status" in data_json and "query" in data_json:
                                    collected_data["status"] = data_json['status']
                                    collected_data["query"] = data_json['query']
                                    if debug:
                                        print(f"Status: {data_json['status']}")
                                        print(f"Query: {data_json['query']}")
                                        print("-" * 10) # Separator
                                elif "row" in data_json:
                                    collected_data["rows"].append(data_json["row"])
                                    if debug:
                                        print("Result Row:")
                                        for key, value in data_json["row"].items():
                                            print(f"  {key}: {value}")
                                        print("-" * 10) # Separator
                                elif "message" in data_json:
                                    collected_data["messages"].append(data_json['message'])
                                    if debug:
                                        print(f"Message: {data_json['message']}")
                                elif "error" in data_json:
                                    stream_successful = False
                                    error_message = data_json['error']
                                    collected_data["messages"].append(f"Error: {error_message}")
                                    print(f"Error from Server Stream: {error_message}", file=sys.stderr)
                                else:
                                    # Fallback for unexpected structure - print but don't store structuredly
                                    print(json.dumps(data_json, indent=2))
                            except json.JSONDecodeError:
                                print(f"Warning: Could not decode JSON data from SSE event: {data_str}", file=sys.stderr)
                    elif line.strip(): # Print other non-empty lines (e.g., comments, event types) if needed for debugging
                        # print(f"SSE Line: {line}", file=sys.stderr) # Uncomment for debugging SSE stream
                        pass # Usually ignore non-data lines

                # Return collected data only if the stream was successful overall
                return collected_data if stream_successful else None

    except httpx.HTTPStatusError as e:
        # This might be less likely with streaming if we check status_code first, but keep for robustness
        try:
            error_detail = e.response.json()
            print(f"HTTP Error ({e.response.status_code}): {error_detail.get('detail', e.response.text)}", file=sys.stderr)
        except json.JSONDecodeError:
            print(f"HTTP Error ({e.response.status_code}): {e.response.text}", file=sys.stderr)
    except httpx.RequestError as e:
        print(f"Error connecting to server at {tool_url}: {e}", file=sys.stderr)
    except Exception as e:
        print(f"Unexpected error during server request stream: {e}", file=sys.stderr)
    finally:
        if debug:
            print("----------------------------") # Mark end of stream processing

    return None # Return None if any exception occurred


# --- Ollama Interaction ---
async def ask_ollama(ollama_url: str, model: str, prompt_template: str, question: str, context_data: Dict[str, Any],
                     conversation_history: list, timeout_seconds: float, debug: bool = False) -> str:
    """
    Sends the question and context data to Ollama using the provided prompt template.
    Includes conversation history for context. Returns the answer.
    """
    ollama_api_url = f"{ollama_url}/api/generate"
    timeout_config = httpx.Timeout(timeout_seconds, connect=10.0)

    # Format the context data for the prompt
    context_str = f"Query Executed: {context_data.get('query', 'N/A')}\n"
    context_str += "Results:\n"
    if context_data.get("rows"):
        # Limit rows in prompt to avoid excessive length? For now, include all.
        context_str += json.dumps(context_data["rows"], indent=2)
    else:
        context_str += "No data rows returned."

    # Format conversation history
    history_str = ""
    if conversation_history:
        history_str = "Previous conversation:\n"
        for i, entry in enumerate(conversation_history[-5:], 1):  # Last 5 exchanges
            history_str += f"\nQ{i}: {entry['question']}\n"
            history_str += f"A{i}: {entry['answer'][:200]}...\n"  # Truncate long answers
        history_str += "\n---\n\n"

    # Enhanced prompt template with history
    enhanced_prompt = f"""{history_str}Current database context:
{context_str}

User question: {question}

Instructions: Use the database results and conversation history to answer.
If the user refers to "this ticket", "that incident", "it", etc., use context from
the conversation history and current results to identify what they're referring to.

Answer:"""

    payload = {
        "model": model,
        "prompt": enhanced_prompt,
        "stream": False
    }

    if debug:
        print("\n--- Asking Ollama for Natural Language Answer ---")
        print(f"Model: {model}")
        print(f"Conversation history items: {len(conversation_history)}")

    try:
        async with httpx.AsyncClient(timeout=timeout_config) as client:
            response = await client.post(ollama_api_url, json=payload)
            response.raise_for_status()
            ollama_response = response.json()

            answer = ollama_response.get("response", "Error: Could not find 'response' key in Ollama output.")

            if debug:
                print("\n--- Ollama Response ---")

            # Print the final answer
            print(answer.strip())

            if debug:
                print("-----------------------")

            return answer.strip()

    except httpx.HTTPStatusError as e:
        try:
            error_detail = e.response.json()
            error_msg = f"Error from Ollama ({e.response.status_code}): {error_detail.get('error', e.response.text)}"
        except json.JSONDecodeError:
            error_msg = f"Error from Ollama ({e.response.status_code}): {e.response.text}"
        print(error_msg, file=sys.stderr)
        return error_msg
    except httpx.RequestError as e:
        error_msg = f"Error connecting to Ollama at {ollama_api_url}: {e}"
        print(error_msg, file=sys.stderr)
        return error_msg
    except json.JSONDecodeError:
        error_msg = "Error: Could not decode JSON response from Ollama."
        print(error_msg, file=sys.stderr)
        return error_msg
    except Exception as e:
        error_msg = f"Unexpected error during Ollama request: {e}"
        print(error_msg, file=sys.stderr)
        return error_msg


# --- Interactive Mode ---
async def interactive_mode(args: argparse.Namespace):
    """Interactive conversation mode with history tracking"""
    conversation_history = []

    print("\n" + "="*70)
    print("🎯 EVA Ticket Assistant - Interactive Mode")
    print("="*70)
    print(f"Server: {args.server_url}")
    print(f"Model: {args.ollama_model}")
    print("\nType 'exit' or 'quit' to end the conversation")
    print("Type 'clear' to clear conversation history")
    print("="*70 + "\n")

    try:
        ollama_config = load_config(args.config)['ollama']
    except (FileNotFoundError, ValueError, RuntimeError, KeyError) as e:
        print(f"\nError loading Ollama configuration: {e}", file=sys.stderr)
        return

    while True:
        try:
            # Get user question
            question = input("\n💬 You: ").strip()

            if not question:
                continue

            if question.lower() in ['exit', 'quit']:
                print("\n👋 Goodbye!\n")
                break

            if question.lower() == 'clear':
                conversation_history = []
                print("🗑️  Conversation history cleared")
                continue

            # Query the server
            if args.debug:
                print(f"\n--- Querying server ---")

            server_results = await ask_server(
                server_url=args.server_url,
                question=question,
                timeout_seconds=args.server_timeout,
                debug=args.debug
            )

            if not server_results:
                print("❌ No results from server")
                continue

            # Ask Ollama with conversation history
            print("\n🤖 Assistant: ", end="", flush=True)

            answer = await ask_ollama(
                ollama_url=args.ollama_url or ollama_config['url'],
                model=args.ollama_model or ollama_config['model'],
                prompt_template=ollama_config['prompt_template'],
                question=question,
                context_data=server_results,
                conversation_history=conversation_history,
                timeout_seconds=args.ollama_timeout or float(ollama_config['timeout']),
                debug=args.debug
            )

            # Store in conversation history
            conversation_history.append({
                "question": question,
                "answer": answer,
                "data": server_results
            })

        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!\n")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}", file=sys.stderr)
            if args.debug:
                import traceback
                traceback.print_exc()


# --- Single Question Mode ---
async def single_question_mode(args: argparse.Namespace):
    """Single question mode (original behavior)"""
    if args.debug:
        print(f"Asking server ({args.server_url})")
        print(f"Question: {args.question}")
        print("-" * 20)

    # Get structured data from the server
    server_results = await ask_server(
        server_url=args.server_url,
        question=args.question,
        timeout_seconds=args.server_timeout,
        debug=args.debug
    )

    if not server_results:
        print("Failed to retrieve data from server.", file=sys.stderr)
        return

    try:
        ollama_config = load_config(args.config)['ollama']
        await ask_ollama(
            ollama_url=args.ollama_url or ollama_config['url'],
            model=args.ollama_model or ollama_config['model'],
            prompt_template=ollama_config['prompt_template'],
            question=args.question,
            context_data=server_results,
            conversation_history=[],  # Empty history for single question
            timeout_seconds=args.ollama_timeout or float(ollama_config['timeout']),
            debug=args.debug
        )
    except (FileNotFoundError, ValueError, RuntimeError, KeyError) as e:
        print(f"\nError loading or using Ollama configuration: {e}", file=sys.stderr)
    except Exception as e:
        print(f"\nError during Ollama processing: {e}", file=sys.stderr)


# --- Command Line Interface ---
if __name__ == "__main__":
    # Load configuration first
    try:
        config = load_config()
        server_config = config['server']
        ollama_config = config['ollama'] # Load ollama config here for use in defaults
    except (FileNotFoundError, ValueError, RuntimeError, KeyError) as e:
        print(f"Error loading configuration: {e}", file=sys.stderr)
        sys.exit(1)

    parser = argparse.ArgumentParser(
        description="Ask questions about ticket data using natural language. Supports both interactive and single-question modes.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument(
        "question",
        nargs="?",  # Optional - not required for interactive mode
        help="The natural language question to ask (omit for interactive mode)"
    )
    parser.add_argument(
        "-i", "--interactive",
        action="store_true",
        help="Start interactive conversation mode"
    )
    parser.add_argument(
        "--server-url",
        default=server_config['url'],
        help=f"URL of the MCP server. Default from config: {server_config['url']}"
    )
    parser.add_argument(
        "--server-timeout", # Renamed from sse-timeout
        type=float,
        default=float(server_config['timeout']),
        help=f"Timeout in seconds for the request to the server. Default from config: {server_config['timeout']}"
    )
    # --- Ollama Arguments ---
    # Load ollama config for defaults, handle potential errors if config failed earlier
    ollama_config = config.get('ollama', {})
    parser.add_argument(
        "--ollama-url",
        default=ollama_config.get('url'), # Use loaded default or None
        help=f"URL of the Ollama API server. Default from config: {ollama_config.get('url', 'Not Set')}"
    )
    parser.add_argument(
        "--ollama-model",
        default=ollama_config.get('model'), # Use loaded default or None
        help=f"Ollama model to use for generating the answer. Default from config: {ollama_config.get('model', 'Not Set')}"
    )
    parser.add_argument(
        "--ollama-timeout",
        type=float,
        default=float(ollama_config['timeout']) if 'timeout' in ollama_config else None, # Use loaded default or None
        help=f"Timeout in seconds for the request to Ollama. Default from config: {ollama_config.get('timeout', 'Not Set')}"
    )
    # --- General Arguments ---
    parser.add_argument(
        "--config",
        default=DEFAULT_CONFIG_PATH,
        help="Path to the configuration YAML file."
    )
    parser.add_argument(
        "-d", "--debug",
        action="store_true",
        help="Enable debug mode (prints server stream details)."
    )

    args = parser.parse_args()

    # Validate mode selection
    if not args.interactive and not args.question:
        print("Error: Either provide a question or use --interactive mode", file=sys.stderr)
        parser.print_help()
        sys.exit(1)

    # Post-parsing validation for Ollama args if not provided and not in config
    if not args.ollama_url:
        print("Error: Ollama URL must be provided via --ollama-url or in the config file.", file=sys.stderr)
        sys.exit(1)
    if not args.ollama_model:
        print("Error: Ollama model must be provided via --ollama-model or in the config file.", file=sys.stderr)
        sys.exit(1)
    if args.ollama_timeout is None:
        print("Error: Ollama timeout must be provided via --ollama-timeout or in the config file.", file=sys.stderr)
        sys.exit(1)

    try:
        # Choose mode based on arguments
        if args.interactive:
            asyncio.run(interactive_mode(args))
        else:
            asyncio.run(single_question_mode(args))
    except KeyboardInterrupt:
        print(file=sys.stderr)
    except Exception as e:
        print(f"An error occurred: {e}", file=sys.stderr)
        sys.exit(1)

