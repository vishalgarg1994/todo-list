{{/*
Expand the name of the chart.
*/}}
{{- define "eva-messaging-infrastructure.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "eva-messaging-infrastructure.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "eva-messaging-infrastructure.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "eva-messaging-infrastructure.labels" -}}
helm.sh/chart: {{ include "eva-messaging-infrastructure.chart" . }}
{{ include "eva-messaging-infrastructure.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
environment: {{ .Values.global.environment }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "eva-messaging-infrastructure.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eva-messaging-infrastructure.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "eva-messaging-infrastructure.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "eva-messaging-infrastructure.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
NATS labels
*/}}
{{- define "eva-messaging-infrastructure.nats.labels" -}}
{{ include "eva-messaging-infrastructure.labels" . }}
app.kubernetes.io/component: nats
{{- end }}

{{/*
NATS selector labels
*/}}
{{- define "eva-messaging-infrastructure.nats.selectorLabels" -}}
{{ include "eva-messaging-infrastructure.selectorLabels" . }}
app.kubernetes.io/component: nats
{{- end }}

{{/*
Stream Manager labels
*/}}
{{- define "eva-messaging-infrastructure.stream-manager.labels" -}}
{{ include "eva-messaging-infrastructure.labels" . }}
app.kubernetes.io/component: stream-manager
{{- end }}

{{/*
Stream Manager selector labels
*/}}
{{- define "eva-messaging-infrastructure.stream-manager.selectorLabels" -}}
{{ include "eva-messaging-infrastructure.selectorLabels" . }}
app.kubernetes.io/component: stream-manager
{{- end }}

{{/*
Message UI labels
*/}}
{{- define "eva-messaging-infrastructure.message-ui.labels" -}}
{{ include "eva-messaging-infrastructure.labels" . }}
app.kubernetes.io/component: message-ui
{{- end }}

{{/*
Message UI selector labels
*/}}
{{- define "eva-messaging-infrastructure.message-ui.selectorLabels" -}}
{{ include "eva-messaging-infrastructure.selectorLabels" . }}
app.kubernetes.io/component: message-ui
{{- end }}