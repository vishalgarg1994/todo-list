"""
Data Pipeline Service - Full extraction with relationships

This service:
1. Uses Extractor to query CMD + all TSM tables (including changes)
2. Uses TicketTransformer to merge and transform (UNION approach)
3. Publishes to NATS with full entity-specific fields for relationship creation

Published Topics:
- tickets.created -> ClientSummary (grouped by client_id)
- tickets.change -> ChangeBatch (infrastructure-level, batched)
- tickets.fault_description -> FaultDescriptionSummary (for Milvus)

The result is tickets with:
- ticket_type (incident/case/problem/request/cmd)
- incident_fields, case_fields, problem_fields, request_fields
- tasks (ITASK, CTASK, PTASK)
- configuration_items (CIs)
- All FK references for relationships (RAISED_BY_INCIDENT, BELONGS_TO_CASE, AFFECTED_BY_CHANGE, etc.)

Changes are published separately as they are infrastructure-level (no client_id):
- ChangeRecord with ChangeFields, ChangeTaskInfo
- Batched in groups of 100 to stay under NATS 1MB limit
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta

from utils.connection_manager import ConnectionManager
from utils.correlation import get_correlation_id
from utils.config import Config
from utils.state_manager import state_manager
from utils.metrics import (
    MetricsTimer,
    increment_records_processed,
    increment_messages_published,
    increment_errors,
)
from utils.compress import compress_and_check
from domain.extractor import Extractor
from domain.api_extractor import create_api_extractor_from_config
from domain.transformers import TicketTransformer
from services.data_quality_monitor import DataQualityMonitor, QualityIssueLevel


class DataPipelineService:
    """Data Pipeline Service - extracts from all tables with relationships"""

    def __init__(self, connection_manager: ConnectionManager, config: Config = None):
        self.connection_manager = connection_manager
        self.config = config or Config()
        self.logger = logging.getLogger(__name__)
        self.quality_monitor = DataQualityMonitor()

        # Will be initialized when process is called
        self.extractor = None  # DB extractor
        self.api_extractor = None  # API extractor
        self.transformer = TicketTransformer()

    async def process(self) -> bool:
        """
        Process all tables in a single pass

        This extracts from:
        - eds.servicenow_cmd_ticket (CMD - enrichment data)
        - eds.snow_tsm_incident
        - eds.snow_tsm_case
        - eds.snow_tsm_problem
        - eds.snow_tsm_request
        - eds.snow_tsm_change (infrastructure changes)
        - eds.snow_tsm_incident_task
        - eds.snow_tsm_case_task
        - eds.snow_tsm_problem_task
        - eds.snow_tsm_change_task
        - eds.snow_task_cmdb_ci_service (Configuration Items)

        Returns:
            bool: True if processing succeeded, False otherwise
        """
        correlation_id = get_correlation_id()
        table_name = "ticket_pipeline"  # Virtual table name for state tracking

        try:
            self.logger.info(
                "Starting pipeline processing", extra={"correlation_id": correlation_id}
            )

            # Start quality monitoring session
            quality_session = self.quality_monitor.start_monitoring(table_name)

            with MetricsTimer("processing_duration", {"table": table_name}):
                # Determine time filter
                since = self._get_time_filter(table_name)

                # Extract data based on DATA_SOURCE configuration
                data_source = self.config.get_data_source()
                self.logger.info(
                    f"Extracting data (DATA_SOURCE={data_source}) since: {since.isoformat() if since else 'beginning'}",
                    extra={"correlation_id": correlation_id},
                )

                extracted_data = await self._extract_data(
                    data_source, since, correlation_id
                )

                # Check if we have any data
                # Count unique tickets to process (not overlapping CMD+TSM)
                # CMD and TSM tables can have the same ticket - we merge them
                cmd_sys_ids = set(
                    r.get("servicenow_task_sys_id")
                    for r in extracted_data.get("cmd_records", [])
                    if r.get("servicenow_task_sys_id")
                )
                tsm_by_sys_id = extracted_data.get("tsm_by_sys_id", {})

                # Unique client-level tickets = CMD + TSM-only (not in CMD)
                unique_client_tickets = len(cmd_sys_ids) + len(
                    set(tsm_by_sys_id.keys()) - cmd_sys_ids
                )

                # Changes are separate (infrastructure-level, no client_id)
                num_changes = len(extracted_data.get("changes", []))

                total_records = unique_client_tickets + num_changes

                if total_records == 0:
                    self.logger.info(
                        "No new data found", extra={"correlation_id": correlation_id}
                    )
                    quality_session.record_processing_stats(0, 0, 0)
                    quality_session.finalize()
                    return True

                self.logger.info(
                    f"Extracted data: {len(extracted_data.get('cmd_records', []))} CMD, "
                    f"{len(extracted_data.get('incidents', []))} incidents, "
                    f"{len(extracted_data.get('cases', []))} cases, "
                    f"{len(extracted_data.get('problems', []))} problems, "
                    f"{len(extracted_data.get('requests', []))} requests, "
                    f"{len(extracted_data.get('changes', []))} changes, "
                    f"{len(extracted_data.get('incident_tasks', []))} incident_tasks, "
                    f"{len(extracted_data.get('case_tasks', []))} case_tasks, "
                    f"{len(extracted_data.get('problem_tasks', []))} problem_tasks, "
                    f"{len(extracted_data.get('change_tasks', []))} change_tasks, "
                    f"{len(extracted_data.get('ci_services', []))} ci_services "
                    f"(unique: {unique_client_tickets} client + {num_changes} changes = {total_records})",
                    extra={"correlation_id": correlation_id},
                )

                # Transform
                (
                    ticket_messages,
                    fault_description_messages,
                    processed_count,
                ) = self.transformer.transform(extracted_data)

                self.logger.info(
                    f"Transformed into {len(ticket_messages)} ticket messages "
                    f"and {len(fault_description_messages)} fault description messages "
                    f"({processed_count} individual tickets)",
                    extra={"correlation_id": correlation_id},
                )

                # Publish ticket messages
                published_count = await self._publish_messages(
                    ticket_messages,
                    self.config.get("TICKET_PUBLISH_SUBJECT", "tickets.created"),
                    correlation_id,
                    quality_session,
                )

                # Publish fault description messages
                if fault_description_messages:
                    fault_published_count = await self._publish_messages(
                        fault_description_messages,
                        self.config.get(
                            "FAULT_DESCRIPTION_PUBLISH_SUBJECT",
                            "tickets.fault_description",
                        ),
                        correlation_id,
                        quality_session,
                    )
                    published_count += fault_published_count

                # Process and publish change batches (infrastructure-level, no client_id)
                change_batch_messages, change_count = self.transformer.process_changes(
                    extracted_data
                )
                if change_batch_messages:
                    change_published_count = await self._publish_messages(
                        change_batch_messages,
                        self.config.get("CHANGE_PUBLISH_SUBJECT", "tickets.change"),
                        correlation_id,
                        quality_session,
                    )
                    published_count += change_published_count
                    processed_count += change_count

                    self.logger.info(
                        f"Processed {change_count} changes into {len(change_batch_messages)} batches",
                        extra={"correlation_id": correlation_id},
                    )

                # Record quality metrics
                # Note: "failed" here includes records skipped due to missing client_id
                # (data quality issue at source) and actual processing errors
                skipped_count = total_records - processed_count
                quality_session.record_processing_stats(
                    total=total_records, processed=processed_count, failed=skipped_count
                )

                if skipped_count > 0:
                    self.logger.info(
                        f"Skipped {skipped_count} records (likely missing client_id or processing errors)",
                        extra={"correlation_id": correlation_id},
                    )

                # Finalize quality report
                quality_report = quality_session.finalize()

                # Update processing state if we published messages
                if published_count > 0:
                    self._update_processing_state(table_name)
                else:
                    self.logger.warning(
                        "No messages published - state not updated (will retry next run)",
                        extra={"correlation_id": correlation_id},
                    )

                increment_records_processed(table_name, "success", processed_count)
                self.logger.info(
                    f"Pipeline completed successfully: {processed_count} tickets extracted, "
                    f"grouped into {published_count} client messages, quality_score={quality_report.quality_score}",
                    extra={"correlation_id": correlation_id},
                )

                return True

        except Exception as e:
            if "quality_session" in locals():
                quality_session.add_issue(
                    QualityIssueLevel.CRITICAL,
                    "processing_error",
                    f"Pipeline failed: {str(e)}",
                    str(e),
                )
                quality_session.finalize()

            increment_errors("processing_failed", "ticket_pipeline")
            self.logger.error(
                f"Pipeline failed: {e}",
                extra={"correlation_id": correlation_id},
                exc_info=True,
            )
            return False

    def _get_time_filter(self, table_name: str) -> Optional[datetime]:
        """Determine time filter for extraction based on DATA_SOURCE"""
        data_source = self.config.get_data_source()

        # API mode: always use API_LOOKBACK_HOURS (no multi-day initial load)
        if data_source == "api":
            hours = self.config.get_api_lookback_hours()
            start_time = datetime.now() - timedelta(hours=hours)
            self.logger.info(
                f"API mode: fetching last {hours} hours from {start_time.isoformat()}"
            )
            return start_time

        # DB or BOTH mode: use state-based initial/incremental logic
        if state_manager.is_initial_load_complete(table_name):
            # Incremental load
            last_processed = state_manager.get_last_processed_timestamp(table_name)
            if last_processed:
                self.logger.info(f"Incremental load from: {last_processed.isoformat()}")
                return last_processed
            else:
                # Fallback
                hours = self.config.get_daily_load_hours()
                return datetime.now() - timedelta(hours=hours)

        elif state_manager.is_initial_load_in_progress(table_name):
            # Retry initial load
            days = self.config.get_initial_load_days()
            start_time = datetime.now() - timedelta(days=days)
            self.logger.warning(f"Retrying initial load from: {start_time.isoformat()}")
            return start_time

        else:
            # First initial load
            days = self.config.get_initial_load_days()
            start_time = datetime.now() - timedelta(days=days)
            state_manager.start_initial_load(table_name, start_time)
            self.logger.info(
                f"Starting initial load: {days} days from {start_time.isoformat()}"
            )
            return start_time

    async def _extract_data(
        self, data_source: str, since: Optional[datetime], correlation_id: str
    ) -> Dict[str, Any]:
        """
        Extract data based on DATA_SOURCE configuration.

        Args:
            data_source: 'api', 'db', or 'both'
            since: Time filter for incremental extraction
            correlation_id: Request correlation ID

        Returns:
            Extracted data dict compatible with TicketTransformer
        """
        if data_source == "api":
            # API-only mode
            return await self._extract_from_api(since, correlation_id)

        elif data_source == "both":
            # Both mode: extract from both and merge (API takes precedence)
            db_data = await self._extract_from_db(since, correlation_id)
            api_data = await self._extract_from_api(since, correlation_id)
            return self._merge_extracted_data(db_data, api_data)

        else:
            # DB mode (default)
            return await self._extract_from_db(since, correlation_id)

    async def _extract_from_db(
        self, since: Optional[datetime], correlation_id: str
    ) -> Dict[str, Any]:
        """Extract data from database using DB Extractor"""
        db_pool = self.connection_manager.get_database_pool()
        self.extractor = Extractor(db_pool)

        self.logger.info(
            "Extracting from database", extra={"correlation_id": correlation_id}
        )

        return await self.extractor.extract_all(since)

    async def _extract_from_api(
        self, since: Optional[datetime], correlation_id: str
    ) -> Dict[str, Any]:
        """Extract data from ServiceNow SMDS API"""
        if self.api_extractor is None:
            self.api_extractor = create_api_extractor_from_config(self.config)

        self.logger.info(
            "Extracting from ServiceNow API", extra={"correlation_id": correlation_id}
        )

        try:
            return await self.api_extractor.extract_all(since)
        finally:
            # Close the API session after extraction
            await self.api_extractor.close()

    def _merge_extracted_data(
        self, db_data: Dict[str, Any], api_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Merge DB and API extracted data.

        API data takes precedence for conflicts (same sys_id).
        """
        self.logger.info(
            f"Merging data: DB has {len(db_data.get('incidents', []))} incidents, "
            f"{len(db_data.get('cases', []))} cases; "
            f"API has {len(api_data.get('incidents', []))} incidents, "
            f"{len(api_data.get('cases', []))} cases"
        )

        # Start with DB data
        merged = {
            "cmd_records": db_data.get("cmd_records", []),
            "cmd_by_sys_id": db_data.get("cmd_by_sys_id", {}),
            "incidents": [],
            "cases": [],
            "problems": db_data.get("problems", []),
            "requests": db_data.get("requests", []),
            "changes": db_data.get("changes", []),
            "incident_tasks": db_data.get("incident_tasks", []),
            "case_tasks": db_data.get("case_tasks", []),
            "problem_tasks": db_data.get("problem_tasks", []),
            "change_tasks": db_data.get("change_tasks", []),
            "tsm_by_sys_id": {},
            "ci_services": db_data.get("ci_services", []),
            "ci_by_task_sys_id": db_data.get("ci_by_task_sys_id", {}),
            "case_tasks_by_case": db_data.get("case_tasks_by_case", {}),
            "change_tasks_by_change": db_data.get("change_tasks_by_change", {}),
        }

        # Merge incidents (API takes precedence)
        db_incidents_by_sys_id = {
            inc.get("incident_sys_id"): inc
            for inc in db_data.get("incidents", [])
            if inc.get("incident_sys_id")
        }
        api_incidents_by_sys_id = {
            inc.get("sys_id"): inc
            for inc in api_data.get("incidents", [])
            if inc.get("sys_id")
        }

        # Add all API incidents (takes precedence)
        for sys_id, inc in api_incidents_by_sys_id.items():
            merged["incidents"].append(inc)
            merged["tsm_by_sys_id"][sys_id] = {"type": "incident", "data": inc}

        # Add DB incidents not in API
        for sys_id, inc in db_incidents_by_sys_id.items():
            if sys_id not in api_incidents_by_sys_id:
                merged["incidents"].append(inc)
                merged["tsm_by_sys_id"][sys_id] = {"type": "incident", "data": inc}

        # Merge cases (API takes precedence)
        db_cases_by_sys_id = {
            case.get("case_sys_id"): case
            for case in db_data.get("cases", [])
            if case.get("case_sys_id")
        }
        api_cases_by_sys_id = {
            case.get("sys_id"): case
            for case in api_data.get("cases", [])
            if case.get("sys_id")
        }

        # Add all API cases (takes precedence)
        for sys_id, case in api_cases_by_sys_id.items():
            merged["cases"].append(case)
            merged["tsm_by_sys_id"][sys_id] = {"type": "case", "data": case}

        # Add DB cases not in API
        for sys_id, case in db_cases_by_sys_id.items():
            if sys_id not in api_cases_by_sys_id:
                merged["cases"].append(case)
                merged["tsm_by_sys_id"][sys_id] = {"type": "case", "data": case}

        # Add problems and requests from DB to tsm_by_sys_id
        for prob in merged["problems"]:
            sys_id = prob.get("problem_sys_id")
            if sys_id:
                merged["tsm_by_sys_id"][sys_id] = {"type": "problem", "data": prob}

        for req in merged["requests"]:
            sys_id = req.get("req_task_sys_id")
            if sys_id:
                merged["tsm_by_sys_id"][sys_id] = {"type": "request", "data": req}

        self.logger.info(
            f"Merged result: {len(merged['incidents'])} incidents, "
            f"{len(merged['cases'])} cases, {len(merged['tsm_by_sys_id'])} total TSM records"
        )

        return merged

    async def _publish_messages(
        self, messages: List[str], topic: str, correlation_id: str, quality_session
    ) -> int:
        """Publish messages to NATS topic"""

        if not messages:
            return 0

        try:
            # Check NATS connection
            nats_connection = self.connection_manager.get_nats_connection()
            if not nats_connection or not nats_connection.is_connected:
                self.logger.warning(
                    f"NATS not available - skipping publish to {topic}",
                    extra={"correlation_id": correlation_id},
                )
                return 0

            publisher = self.connection_manager.get_nats_publisher()
            if not publisher:
                self.logger.warning(
                    f"NATS publisher not available - skipping publish to {topic}",
                    extra={"correlation_id": correlation_id},
                )
                return 0

            published_count = 0
            failed_count = 0

            for message in messages:
                try:
                    compressed = compress_and_check(message)
                    if compressed:
                        success = await publisher.publish(topic, compressed)
                        if success:
                            published_count += 1
                        else:
                            failed_count += 1
                    else:
                        failed_count += 1
                        self.logger.warning(
                            "Message skipped due to size limit",
                            extra={"topic": topic, "correlation_id": correlation_id},
                        )
                except Exception as e:
                    failed_count += 1
                    self.logger.error(
                        f"Failed to publish message: {e}",
                        extra={"topic": topic, "correlation_id": correlation_id},
                    )

            # Record metrics
            increment_messages_published(topic, "success", published_count)
            if failed_count > 0:
                increment_messages_published(topic, "failed", failed_count)
                quality_session.add_issue(
                    QualityIssueLevel.WARNING,
                    "publish_failures",
                    f"{failed_count} messages failed to publish to {topic}",
                    failed_count,
                )

            self.logger.info(
                f"Published {published_count}/{len(messages)} messages to {topic}",
                extra={"correlation_id": correlation_id},
            )

            return published_count

        except Exception as e:
            increment_errors("publishing_failed", "ticket_pipeline")
            self.logger.error(
                f"Publishing failed for topic {topic}: {e}",
                extra={"correlation_id": correlation_id},
                exc_info=True,
            )
            return 0

    def _update_processing_state(self, table_name: str):
        """Update processing state after successful publish"""
        current_time = datetime.now()

        if state_manager.is_initial_load_in_progress(table_name):
            state_manager.complete_initial_load(table_name, current_time)
            self.logger.info(f"Initial load completed for {table_name}")
        else:
            data_source = self.config.get_data_source()
            state_manager.update_incremental_timestamp(
                table_name, current_time, data_source
            )
            self.logger.debug(f"Updated incremental timestamp for {table_name}")

    def get_quality_monitor(self) -> DataQualityMonitor:
        """Get the data quality monitor for health checks"""
        return self.quality_monitor
