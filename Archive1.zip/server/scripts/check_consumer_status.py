#!/usr/bin/env python3
"""
Check consumer status for fault_description subject
"""
import asyncio
import nats

async def check_consumer():
    """Check consumer status"""
    try:
        nc = await nats.connect("nats://localhost:4222")
        js = nc.jetstream()
        print("✅ Connected to NATS")

        # List all consumers for EVA_TICKETING_STREAM
        print(f"\n{'='*70}")
        print(f"👥 Consumers for EVA_TICKETING_STREAM:")
        print(f"{'='*70}")

        consumers = await js.consumers_info("EVA_TICKETING_STREAM")
        for consumer in consumers:
            print(f"\n📌 Consumer: {consumer.name}")
            print(f"   Filter Subject: {consumer.config.filter_subject}")
            print(f"   Delivered Count: {consumer.delivered.consumer_seq}")
            print(f"   Stream Sequence: {consumer.delivered.stream_seq}")
            print(f"   Ack Pending: {consumer.num_ack_pending}")
            print(f"   Pending Messages: {consumer.num_pending}")
            print(f"   Redelivered: {consumer.num_redelivered}")

        # Check stream info
        stream_info = await js.stream_info("EVA_TICKETING_STREAM")
        print(f"\n{'='*70}")
        print(f"📊 Stream Status:")
        print(f"{'='*70}")
        print(f"Total Messages: {stream_info.state.messages}")
        print(f"First Seq: {stream_info.state.first_seq}")
        print(f"Last Seq: {stream_info.state.last_seq}")
        print(f"Consumer Count: {stream_info.state.consumer_count}")

        await nc.close()

    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(check_consumer())
