# Kubernetes Deployment - Eva Messaging Infrastructure

## 🚀 Quick Start

### Prerequisites
- Kubernetes cluster (1.20+)
- Helm 3.0+
- kubectl configured

### Deploy to Development
```bash
cd helm
./deploy.sh dev
```

### Deploy to Production
```bash
cd helm
./deploy.sh prod --upgrade
```

## 🎯 Deployment Options

### Available Environments
- **dev** - Development environment with minimal resources
- **staging** - Staging environment with moderate resources
- **prod** - Production environment with high availability

### Deployment Commands
```bash
# Fresh installation
./deploy.sh [env]

# Upgrade existing deployment
./deploy.sh [env] --upgrade

# Preview changes (dry run)
./deploy.sh [env] --dry-run

# Custom namespace
./deploy.sh [env] --namespace my-namespace
```

## 📊 Architecture

### Components Deployed
1. **NATS JetStream Server**
   - Persistent messaging with file storage
   - HTTP monitoring on port 8222
   - Client connections on port 4222

2. **Stream Manager**
   - Automatic stream initialization
   - Stream template configuration
   - Health monitoring

3. **Message UI**
   - Real-time message viewer
   - WebSocket-based updates
   - Web interface on port 3001

### Kubernetes Resources
- **Deployments**: NATS, Stream Manager, Message UI
- **Services**: ClusterIP services for internal communication
- **ConfigMaps**: NATS configuration and stream templates
- **PersistentVolumeClaims**: JetStream data storage
- **Ingress**: External access (optional)
- **ServiceAccount**: Security context

## 🔧 Configuration

### Environment-Specific Values

#### Development (`values-dev.yaml`)
- Single replica
- 500Mi storage
- Local ingress

#### Production (`values-prod.yaml`)
- 3 NATS replicas
- 5Gi storage with SSD
- TLS ingress with certificates
- Pod anti-affinity rules

### Custom Configuration
Override values by editing:
- `values.yaml` - Base configuration
- `values-[env].yaml` - Environment-specific overrides

## 🌐 Access Points

### Port Forwarding (Development)
```bash
# NATS Monitor
kubectl port-forward -n eva-messaging-dev svc/eva-messaging-nats-monitor 8222:8222
# Access: http://localhost:8222

# Message UI
kubectl port-forward -n eva-messaging-dev svc/eva-messaging-message-ui 3001:3001
# Access: http://localhost:3001

# NATS Server (for client connections)
kubectl port-forward -n eva-messaging-dev svc/eva-messaging-nats 4222:4222
# Access: nats://localhost:4222
```

### Ingress (Staging/Production)
When ingress is enabled, access via:
- **NATS Monitor**: https://eva-messaging.yourdomain.com/monitor
- **Message UI**: https://eva-messaging.yourdomain.com/ui
- **Stream Manager API**: https://eva-messaging.yourdomain.com/api

## 🔍 Monitoring & Health Checks

### Health Endpoints
```bash
# NATS health
kubectl exec -n eva-messaging-dev deploy/eva-messaging-nats -- wget -qO- http://localhost:8222

# Message UI health
kubectl exec -n eva-messaging-dev deploy/eva-messaging-message-ui -- wget -qO- http://localhost:3001/health
```

### Pod Status
```bash
kubectl get pods -n eva-messaging-dev
kubectl logs -f deployment/eva-messaging-nats -n eva-messaging-dev
```

### Persistent Volumes
```bash
kubectl get pvc -n eva-messaging-dev
kubectl describe pv -n eva-messaging-dev
```

## 🛡️ Security

### Authentication
NATS authentication is configured with users:
- `ticket-app` / `ticket-app-2024`
- `analytics-app` / `analytics-app-2024`

### Security Context
- Non-root containers (UID 1000)
- Read-only root filesystem where possible
- Service account with minimal permissions

### Network Security
- ClusterIP services (internal access only)
- Ingress with TLS termination in production
- Network policies can be added for additional isolation

## 📈 Scaling

### Horizontal Scaling
```bash
# Scale NATS (production only - clustering required)
kubectl scale deployment eva-messaging-nats -n eva-messaging-prod --replicas=3

# Scale UI components
kubectl scale deployment eva-messaging-message-ui -n eva-messaging-prod --replicas=2
kubectl scale deployment eva-messaging-stream-manager -n eva-messaging-prod --replicas=2
```

### Vertical Scaling
Edit values file and upgrade:
```yaml
nats:
  resources:
    requests:
      cpu: 1000m
      memory: 1Gi
```

## 🗄️ Persistence

### Storage Classes
Configure storage class in values files:
```yaml
nats:
  persistence:
    storageClass: "ssd"  # Use SSD storage
    size: 5Gi
```

### Backup Strategy
JetStream data is stored in persistent volumes:
- **Location**: `/data/jetstream` in NATS containers
- **Backup**: Use Kubernetes volume snapshots or backup operators
- **Recovery**: Restore PVC data and restart pods

## 🔄 Updates & Maintenance

### Upgrade Process
1. Update Helm chart or values
2. Run deployment with `--upgrade` flag
3. Monitor rollout status

```bash
./deploy.sh prod --upgrade
kubectl rollout status deployment/eva-messaging-nats -n eva-messaging-prod
```

### Rolling Updates
Deployments are configured with rolling update strategy:
- Zero downtime for stateless components
- NATS persistence ensures no message loss

### Rollback
```bash
helm rollback eva-messaging -n eva-messaging-prod
```

## 🚨 Troubleshooting

### Common Issues

1. **Pods not starting**
   ```bash
   kubectl describe pod -n eva-messaging-dev
   kubectl logs -n eva-messaging-dev deployment/eva-messaging-nats
   ```

2. **Storage issues**
   ```bash
   kubectl get events -n eva-messaging-dev --sort-by='.lastTimestamp'
   kubectl describe pvc -n eva-messaging-dev
   ```

3. **Network connectivity**
   ```bash
   kubectl exec -it deployment/eva-messaging-stream-manager -n eva-messaging-dev -- nc -z eva-messaging-nats 4222
   ```

### Debug Mode
Enable debug mode in values:
```yaml
nats:
  config:
    debug: true
    trace: true
```

## 📋 Resource Requirements

### Minimum Requirements (Development)
- **CPU**: 0.5 cores total
- **Memory**: 1Gi total
- **Storage**: 500Mi

### Production Requirements
- **CPU**: 3+ cores total
- **Memory**: 3Gi+ total
- **Storage**: 5Gi+ SSD
- **Nodes**: 3+ (for high availability)

## 🎛️ Advanced Configuration

### NATS Clustering
For production clustering, modify NATS configuration:
```yaml
nats:
  config:
    cluster:
      enabled: true
      routes: ["nats://eva-messaging-nats-0:6222", "nats://eva-messaging-nats-1:6222"]
```

### Custom Stream Templates
Edit the ConfigMap to add custom streams:
```yaml
streams:
  - name: "MY_CUSTOM_STREAM"
    subjects: ["custom.>"]
    # ... other configuration
```

### TLS Configuration
For TLS connections, add certificates:
```yaml
nats:
  tls:
    enabled: true
    secretName: "nats-tls-secret"
```

---

**🎉 Eva Messaging Infrastructure is now Kubernetes-ready!**

For support, check the logs, monitor health endpoints, and refer to NATS documentation for advanced configuration options.