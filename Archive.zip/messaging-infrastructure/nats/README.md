# Eva Messaging Infrastructure - NATS JetStream

## Environment Configuration

Use the appropriate environment file when initializing streams:

### Development
```bash
# Load development settings (50MB, 1 day retention)
source .env.development
./scripts/init-streams.sh
```

### Staging
```bash
# Load staging settings (200MB, 3 days retention)
source .env.staging
./scripts/init-streams.sh
```

### Production
```bash
# Load production settings (2GB, 7 days retention)
source .env.production
./scripts/init-streams.sh
```

## Stream Limits by Environment

| Environment | Max Messages | Max Storage | Retention | Use Case |
|-------------|-------------|-------------|-----------|----------|
| Development | 50,000      | 50MB        | 1 day     | Local dev, testing |
| Staging     | 200,000     | 200MB       | 3 days    | Integration testing |
| Production  | 2,000,000   | 2GB         | 7 days    | Live workloads |

## Docker Compose Usage

For development, the docker-compose.yml should automatically source `.env.development`:

```yaml
# In docker-compose.yml
services:
  nats:
    env_file:
      - .env.development
```