"""
Fault Description Consumer
Consumes fault descriptions from NATS or synthetic data, generates embeddings, and stores in Milvus
"""
import logging
import json
import asyncio
from pathlib import Path
from typing import List, Dict, Any, Optional
from nats.aio.client import Client as NATS
from nats.js.api import ConsumerConfig, AckPolicy

from configs.config import Config
from data_access.milvusClient import MilvusClient
from services.embedding_service import EmbeddingService
from services.extraction_service import ExtractionService
from utils.text_utils import strip_html_css, sanitize_for_embedding


class FaultDescriptionConsumer:
    """Consumer for processing fault descriptions and creating embeddings"""

    def __init__(self, config: Config = None):
        """
        Initialize consumer

        Args:
            config: Configuration object
        """
        self.config = config or Config()
        self.milvus_client = MilvusClient(self.config, connection_alias="fault_consumer")
        self.embedding_service = EmbeddingService(self.config)
        self.extraction_service = ExtractionService(self.config)
        self.nats_client: Optional[NATS] = None
        self.running = False

        logging.info(f"Initialized FaultDescriptionConsumer (TEST_MODE={self.config.test_mode})")

    async def start(self):
        """Start the consumer (NATS or TEST_MODE)"""
        self.running = True

        # Connect to Milvus (handles collection creation if needed)
        logging.info("Connecting to Milvus...")
        self.milvus_client.connect()
        logging.info("✅ Connected to Milvus")

        # Create index if collection was just created
        if self.milvus_client.collection and not self.milvus_client.collection.has_index():
            logging.info("Creating Milvus index...")
            self.milvus_client.create_index()
            logging.info("✅ Milvus index created")

        # Test Ollama connections (embedding + extraction)
        logging.info("Testing Ollama embedding connection...")
        if not self.embedding_service.test_connection():
            logging.error("❌ Ollama embedding connection failed - is Ollama running?")
            raise RuntimeError("Ollama embedding service not available")
        logging.info("✅ Ollama embedding connection successful")

        logging.info("Testing Ollama extraction/summarization connection...")
        if not self.extraction_service.test_connection():
            logging.warning("⚠️  Ollama extraction connection failed - summarization will use fallback")
        else:
            logging.info("✅ Ollama extraction connection successful")

        # Start appropriate mode
        if self.config.test_mode:
            await self._run_test_mode()
        else:
            await self._run_nats_mode()

    async def _run_test_mode(self):
        """Run in TEST_MODE using synthetic data"""
        logging.info("🧪 Running in TEST_MODE - loading synthetic data...")

        # Load synthetic data
        test_data_file = Path("/app/test_data/synthetic_fault_descriptions.json")

        if not test_data_file.exists():
            logging.error(f"❌ Synthetic data file not found: {test_data_file}")
            logging.error("   Run: python3 test_data/synthetic_fault_descriptions.py")
            return

        with open(test_data_file, 'r') as f:
            summaries = json.load(f)

        logging.info(f"📊 Loaded {len(summaries)} FaultDescriptionSummary messages")

        # Process all summaries
        total_processed = 0
        total_success = 0
        total_failed = 0

        for summary in summaries:
            client_id = summary['client_id']
            fault_descriptions = summary['fault_descriptions']

            logging.info(f"\n{'=' * 70}")
            logging.info(f"Processing client: {client_id} ({len(fault_descriptions)} tickets)")
            logging.info(f"{'=' * 70}")

            # Process batch
            success, failed = await self._process_fault_description_batch(fault_descriptions)

            total_processed += len(fault_descriptions)
            total_success += success
            total_failed += failed

            logging.info(f"✅ Client {client_id}: {success}/{len(fault_descriptions)} successful")

        # Final summary
        logging.info(f"\n{'=' * 70}")
        logging.info(f"🎉 TEST_MODE Processing Complete!")
        logging.info(f"{'=' * 70}")
        logging.info(f"   Total tickets: {total_processed}")
        logging.info(f"   ✅ Successful: {total_success}")
        logging.info(f"   ❌ Failed: {total_failed}")
        logging.info(f"   Success rate: {(total_success/total_processed*100):.1f}%")

        # Show collection stats
        count = self.milvus_client.get_collection_count()
        logging.info(f"\n📊 Milvus Collection Stats:")
        logging.info(f"   Total embeddings: {count}")

    async def _run_nats_mode(self):
        """Run in production mode consuming from NATS"""
        logging.info("🚀 Running in NATS mode - subscribing to fault descriptions...")

        # Connect to NATS
        self.nats_client = NATS()
        await self.nats_client.connect(
            servers=[self.config.nats_url],
            name="fault-description-consumer"
        )
        logging.info(f"✅ Connected to NATS: {self.config.nats_url}")

        # Get JetStream context
        js = self.nats_client.jetstream()

        # Create durable consumer for fault descriptions
        consumer_config = ConsumerConfig(
            durable_name="fault_description_embeddings",
            ack_policy=AckPolicy.EXPLICIT,
            max_deliver=3,  # Retry up to 3 times
            ack_wait=300,   # 5 minutes to process and ack
        )

        # Subscribe to fault description subject
        subscription = await js.subscribe(
            subject="tickets.fault_description",
            config=consumer_config,
            cb=self._handle_nats_message
        )

        logging.info(f"✅ Subscribed to: tickets.fault_description")
        logging.info(f"   Consumer: {consumer_config.durable_name}")
        logging.info(f"   Waiting for messages...")

        # Keep running until stopped
        while self.running:
            await asyncio.sleep(1)

        # Cleanup
        await subscription.unsubscribe()
        await self.nats_client.close()

    async def _handle_nats_message(self, msg):
        """
        Handle incoming NATS message with FaultDescriptionSummary

        Args:
            msg: NATS message
        """
        try:
            # Parse message
            data = json.loads(msg.data.decode())

            # Validate it's a FaultDescriptionSummary
            if 'fault_description_summary_id' not in data:
                logging.error(f"Invalid message format - missing fault_description_summary_id")
                await msg.nak()
                return

            client_id = data.get('client_id')
            part_number = data.get('part_number', 1)
            total_parts = data.get('total_parts', 1)
            fault_descriptions = data.get('fault_descriptions', [])

            logging.info(f"\n{'=' * 70}")
            logging.info(f"📨 Received FaultDescriptionSummary")
            logging.info(f"   Client: {client_id}")
            logging.info(f"   Part: {part_number}/{total_parts}")
            logging.info(f"   Fault descriptions: {len(fault_descriptions)}")
            logging.info(f"{'=' * 70}")

            # Process batch
            success, failed = await self._process_fault_description_batch(fault_descriptions)

            logging.info(f"✅ Processed: {success}/{len(fault_descriptions)} successful, {failed} failed")

            # Ack message
            await msg.ack()

        except json.JSONDecodeError as e:
            logging.error(f"Failed to parse NATS message: {e}")
            await msg.nak()
        except Exception as e:
            logging.error(f"Error processing NATS message: {e}")
            await msg.nak()

    async def _process_fault_description_batch(
        self,
        fault_descriptions: List[Dict[str, Any]]
    ) -> tuple[int, int]:
        """
        Process a batch of fault descriptions.

        WS-B flow: sanitize → summarize → embed summary → store 3 fields

        Args:
            fault_descriptions: List of fault description dicts

        Returns:
            Tuple of (success_count, failed_count)
        """
        if not fault_descriptions:
            return 0, 0

        raw_texts = [fd['fault_description'] for fd in fault_descriptions]
        fault_description_ids = [fd['fault_description_id'] for fd in fault_descriptions]

        # Step 1: Sanitize
        MAX_TEXT_LENGTH = 65535
        sanitized_texts = []
        for text in raw_texts:
            sanitized = strip_html_css(text)
            sanitized = sanitize_for_embedding(sanitized)
            if len(sanitized) > MAX_TEXT_LENGTH:
                sanitized = sanitized[:MAX_TEXT_LENGTH]
            sanitized_texts.append(sanitized)

        # Step 2: Summarize
        summaries = []
        for i, sanitized in enumerate(sanitized_texts):
            summary = None
            try:
                summary = await self.extraction_service.summarize_fault_description_async(sanitized)
            except Exception as e:
                logging.warning(f"Summarization failed for {fault_description_ids[i]}: {e}")

            if summary:
                summaries.append(summary)
            else:
                # Fallback: use truncated sanitized text
                fallback = sanitized[:500] if len(sanitized) > 500 else sanitized
                summaries.append(fallback)

        # Step 3: Embed from summary
        logging.info(f"🔄 Generating {len(summaries)} embeddings from summaries...")
        embeddings = await self.embedding_service.generate_embeddings_batch(
            summaries,
            batch_size=10
        )

        # Step 4: Collect successful results and insert
        successful_ids = []
        successful_embeddings = []
        successful_texts = []
        successful_summaries = []
        failed_count = 0

        for i, embedding in enumerate(embeddings):
            if embedding is not None:
                successful_ids.append(fault_description_ids[i])
                successful_embeddings.append(embedding)
                successful_texts.append(sanitized_texts[i])
                successful_summaries.append(summaries[i])
            else:
                failed_count += 1
                logging.warning(f"Failed to generate embedding for {fault_description_ids[i]}")

        if successful_ids:
            logging.info(f"💾 Inserting {len(successful_ids)} embeddings into Milvus...")
            try:
                inserted_count = await self.milvus_client.insert(
                    fault_description_ids=successful_ids,
                    embeddings=successful_embeddings,
                    fault_description_texts=successful_texts,
                    fault_description_summaries=successful_summaries
                )
                logging.info(f"✅ Inserted {inserted_count} embeddings into Milvus")
            except Exception as e:
                logging.error(f"❌ Failed to insert embeddings into Milvus: {e}")
                failed_count = len(fault_descriptions)
                successful_ids = []

        success_count = len(successful_ids)
        return success_count, failed_count

    async def stop(self):
        """Stop the consumer"""
        logging.info("Stopping FaultDescriptionConsumer...")
        self.running = False

        # Disconnect from Milvus
        self.milvus_client.disconnect()

        # Close NATS if connected
        if self.nats_client and self.nats_client.is_connected:
            await self.nats_client.close()

        logging.info("✅ FaultDescriptionConsumer stopped")


async def main():
    """Main entry point for standalone testing"""
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    # Initialize and start consumer
    config = Config()
    consumer = FaultDescriptionConsumer(config)

    try:
        await consumer.start()
    except KeyboardInterrupt:
        logging.info("\n⚠️  Received interrupt signal")
    except Exception as e:
        logging.error(f"❌ Consumer error: {e}")
        raise
    finally:
        await consumer.stop()


if __name__ == "__main__":
    asyncio.run(main())
