#!/usr/bin/env python3
"""
Schema Validation Test for Enhanced MCP Ticket System
Validates the Memgraph database schema and performs analytics queries
"""

import sys
import os

# Add the app directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from data_access.memgraphClient import MemgraphClient  # noqa: E402
from configs.config import Config  # noqa: E402
from utils.utilities import Helpers  # noqa: E402


class SchemaValidationTest:
    """Test class for schema validation and analytics"""

    def __init__(self):
        self.test_db_uri = None
        self.memgraph_client = None
        self.config = None

    def setup_test_environment(self):
        """Set up a temporary test environment"""
        print("🔧 Setting up schema validation environment...")

        # Use test Memgraph instance
        self.test_db_uri = "bolt://localhost:7687"
        print(f"📁 Test database: {self.test_db_uri}")

        # Initialize test config
        self.config = Config()
        self.config._memgraph_uri = self.test_db_uri

        # Load cypher configs for MemgraphClient
        cyphers_yaml_dict = Helpers.load_cypher_configs(self.config.cypher_file_path)

        # Initialize Memgraph client with test database
        self.memgraph_client = MemgraphClient(
            uri=self.test_db_uri,
            jsonPath="test/json/path",
            cyphers_dict=cyphers_yaml_dict
        )

        print("✅ Schema validation environment ready")

    def teardown_test_environment(self):
        """Clean up test environment"""
        print("🧹 Cleaning up schema validation environment...")

        if self.memgraph_client:
            self.memgraph_client.shutdown()

        # Memgraph data cleanup is handled by the database service
        print(f"🗑️  Test database cleaned: {self.test_db_uri}")

    def test_enhanced_schema_creation(self):
        """Test that the enhanced schema can be created without errors"""
        print("\n🏗️  Testing Enhanced Schema Creation")

        try:
            # Load enhanced cypher configuration
            cyphers_yaml_dict = Helpers.load_cypher_configs(self.config.cypher_file_path)

            # Execute schema creation
            self.memgraph_client.conn.execute(cyphers_yaml_dict["memgraph_create_nodes_rels_tables_queries"])
            print("✅ Enhanced schema created successfully")
            return True

        except Exception as e:
            print(f"❌ Schema creation failed: {e}")
            import traceback
            traceback.print_exc()
            return False

    def validate_node_tables(self):
        """Validate that all expected node tables exist"""
        print("\n📋 Validating Node Tables")

        expected_node_tables = [
            "Client", "Service", "Incident", "Ticket", "Outage_Info",
            "UserInfo", "ContactInfo", "VendorInfo", "MaintenanceWindow",
            "SurveyInfo", "NOCInfo"
        ]

        try:
            # Query to check if tables exist by trying to match nodes
            existing_tables = set()
            for table_name in expected_node_tables:
                try:
                    self.memgraph_client.conn.execute(f"MATCH (n:{table_name}) RETURN count(n) as count LIMIT 1")
                    existing_tables.add(table_name)
                    print(f"✅ Found node table: {table_name}")
                except Exception:
                    # Table doesn't exist, will be caught later
                    pass

            missing_tables = set(expected_node_tables) - existing_tables
            if missing_tables:
                print(f"❌ Missing node tables: {missing_tables}")
                return False
            else:
                print(f"✅ All {len(expected_node_tables)} expected node tables found")
                return True

        except Exception as e:
            print(f"❌ Error validating node tables: {e}")
            return False

    def validate_relationship_tables(self):
        """Validate that all expected relationship tables exist"""
        print("\n🔗 Validating Relationship Tables")

        expected_rel_tables = [
            # Existing relationships
            "HAS_TICKET", "HAS_OUTAGE_INFO", "TRIGGERED_BY", "IMPACTS", "CHILD_OF",
            # New relationships
            "LINKED_TO", "CREATED_BY", "ASSIGNED_TO", "CLOSED_BY", "FIRST_ASSIGNED_TO",
            "HAS_CONTACT", "TICKET_CONTACT", "HANDLED_BY", "SUPPLIED_BY",
            "HAS_MAINTENANCE", "DURING_MAINTENANCE", "HAS_SURVEY",
            "ASSIGNED_TO_NOC", "MONITORED_BY_NOC"
        ]

        try:
            # Query to check if relationship tables exist by trying to match relationships
            existing_rel_tables = set()
            for rel_name in expected_rel_tables:
                try:
                    self.memgraph_client.conn.execute(f"MATCH ()-[r:{rel_name}]->() RETURN count(r) as count LIMIT 1")
                    existing_rel_tables.add(rel_name)
                    print(f"✅ Found relationship table: {rel_name}")
                except Exception:
                    # Relationship doesn't exist, will be caught later
                    pass

            missing_rel_tables = set(expected_rel_tables) - existing_rel_tables
            if missing_rel_tables:
                print(f"❌ Missing relationship tables: {missing_rel_tables}")
                return False
            else:
                print(f"✅ All {len(expected_rel_tables)} expected relationship tables found")
                return True

        except Exception as e:
            print(f"❌ Error validating relationship tables: {e}")
            return False

    def test_node_table_schemas(self):
        """Test node table schemas for correct data types"""
        print("\n📊 Testing Node Table Schemas")

        schema_tests = [
            {
                "table": "Ticket",
                "expected_fields": {
                    "ticket_id": "STRING",
                    "is_master_ticket": "BOOLEAN",
                    "priority": "INT64"
                }
            },
            {
                "table": "UserInfo",
                "expected_fields": {
                    "user_id": "STRING",
                    "name": "STRING",
                    "role": "STRING"
                }
            },
            {
                "table": "VendorInfo",
                "expected_fields": {
                    "vendor_id": "STRING",
                    "vendor_downtime": "DOUBLE"
                }
            }
        ]

        all_passed = True

        for test in schema_tests:
            try:
                # For Memgraph, we'll skip detailed schema validation and just check if tables exist
                # since Memgraph doesn't have a DESCRIBE command like traditional SQL databases
                try:
                    self.memgraph_client.conn.execute(f"MATCH (n:{test['table']}) RETURN count(n) as count LIMIT 1")
                    print(f"  ✅ {test['table']} table exists")
                    continue
                except Exception:
                    print(f"  ❌ {test['table']} table does not exist")
                    all_passed = False
                    continue

            except Exception as e:
                print(f"❌ Error checking {test['table']} schema: {e}")
                all_passed = False

        return all_passed

    def test_sample_queries(self):
        """Test sample analytics queries to ensure schema supports complex operations"""
        print("\n🔍 Testing Sample Analytics Queries")

        # Note: These queries test syntax and structure, not data (since we have no data)
        sample_queries = [
            {
                "name": "User Performance Query",
                "query": """
                    MATCH (t:Ticket)-[:ASSIGNED_TO]->(u:UserInfo)
                    WHERE t.ticket_status = 'Closed'
                    RETURN u.name, count(t) as ticket_count
                    LIMIT 5
                """,
                "description": "Test user-ticket relationships"
            },
            {
                "name": "Vendor Analysis Query",
                "query": """
                    MATCH (t:Ticket)-[:HANDLED_BY]->(v:VendorInfo)
                    RETURN v.vendor, avg(v.vendor_downtime) as avg_downtime
                    LIMIT 5
                """,
                "description": "Test vendor analytics"
            },
            {
                "name": "Client Escalation Query",
                "query": """
                    MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
                    WHERE t.ticket_escalation_level > 0
                    RETURN c.client_name, count(t) as escalated_tickets
                    LIMIT 5
                """,
                "description": "Test escalation tracking"
            },
            {
                "name": "Contact Communication Query",
                "query": """
                    MATCH (t:Ticket)-[:TICKET_CONTACT]->(con:ContactInfo)
                    WHERE con.contact_type = 'customer'
                    RETURN con.contact_type, count(t) as tickets
                    LIMIT 5
                """,
                "description": "Test contact relationships"
            },
            {
                "name": "Survey Satisfaction Query",
                "query": """
                    MATCH (t:Ticket)-[:HAS_SURVEY]->(s:SurveyInfo)
                    RETURN s.survey_score, count(t) as ticket_count
                    LIMIT 5
                """,
                "description": "Test survey analytics"
            },
            {
                "name": "Maintenance Correlation Query",
                "query": """
                    MATCH (t:Ticket)-[:DURING_MAINTENANCE]->(mw:MaintenanceWindow)
                    MATCH (t)-[:TRIGGERED_BY]->(i:Incident)
                    RETURN mw.pw_reason, count(t) as related_tickets
                    LIMIT 5
                """,
                "description": "Test maintenance impact analysis"
            }
        ]

        all_passed = True

        for query_test in sample_queries:
            try:
                print(f"🔍 Testing: {query_test['name']}")
                self.memgraph_client.conn.execute(query_test["query"])

                # Just test that the query executes without error
                # (won't have data, but syntax should be valid)
                print(f"  ✅ {query_test['description']} - Query executed successfully")

            except Exception as e:
                print(f"  ❌ {query_test['description']} - Query failed: {e}")
                all_passed = False

        return all_passed

    def test_schema_statistics(self):
        """Generate schema statistics"""
        print("\n📊 Schema Statistics")

        try:
            # Count node and relationship tables by testing existence
            expected_node_tables = [
                "Client", "Service", "Incident", "Ticket", "Outage_Info",
                "UserInfo", "ContactInfo", "VendorInfo", "MaintenanceWindow",
                "SurveyInfo", "NOCInfo"
            ]
            expected_rel_tables = [
                "HAS_TICKET", "HAS_OUTAGE_INFO", "TRIGGERED_BY", "IMPACTS", "CHILD_OF",
                "LINKED_TO", "CREATED_BY", "ASSIGNED_TO", "CLOSED_BY", "FIRST_ASSIGNED_TO",
                "HAS_CONTACT", "TICKET_CONTACT", "HANDLED_BY", "SUPPLIED_BY",
                "HAS_MAINTENANCE", "DURING_MAINTENANCE", "HAS_SURVEY",
                "ASSIGNED_TO_NOC", "MONITORED_BY_NOC"
            ]

            node_tables = 0
            rel_tables = 0

            # Count existing node tables
            for table_name in expected_node_tables:
                try:
                    self.memgraph_client.conn.execute(f"MATCH (n:{table_name}) RETURN count(n) as count LIMIT 1")
                    node_tables += 1
                except Exception:
                    pass

            # Count existing relationship tables
            for rel_name in expected_rel_tables:
                try:
                    self.memgraph_client.conn.execute(f"MATCH ()-[r:{rel_name}]->() RETURN count(r) as count LIMIT 1")
                    rel_tables += 1
                except Exception:
                    pass

            print("📈 Schema Statistics:")
            print(f"  Node Tables: {node_tables}")
            print(f"  Relationship Tables: {rel_tables}")
            print(f"  Total Tables: {node_tables + rel_tables}")

            # Expected counts
            expected_nodes = 11
            expected_rels = 19

            if node_tables == expected_nodes and rel_tables == expected_rels:
                print(f"✅ Schema matches expected structure ({expected_nodes} nodes, {expected_rels} relationships)")
                return True
            else:
                print(f"❌ Schema mismatch: Expected {expected_nodes} nodes/{expected_rels} rels, got {node_tables} nodes/{rel_tables} rels")
                return False

        except Exception as e:
            print(f"❌ Error generating schema statistics: {e}")
            return False

    def run_all_tests(self):
        """Run all schema validation tests"""
        print("🔍 Starting Schema Validation Tests")
        print("=" * 60)

        try:
            self.setup_test_environment()

            test_results = []

            # Test 1: Schema Creation
            test_results.append(self.test_enhanced_schema_creation())

            # Test 2: Node Table Validation
            test_results.append(self.validate_node_tables())

            # Test 3: Relationship Table Validation
            test_results.append(self.validate_relationship_tables())

            # Test 4: Node Table Schema Validation
            test_results.append(self.test_node_table_schemas())

            # Test 5: Sample Queries
            test_results.append(self.test_sample_queries())

            # Test 6: Schema Statistics
            test_results.append(self.test_schema_statistics())

            # Summary
            passed_tests = sum(test_results)
            total_tests = len(test_results)

            print("\n" + "=" * 60)
            print(f"🏁 Schema Validation Results: {passed_tests}/{total_tests} tests passed")

            if passed_tests == total_tests:
                print("🎉 SCHEMA VALIDATION PASSED! Enhanced schema is properly structured.")
                return True
            else:
                print(f"❌ {total_tests - passed_tests} schema tests failed.")
                return False

        except Exception as e:
            print(f"💥 Schema validation failed with exception: {e}")
            import traceback
            traceback.print_exc()
            return False

        finally:
            self.teardown_test_environment()


def main():
    """Main function to run schema validation"""
    test_suite = SchemaValidationTest()
    success = test_suite.run_all_tests()

    # Exit with appropriate code
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
