# utils/serializers.py
from datetime import datetime
from decimal import Decimal


def custom_serializer(obj):
    """Handles JSON serialization for datetime and decimal objects."""
    if isinstance(obj, datetime):
        return obj.strftime("%Y-%m-%d %H:%M:%S")  # Convert datetime to string
    elif isinstance(obj, Decimal):
        return float(obj)  # Convert Decimal to float
    raise TypeError(f"Type {type(obj)} not serializable")
