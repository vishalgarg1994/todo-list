#!/bin/bash

# Eva Messaging Infrastructure Deployment Script
# Automatically detects environment and deploys appropriately

set -e

ENVIRONMENT=${1:-dev}
VALID_ENVIRONMENTS=("dev" "test" "prod")

echo "🚀 Eva Messaging Infrastructure Deployment"
echo "📍 Target Environment: $ENVIRONMENT"
echo ""

# Validate environment
if [[ ! " ${VALID_ENVIRONMENTS[@]} " =~ " $ENVIRONMENT " ]]; then
    echo "❌ Invalid environment: $ENVIRONMENT"
    echo "✅ Valid environments: ${VALID_ENVIRONMENTS[*]}"
    exit 1
fi

# Check if running in Kubernetes context
if kubectl config current-context &>/dev/null; then
    echo "☸️  Kubernetes context detected - using Helm deployment"

    # Deploy with Helm
    cd helm
    echo "📦 Deploying Eva messaging infrastructure to $ENVIRONMENT..."

    if [[ "$ENVIRONMENT" == "dev" ]]; then
        helm upgrade --install eva-messaging-infrastructure . -f values-dev.yaml -n eva-dev --create-namespace
    elif [[ "$ENVIRONMENT" == "test" ]]; then
        helm upgrade --install eva-messaging-infrastructure . -f values-test.yaml -n eva-test --create-namespace
    elif [[ "$ENVIRONMENT" == "prod" ]]; then
        helm upgrade --install eva-messaging-infrastructure . -f values-prod.yaml -n eva-prod --create-namespace
    fi

    echo "✅ Helm deployment complete!"

else
    echo "🐳 Local Docker context detected - using Docker Compose"

    # Check if environment file exists
    if [[ ! -f "nats/.env.$ENVIRONMENT" ]]; then
        echo "❌ Environment file nats/.env.$ENVIRONMENT not found!"
        exit 1
    fi

    # Deploy with Docker Compose
    export ENVIRONMENT=$ENVIRONMENT
    echo "📦 Starting Eva messaging infrastructure with $ENVIRONMENT configuration..."

    docker-compose down --remove-orphans 2>/dev/null || true
    docker-compose up -d

    echo "⏳ Waiting for NATS to be ready..."
    sleep 5

    # Initialize streams with environment-specific configuration
    echo "🏗️  Initializing JetStream streams..."
    source nats/.env.$ENVIRONMENT
    ./nats/scripts/init-streams.sh

    echo "✅ Docker Compose deployment complete!"
fi

echo ""
echo "🎉 Eva Messaging Infrastructure is ready!"
echo ""
echo "📊 Monitoring URLs:"
case $ENVIRONMENT in
    dev)
        echo "   NATS Monitor: http://localhost:8222"
        echo "   Message UI: http://localhost:3000"
        ;;
    test)
        echo "   NATS Monitor: https://evo-test.gt-t.net/monitor"
        echo "   Message UI: https://evo-test.gt-t.net/ui"
        ;;
    prod)
        echo "   NATS Monitor: https://evo.gt-t.net/monitor"
        echo "   Message UI: https://evo.gt-t.net/ui"
        ;;
esac
echo ""
echo "🔧 Configuration Applied:"
if [[ -f "nats/.env.$ENVIRONMENT" ]]; then
    echo "   $(grep JETSTREAM_MAX_BYTES nats/.env.$ENVIRONMENT)"
    echo "   $(grep JETSTREAM_MAX_MSGS nats/.env.$ENVIRONMENT)"
    echo "   $(grep JETSTREAM_MAX_AGE nats/.env.$ENVIRONMENT)"
fi