"""
ServiceNow SMDS API Extractor

Extracts incidents, cases, and their tasks from ServiceNow SMDS API endpoints.
Based on GTT Service Management Data Services API documentation.

Features:
- Basic Auth with aiohttp
- JSON response parsing (default format per API docs)
- Semaphore-based rate limiting
- Date filtering with from_date/to_date params (format: YYYY-MM-DD HH:mm:ss)
- Sequential task fetching per ticket (simple and debuggable)

API Endpoints:
- /incidents - List incidents (with date filter)
- /cases - List cases (with date filter)
- /problems - List problems (with date filter)
- /change_requests - List change requests (with date filter)
- /service_requests - List service requests (with date filter)
- /customers/{sys_id} - Get customer details
- /incidents/{sys_id}/tasks - Get tasks for incident
- /cases/{sys_id}/tasks - Get tasks for case
- /problems/{sys_id}/tasks - Get tasks for problem
- /change_requests/{sys_id}/tasks - Get tasks for change request
- /service_requests/{sys_id}/tasks - Get tasks for service request

Returns data in the same structure as the DB Extractor for compatibility
with the existing transformer.
"""

import asyncio
import logging
import time
import aiohttp
from typing import Dict, Any, Optional, List, Set
from datetime import datetime, timedelta


logger = logging.getLogger(__name__)


def parse_business_elapsed_to_minutes(elapsed_str: str) -> Optional[int]:
    """
    Parse ServiceNow business_elapsed string to integer minutes.

    Examples:
        "51 Days 20 Hours 8 Minutes" -> 74648
        "2 Hours 30 Minutes" -> 150
        "45 Minutes" -> 45
        "18 Hours 50 Minutes" -> 1130

    Args:
        elapsed_str: String like "X Days Y Hours Z Minutes"

    Returns:
        Total minutes as int, or None if cannot parse
    """
    if not elapsed_str:
        return None

    import re
    total_minutes = 0

    # Extract days
    days_match = re.search(r'(\d+)\s*Days?', elapsed_str, re.IGNORECASE)
    if days_match:
        total_minutes += int(days_match.group(1)) * 24 * 60

    # Extract hours
    hours_match = re.search(r'(\d+)\s*Hours?', elapsed_str, re.IGNORECASE)
    if hours_match:
        total_minutes += int(hours_match.group(1)) * 60

    # Extract minutes
    minutes_match = re.search(r'(\d+)\s*Minutes?', elapsed_str, re.IGNORECASE)
    if minutes_match:
        total_minutes += int(minutes_match.group(1))

    return total_minutes if total_minutes > 0 else None


class ServiceNowAPIExtractor:
    """
    Extracts data from ServiceNow SMDS API.

    This class provides the same interface as the DB Extractor,
    returning data in a format compatible with TicketTransformer.
    """

    def __init__(
        self,
        base_url: str,
        username: str,
        password: str,
        timeout: int = 60,
        max_concurrent: int = 5,
        lookback_hours: int = 24,
        client_id: str = "",
        client_secret: str = ""
    ):
        """
        Initialize the API extractor.

        Args:
            base_url: ServiceNow SMDS API base URL
            username: API username for Basic Auth or OAuth2
            password: API password for Basic Auth or OAuth2
            timeout: Request timeout in seconds
            max_concurrent: Maximum concurrent requests
            lookback_hours: How many hours back to fetch (default 24, max 24 per API)
            client_id: OAuth2 client ID (if set, uses OAuth2 instead of Basic Auth)
            client_secret: OAuth2 client secret
        """
        self.base_url = base_url.rstrip('/')
        self.username = username
        self.password = password
        self.client_id = client_id
        self.client_secret = client_secret
        self.timeout = timeout
        self.max_concurrent = max_concurrent
        self.lookback_hours = min(lookback_hours, 24)  # API limits to 24 hours max

        self._session: Optional[aiohttp.ClientSession] = None
        self._semaphore: Optional[asyncio.Semaphore] = None
        self._access_token: Optional[str] = None
        self._token_expiry: float = 0

        self._use_oauth = bool(client_id and client_secret)
        if self._use_oauth:
            logger.info("ServiceNow auth: OAuth2 (client_id set)")
        else:
            logger.info("ServiceNow auth: Basic Auth")

    async def _fetch_oauth_token(self):
        """Fetch OAuth2 access token from ServiceNow"""
        # Extract instance base from the API URL (e.g., https://gttuat.service-now.com)
        from urllib.parse import urlparse
        parsed = urlparse(self.base_url)
        token_url = f"{parsed.scheme}://{parsed.netloc}/oauth_token.do"

        data = {
            "grant_type": "password",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "username": self.username,
            "password": self.password,
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(token_url, data=data) as resp:
                if resp.status != 200:
                    body = await resp.text()
                    raise RuntimeError(f"OAuth2 token request failed ({resp.status}): {body}")
                result = await resp.json()
                self._access_token = result["access_token"]
                expires_in = int(result.get("expires_in", 1800))
                self._token_expiry = time.time() + expires_in - 60  # refresh 60s early
                logger.info(f"OAuth2 token acquired, expires in {expires_in}s")

    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session with OAuth2 or Basic Auth"""
        if self._use_oauth:
            # Refresh token if expired
            if self._access_token is None or time.time() >= self._token_expiry:
                await self._fetch_oauth_token()
            if self._session is not None and not self._session.closed:
                await self._session.close()
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self._session = aiohttp.ClientSession(
                timeout=timeout,
                headers={
                    "Accept": "application/json",
                    "Authorization": f"Bearer {self._access_token}",
                }
            )
        elif self._session is None or self._session.closed:
            auth = aiohttp.BasicAuth(self.username, self.password)
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self._session = aiohttp.ClientSession(
                auth=auth,
                timeout=timeout,
                headers={"Accept": "application/json"}
            )
        return self._session

    async def _get_semaphore(self) -> asyncio.Semaphore:
        """Get or create semaphore for concurrency control"""
        if self._semaphore is None:
            self._semaphore = asyncio.Semaphore(self.max_concurrent)
        return self._semaphore

    async def close(self):
        """Close the aiohttp session"""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None

    async def extract_all(self, since: Optional[datetime] = None) -> Dict[str, Any]:
        """
        Extract all ticket types from API.

        Args:
            since: Optional datetime filter for incremental loads

        Returns:
            Dict with same structure as DB Extractor:
                - cmd_records: empty (no CMD from API)
                - cmd_by_sys_id: empty
                - incidents, cases, problems, requests, changes
                - incident_tasks, case_tasks, problem_tasks, change_tasks
                - tsm_by_sys_id: index of all client-centric tickets
                - ci_services, ci_by_task_sys_id: empty
                - case_tasks_by_case, change_tasks_by_change: indexes
        """
        logger.info(f"API Extracting data since: {since}")

        try:
            # Fetch all ticket types in parallel
            results = await asyncio.gather(
                self._fetch_incidents(since),
                self._fetch_cases(since),
                self._fetch_problems(since),
                self._fetch_changes(since),
                self._fetch_service_requests(since),
                return_exceptions=True
            )

            # Unpack and handle exceptions
            incidents, cases, problems, changes, requests = [], [], [], [], []
            labels = ['incidents', 'cases', 'problems', 'changes', 'service_requests']
            targets = [incidents, cases, problems, changes, requests]
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    logger.error(f"Failed to fetch {labels[i]}: {result}")
                else:
                    targets[i].extend(result)

            # Collect unique client sys_ids from client-centric types
            # (changes are infrastructure-level, no client_id)
            client_sys_ids: Set[str] = set()
            for record in incidents + cases + problems + requests:
                client_sys_id = self._extract_client_sys_id(record)
                if client_sys_id:
                    client_sys_ids.add(client_sys_id)

            logger.info(f"Found {len(client_sys_ids)} unique clients to fetch")

            # Fetch client details via /customers/{sys_id} endpoint
            clients = {}
            if client_sys_ids:
                clients = await self._fetch_clients(client_sys_ids)
            else:
                logger.warning("No valid client sys_ids found - skipping client lookup")

            # Enrich client-centric records with client data
            # (changes are infrastructure-level - no client enrichment)
            incidents = self._enrich_with_client(incidents, clients)
            cases = self._enrich_with_client(cases, clients)
            problems = self._enrich_with_client(problems, clients)
            requests = self._enrich_with_client(requests, clients)

            # Normalize field names to match DB extractor format for transformer compatibility
            incidents = [self._normalize_incident(inc) for inc in incidents]
            cases = [self._normalize_case(case) for case in cases]
            problems = [self._normalize_problem(prob) for prob in problems]
            changes = [self._normalize_change(chg) for chg in changes]
            requests = [self._normalize_service_request(req) for req in requests]

            # Fetch tasks for all types that have them
            # (service_requests/SCTASKs don't have nested tasks - SCTASK IS the ticket)
            logger.info("Fetching tasks for incidents, cases, problems, and changes...")
            incident_tasks_raw = await self._fetch_tasks_for_incidents(incidents)
            case_tasks_raw = await self._fetch_tasks_for_cases(cases)
            problem_tasks_raw = await self._fetch_tasks_for_problems(problems)
            change_tasks_raw = await self._fetch_tasks_for_changes(changes)

            # Normalize tasks
            incident_tasks = [self._normalize_incident_task(t) for t in incident_tasks_raw]
            case_tasks = [self._normalize_case_task(t) for t in case_tasks_raw]
            problem_tasks = [self._normalize_problem_task(t) for t in problem_tasks_raw]
            change_tasks = [self._normalize_change_task(t) for t in change_tasks_raw]

            # Build case_tasks_by_case index for transformer compatibility
            case_tasks_by_case: Dict[str, List[Dict[str, Any]]] = {}
            for task in case_tasks:
                parent_sys_id = task.get('parent_case_sys_id')
                if parent_sys_id:
                    if parent_sys_id not in case_tasks_by_case:
                        case_tasks_by_case[parent_sys_id] = []
                    case_tasks_by_case[parent_sys_id].append(task)

            # Build change_tasks_by_change index for transformer compatibility
            change_tasks_by_change: Dict[str, List[Dict[str, Any]]] = {}
            for task in change_tasks:
                parent_sys_id = task.get('change_sys_id')
                if parent_sys_id:
                    if parent_sys_id not in change_tasks_by_change:
                        change_tasks_by_change[parent_sys_id] = []
                    change_tasks_by_change[parent_sys_id].append(task)

            # Build tsm_by_sys_id index (using normalized field names)
            tsm_by_sys_id: Dict[str, Dict[str, Any]] = {}
            for inc in incidents:
                sys_id = inc.get('incident_sys_id')
                if sys_id:
                    tsm_by_sys_id[sys_id] = {'type': 'incident', 'data': inc}
            for case in cases:
                sys_id = case.get('case_sys_id')
                if sys_id:
                    tsm_by_sys_id[sys_id] = {'type': 'case', 'data': case}
            for prob in problems:
                sys_id = prob.get('problem_sys_id')
                if sys_id:
                    tsm_by_sys_id[sys_id] = {'type': 'problem', 'data': prob}
            for req in requests:
                sys_id = req.get('req_task_sys_id')
                if sys_id:
                    tsm_by_sys_id[sys_id] = {'type': 'request', 'data': req}

            logger.info(
                f"API Extracted: {len(incidents)} incidents, {len(cases)} cases, "
                f"{len(problems)} problems, {len(changes)} changes, "
                f"{len(requests)} service_requests, {len(clients)} clients, "
                f"{len(incident_tasks)} incident tasks, {len(case_tasks)} case tasks, "
                f"{len(problem_tasks)} problem tasks, {len(change_tasks)} change tasks"
            )

            return {
                # CMD records (empty - no CMD from API)
                'cmd_records': [],
                'cmd_by_sys_id': {},
                # TSM client-centric records
                'incidents': incidents,
                'cases': cases,
                'problems': problems,
                'requests': requests,
                # TSM infrastructure records
                'changes': changes,
                # TSM tasks
                'incident_tasks': incident_tasks,
                'case_tasks': case_tasks,
                'problem_tasks': problem_tasks,
                'change_tasks': change_tasks,
                # Lookups
                'tsm_by_sys_id': tsm_by_sys_id,
                'ci_services': [],
                'ci_by_task_sys_id': {},
                'case_tasks_by_case': case_tasks_by_case,
                'change_tasks_by_change': change_tasks_by_change,
                # API-specific: client data for enrichment
                '_clients': clients,
            }

        except Exception as e:
            logger.error(f"API extraction failed: {e}", exc_info=True)
            raise

    async def _fetch_incidents(self, since: Optional[datetime]) -> List[Dict[str, Any]]:
        """
        Fetch incidents from /incidents endpoint.

        Args:
            since: Optional start date filter

        Returns:
            List of incident records
        """
        url = f"{self.base_url}/incidents"
        params = self._build_date_params(since)

        logger.debug(f"Fetching incidents from {url} with params {params}")
        json_response = await self._fetch_json(url, params)

        if json_response is None:
            return []

        return self._parse_records(json_response, 'incident')

    async def _fetch_cases(self, since: Optional[datetime]) -> List[Dict[str, Any]]:
        """
        Fetch cases from /cases endpoint.

        Args:
            since: Optional start date filter

        Returns:
            List of case records
        """
        url = f"{self.base_url}/cases"
        params = self._build_date_params(since)

        logger.debug(f"Fetching cases from {url} with params {params}")
        json_response = await self._fetch_json(url, params)

        if json_response is None:
            return []

        return self._parse_records(json_response, 'case')

    async def _fetch_problems(self, since: Optional[datetime]) -> List[Dict[str, Any]]:
        """Fetch problems from /problems endpoint."""
        url = f"{self.base_url}/problems"
        params = self._build_date_params(since)

        logger.debug(f"Fetching problems from {url} with params {params}")
        json_response = await self._fetch_json(url, params)

        if json_response is None:
            return []

        return self._parse_records(json_response, 'problem')

    async def _fetch_changes(self, since: Optional[datetime]) -> List[Dict[str, Any]]:
        """Fetch change requests from /change_requests endpoint."""
        url = f"{self.base_url}/change_requests"
        params = self._build_date_params(since)

        logger.debug(f"Fetching change_requests from {url} with params {params}")
        json_response = await self._fetch_json(url, params)

        if json_response is None:
            return []

        return self._parse_records(json_response, 'change')

    async def _fetch_service_requests(self, since: Optional[datetime]) -> List[Dict[str, Any]]:
        """Fetch service requests from /service_requests endpoint."""
        url = f"{self.base_url}/service_requests"
        params = self._build_date_params(since)

        logger.debug(f"Fetching service_requests from {url} with params {params}")
        json_response = await self._fetch_json(url, params)

        if json_response is None:
            return []

        return self._parse_records(json_response, 'service_request')

    async def _fetch_clients(self, sys_ids: Set[str]) -> Dict[str, Dict[str, Any]]:
        """
        Fetch client details for given sys_ids.

        Uses /customers/{sys_id} endpoint (API uses "customer" terminology).

        Args:
            sys_ids: Set of client sys_ids to fetch

        Returns:
            Dict of client records indexed by sys_id
        """
        if not sys_ids:
            return {}

        clients: Dict[str, Dict[str, Any]] = {}

        # Fetch clients in parallel with semaphore for rate limiting
        tasks = [
            self._fetch_client(sys_id)
            for sys_id in sys_ids
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for sys_id, result in zip(sys_ids, results):
            if isinstance(result, Exception):
                logger.warning(f"Failed to fetch client {sys_id}: {result}")
            elif result:
                clients[sys_id] = result

        logger.info(f"Fetched {len(clients)}/{len(sys_ids)} clients")
        return clients

    async def _fetch_client(self, sys_id: str) -> Optional[Dict[str, Any]]:
        """
        Fetch a single client by sys_id.

        Uses /customers/{sys_id} endpoint (API uses "customer" terminology).

        Args:
            sys_id: Client sys_id

        Returns:
            Client record or None
        """
        url = f"{self.base_url}/customers/{sys_id}"
        json_response = await self._fetch_json(url)

        if json_response is None:
            return None

        # Parse single client record
        records = self._parse_records(json_response, 'client')
        return records[0] if records else None

    # =========================================================================
    # Task Fetching - Sequential per ticket approach
    # =========================================================================

    async def _fetch_tasks_for_incidents(
        self,
        incidents: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Fetch tasks for each incident sequentially.

        Sequential approach: fetch ticket -> fetch its tasks -> next ticket.
        Simple, debuggable, and easier to trace issues.

        Args:
            incidents: List of incident records

        Returns:
            List of all incident tasks
        """
        all_tasks = []
        total = len(incidents)

        for idx, inc in enumerate(incidents, 1):
            sys_id = inc.get('incident_sys_id') or inc.get('sys_id')
            number = inc.get('incident_number') or inc.get('number')

            if not sys_id:
                continue

            tasks = await self._fetch_tasks_for_record('incidents', sys_id)
            if tasks:
                # Enrich tasks with parent info
                for task in tasks:
                    task['parent_sys_id'] = sys_id
                    task['parent_number'] = number
                    task['parent_type'] = 'incident'
                all_tasks.extend(tasks)

                if idx % 10 == 0 or idx == total:
                    logger.debug(f"Incident tasks: {idx}/{total} processed, {len(all_tasks)} tasks found")

        logger.info(f"Fetched {len(all_tasks)} tasks for {total} incidents")
        return all_tasks

    async def _fetch_tasks_for_cases(
        self,
        cases: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Fetch tasks for each case sequentially.

        Args:
            cases: List of case records

        Returns:
            List of all case tasks
        """
        all_tasks = []
        total = len(cases)

        for idx, case in enumerate(cases, 1):
            sys_id = case.get('case_sys_id') or case.get('sys_id')
            number = case.get('case_number') or case.get('number')

            if not sys_id:
                continue

            tasks = await self._fetch_tasks_for_record('cases', sys_id)
            if tasks:
                # Enrich tasks with parent info
                for task in tasks:
                    task['parent_case_sys_id'] = sys_id
                    task['parent_case_number'] = number
                    task['parent_type'] = 'case'
                all_tasks.extend(tasks)

                if idx % 10 == 0 or idx == total:
                    logger.debug(f"Case tasks: {idx}/{total} processed, {len(all_tasks)} tasks found")

        logger.info(f"Fetched {len(all_tasks)} tasks for {total} cases")
        return all_tasks

    async def _fetch_tasks_for_problems(
        self,
        problems: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Fetch tasks for each problem sequentially."""
        all_tasks = []
        total = len(problems)

        for idx, prob in enumerate(problems, 1):
            sys_id = prob.get('problem_sys_id') or prob.get('sys_id')
            number = prob.get('problem_number') or prob.get('number')

            if not sys_id:
                continue

            tasks = await self._fetch_tasks_for_record('problems', sys_id)
            if tasks:
                for task in tasks:
                    task['problem_sys_id'] = sys_id
                    task['problem_number'] = number
                    task['parent_type'] = 'problem'
                all_tasks.extend(tasks)

                if idx % 10 == 0 or idx == total:
                    logger.debug(f"Problem tasks: {idx}/{total} processed, {len(all_tasks)} tasks found")

        logger.info(f"Fetched {len(all_tasks)} tasks for {total} problems")
        return all_tasks

    async def _fetch_tasks_for_changes(
        self,
        changes: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Fetch tasks for each change request sequentially."""
        all_tasks = []
        total = len(changes)

        for idx, chg in enumerate(changes, 1):
            sys_id = chg.get('change_sys_id') or chg.get('sys_id')
            number = chg.get('change_number') or chg.get('number')

            if not sys_id:
                continue

            tasks = await self._fetch_tasks_for_record('change_requests', sys_id)
            if tasks:
                for task in tasks:
                    task['change_sys_id'] = sys_id
                    task['change_number'] = number
                    task['parent_type'] = 'change'
                all_tasks.extend(tasks)

                if idx % 10 == 0 or idx == total:
                    logger.debug(f"Change tasks: {idx}/{total} processed, {len(all_tasks)} tasks found")

        logger.info(f"Fetched {len(all_tasks)} tasks for {total} changes")
        return all_tasks

    async def _fetch_tasks_for_record(
        self,
        record_type: str,
        sys_id: str
    ) -> List[Dict[str, Any]]:
        """
        Fetch tasks for a single ticket.

        Endpoint format: /{record_type}/{sys_id}/tasks
        Examples:
            - /incidents/{sys_id}/tasks
            - /cases/{sys_id}/tasks
            - /change_requests/{sys_id}/tasks
            - /problems/{sys_id}/tasks
            - /service_requests/{sys_id}/tasks

        Args:
            record_type: Type of parent record (incidents, cases, etc.)
            sys_id: Parent record sys_id

        Returns:
            List of task records (empty if no tasks or error)
        """
        url = f"{self.base_url}/{record_type}/{sys_id}/tasks"

        try:
            json_response = await self._fetch_json(url)
            if json_response is None:
                return []

            tasks = self._parse_records(json_response, f'{record_type}_task')
            return tasks

        except Exception as e:
            logger.warning(f"Failed to fetch tasks for {record_type}/{sys_id}: {e}")
            return []

    def _normalize_incident_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize API incident task fields to match IncidentTaskInfo model.

        API returns fields like:
        - sys_id, number, state, short_description, priority
        - assignment_group, assigned_to_sys_id, assigned_to_first_name, assigned_to_last_name
        - created_on, closed_on, closure_code
        - third_party_name, third_party_ticket, vendor_id
        """
        # Build assigned_to from first_name + last_name
        assigned_to_parts = []
        if task.get('assigned_to_first_name'):
            assigned_to_parts.append(task.get('assigned_to_first_name'))
        if task.get('assigned_to_last_name'):
            assigned_to_parts.append(task.get('assigned_to_last_name'))
        assigned_to = ' '.join(assigned_to_parts) if assigned_to_parts else None

        return {
            'task_sys_id': task.get('sys_id'),
            'task_number': task.get('number'),
            'task_type': 'task',  # Incident tasks are "task" type
            'task_state': task.get('state'),
            'short_description': task.get('short_description'),
            'priority': self._parse_int(task.get('priority')),
            'assigned_to': assigned_to or task.get('assigned_to'),
            'assigned_to_sys_id': task.get('assigned_to_sys_id'),
            'assignment_group': task.get('assignment_group'),
            'created_on': task.get('created_on'),
            'closed_on': task.get('closed_on'),
            'closure_code': task.get('closure_code'),
            'third_party_name': task.get('third_party_name'),
            'third_party_ticket': task.get('third_party_ticket'),
            'vendor_id': task.get('vendor_id'),
            # Parent info (set by caller)
            'parent_sys_id': task.get('parent_sys_id'),
            'parent_number': task.get('parent_number'),
        }

    def _normalize_case_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize API case task fields to match CaseTaskInfo model.

        API returns fields like:
        - sys_id, number, state, short_description, priority
        - assignment_group, assigned_to_sys_id, assigned_to_first_name, assigned_to_last_name
        - created_on, closed_on, service_type
        - third_party_sys_id, third_party_name, third_party_ticket, third_party_score
        - vendor_id, vendor_name
        """
        # Build assigned_to from first_name + last_name
        assigned_to_parts = []
        if task.get('assigned_to_first_name'):
            assigned_to_parts.append(task.get('assigned_to_first_name'))
        if task.get('assigned_to_last_name'):
            assigned_to_parts.append(task.get('assigned_to_last_name'))
        assigned_to = ' '.join(assigned_to_parts) if assigned_to_parts else None

        return {
            'task_sys_id': task.get('sys_id'),
            'task_number': task.get('number'),
            'task_type': 'cstask',  # Case tasks are "cstask" type
            'parent_case_sys_id': task.get('parent_case_sys_id'),
            'parent_case_number': task.get('parent_case_number'),
            'short_description': task.get('short_description'),
            'state': task.get('state'),
            'priority': self._parse_int(task.get('priority')),
            'service_type': task.get('service_type'),
            'third_party_sys_id': task.get('third_party_sys_id'),
            'third_party_name': task.get('third_party_name'),
            'third_party_ticket': task.get('third_party_ticket'),
            'third_party_score': task.get('third_party_score'),
            'assignment_group': task.get('assignment_group'),
            'assigned_to': assigned_to or task.get('assigned_to'),
            'assigned_to_sys_id': task.get('assigned_to_sys_id'),
            'vendor_id': task.get('vendor_id'),
            'vendor_name': task.get('vendor_name'),
            'created_on': task.get('created_on'),
            'created_by': task.get('created_by'),
            'updated_on': task.get('updated_on'),
            'closed_on': task.get('closed_on'),
            'closed_by': task.get('closed_by'),
            'closed_by_sys_id': task.get('closed_by_sys_id'),
        }

    def _normalize_problem_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize API problem task fields to match ProblemTaskInfo model.

        Maps to DB field names: problem_task_sys_id, problem_task_number,
        problem_task_state, etc.
        """
        assigned_to_parts = []
        if task.get('assigned_to_first_name'):
            assigned_to_parts.append(task.get('assigned_to_first_name'))
        if task.get('assigned_to_last_name'):
            assigned_to_parts.append(task.get('assigned_to_last_name'))
        assigned_to = ' '.join(assigned_to_parts) if assigned_to_parts else None

        return {
            'problem_task_sys_id': task.get('sys_id'),
            'problem_task_number': task.get('number'),
            'problem_sys_id': task.get('problem_sys_id'),
            'problem_number': task.get('problem_number'),
            'problem_task_state': task.get('state'),
            'short_description': task.get('short_description'),
            'description': task.get('description'),
            'priority_number': self._parse_int(task.get('priority')),
            'assigned_to': assigned_to or task.get('assigned_to'),
            'assigned_to_sys_id': task.get('assigned_to_sys_id'),
            'assignment_group': task.get('assignment_group'),
            'created_on': task.get('created_on'),
            'created_by': task.get('created_by'),
            'updated_on': task.get('updated_on'),
            'closed_on': task.get('closed_on'),
            'closed_by': task.get('closed_by'),
            'closed_by_sys_id': task.get('closed_by_sys_id'),
            'started_on': task.get('started_on'),
            'cause_code': task.get('cause_code'),
            'cause_notes': task.get('cause_notes'),
            'close_notes': task.get('close_notes'),
            'is_pending': task.get('is_pending'),
        }

    def _normalize_change_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize API change task fields to match ChangeTaskInfo model.

        Maps to DB field names: task_sys_id, task_number, change_sys_id, etc.
        """
        assigned_to_parts = []
        if task.get('assigned_to_first_name'):
            assigned_to_parts.append(task.get('assigned_to_first_name'))
        if task.get('assigned_to_last_name'):
            assigned_to_parts.append(task.get('assigned_to_last_name'))
        assigned_to = ' '.join(assigned_to_parts) if assigned_to_parts else None

        return {
            'task_sys_id': task.get('sys_id'),
            'task_number': task.get('number'),
            'change_sys_id': task.get('change_sys_id'),
            'change_number': task.get('change_number'),
            'state': task.get('state'),
            'short_description': task.get('short_description'),
            'description': task.get('description'),
            'priority_number': self._parse_int(task.get('priority')),
            'change_category': task.get('change_category') or task.get('category'),
            'change_subcategory': task.get('change_subcategory') or task.get('subcategory'),
            'assigned_to': assigned_to or task.get('assigned_to'),
            'assigned_to_sys_id': task.get('assigned_to_sys_id'),
            'assignment_group': task.get('assignment_group'),
            'created_on': task.get('created_on'),
            'created_by': task.get('created_by'),
            'updated_on': task.get('updated_on'),
            'closed_on': task.get('closed_on'),
            'closed_by': task.get('closed_by'),
            'closed_by_sys_id': task.get('closed_by_sys_id'),
            'close_notes': task.get('close_notes'),
            'close_code': task.get('close_code'),
            'closure_responsibility': task.get('closure_responsibility'),
            'responsible_team': task.get('responsible_team'),
            'fulfillment_y_n': task.get('fulfillment'),
            'follow_up_needed_y_n': task.get('follow_up_needed'),
            'implemented_in_timeframe_y_n': task.get('implemented_in_timeframe'),
            'unexpected_consequences_y_n': task.get('unexpected_consequences'),
        }

    def _parse_int(self, value: Any) -> Optional[int]:
        """Safely parse a value to int"""
        if value is None:
            return None
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            try:
                return int(value)
            except ValueError:
                return None
        return None

    def _build_date_params(self, since: Optional[datetime] = None) -> Dict[str, str]:
        """
        Build date filter parameters for API request.

        Per PDF documentation:
        - from_date: Optional, format YYYY-MM-DD HH:mm:ss
        - to_date: Optional, format YYYY-MM-DD HH:mm:ss
        - If difference > 24 hours, API returns last 24 hours by default

        Args:
            since: Optional start date. If None, uses lookback_hours from config.

        Returns:
            Dict of query parameters
        """
        now = datetime.now()

        if since:
            from_date = since
        else:
            # Use lookback_hours when no specific time is provided
            from_date = now - timedelta(hours=self.lookback_hours)

        # Format as YYYY-MM-DD HH:mm:ss per PDF spec
        params = {
            'from_date': from_date.strftime('%Y-%m-%d %H:%M:%S'),
            'to_date': now.strftime('%Y-%m-%d %H:%M:%S')
        }

        return params

    async def _fetch_json(
        self,
        url: str,
        params: Optional[Dict[str, str]] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch JSON from a URL and parse it.

        Args:
            url: API endpoint URL
            params: Optional query parameters

        Returns:
            Parsed JSON dict on success, None on 404 (no data), raises on other errors
        """
        session = await self._get_session()
        semaphore = await self._get_semaphore()

        async with semaphore:
            try:
                async with session.get(url, params=params) as response:
                    if response.status == 200:
                        return await response.json()
                    elif response.status == 404:
                        logger.debug(f"No data found at {url}")
                        return None
                    else:
                        error_text = await response.text()
                        logger.warning(f"HTTP {response.status} from {url}: {error_text[:200]}")
                        raise aiohttp.ClientResponseError(
                            response.request_info,
                            response.history,
                            status=response.status,
                            message=f"HTTP {response.status}"
                        )
            except asyncio.TimeoutError:
                logger.error(f"Timeout fetching {url}")
                return None
            except aiohttp.ClientError as e:
                logger.error(f"HTTP error fetching {url}: {e}")
                return None

    def _parse_records(
        self,
        json_response: Dict[str, Any],
        record_type: str
    ) -> List[Dict[str, Any]]:
        """
        Parse JSON response into list of record dicts.

        Per PDF, the response structure is:
        {
            "result": {
                "data": [
                    [
                        { ...record1... },
                        { ...record2... }
                    ]
                ]
            }
        }

        Note: data is an array of arrays (double nested)

        Args:
            json_response: Parsed JSON response
            record_type: Type hint for logging

        Returns:
            List of record dicts
        """
        records = []

        if not json_response:
            return records

        # Navigate to result.data
        result = json_response.get('result', {})
        data = result.get('data', [])

        # Data is an array of arrays per PDF examples
        for data_array in data:
            if isinstance(data_array, list):
                for record in data_array:
                    if isinstance(record, dict):
                        records.append(record)
            elif isinstance(data_array, dict):
                # Sometimes it might be a single record
                records.append(data_array)

        logger.debug(f"Parsed {len(records)} {record_type} records")
        return records

    def _enrich_with_client(
        self,
        records: List[Dict[str, Any]],
        clients: Dict[str, Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Enrich records with client data from Client API (customer endpoint).

        Maps API "customer" to our "client" terminology for consistency.

        Args:
            records: List of incident or case records
            clients: Dict of client records indexed by sys_id

        Returns:
            Records with client fields populated
        """
        # Debug: Log sample client structure if we have data
        if clients:
            sample_sys_id = next(iter(clients))
            sample_client = clients[sample_sys_id]
            logger.debug(f"Sample client keys: {list(sample_client.keys())}")
            logger.debug(f"Sample client data: {sample_client}")

        enriched_count = 0
        no_match_count = 0
        no_client_id_count = 0

        for record in records:
            # API returns customer_sys_id - map to client_sys_id internally
            client_sys_id = record.get('customer_sys_id')

            if client_sys_id and client_sys_id in clients:
                client = clients[client_sys_id]

                # Per PDF documentation (page 37-38), Client API returns:
                # "id" - CMD numeric id for the customer (our client_id)
                client_id = client.get('id')

                if client_id:
                    record['client_id'] = client_id
                    enriched_count += 1
                else:
                    if no_client_id_count == 0:
                        logger.warning(
                            f"Client {client_sys_id} has no 'id' field. "
                            f"Available fields: {list(client.keys())}"
                        )
                    no_client_id_count += 1

                # Map Client API fields to our client terminology
                # Per PDF: name, group, segment, division, default_noc_queue, etc.
                record['client_name'] = client.get('name') or record.get('customer')
                record['client_group'] = client.get('group')
                record['market_segment'] = client.get('segment')
                record['sales_division'] = client.get('division')
                record['default_noc_queue'] = client.get('default_noc_queue')
                record['incident_manager'] = client.get('incident_manager')
                record['service_manager'] = client.get('service_manager')
                # NEW fields from API (not in DB)
                record['operations_specialist'] = client.get('operations_specialist')
                record['operations_specialist_sys_id'] = client.get('operations_specialist_sys_id')
            else:
                no_match_count += 1
                # If no client lookup, preserve name from incident/case
                if not record.get('client_name'):
                    record['client_name'] = record.get('customer')

        logger.info(
            f"Client enrichment: {enriched_count} enriched, "
            f"{no_match_count} no match, {no_client_id_count} missing client_id"
        )

        return records

    def _normalize_incident(self, inc: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize API incident field names to match DB extractor format.

        Based on actual API response structure from PDF:
        - sys_id, number, category, subcategory
        - configuration_item_sys_id, configuration_item, configuration_item_id
        - service_type, customer_ticket, customer_sys_id, customer
        - description, short_description, channel
        - state_id, state, impact, urgency, priority
        - assignment_group_sys_id, assignment_group
        - assigned_to_sys_id, assigned_to_first_name, assigned_to_last_name, assigned_to_email
        - resolution_notes, internal_resolution_notes
        - business_elapsed_minutes, actual_elapsed_minutes (MTTR strings like "51 Days 20 Hours 8 Minutes")
        - opened, updated_on, actual_start_date, actual_end_date, due_date, actual_end
        - closed_at, closed_by, created_by, created_on
        - closure_code, closure_responsibility, cpe_closure_code, pi_close_code
        - escalation_level, on_hold_reason, resolved_by
        """
        # Build assigned_to from first_name + last_name
        assigned_to_parts = []
        if inc.get('assigned_to_first_name'):
            assigned_to_parts.append(inc.get('assigned_to_first_name'))
        if inc.get('assigned_to_last_name'):
            assigned_to_parts.append(inc.get('assigned_to_last_name'))
        assigned_to = ' '.join(assigned_to_parts) if assigned_to_parts else None

        normalized = {
            # Primary keys
            'incident_sys_id': inc.get('sys_id'),
            'incident_number': inc.get('number'),
            # State
            'incident_state': inc.get('state'),
            'state_id': inc.get('state_id'),
            'short_description': inc.get('short_description'),
            'description': inc.get('description'),
            'fault_description': inc.get('description'),  # Alias for transformer compatibility
            # Category
            'category': inc.get('category'),
            'subcategory': inc.get('subcategory'),
            # Configuration Item
            'ci_sys_id': inc.get('configuration_item_sys_id'),
            'ci_name': inc.get('configuration_item'),
            'circuit_id': inc.get('configuration_item_id'),
            'service_type': inc.get('service_type'),
            # Priority / Impact / Urgency
            'priority': inc.get('priority'),
            'priority_number': inc.get('priority'),  # Alias for transformer compatibility
            'impact': inc.get('impact'),
            'urgency': inc.get('urgency'),
            'escalation_level': inc.get('escalation_level'),
            # Assignment
            'assignment_group': inc.get('assignment_group'),
            'assignment_group_sys_id': inc.get('assignment_group_sys_id'),
            'assigned_to': assigned_to,
            'assigned_to_sys_id': inc.get('assigned_to_sys_id'),
            'assigned_to_email': inc.get('assigned_to_email'),
            # Customer
            'customer_sys_id': inc.get('customer_sys_id'),
            'customer_name': inc.get('customer'),
            'client_id': inc.get('client_id'),  # Populated by _enrich_with_client
            'client_name': inc.get('client_name') or inc.get('customer'),
            'customer_ticket': inc.get('customer_ticket'),
            # Lifecycle dates
            'opened': inc.get('opened'),
            'created_on': inc.get('created_on'),
            'created_by': inc.get('created_by'),
            'updated_on': inc.get('updated_on'),
            'closed_at': inc.get('closed_at'),
            'closed_by': inc.get('closed_by'),
            'resolved_by': inc.get('resolved_by'),
            'due_date': inc.get('due_date'),
            'actual_start_date': inc.get('actual_start_date'),
            'actual_end_date': inc.get('actual_end_date'),
            'actual_end': inc.get('actual_end'),
            # Resolution
            'resolution_notes': inc.get('resolution_notes'),
            'internal_resolution_notes': inc.get('internal_resolution_notes'),
            'closure_code': inc.get('closure_code'),
            'closure_responsibility': inc.get('closure_responsibility'),
            'cpe_closure_code': inc.get('cpe_closure_code'),
            'pi_close_code': inc.get('pi_close_code'),
            # MTTR - Incident uses business_elapsed_minutes (string like "51 Days 20 Hours 8 Minutes")
            'business_elapsed_minutes': inc.get('business_elapsed_minutes'),
            'actual_elapsed_minutes': inc.get('actual_elapsed_minutes'),
            # Parsed MTTR in minutes for OutageInfo (when no CMD data)
            'mttr': parse_business_elapsed_to_minutes(inc.get('business_elapsed_minutes')),
            # Other
            'channel': inc.get('channel'),
            'on_hold_reason': inc.get('on_hold_reason'),
        }

        # Keep original fields that don't need mapping
        for key, value in inc.items():
            if key not in normalized:
                normalized[key] = value

        return normalized

    def _normalize_case(self, case: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize API case field names to match DB extractor format.

        Based on actual API response structure from PDF:
        - sys_id, number, category_id, category, subcategory_id, subcategory
        - configuration_item_sys_id, configuration_item, configuration_item_id
        - service_type, customer_ticket, customer_sys_id, customer
        - description, short_description, channel
        - state_id, state, impact, urgency, priority, escalation_level
        - assignment_group_sys_id, assignment_group
        - assigned_to_sys_id, assigned_to_first_name, assigned_to_last_name, assigned_to_email
        - created_by, resolution_notes, internal_resolution_notes
        - opened, business_elapsed, actual_elapsed (NO "_minutes" suffix for Case!)
        - actual_start, actual_end, due_date, updated_on, created_on
        - resolved_on, closed_on, assigned_on
        - responsible_party, resolution_code
        - incident_number, incidentsys_id (related incident)
        - problem_number, problem_sys_id, parent_number, parent_sys_id
        - change_request_number, change_request_sys_id
        """
        # Build assigned_to from first_name + last_name
        assigned_to_parts = []
        if case.get('assigned_to_first_name'):
            assigned_to_parts.append(case.get('assigned_to_first_name'))
        if case.get('assigned_to_last_name'):
            assigned_to_parts.append(case.get('assigned_to_last_name'))
        assigned_to = ' '.join(assigned_to_parts) if assigned_to_parts else None

        normalized = {
            # Primary keys
            'case_sys_id': case.get('sys_id'),
            'case_number': case.get('number'),
            # State
            'case_state': case.get('state'),
            'state_id': case.get('state_id'),
            'short_description': case.get('short_description'),
            'description': case.get('description'),
            'fault_description': case.get('description'),  # Alias for transformer compatibility
            # Category
            'category_id': case.get('category_id'),
            'category': case.get('category'),
            'subcategory_id': case.get('subcategory_id'),
            'subcategory': case.get('subcategory'),
            # Configuration Item
            'ci_sys_id': case.get('configuration_item_sys_id'),
            'ci_name': case.get('configuration_item'),
            'circuit_id': case.get('configuration_item_id'),
            'service_type': case.get('service_type'),
            # Priority / Impact / Urgency
            'priority': case.get('priority'),
            'priority_number': case.get('priority'),  # Alias for transformer compatibility
            'impact': case.get('impact'),
            'urgency': case.get('urgency'),
            'escalation_level': case.get('escalation_level'),
            # Assignment
            'assignment_group': case.get('assignment_group'),
            'assignment_group_sys_id': case.get('assignment_group_sys_id'),
            'assigned_to': assigned_to,
            'assigned_to_sys_id': case.get('assigned_to_sys_id'),
            'assigned_to_email': case.get('assigned_to_email'),
            # Customer
            'customer_sys_id': case.get('customer_sys_id'),
            'customer_name': case.get('customer'),
            'client_id': case.get('client_id'),  # Populated by _enrich_with_client
            'client_name': case.get('client_name') or case.get('customer'),
            'customer_ticket': case.get('customer_ticket'),
            # Lifecycle dates (Case uses resolved_on, closed_on - NOT closed_at)
            'opened': case.get('opened'),
            'created_on': case.get('created_on'),
            'created_by': case.get('created_by'),
            'updated_on': case.get('updated_on'),
            'resolved_on': case.get('resolved_on'),
            'closed_on': case.get('closed_on'),
            'assigned_on': case.get('assigned_on'),
            'due_date': case.get('due_date'),
            'actual_start': case.get('actual_start'),
            'actual_end': case.get('actual_end'),
            # Related records
            'incident_sys_id': case.get('incidentsys_id'),  # Note: API uses "incidentsys_id" (no underscore)
            'incident_number': case.get('incident_number'),
            'problem_sys_id': case.get('problem_sys_id'),
            'problem_number': case.get('problem_number'),
            'parent_sys_id': case.get('parent_sys_id'),
            'parent_number': case.get('parent_number'),
            'change_request_sys_id': case.get('change_request_sys_id'),
            'change_request_number': case.get('change_request_number'),
            # Resolution
            'resolution_notes': case.get('resolution_notes'),
            'internal_resolution_notes': case.get('internal_resolution_notes'),
            'resolution_code': case.get('resolution_code'),
            'responsible_party': case.get('responsible_party'),
            # MTTR - Case uses business_elapsed (NO "_minutes" suffix, unlike Incident)
            'business_elapsed': case.get('business_elapsed'),
            'actual_elapsed': case.get('actual_elapsed'),
            # Parsed MTTR in minutes for OutageInfo (when no CMD data)
            'mttr': parse_business_elapsed_to_minutes(case.get('business_elapsed')),
            # Other
            'channel': case.get('channel'),
        }

        # Keep original fields that don't need mapping
        for key, value in case.items():
            if key not in normalized:
                normalized[key] = value

        return normalized

    def _normalize_problem(self, prob: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize API problem field names to match DB extractor format.

        Maps API fields to: problem_sys_id, problem_number, problem_state, etc.
        """
        assigned_to_parts = []
        if prob.get('assigned_to_first_name'):
            assigned_to_parts.append(prob.get('assigned_to_first_name'))
        if prob.get('assigned_to_last_name'):
            assigned_to_parts.append(prob.get('assigned_to_last_name'))
        assigned_to = ' '.join(assigned_to_parts) if assigned_to_parts else None

        normalized = {
            # Primary keys
            'problem_sys_id': prob.get('sys_id'),
            'problem_number': prob.get('number'),
            # State
            'problem_state': prob.get('state'),
            'short_description': prob.get('short_description'),
            'description': prob.get('description'),
            'fault_description': prob.get('description'),
            # Category
            'category': prob.get('category'),
            'subcategory': prob.get('subcategory'),
            # Configuration Item
            'ci_sys_id': prob.get('configuration_item_sys_id'),
            'ci_name': prob.get('configuration_item'),
            'ci_class': prob.get('ci_class') or prob.get('configuration_item_class'),
            'circuit_id': prob.get('configuration_item_id'),
            'segment_id': prob.get('segment_id'),
            # Priority
            'priority': prob.get('priority'),
            'priority_number': prob.get('priority'),
            # Assignment
            'assignment_group': prob.get('assignment_group'),
            'assigned_to': assigned_to,
            'assigned_to_sys_id': prob.get('assigned_to_sys_id'),
            # Customer
            'customer_sys_id': prob.get('customer_sys_id'),
            'customer_name': prob.get('customer') or prob.get('customer_name'),
            'client_id': prob.get('client_id'),
            'client_name': prob.get('client_name') or prob.get('customer'),
            'customer_group': prob.get('customer_group'),
            # Problem-specific
            'problem_source': prob.get('problem_source'),
            'problem_type': prob.get('problem_type'),
            'problem_duration': prob.get('problem_duration'),
            'problem_duration_minutes': self._parse_int(prob.get('problem_duration_minutes')),
            'is_on_hold': prob.get('is_on_hold'),
            'on_hold_reason': prob.get('on_hold_reason'),
            'resolution_code': prob.get('resolution_code'),
            'responsible_party': prob.get('responsible_party'),
            'fix_notes': prob.get('fix_notes'),
            'internal_fix_notes': prob.get('internal_fix_notes'),
            'is_customer_visible': prob.get('is_customer_visible'),
            'first_reported_by_task_sys_id': prob.get('first_reported_by_task_sys_id'),
            'first_reported_by_task_number': prob.get('first_reported_by_task_number'),
            # Lifecycle dates
            'created_on': prob.get('created_on'),
            'created_by': prob.get('created_by'),
            'updated_on': prob.get('updated_on'),
            'closed_on': prob.get('closed_on'),
            'closed_by': prob.get('closed_by'),
            'closed_by_sys_id': prob.get('closed_by_sys_id'),
            'fixed_on': prob.get('fixed_on'),
            'due_date': prob.get('due_date'),
            # Other
            'is_worked_ticket': prob.get('is_worked_ticket'),
            'time_worked_minutes': self._parse_int(prob.get('time_worked_minutes')),
            'customer_ticket_reference': prob.get('customer_ticket_reference'),
        }

        for key, value in prob.items():
            if key not in normalized:
                normalized[key] = value

        return normalized

    def _normalize_change(self, chg: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize API change request field names to match DB extractor format.

        Changes are infrastructure-level records (no client_id).
        Maps API fields to: change_sys_id, change_number, change_state, etc.
        """
        assigned_to_parts = []
        if chg.get('assigned_to_first_name'):
            assigned_to_parts.append(chg.get('assigned_to_first_name'))
        if chg.get('assigned_to_last_name'):
            assigned_to_parts.append(chg.get('assigned_to_last_name'))
        assigned_to = ' '.join(assigned_to_parts) if assigned_to_parts else None

        normalized = {
            # Primary keys
            'change_sys_id': chg.get('sys_id'),
            'change_number': chg.get('number'),
            # State
            'change_state': chg.get('state'),
            'short_description': chg.get('short_description'),
            'description': chg.get('description'),
            # Category
            'category': chg.get('category'),
            'subcategory': chg.get('subcategory'),
            'reason': chg.get('reason'),
            # Change-specific type fields
            'change_type': chg.get('change_type') or chg.get('type'),
            'work_type': chg.get('work_type'),
            'source': chg.get('source'),
            # Planned work
            'planned_start_date': chg.get('planned_start_date'),
            'planned_end_date': chg.get('planned_end_date'),
            'backup_start_date': chg.get('backup_start_date'),
            'backup_end_date': chg.get('backup_end_date'),
            'second_backup_start_date': chg.get('second_backup_start_date'),
            'second_backup_end_date': chg.get('second_backup_end_date'),
            'impact_duration': chg.get('impact_duration'),
            'impact_duration_minutes': self._parse_int(chg.get('impact_duration_minutes')),
            # Plans
            'implementation_plan': chg.get('implementation_plan'),
            'backout_plan': chg.get('backout_plan'),
            'test_plan': chg.get('test_plan'),
            'risk_impact_analysis': chg.get('risk_impact_analysis'),
            'justification': chg.get('justification'),
            # Location
            'country': chg.get('country'),
            'city': chg.get('city'),
            'planned_work_location': chg.get('planned_work_location'),
            'planned_work_reason': chg.get('planned_work_reason'),
            # Risk flags
            'risk': chg.get('risk'),
            'security_risk_y_n': chg.get('security_risk'),
            'modification_of_access_y_n': chg.get('modification_of_access'),
            'modification_of_cryptographic_y_n': chg.get('modification_of_cryptographic'),
            'core_nwk_y_n': chg.get('core_network'),
            'critical_systems_y_n': chg.get('critical_systems'),
            # CAB
            'cab_date_time': chg.get('cab_date_time'),
            'is_cab_required': chg.get('is_cab_required'),
            'is_postponed': chg.get('is_postponed'),
            # Supplier
            'supplier_sys_id': chg.get('supplier_sys_id'),
            'supplier_name': chg.get('supplier_name'),
            'supplier_reference': chg.get('supplier_reference'),
            'vendor_id': chg.get('vendor_id'),
            # Implementation
            'implemented_by_sys_ids': chg.get('implemented_by_sys_ids'),
            'implemented_by_names': chg.get('implemented_by_names'),
            'requested_by_sys_id': chg.get('requested_by_sys_id'),
            'requested_by': chg.get('requested_by'),
            'requested_by_date': chg.get('requested_by_date'),
            # Assignment
            'assignment_group': chg.get('assignment_group'),
            'assignment_group_sys_id': chg.get('assignment_group_sys_id'),
            'assigned_to': assigned_to,
            'assigned_to_sys_id': chg.get('assigned_to_sys_id'),
            # Lifecycle
            'created_on': chg.get('created_on'),
            'created_by': chg.get('created_by'),
            'updated_on': chg.get('updated_on'),
            'closed_on': chg.get('closed_on'),
            'closed_by': chg.get('closed_by'),
            'closed_by_sys_id': chg.get('closed_by_sys_id'),
            'close_code': chg.get('close_code'),
            'close_notes': chg.get('close_notes'),
            # Blackout / notifications
            'is_inside_blackout_schedule': chg.get('is_inside_blackout_schedule'),
            'is_suppress_client_notifications': chg.get('is_suppress_client_notifications'),
            # Work tracking
            'time_worked_minutes': self._parse_int(chg.get('time_worked_minutes')),
            'support_area': chg.get('support_area'),
            'contact_type': chg.get('contact_type'),
            'impacted_services_count': self._parse_int(chg.get('impacted_services_count')),
        }

        for key, value in chg.items():
            if key not in normalized:
                normalized[key] = value

        return normalized

    def _normalize_service_request(self, req: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize API service request field names to match DB extractor format.

        SCTASK is the ticket. REQ, RITM, and Case are reference metadata.
        Maps API fields to: req_task_sys_id, req_task_number, req_task_state, etc.
        """
        assigned_to_parts = []
        if req.get('assigned_to_first_name'):
            assigned_to_parts.append(req.get('assigned_to_first_name'))
        if req.get('assigned_to_last_name'):
            assigned_to_parts.append(req.get('assigned_to_last_name'))
        assigned_to = ' '.join(assigned_to_parts) if assigned_to_parts else None

        normalized = {
            # Primary keys (SCTASK is the ticket)
            'req_task_sys_id': req.get('sys_id'),
            'req_task_number': req.get('number'),
            # State
            'req_task_state': req.get('state'),
            'short_description': req.get('short_description'),
            'description': req.get('description'),
            'fault_description': req.get('description'),
            # Parent references
            'req_sys_id': req.get('req_sys_id') or req.get('request_sys_id'),
            'req_number': req.get('req_number') or req.get('request_number'),
            'req_item_sys_id': req.get('req_item_sys_id') or req.get('request_item_sys_id'),
            'req_item_number': req.get('req_item_number') or req.get('request_item_number'),
            'case_sys_id': req.get('case_sys_id'),
            'case_number': req.get('case_number'),
            # Request item details
            'request_item_name': req.get('request_item_name'),
            'request_item_form': req.get('request_item_form'),
            'request_item_type': req.get('request_item_type'),
            # Priority
            'priority': req.get('priority'),
            'priority_number': req.get('priority'),
            # Configuration Item
            'ci_sys_id': req.get('configuration_item_sys_id'),
            'ci_name': req.get('configuration_item'),
            'ci_class': req.get('configuration_item_class') or req.get('ci_class'),
            'circuit_id': req.get('configuration_item_id'),
            'segment_id': req.get('segment_id'),
            # Assignment
            'assignment_group': req.get('assignment_group'),
            'assigned_to': assigned_to,
            'assigned_to_sys_id': req.get('assigned_to_sys_id'),
            # Customer
            'customer_sys_id': req.get('customer_sys_id'),
            'customer_name': req.get('customer') or req.get('customer_name'),
            'client_id': req.get('client_id'),
            'client_name': req.get('client_name') or req.get('customer'),
            'customer_group': req.get('customer_group'),
            'customer_ticket_reference': req.get('customer_ticket_reference'),
            # Lifecycle
            'created_on': req.get('created_on'),
            'created_by': req.get('created_by'),
            'updated_on': req.get('updated_on'),
            'closed_on': req.get('closed_on'),
            'closed_by': req.get('closed_by'),
            'closed_by_sys_id': req.get('closed_by_sys_id'),
            'due_date': req.get('due_date'),
            'actual_work_start': req.get('actual_work_start'),
            'actual_work_end': req.get('actual_work_end'),
            # Resolution
            'resolution_code': req.get('resolution_code'),
            'responsible_party': req.get('responsible_party'),
            'close_notes': req.get('close_notes'),
            'internal_close_notes': req.get('internal_close_notes'),
            # Other
            'channel': req.get('channel'),
            'is_worked_ticket': req.get('is_worked_ticket'),
            'time_worked_minutes': self._parse_int(req.get('time_worked_minutes')),
            'service_type': req.get('service_type'),
        }

        for key, value in req.items():
            if key not in normalized:
                normalized[key] = value

        return normalized

    def _get_ref_value(self, ref: Any) -> Optional[str]:
        """Extract value from a reference field (dict with value/display_value)"""
        if isinstance(ref, dict):
            return ref.get('value')
        return None

    def _get_ref_display(self, ref: Any) -> Optional[str]:
        """Extract display_value from a reference field"""
        if isinstance(ref, dict):
            return ref.get('display_value')
        return None

    def _extract_client_sys_id(self, record: Dict[str, Any]) -> Optional[str]:
        """
        Extract client sys_id from a record.

        API uses 'customer_sys_id' field - we map to client internally.
        Example: "customer_sys_id": "e53f16f47b9752503c39fc28a83f9eb9"

        Args:
            record: Incident or case record from API

        Returns:
            Client sys_id if found and valid, None otherwise
        """
        # API uses 'customer_sys_id' - we map to client
        client_sys_id = record.get('customer_sys_id')
        if self._is_valid_sys_id(client_sys_id):
            return client_sys_id

        # Fallback fields
        for field in ['account_sys_id', 'company_sys_id']:
            value = record.get(field)
            if self._is_valid_sys_id(value):
                return value

        return None

    def _is_valid_sys_id(self, value: Any) -> bool:
        """
        Check if a value looks like a valid ServiceNow sys_id.

        sys_ids are 32-character hexadecimal strings.
        """
        if not isinstance(value, str):
            return False
        if len(value) != 32:
            return False
        try:
            int(value, 16)  # Try parsing as hex
            return True
        except ValueError:
            return False


# =============================================================================
# Factory function for creating extractor from config
# =============================================================================

def create_api_extractor_from_config(config) -> ServiceNowAPIExtractor:
    """
    Create ServiceNowAPIExtractor from Config object.

    Args:
        config: Config object with ServiceNow API settings

    Returns:
        Configured ServiceNowAPIExtractor instance
    """
    return ServiceNowAPIExtractor(
        base_url=config.get_servicenow_base_url(),
        username=config.get_servicenow_username(),
        password=config.get_servicenow_password(),
        timeout=config.get_servicenow_timeout(),
        max_concurrent=config.get_servicenow_max_concurrent(),
        lookback_hours=config.get_api_lookback_hours(),
        client_id=config.get_servicenow_client_id(),
        client_secret=config.get_servicenow_client_secret(),
    )
