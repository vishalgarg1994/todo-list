import asyncio
import logging
import nats

# from app.configs.config import Config
from configs.config import Config

# Load configurations dynamically
config = Config()


class NatsJetStreamManager:
    """Manages NATS JetStream operations including setup, subscriptions, and message handling."""

    def __init__(self, max_stream_retries: int = 30, initial_backoff: float = 2.0, max_backoff: float = 60.0):
        self.nc = None
        self.js = None
        self.max_stream_retries = max_stream_retries
        self.initial_backoff = initial_backoff
        self.max_backoff = max_backoff

    async def connect(self):
        """Establish connection to NATS and JetStream."""
        while True:
            try:
                if config.nats_user and config.nats_password:
                    self.nc = await nats.connect(config.nats_url, user=config.nats_user, password=config.nats_password)
                else:
                    self.nc = await nats.connect(config.nats_url)
                self.js = self.nc.jetstream()
                logging.info(f"✅ Connected to NATS at {config.nats_url}")

                await self.wait_for_stream()
                return
            except Exception as e:
                logging.warning(f"⚠️ NATS connection failed: {e}. Retrying in 5 seconds...")
                await asyncio.sleep(5)

    async def wait_for_stream(self):
        """
        Wait for JetStream stream to become available.
        Stream creation is the responsibility of messaging-infrastructure.
        Retries with exponential backoff until stream is available.
        """
        stream_name = config.jetstream_stream_name
        backoff = self.initial_backoff

        logging.info(f"Waiting for stream '{stream_name}' to become available...")

        for attempt in range(1, self.max_stream_retries + 1):
            try:
                stream_info = await self.js.stream_info(stream_name)
                logging.info(
                    f"✅ Stream '{stream_name}' is available with {stream_info.state.messages} messages"
                )
                return
            except Exception as e:
                if "stream not found" in str(e).lower() or "not found" in str(e).lower():
                    if attempt < self.max_stream_retries:
                        logging.warning(
                            f"⏳ Attempt {attempt}/{self.max_stream_retries}: Stream '{stream_name}' not found. "
                            f"Retrying in {backoff:.1f}s..."
                        )
                        await asyncio.sleep(backoff)
                        backoff = min(backoff * 2, self.max_backoff)
                    else:
                        logging.error(
                            f"❌ Stream '{stream_name}' not available after {self.max_stream_retries} attempts. "
                            f"Ensure messaging-infrastructure is running and has created the stream."
                        )
                        raise RuntimeError(f"Stream '{stream_name}' not available")
                else:
                    logging.error(f"❌ Error checking stream '{stream_name}': {e}")
                    raise

    async def subscribe(self, message_handler):
        """Subscribe to JetStream and forward messages to `message_handler`."""

        logging.info("🚀 Debug: Inside `subscribe()` from nats_js.py")

        try:
            await self.connect()  # Ensure connection is established
            logging.info(f"🚀 Debug: Registering message_handler = {message_handler}")
            sub = await self.js.subscribe(config.ticket_subscribe_subject, cb=message_handler)
            logging.info(f"✅ Subscribed to NATS topic: {config.ticket_subscribe_subject}")
            return sub
        except Exception as e:
            logging.error(f"❌ Subscription error: {e}", exc_info=True)

    async def shutdown(self):
        """Cleanly shuts down the NATS connection."""
        try:
            if self.nc and not self.nc.is_closed:
                await self.nc.close()
                logging.info("🔌 NATS connection closed.")
        except Exception as e:
            logging.error(f"❌ Error during NATS shutdown: {e}")
