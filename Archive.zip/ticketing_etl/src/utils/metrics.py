"""
Basic metrics infrastructure for monitoring application performance.
Note: Prometheus client would be added to requirements.txt for full implementation.
"""

import time
import logging
from typing import Dict, Any
from collections import defaultdict, deque


class InMemoryMetrics:
    """In-memory metrics store for basic monitoring until Prometheus is added"""

    def __init__(self):
        self.counters = defaultdict(int)
        self.histograms = defaultdict(
            lambda: deque(maxlen=1000)
        )  # Keep last 1000 measurements
        self.gauges = {}
        self.logger = logging.getLogger(__name__)

    def increment_counter(
        self, name: str, labels: Dict[str, str] = None, value: int = 1
    ):
        """Increment a counter metric"""
        key = self._build_key(name, labels)
        self.counters[key] += value

    def record_histogram(self, name: str, value: float, labels: Dict[str, str] = None):
        """Record a histogram value"""
        key = self._build_key(name, labels)
        self.histograms[key].append({"value": value, "timestamp": time.time()})

    def set_gauge(self, name: str, value: float, labels: Dict[str, str] = None):
        """Set a gauge value"""
        key = self._build_key(name, labels)
        self.gauges[key] = value

    def _build_key(self, name: str, labels: Dict[str, str] = None) -> str:
        """Build metric key from name and labels"""
        if not labels:
            return name
        label_str = ",".join(f"{k}={v}" for k, v in sorted(labels.items()))
        return f"{name}{{{label_str}}}"

    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get a summary of all metrics"""
        return {
            "counters": dict(self.counters),
            "gauges": dict(self.gauges),
            "histogram_counts": {k: len(v) for k, v in self.histograms.items()},
        }


# Global metrics instance
metrics = InMemoryMetrics()


class MetricsTimer:
    """Context manager for timing operations"""

    def __init__(self, metric_name: str, labels: Dict[str, str] = None):
        self.metric_name = metric_name
        self.labels = labels or {}
        self.start_time = None

    def __enter__(self):
        self.start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.start_time:
            duration = time.time() - self.start_time
            metrics.record_histogram(self.metric_name, duration, self.labels)


# Pre-defined metrics for common operations
def record_processing_time(table_name: str, duration: float):
    """Record processing time for a table"""
    metrics.record_histogram(
        "processing_duration_seconds", duration, {"table": table_name}
    )


def increment_records_processed(table_name: str, status: str, count: int = 1):
    """Record processed records count"""
    metrics.increment_counter(
        "records_processed_total", {"table": table_name, "status": status}, count
    )


def increment_messages_published(topic: str, status: str, count: int = 1):
    """Record published messages count"""
    metrics.increment_counter(
        "messages_published_total", {"topic": topic, "status": status}, count
    )


def set_connection_pool_usage(active_connections: int):
    """Record database connection pool usage"""
    metrics.set_gauge("database_connections_active", active_connections)


def increment_errors(error_type: str, component: str):
    """Record error occurrences"""
    metrics.increment_counter(
        "errors_total", {"type": error_type, "component": component}
    )


# Usage example for processing pipeline:
def log_metrics_summary():
    """Log current metrics summary"""
    summary = metrics.get_metrics_summary()
    logger = logging.getLogger(__name__)
    logger.info("Metrics summary", extra={"metrics": summary})
