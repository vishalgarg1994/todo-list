import logging
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from enum import Enum
from utils.correlation import get_correlation_id


class QualityIssueLevel(str, Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class QualityMetric:
    name: str
    value: Any
    expected_range: Optional[tuple] = None
    threshold_warning: Optional[float] = None
    threshold_error: Optional[float] = None
    higher_is_better: bool = False  # True for success rates, False for failure rates
    description: Optional[str] = None


@dataclass
class QualityIssue:
    level: QualityIssueLevel
    metric_name: str
    message: str
    actual_value: Any
    expected_value: Any = None
    table_name: Optional[str] = None
    timestamp: datetime = None
    correlation_id: Optional[str] = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now(timezone.utc)
        if self.correlation_id is None:
            self.correlation_id = get_correlation_id()


@dataclass
class QualityReport:
    table_name: str
    processing_start: datetime
    processing_end: datetime
    total_records: int
    processed_records: int
    failed_records: int
    quality_score: float  # 0.0 to 1.0
    metrics: Dict[str, QualityMetric]
    issues: List[QualityIssue]
    correlation_id: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "table_name": self.table_name,
            "processing_start": self.processing_start.isoformat(),
            "processing_end": self.processing_end.isoformat(),
            "duration_seconds": (
                self.processing_end - self.processing_start
            ).total_seconds(),
            "total_records": self.total_records,
            "processed_records": self.processed_records,
            "failed_records": self.failed_records,
            "success_rate": self.processed_records / self.total_records
            if self.total_records > 0
            else 0,
            "quality_score": self.quality_score,
            "metrics": {
                name: {
                    "name": metric.name,
                    "value": metric.value,
                    "expected_range": metric.expected_range,
                    "threshold_warning": metric.threshold_warning,
                    "threshold_error": metric.threshold_error,
                    "description": metric.description,
                }
                for name, metric in self.metrics.items()
            },
            "issues": [
                {
                    "level": issue.level.value,
                    "metric_name": issue.metric_name,
                    "message": issue.message,
                    "actual_value": issue.actual_value,
                    "expected_value": issue.expected_value,
                    "timestamp": issue.timestamp.isoformat(),
                    "correlation_id": issue.correlation_id,
                }
                for issue in self.issues
            ],
            "correlation_id": self.correlation_id,
        }


class DataQualityMonitor:
    """Monitor data quality throughout the ETL pipeline"""

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.quality_reports: List[QualityReport] = []
        self.max_reports_retention = 100  # Keep last 100 reports

    def start_monitoring(self, table_name: str) -> "QualitySession":
        """Start a new quality monitoring session for a table"""
        correlation_id = get_correlation_id()
        self.logger.info(
            f"Starting data quality monitoring for {table_name}",
            extra={"correlation_id": correlation_id},
        )
        return QualitySession(table_name, self, correlation_id)

    def record_quality_report(self, report: QualityReport):
        """Record a completed quality report"""
        self.quality_reports.append(report)

        # Maintain retention limit
        if len(self.quality_reports) > self.max_reports_retention:
            self.quality_reports = self.quality_reports[-self.max_reports_retention :]

        # Log quality issues
        for issue in report.issues:
            if issue.level == QualityIssueLevel.CRITICAL:
                self.logger.error(
                    f"Critical data quality issue: {issue.message}",
                    extra={"correlation_id": issue.correlation_id},
                )
            elif issue.level == QualityIssueLevel.ERROR:
                self.logger.error(
                    f"Data quality error: {issue.message}",
                    extra={"correlation_id": issue.correlation_id},
                )
            elif issue.level == QualityIssueLevel.WARNING:
                self.logger.warning(
                    f"Data quality warning: {issue.message}",
                    extra={"correlation_id": issue.correlation_id},
                )

        # Log overall quality score
        if report.quality_score < 0.8:
            self.logger.error(
                f"Low data quality score for {report.table_name}: {report.quality_score:.2%}",
                extra={"correlation_id": report.correlation_id},
            )
        elif report.quality_score < 0.95:
            self.logger.warning(
                f"Moderate data quality score for {report.table_name}: {report.quality_score:.2%}",
                extra={"correlation_id": report.correlation_id},
            )
        else:
            self.logger.info(
                f"Good data quality score for {report.table_name}: {report.quality_score:.2%}",
                extra={"correlation_id": report.correlation_id},
            )

    def get_recent_reports(self, limit: int = 10) -> List[QualityReport]:
        """Get recent quality reports"""
        return self.quality_reports[-limit:] if self.quality_reports else []

    def get_quality_metrics(self) -> Dict[str, Any]:
        """Get aggregated quality metrics for monitoring"""
        if not self.quality_reports:
            return {
                "total_reports": 0,
                "average_quality_score": 0.0,
                "critical_issues": 0,
                "error_issues": 0,
                "warning_issues": 0,
            }

        recent_reports = self.get_recent_reports(20)  # Last 20 reports

        total_issues_by_level = {level: 0 for level in QualityIssueLevel}
        total_quality_score = 0

        for report in recent_reports:
            total_quality_score += report.quality_score
            for issue in report.issues:
                total_issues_by_level[issue.level] += 1

        return {
            "total_reports": len(self.quality_reports),
            "recent_reports": len(recent_reports),
            "average_quality_score": total_quality_score / len(recent_reports)
            if recent_reports
            else 0.0,
            "critical_issues": total_issues_by_level[QualityIssueLevel.CRITICAL],
            "error_issues": total_issues_by_level[QualityIssueLevel.ERROR],
            "warning_issues": total_issues_by_level[QualityIssueLevel.WARNING],
            "info_issues": total_issues_by_level[QualityIssueLevel.INFO],
        }


class QualitySession:
    """Context manager for data quality monitoring session"""

    def __init__(
        self, table_name: str, monitor: DataQualityMonitor, correlation_id: str
    ):
        self.table_name = table_name
        self.monitor = monitor
        self.correlation_id = correlation_id
        self.logger = logging.getLogger(__name__)

        # Session tracking
        self.start_time = datetime.now(timezone.utc)
        self.end_time = None
        self.total_records = 0
        self.processed_records = 0
        self.failed_records = 0
        self.metrics: Dict[str, QualityMetric] = {}
        self.issues: List[QualityIssue] = []

    def record_metric(self, metric: QualityMetric):
        """Record a quality metric"""
        self.metrics[metric.name] = metric

        # Check thresholds and create issues if needed
        if isinstance(metric.value, (int, float)):
            if metric.higher_is_better:
                # For success rates: low values are bad, high values are good
                if metric.threshold_error and metric.value <= metric.threshold_error:
                    self.add_issue(
                        QualityIssueLevel.ERROR,
                        metric.name,
                        f"{metric.name} value {metric.value} is below error threshold {metric.threshold_error}",
                        metric.value,
                        f"> {metric.threshold_error}",
                    )
                elif (
                    metric.threshold_warning
                    and metric.value <= metric.threshold_warning
                ):
                    self.add_issue(
                        QualityIssueLevel.WARNING,
                        metric.name,
                        f"{metric.name} value {metric.value} is below warning threshold {metric.threshold_warning}",
                        metric.value,
                        f"> {metric.threshold_warning}",
                    )
            else:
                # For failure rates: high values are bad, low values are good
                if metric.threshold_error and metric.value >= metric.threshold_error:
                    self.add_issue(
                        QualityIssueLevel.ERROR,
                        metric.name,
                        f"{metric.name} value {metric.value} exceeds error threshold {metric.threshold_error}",
                        metric.value,
                        f"< {metric.threshold_error}",
                    )
                elif (
                    metric.threshold_warning
                    and metric.value >= metric.threshold_warning
                ):
                    self.add_issue(
                        QualityIssueLevel.WARNING,
                        metric.name,
                        f"{metric.name} value {metric.value} exceeds warning threshold {metric.threshold_warning}",
                        metric.value,
                        f"< {metric.threshold_warning}",
                    )

    def add_issue(
        self,
        level: QualityIssueLevel,
        metric_name: str,
        message: str,
        actual_value: Any,
        expected_value: Any = None,
    ):
        """Add a quality issue"""
        issue = QualityIssue(
            level=level,
            metric_name=metric_name,
            message=message,
            actual_value=actual_value,
            expected_value=expected_value,
            table_name=self.table_name,
            correlation_id=self.correlation_id,
        )
        self.issues.append(issue)

    def record_processing_stats(self, total: int, processed: int, failed: int):
        """Record processing statistics"""
        self.total_records = total
        self.processed_records = processed
        self.failed_records = failed

        # Handle "no data" case - this is normal for incremental processing
        if total == 0:
            # No data to process is INFO level, not an error
            # Don't record success_rate/failure_rate metrics as they're meaningless
            self.add_issue(
                QualityIssueLevel.INFO,
                "data_volume",
                "No new records found for incremental processing",
                0,
                "> 0",
            )
            return  # Skip metric recording for empty data

        # Only record rate metrics when we have data
        success_rate = processed / total
        failure_rate = failed / total

        self.record_metric(
            QualityMetric(
                name="success_rate",
                value=success_rate,
                threshold_warning=0.95,  # Warn if < 95% success
                threshold_error=0.90,  # Error if < 90% success
                higher_is_better=True,
                description="Percentage of successfully processed records",
            )
        )

        self.record_metric(
            QualityMetric(
                name="failure_rate",
                value=failure_rate,
                threshold_warning=0.05,
                threshold_error=0.2,
                description="Percentage of failed records",
            )
        )

        # Warn on low record counts (but not zero - that's handled above)
        if total < 10:
            self.add_issue(
                QualityIssueLevel.WARNING,
                "data_volume",
                f"Low record count: {total} records",
                total,
                ">= 10",
            )

    def finalize(self) -> QualityReport:
        """Finalize the session and create quality report"""
        self.end_time = datetime.now(timezone.utc)

        # Calculate overall quality score
        quality_score = self._calculate_quality_score()

        report = QualityReport(
            table_name=self.table_name,
            processing_start=self.start_time,
            processing_end=self.end_time,
            total_records=self.total_records,
            processed_records=self.processed_records,
            failed_records=self.failed_records,
            quality_score=quality_score,
            metrics=self.metrics,
            issues=self.issues,
            correlation_id=self.correlation_id,
        )

        # Record with monitor
        self.monitor.record_quality_report(report)

        return report

    def _calculate_quality_score(self) -> float:
        """Calculate overall quality score (0.0 to 1.0)

        Score is based on issues encountered during processing:
        - CRITICAL: -0.3 (pipeline failures)
        - ERROR: -0.2 (publish failures, etc.)
        - WARNING: -0.1 (transformation issues, threshold breaches)
        - INFO: no penalty (informational only)

        Note: Skipped records (e.g., missing client_id) are not penalized
        as they represent source data issues, not pipeline quality issues.
        """
        score = 1.0

        # Penalize based on actual problems (not INFO)
        for issue in self.issues:
            if issue.level == QualityIssueLevel.CRITICAL:
                score -= 0.3
            elif issue.level == QualityIssueLevel.ERROR:
                score -= 0.2
            elif issue.level == QualityIssueLevel.WARNING:
                score -= 0.1
            # INFO is informational - no penalty

        return max(0.0, min(1.0, score))  # Clamp to 0.0-1.0 range
