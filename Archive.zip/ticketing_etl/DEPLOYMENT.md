# Deployment Options

This application supports multiple deployment configurations:

## 1. All-in-One Deployment (Development)

For development and testing with both app and NATS in the same stack:

```bash
# Start both app and NATS together
docker-compose up -d

# Stop everything
docker-compose down
```

## 2. Separate NATS Deployment (Production)

For production environments where NATS runs as a separate service:

### Step 1: Deploy NATS standalone
```bash
# Start NATS server
docker-compose -f docker-compose.nats.yml up -d

# Check NATS health
docker-compose -f docker-compose.nats.yml ps
```

### Step 2: Deploy App connecting to external NATS
```bash
# Set NATS connection URL
export NATS_URL=nats://localhost:4222

# Start app only
docker-compose -f docker-compose.app.yml up -d

# Check app health
curl http://localhost:8080/health/live
```

## 3. External NATS Service

For connecting to an existing NATS cluster:

```bash
# Set external NATS URL
export NATS_URL=nats://your-nats-cluster:4222

# Start app only
docker-compose -f docker-compose.app.yml up -d
```

## Network Configuration

- **NATS Network**: `nats-network` (shared between NATS and app)
- **App Network**: `app-network` (internal app network)
- **NATS Ports**: 4222 (client), 6222 (cluster), 8222 (monitoring)
- **App Ports**: 8080 (health endpoint)

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `NATS_URL` | NATS server connection URL | `nats://nats:4222` |
| `CONFIG_ENV` | Configuration environment | `production` |

## Data Persistence

- **NATS**: Data persisted in `nats_data` volume
- **App**: Stateless (no persistent data)

## Health Checks

- **NATS**: Port 4222 connectivity check
- **App**: HTTP health endpoint at `/health/live`

## Scaling

- **NATS**: Can be clustered using multiple instances
- **App**: Can run multiple instances (stateless)