const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const nats = require('nats');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Configuration
const NATS_URL = process.env.NATS_URL || 'nats://localhost:4222';
const NATS_USER = process.env.NATS_USER || 'eva-app';
const NATS_PASSWORD = process.env.NATS_PASSWORD || 'eva-app-2024';
const PORT = process.env.PORT || 3001;

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// NATS connection
let nc = null;
let js = null;

async function connectToNats() {
  try {
    console.log('🔌 Connecting to Eva NATS infrastructure...');

    nc = await nats.connect({
      servers: NATS_URL,
      user: NATS_USER,
      password: NATS_PASSWORD,
      name: 'eva-simple-ui'
    });

    js = nc.jetstream();
    console.log('✅ Connected to Eva NATS infrastructure');

    // Subscribe to all Eva streams for monitoring
    await subscribeToEvaStreams();

  } catch (error) {
    console.error('❌ Failed to connect to NATS:', error);
    // Retry connection after 5 seconds
    setTimeout(connectToNats, 5000);
  }
}

async function subscribeToEvaStreams() {
  try {
    // Get list of existing streams
    const streams = await js.streams.list().next();
    console.log('📊 Available streams:', streams.map(s => s.config.name));

    // Subscribe to ticketing stream (primary focus)
    if (streams.some(s => s.config.name === 'MESSAGING_TICKETING_STREAM')) {
      await subscribeToStream('MESSAGING_TICKETING_STREAM', 'ticketing.>');
      console.log('✅ Subscribed to MESSAGING_TICKETING_STREAM');
    }

    // Subscribe to other messaging streams if they exist
    const messagingStreams = ['MESSAGING_ANALYTICS_STREAM', 'MESSAGING_AUDIT_STREAM', 'MESSAGING_NOTIFICATIONS_STREAM'];
    for (const streamName of messagingStreams) {
      if (streams.some(s => s.config.name === streamName)) {
        const subject = streamName.replace('MESSAGING_', '').replace('_STREAM', '').toLowerCase() + '.>';
        await subscribeToStream(streamName, subject);
        console.log(`✅ Subscribed to ${streamName}`);
      }
    }

  } catch (error) {
    console.error('❌ Failed to subscribe to streams:', error);
  }
}

async function subscribeToStream(streamName, subject) {
  try {
    const consumer = await js.consumers.get(streamName, 'messaging-ui-monitor', {
      durable_name: 'messaging-ui-monitor',
      deliver_policy: 'new',
      ack_policy: 'explicit'
    });

    const messages = await consumer.consume();

    for await (const msg of messages) {
      try {
        const data = JSON.parse(msg.data.toString());
        const messageInfo = {
          timestamp: new Date().toISOString(),
          stream: streamName,
          subject: msg.subject,
          data: data,
          headers: msg.headers || {},
          sequence: msg.seq
        };

        // Broadcast to all connected clients
        io.emit('message', messageInfo);

        // Acknowledge the message
        msg.ack();

      } catch (parseError) {
        console.error('❌ Failed to parse message:', parseError);
        msg.ack(); // Acknowledge even if parsing fails
      }
    }

  } catch (error) {
    console.error(`❌ Failed to subscribe to ${streamName}:`, error);
  }
}

// Socket.io connection handling
io.on('connection', (socket) => {
  console.log('👤 Client connected:', socket.id);

  socket.on('disconnect', () => {
    console.log('👤 Client disconnected:', socket.id);
  });

  // Send connection status
  socket.emit('status', {
    connected: nc && !nc.isClosed(),
    natsUrl: NATS_URL,
    timestamp: new Date().toISOString()
  });
});

// API endpoints
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    nats: {
      connected: nc && !nc.isClosed(),
      url: NATS_URL
    },
    timestamp: new Date().toISOString()
  });
});

app.get('/api/streams', async (req, res) => {
  try {
    if (!js) {
      return res.status(503).json({ error: 'NATS not connected' });
    }

    const streams = await js.streams.list().next();
    const streamInfo = streams.map(s => ({
      name: s.config.name,
      subjects: s.config.subjects,
      messages: s.state.messages,
      bytes: s.state.bytes,
      consumers: s.state.consumers
    }));

    res.json(streamInfo);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start server
server.listen(PORT, () => {
  console.log(`🌐 Eva Simple Message Viewer running on http://localhost:${PORT}`);
  console.log(`📡 Connecting to NATS: ${NATS_URL}`);

  // Connect to NATS
  connectToNats();
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('🛑 Shutting down...');
  if (nc) {
    await nc.close();
  }
  process.exit(0);
});