# MCP Ticket Server Scripts

## Memgraph Lab - Visual Database Explorer

### Quick Start
```bash
# Open Memgraph Lab in browser
./open_memgraph_lab.sh
```

Access Memgraph Lab directly at: **http://localhost:7444**

### Features
- **Visual Graph Exploration** - Click and drag to explore your knowledge graph
- **Cypher Query Editor** - Syntax highlighting and auto-complete
- **Real-time Results** - See query results instantly
- **Graph Visualizations** - Interactive node-relationship diagrams

### Example Queries

**Get all tickets:**
```cypher
MATCH (t:Ticket)
RETURN t
LIMIT 10
```

**Explore ticket relationships:**
```cypher
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)-[:TRIGGERED_BY]->(i:Incident)
RETURN c, t, i
LIMIT 20
```

**Count tickets by status:**
```cypher
MATCH (t:Ticket)
RETURN t.ticket_status AS status, COUNT(t) AS count
ORDER BY count DESC
```

**Find high-priority open tickets:**
```cypher
MATCH (t:Ticket)
WHERE t.ticket_status = 'Open' AND t.priority >= 3
RETURN t
ORDER BY t.priority DESC
LIMIT 10
```

### Remote Access (SSH Tunnel)

To access Memgraph Lab on a remote server:

```bash
# From your laptop
ssh -L 7444:localhost:7444 -L 7687:localhost:7687 user@remote-server

# Then open http://localhost:7444 in your browser
```

### Alternative: Command Line Access

Use `mgconsole` for terminal-based access:

```bash
# Inside Memgraph container
docker exec -it memgraph mgconsole

# Or from host with mgconsole installed
mgconsole --host localhost --port 7687
```

### Troubleshooting

**Memgraph Lab not loading?**
```bash
# Check if Memgraph is running
docker ps | grep memgraph

# Check logs
docker logs memgraph

# Restart if needed
docker-compose restart memgraph
```

**Can't connect to database?**
- Verify Memgraph is running on port 7687
- Check docker-compose.yml for correct port mappings
- Ensure no firewall blocking ports 7444 or 7687
