"""
Shared text utilities for sanitizing and cleaning text.

Used by both fault_description_handler (WS-B) and notes_processor (WS-C).
"""
import re


def strip_html_css(text: str) -> str:
    """Strip HTML tags and CSS from text, preserving readable content"""
    if not text:
        return text
    # Remove <style>...</style> blocks entirely
    text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)
    # Remove <script>...</script> blocks
    text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL | re.IGNORECASE)
    # Replace <br>, <div>, <p>, <tr> with newlines for readability
    text = re.sub(r'<br\s*/?>', ' ', text, flags=re.IGNORECASE)
    text = re.sub(r'</?(div|p|tr)[^>]*>', ' ', text, flags=re.IGNORECASE)
    # Remove all remaining HTML tags
    text = re.sub(r'<[^>]+>', ' ', text)
    # Decode common HTML entities
    text = text.replace('&nbsp;', ' ').replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
    # Collapse multiple spaces/newlines
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def sanitize_for_embedding(text: str) -> str:
    """
    Sanitize text for embedding model.
    Removes problematic characters that can cause Ollama to crash.
    """
    if not text:
        return text

    # Remove null bytes and control characters (except newline, tab)
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)

    # Replace non-ASCII characters with ASCII equivalents or remove
    # Keep common Unicode but remove exotic characters
    cleaned = []
    for char in text:
        code = ord(char)
        if code < 128:  # ASCII
            cleaned.append(char)
        elif code < 256:  # Latin-1 supplement (accents, symbols)
            cleaned.append(char)
        elif char in '\u201c\u201d\u2018\u2019\u2013\u2014\u2026\u2022\u00b7':  # Common Unicode punctuation
            # Replace with ASCII equivalents
            replacements = {
                '\u201c': '"', '\u201d': '"', '\u2018': "'", '\u2019': "'",
                '\u2013': '-', '\u2014': '-', '\u2026': '...', '\u2022': '*', '\u00b7': '.'
            }
            cleaned.append(replacements.get(char, ' '))
        else:
            # Skip other Unicode (emojis, CJK, etc.)
            cleaned.append(' ')

    text = ''.join(cleaned)

    # Collapse multiple spaces (preserve newlines for section parsing)
    text = re.sub(r'[^\S\n]+', ' ', text)  # horizontal whitespace only
    text = re.sub(r'\n{3,}', '\n\n', text)  # max 2 consecutive newlines

    return text.strip()
