import asyncio
import logging
import asyncpg  # Import asyncpg for connection pooling
from utils.config import Config
from typing import List, Dict, Optional


class TicketDatabase:
    def __init__(self, config: Config):
        """Initialize the database connection pool using the configuration."""
        self.config = config
        self.db_url = self.config.get_db_uri()
        self.logger = logging.getLogger(__name__)
        self.pool = None  # Initialize the connection pool

    async def connect(self):
        """Establish an asynchronous connection pool to the database."""
        if self.pool is None:
            try:
                self.pool = await asyncpg.create_pool(
                    self.db_url,
                    min_size=5,  # Minimum number of connections in the pool (adjust as needed)
                    max_size=20,  # Maximum number of connections in the pool (adjust as needed)
                )
                self.logger.info("Database connection pool established.")
            except Exception as e:
                self.logger.error(
                    f"Database connection pool failed: {e}", exc_info=True
                )
                self.pool = None  # Ensure pool is None on failure
                raise  # Re-raise exception to prevent the app from running without a DB connection

    async def execute_query(self, query, *args):
        """
        Execute a SQL query asynchronously using a connection from the pool.
        """
        if not self.pool:
            raise Exception("Database connection pool is not initialized")

        try:
            async with self.pool.acquire() as conn:
                self.logger.debug(f"Executing query: {query} with args: {args}")
                rows = await conn.fetch(query, *args)
                return rows
                # async with conn.cursor(query, *args) as cur:
                #     return await cur.fetchall()
        except Exception as e:
            self.logger.error(f"Query execution failed: {e}", exc_info=True)
            raise  # Re-raise the exception

    async def fetch_data(
        self,
        table_name: str,
        columns: List[str],
        filters: Optional[Dict[str, str]] = None,
    ) -> List[Dict]:
        """
        Fetches data from the specified table with optional column selection and filtering.

        Args:
            table_name: The name of the table.
            columns: A tuple of column names to select.
            filters: A dictionary of filters.  Each key is a column name,
                     and each value is a string representing the filter condition
                     (e.g., "='value'", ">= '2024-01-01'", "IN ('A', 'B')").
        """

        self.logger.debug(f"The columns: {columns}")
        self.logger.debug(f"The filters: {filters}")

        if not columns:
            columns_str = "*"  # Select all the columns if none are specified
        else:
            columns_str = columns

        columns_str = "client"

        query = f"SELECT {columns_str} FROM {table_name}"

        conditions = []
        # Ensure filters exist before processing them
        if filters and len(filters) > 0:
            for column, condition_str in filters.items():
                # Add operator "=" for now - Could be ["=", ">", "<", "IN", "LIKE"]
                # Enclose the value in quotes for SQL compatibility
                formatted_condition = (
                    f"{column} >= '{condition_str}'"  # Formatting for SQL syntax
                )
                conditions.append(formatted_condition)  # Store the formatted condition

            # Construct the WHERE clause only if conditions exist
            if conditions:
                query += " WHERE " + " AND ".join(conditions)

        query += " limit 10;"
        self.logger.info(f"Executing query: {query}")

        rows = await self.execute_query(query)  # Use the new execute_query
        return [dict(row) for row in rows]  # Convert `Record` objects to dictionaries

    async def close(self):
        """Close the database connection pool asynchronously."""
        if self.pool:
            await self.pool.close()
            self.logger.info("Database connection pool closed.")
            self.pool = None

    def __del__(self):
        """Ensure the connection pool is closed when the object is garbage collected."""
        if self.pool is not None:
            #  The original code had a potential issue here by calling an async method
            #  in a sync context (__del__).  It's safer to log and attempt a synchronous
            #  close if the event loop is running.  However, proper cleanup should be
            #  handled by the application's shutdown process.
            self.logger.warning(
                "TicketDatabase.__del__ called, attempting to close pool."
            )
            try:
                if asyncio.get_event_loop().is_running():
                    asyncio.get_event_loop().run_until_complete(self.close())
                else:
                    #  If the event loop is not running, we can't properly close the
                    #  async pool.  We log a warning and attempt a sync close, which
                    #  might not release all resources.
                    self.logger.warning(
                        "Event loop not running, cant properly close async pool."
                    )
                    #  It's possible to get the underlying psycopg2 pool and close it, but
                    #  this is not recommended.
            except Exception as e:
                self.logger.error(f"Error closing connection pool in __del__: {e}")
