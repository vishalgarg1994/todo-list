#!/bin/bash
# Test semantic search via MCP HTTP API

SERVER_URL="http://localhost:8003"

echo "========================================================================"
echo "🔍 Testing Semantic Search: search_similar_faults"
echo "========================================================================"
echo ""
echo "Query: 'fiber cut outage'"
echo ""

curl -s -X POST "$SERVER_URL/mcp/tools/search_similar_faults" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{
    "jsonrpc": "2.0",
    "method": "tools/call",
    "params": {
      "name": "search_similar_faults",
      "arguments": {
        "query": "fiber cut outage",
        "top_k": 5
      }
    },
    "id": 1
  }' | while IFS= read -r line; do
    if [[ $line == data:* ]]; then
      echo "${line:5}" | jq '.'
    fi
  done

echo ""
echo "========================================================================"
echo "✅ Test complete"
echo "========================================================================"
