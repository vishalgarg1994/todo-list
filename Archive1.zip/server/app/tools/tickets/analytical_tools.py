"""
Analytical tools for ticket system
Provides statistics, aggregations, and summaries
"""
import asyncio
import logging
import polars as pl
from typing import Any, Optional
from fastmcp.exceptions import ToolError
from utils.utilities import Helpers


async def get_client_summary(client_name: str, services: dict) -> Any:
    """
    Get comprehensive summary and statistics for a client.

    Returns total tickets, status breakdown, priority distribution,
    average MTTR, top RFOs, and recent activity.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_client_summary for client: '{client_name}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Get overall statistics
        stats_query = """
            MATCH (c:Client {client_name: $client_name})-[:HAS_TICKET]->(t:Ticket)
            OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
            RETURN
                count(t) as total_tickets,
                count(CASE WHEN t.ticket_status = 'Open' THEN 1 END) as open_tickets,
                count(CASE WHEN t.ticket_status = 'Closed' THEN 1 END) as closed_tickets,
                count(CASE WHEN t.priority <= 2 THEN 1 END) as high_priority_tickets,
                avg(o.mttr) as avg_mttr,
                min(t.created_on) as first_ticket_date,
                max(t.created_on) as latest_ticket_date
        """

        # Get top RFOs
        rfo_query = """
            MATCH (c:Client {client_name: $client_name})-[:HAS_TICKET]->(t:Ticket)
            MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
            WHERE o.rfo IS NOT NULL
            RETURN o.rfo as rfo, count(*) as count
            ORDER BY count DESC
            LIMIT 5
        """

        # Get status breakdown
        status_query = """
            MATCH (c:Client {client_name: $client_name})-[:HAS_TICKET]->(t:Ticket)
            RETURN t.ticket_status as status, count(*) as count
            ORDER BY count DESC
        """

        stats_result = await memgraph_client.execute( stats_query, {"client_name": client_name})
        stats_records = [record.data() for record in stats_result]
        stats_df = pl.DataFrame(stats_records) if stats_records else pl.DataFrame()
        stats_data = stats_df.to_dicts()

        if not stats_data or stats_data[0]['total_tickets'] == 0:
            return {"message": f"No tickets found for client: {client_name}"}

        rfo_result = await memgraph_client.execute( rfo_query, {"client_name": client_name})
        rfo_records = [record.data() for record in rfo_result]
        rfo_df = pl.DataFrame(rfo_records) if rfo_records else pl.DataFrame()
        rfo_data = rfo_df.to_dicts()

        status_result = await memgraph_client.execute( status_query, {"client_name": client_name})
        status_records = [record.data() for record in status_result]
        status_df = pl.DataFrame(status_records) if status_records else pl.DataFrame()
        status_data = status_df.to_dicts()

        return Helpers.recursive_serialize({
            "client_name": client_name,
            "statistics": stats_data[0],
            "top_rfos": rfo_data,
            "status_breakdown": status_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_client_summary: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve client summary: {e}")


async def get_tickets_by_status(
    status: str,
    services: dict,
    client_name: Optional[str] = None,
    limit: Optional[int] = 100
) -> Any:
    """
    Get tickets filtered by status.

    Optionally filter by client. Returns ticket details sorted by creation date.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_tickets_by_status with status: '{status}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Build query based on whether client_name is provided
        if client_name:
            cypher_query = """
                MATCH (c:Client {client_name: $client_name})-[:HAS_TICKET]->(t:Ticket)
                WHERE t.ticket_status = $status
                OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
                RETURN t.ticket_id as ticket_id,
                       t.ticket_category as category,
                       t.priority as priority,
                       t.created_on as created_on,
                       t.closed_on as closed_on,
                       t.assigned_to as assigned_to,
                       o.rfo as rfo,
                       o.mttr as mttr
                ORDER BY t.created_on DESC
            """
            params = {"status": status.lower(), "client_name": client_name}
        else:
            cypher_query = """
                MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
                WHERE t.ticket_status = $status
                OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
                RETURN c.client_name as client_name,
                       t.ticket_id as ticket_id,
                       t.ticket_category as category,
                       t.priority as priority,
                       t.created_on as created_on,
                       t.closed_on as closed_on,
                       t.assigned_to as assigned_to,
                       o.rfo as rfo,
                       o.mttr as mttr
                ORDER BY t.created_on DESC
            """
            params = {"status": status.lower()}

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute( cypher_query, params)
        response_data = result
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No tickets found with status: {status}"}

        return Helpers.recursive_serialize({
            "status": status,
            "client_name": client_name,
            "ticket_count": len(response_data),
            "tickets": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_tickets_by_status: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve tickets by status: {e}")


async def get_high_priority_tickets(
    services: dict,
    priority_threshold: int = 2,
    client_name: Optional[str] = None,
    limit: Optional[int] = 50
) -> Any:
    """
    Get high-priority tickets (priority <= threshold).

    Lower priority numbers = higher urgency. Default threshold is 2 (P1, P2).
    Optionally filter by client.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_high_priority_tickets with threshold: {priority_threshold}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Build query based on whether client_name is provided
        if client_name:
            cypher_query = """
                MATCH (c:Client {client_name: $client_name})-[:HAS_TICKET]->(t:Ticket)
                WHERE t.priority <= $priority_threshold AND t.ticket_status <> 'Closed'
                OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
                RETURN t.ticket_id as ticket_id,
                       t.priority as priority,
                       t.ticket_status as status,
                       t.ticket_category as category,
                       t.created_on as created_on,
                       t.assigned_to as assigned_to,
                       o.rfo as rfo,
                       o.mttr as mttr
                ORDER BY t.priority ASC, t.created_on DESC
            """
            params = {"priority_threshold": priority_threshold, "client_name": client_name}
        else:
            cypher_query = """
                MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
                WHERE t.priority <= $priority_threshold AND t.ticket_status <> 'Closed'
                OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
                RETURN c.client_name as client_name,
                       t.ticket_id as ticket_id,
                       t.priority as priority,
                       t.ticket_status as status,
                       t.ticket_category as category,
                       t.created_on as created_on,
                       t.assigned_to as assigned_to,
                       o.rfo as rfo,
                       o.mttr as mttr
                ORDER BY t.priority ASC, t.created_on DESC
            """
            params = {"priority_threshold": priority_threshold}

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute( cypher_query, params)
        response_data = result
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No high-priority tickets found (P<={priority_threshold})"}

        return Helpers.recursive_serialize({
            "priority_threshold": priority_threshold,
            "client_name": client_name,
            "ticket_count": len(response_data),
            "tickets": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_high_priority_tickets: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve high-priority tickets: {e}")


async def get_user_performance(
    services: dict,
    status_filter: Optional[str] = "Closed",
    limit: Optional[int] = 100
) -> Any:
    """
    Get user productivity metrics and performance statistics.

    Shows tickets resolved per user, average resolution time, and user roles.
    Default shows closed tickets. Use status_filter=None for all tickets.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_user_performance with status: '{status_filter}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Build query based on status filter
        if status_filter:
            cypher_query = """
                MATCH (t:Ticket)-[r:HAS_USER]->(u:UserInfo)
                WHERE t.ticket_status = $status
                RETURN u.name as user_name,
                       r.role as user_role,
                       count(t) as tickets_handled,
                       collect(DISTINCT t.ticket_status) as ticket_statuses
                ORDER BY tickets_handled DESC
                LIMIT $limit
            """
            params = {"status": status_filter.lower(), "limit": limit}
        else:
            cypher_query = """
                MATCH (t:Ticket)-[r:HAS_USER]->(u:UserInfo)
                RETURN u.name as user_name,
                       r.role as user_role,
                       count(t) as tickets_handled,
                       collect(DISTINCT t.ticket_status) as ticket_statuses
                ORDER BY tickets_handled DESC
                LIMIT $limit
            """
            params = {"limit": limit}

        result = await memgraph_client.execute( cypher_query, params)
        records = [record.data() for record in result]

        if not records:
            return {"message": f"No user performance data found"}

        return Helpers.recursive_serialize({
            "status_filter": status_filter,
            "user_count": len(records),
            "users": records
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_user_performance: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve user performance: {e}")


async def get_vendor_impact(
    services: dict,
    vendor_name: Optional[str] = None,
    limit: Optional[int] = 100
) -> Any:
    """
    Get vendor performance and impact analysis.

    Shows tickets per vendor, average downtime, and vendor involvement patterns.
    Optionally filter by specific vendor name.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_vendor_impact for vendor: '{vendor_name}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        if vendor_name:
            cypher_query = """
                MATCH (t:Ticket)-[:INVOLVES_VENDOR]->(v:VendorInfo {vendor: $vendor_name})
                RETURN v.vendor as vendor_name,
                       count(t) as tickets_handled,
                       avg(v.vendor_downtime) as avg_downtime,
                       collect(DISTINCT t.priority) as priority_levels,
                       collect(DISTINCT t.ticket_status) as ticket_statuses
            """
            params = {"vendor_name": vendor_name}
        else:
            cypher_query = """
                MATCH (t:Ticket)-[:INVOLVES_VENDOR]->(v:VendorInfo)
                RETURN v.vendor as vendor_name,
                       count(t) as tickets_handled,
                       avg(v.vendor_downtime) as avg_downtime,
                       collect(DISTINCT t.priority) as priority_levels
                ORDER BY tickets_handled DESC
                LIMIT $limit
            """
            params = {"limit": limit}

        result = await memgraph_client.execute( cypher_query, params)
        records = [record.data() for record in result]

        if not records:
            return {"message": f"No vendor impact data found"}

        return Helpers.recursive_serialize({
            "vendor_name": vendor_name,
            "vendor_count": len(records),
            "vendors": records
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_vendor_impact: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve vendor impact: {e}")


async def get_client_escalations(
    services: dict,
    client_tier: Optional[str] = None,
    min_escalation_level: Optional[int] = 1,
    limit: Optional[int] = 100
) -> Any:
    """
    Get client escalation patterns and statistics.

    Shows clients with escalated tickets, escalation levels, and tier analysis.
    Optionally filter by client tier and minimum escalation level.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_client_escalations with tier: '{client_tier}', min_level: {min_escalation_level}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        if client_tier:
            cypher_query = """
                MATCH (c:Client {client_tier: $client_tier})-[:HAS_TICKET]->(t:Ticket)
                WHERE t.ticket_escalation_level >= $min_escalation_level
                RETURN c.client_name as client_name,
                       c.client_tier as client_tier,
                       count(t) as escalated_tickets,
                       avg(t.ticket_escalation_level) as avg_escalation_level,
                       max(t.ticket_escalation_level) as max_escalation_level
                ORDER BY escalated_tickets DESC
                LIMIT $limit
            """
            params = {"client_tier": client_tier, "min_escalation_level": min_escalation_level, "limit": limit}
        else:
            cypher_query = """
                MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
                WHERE t.ticket_escalation_level >= $min_escalation_level
                RETURN c.client_name as client_name,
                       c.client_tier as client_tier,
                       count(t) as escalated_tickets,
                       avg(t.ticket_escalation_level) as avg_escalation_level,
                       max(t.ticket_escalation_level) as max_escalation_level
                ORDER BY escalated_tickets DESC
                LIMIT $limit
            """
            params = {"min_escalation_level": min_escalation_level, "limit": limit}

        result = await memgraph_client.execute( cypher_query, params)
        records = [record.data() for record in result]

        if not records:
            return {"message": f"No escalation data found"}

        return Helpers.recursive_serialize({
            "client_tier": client_tier,
            "min_escalation_level": min_escalation_level,
            "client_count": len(records),
            "clients": records
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_client_escalations: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve client escalations: {e}")


async def get_survey_satisfaction(
    services: dict,
    assignee_name: Optional[str] = None,
    limit: Optional[int] = 100
) -> Any:
    """
    Get customer satisfaction analytics from ticket surveys.

    Shows survey scores, feedback themes, and satisfaction by assignee.
    Optionally filter by specific assignee.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_survey_satisfaction for assignee: '{assignee_name}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        if assignee_name:
            cypher_query = """
                MATCH (t:Ticket {assigned_to: $assignee_name})-[:HAS_SURVEY]->(s:SurveyInfo)
                RETURN t.assigned_to as assignee,
                       count(s) as surveys_received,
                       avg(toInteger(s.survey_score)) as avg_satisfaction_score,
                       collect(s.score_reason) as feedback_themes
            """
            params = {"assignee_name": assignee_name}
        else:
            cypher_query = """
                MATCH (t:Ticket)-[:HAS_SURVEY]->(s:SurveyInfo)
                WHERE t.assigned_to IS NOT NULL
                RETURN t.assigned_to as assignee,
                       count(s) as surveys_received,
                       avg(toInteger(s.survey_score)) as avg_satisfaction_score
                ORDER BY avg_satisfaction_score DESC
                LIMIT $limit
            """
            params = {"limit": limit}

        result = await memgraph_client.execute( cypher_query, params)
        records = [record.data() for record in result]

        if not records:
            return {"message": f"No survey satisfaction data found"}

        return Helpers.recursive_serialize({
            "assignee_name": assignee_name,
            "assignee_count": len(records),
            "survey_data": records
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_survey_satisfaction: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve survey satisfaction: {e}")


async def get_maintenance_impact(
    services: dict,
    technology: Optional[str] = None,
    limit: Optional[int] = 100
) -> Any:
    """
    Get maintenance window impact and correlation analysis.

    Shows tickets during maintenance windows, technology affected, and patterns.
    Optionally filter by specific technology.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_maintenance_impact for technology: '{technology}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Updated to match current schema from batch_graph_loader.py
        if technology:
            cypher_query = """
                MATCH (t:Ticket)-[:DURING_MAINTENANCE]->(m:MaintenanceWindow)
                MATCH (t)-[:HAS_SERVICE]->(s:Service {technology: $technology})
                RETURN m.pw_reason as maintenance_reason,
                       s.technology as technology,
                       count(t) as related_tickets,
                       m.pw_start as window_start,
                       m.pw_end as window_end
                ORDER BY related_tickets DESC
                LIMIT $limit
            """
            params = {"technology": technology, "limit": limit}
        else:
            cypher_query = """
                MATCH (t:Ticket)-[:DURING_MAINTENANCE]->(m:MaintenanceWindow)
                OPTIONAL MATCH (t)-[:HAS_SERVICE]->(s:Service)
                RETURN m.pw_reason as maintenance_reason,
                       collect(DISTINCT s.technology) as technologies,
                       count(t) as related_tickets,
                       m.pw_start as window_start,
                       m.pw_end as window_end
                ORDER BY related_tickets DESC
                LIMIT $limit
            """
            params = {"limit": limit}

        result = await memgraph_client.execute( cypher_query, params)
        records = [record.data() for record in result]

        if not records:
            return {"message": f"No maintenance impact data found"}

        return Helpers.recursive_serialize({
            "technology": technology,
            "maintenance_window_count": len(records),
            "maintenance_windows": records
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_maintenance_impact: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve maintenance impact: {e}")


# DISABLED - No contact data in PostgreSQL schema
# async def get_contact_communication_stats(
#     services: dict,
#     contact_type: Optional[str] = None,
#     limit: Optional[int] = 100
# ) -> Any:
#     """
#     Get contact communication analysis and patterns.
#
#     Shows contact involvement by type, ticket patterns, and communication metrics.
#     Optionally filter by contact type (e.g., 'technical', 'business', 'escalation').
#     """
#     try:
#         logging.info(f"FastMCP Tool Call: get_contact_communication_stats for type: '{contact_type}'")
#
#         memgraph_client = services["memgraph_client"]
#         if not memgraph_client:
#             raise ToolError("Memgraph client not initialized.")
#
#         if contact_type:
#             cypher_query = """
#                 MATCH (t:Ticket)-[:HAS_CONTACT]->(c:ContactInfo {contact_type: $contact_type})
#                 RETURN c.contact_type as contact_type,
#                        count(DISTINCT c) as unique_contacts,
#                        count(t) as tickets_involved,
#                        collect(DISTINCT c.name) as contact_names
#             """
#             params = {"contact_type": contact_type}
#         else:
#             cypher_query = """
#                 MATCH (t:Ticket)-[:HAS_CONTACT]->(c:ContactInfo)
#                 RETURN c.contact_type as contact_type,
#                        count(DISTINCT c) as unique_contacts,
#                        count(t) as tickets_involved
#                 ORDER BY tickets_involved DESC
#                 LIMIT $limit
#             """
#             params = {"limit": limit}
#
#         result = await memgraph_client.execute( cypher_query, params)
#         records = [record.data() for record in result]
#
#         if not records:
#             return {"message": f"No contact communication data found"}
#
#         return Helpers.recursive_serialize({
#             "contact_type": contact_type,
#             "contact_type_count": len(records),
#             "contact_stats": records
#         })
#
#     except ToolError:
#         raise
#     except Exception as e:
#         logging.error(f"Error in get_contact_communication_stats: {e}", exc_info=True)
#         raise ToolError(f"Failed to retrieve contact communication stats: {e}")
