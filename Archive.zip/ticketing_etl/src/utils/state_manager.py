"""
Processing State Manager - Handles persistent state for data processing
"""

import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)


class ProcessingStateManager:
    """Manages persistent processing state for tables"""

    def __init__(self, state_file_path: str = None):
        if state_file_path is None:
            # Use environment variable or fallback to /tmp
            state_file_path = os.getenv(
                "STATE_FILE_PATH", "/app/data/processing_state.json"
            )

        self.state_file = Path(state_file_path)
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"Using state file location: {state_file_path}")

    def _ensure_state_directory(self):
        """Ensure the state directory exists"""
        self.state_file.parent.mkdir(parents=True, exist_ok=True)

    def _load_state(self) -> Dict[str, Any]:
        """Load complete state from file"""
        try:
            if self.state_file.exists():
                with open(self.state_file, "r") as f:
                    return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            self.logger.warning(f"Could not load processing state: {e}")
        return {}

    def _save_state(self, state: Dict[str, Any]):
        """Save complete state to file"""
        try:
            self._ensure_state_directory()
            with open(self.state_file, "w") as f:
                json.dump(state, f, indent=2, default=str)
        except Exception as e:
            self.logger.error(f"Failed to save processing state: {e}")

    def is_initial_load_complete(self, table_name: str) -> bool:
        """Check if initial load is complete for a table"""
        state = self._load_state()
        table_state = state.get(table_name, {})
        return table_state.get("status") == "initial_load_complete"

    def is_initial_load_in_progress(self, table_name: str) -> bool:
        """Check if initial load is in progress for a table"""
        state = self._load_state()
        table_state = state.get(table_name, {})
        return table_state.get("status") == "initial_load_in_progress"

    def start_initial_load(self, table_name: str, start_timestamp: datetime):
        """Mark initial load as started"""
        state = self._load_state()
        state[table_name] = {
            "status": "initial_load_in_progress",
            "initial_load_started_at": start_timestamp.isoformat(),
            "last_processed_timestamp": None,
        }
        self._save_state(state)
        self.logger.info(f"Started initial load for {table_name}")

    def complete_initial_load(self, table_name: str, completion_timestamp: datetime):
        """Mark initial load as complete"""
        state = self._load_state()
        if table_name not in state:
            state[table_name] = {}

        state[table_name].update(
            {
                "status": "initial_load_complete",
                "initial_load_completed_at": completion_timestamp.isoformat(),
                "last_processed_timestamp": completion_timestamp.isoformat(),
            }
        )
        self._save_state(state)
        self.logger.info(f"Completed initial load for {table_name}")

    def update_incremental_timestamp(
        self, table_name: str, timestamp: datetime, data_source: str = "db"
    ):
        """Update last processed timestamp for incremental processing"""
        state = self._load_state()
        if table_name not in state:
            if data_source == "api":
                # Expected for API mode - no initial load concept
                self.logger.debug(f"Initializing state for {table_name} (API mode)")
            else:
                # DB or BOTH mode - warn about missing initial load
                self.logger.warning(
                    f"Updating timestamp for {table_name} without initial load completion"
                )
            state[table_name] = {"status": "initial_load_complete"}

        state[table_name]["last_processed_timestamp"] = timestamp.isoformat()
        self._save_state(state)
        self.logger.debug(
            f"Updated incremental timestamp for {table_name}: {timestamp}"
        )

    def get_last_processed_timestamp(self, table_name: str) -> Optional[datetime]:
        """Get the last successfully processed timestamp"""
        state = self._load_state()
        table_state = state.get(table_name, {})
        timestamp_str = table_state.get("last_processed_timestamp")

        if timestamp_str:
            try:
                return datetime.fromisoformat(timestamp_str)
            except ValueError as e:
                self.logger.error(
                    f"Invalid timestamp format for {table_name}: {timestamp_str}, error: {e}"
                )

        return None

    def reset_table_state(self, table_name: str):
        """Reset state for a table (useful for debugging/recovery)"""
        state = self._load_state()
        if table_name in state:
            del state[table_name]
            self._save_state(state)
            self.logger.info(f"Reset state for {table_name}")

    def get_table_status(self, table_name: str) -> Dict[str, Any]:
        """Get complete status information for a table"""
        state = self._load_state()
        return state.get(table_name, {})

    def get_all_tables_status(self) -> Dict[str, Dict[str, Any]]:
        """Get status for all tables"""
        return self._load_state()


# Global instance for easy access
state_manager = ProcessingStateManager()
