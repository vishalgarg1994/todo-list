"""
Optimized Ticket Message Handler using Batch Operations
Dramatically faster than individual query approach

LOGGING MODES:
- Production Mode (default): Only batch-level summaries from consumer
  Result: 2 lines per 100 messages + errors

- Debug Mode (Option 3): Uncomment all "VERBOSE LOGGING (Option 3)" sections
  Result: ~6 lines per message for detailed timing breakdown
  Useful for performance troubleshooting
"""
import asyncio
import json
import logging
import traceback
import polars as pl
import time
from typing import Dict, Any

from utils.utilities import Helpers
from configs.config import Config
from data_access.memgraphClient import MemgraphClient
from services.batch_graph_loader import BatchGraphLoader

# Global locks to serialize operations on shared nodes (prevents transaction conflicts)
_user_relationship_lock = asyncio.Lock()  # Shared UserInfo nodes in relationships
_vendor_relationship_lock = asyncio.Lock()  # Shared VendorInfo nodes in relationships
_user_node_lock = asyncio.Lock()  # Shared UserInfo node creation


class TicketMessageHandler:
    def __init__(self, memgraph_client: MemgraphClient, config: Config = None):
        self.config = config or Config()
        self.memgraphClient = memgraph_client
        self.batch_loader = BatchGraphLoader(memgraph_client)

    async def handle_ticket_message(self, msg):
        """Processes incoming ticket messages from JetStream."""
        msg_start = time.time()
        try:
            # VERBOSE LOGGING (Option 3): Uncomment below for detailed per-message timing
            # decompress_start = time.time()
            payload = Helpers.decompress_message(msg.data)
            # decompress_time = time.time() - decompress_start
            # logging.info(f"⏱️  Decompression took: {decompress_time:.3f}s")

            if not isinstance(payload, dict):
                logging.error(f"❌ Unexpected payload type: {type(payload)} - Raw Data: {msg.data}")
                await msg.term()
                return

            # Process ticket before acknowledging
            # VERBOSE LOGGING (Option 3): Uncomment below for detailed per-message timing
            # process_start = time.time()
            success = await self.process_ticket(payload)
            # process_time = time.time() - process_start
            # msg_total_time = time.time() - msg_start
            # logging.info(f"⏱️  Message processing took: {process_time:.3f}s (total: {msg_total_time:.3f}s)")

            if success:
                await msg.ack()
                # logging.debug("✅ Message processed and acknowledged successfully.")
            else:
                logging.error("❌ Ticket processing failed")
                await msg.ack()  # ACK to avoid infinite retry loop
                logging.warning("⚠️  ACK'd failed message to continue processing")

        except json.JSONDecodeError:
            logging.error(f"❌ Invalid JSON format in ticket message: {msg.data}")
            await msg.term()
        except Exception as e:
            logging.error(f"❌ Unexpected error in handle_ticket_message: {type(e).__name__} - {str(e)}")
            logging.error(f"🔍 Stack Trace:\n{traceback.format_exc()}")
            await msg.ack()  # ACK to avoid infinite retry loop
            logging.warning("⚠️  ACK'd failed message to continue processing")

    async def process_ticket(self, ticket_summary: Dict[str, Any]):
        """Main orchestrator using batch operations for speed"""
        try:
            # Step 1: Prepare and transform data
            # VERBOSE LOGGING (Option 3): Uncomment below for detailed per-message timing
            # prep_start = time.time()
            processed_data = self._prepare_ticket_data(ticket_summary)
            # prep_time = time.time() - prep_start
            # logging.info(f"⏱️  Data preparation took: {prep_time:.3f}s")

            # Step 2: Batch load all nodes
            # VERBOSE LOGGING (Option 3): Uncomment below for detailed per-message timing
            # nodes_start = time.time()
            client_id = await self._batch_load_all_nodes(processed_data)
            # nodes_time = time.time() - nodes_start
            # logging.info(f"⏱️  Batch loading nodes took: {nodes_time:.3f}s")

            # Step 3: Batch load all relationships
            # VERBOSE LOGGING (Option 3): Uncomment below for detailed per-message timing
            # rels_start = time.time()
            await self._batch_load_all_relationships(processed_data, client_id)
            # rels_time = time.time() - rels_start
            # logging.info(f"⏱️  Batch loading relationships took: {rels_time:.3f}s")

            # Step 4: Log completion status
            # DISABLED: This scans entire DB per message - too expensive!
            # status_start = time.time()
            # await self._log_processing_status()
            # status_time = time.time() - status_start
            # logging.info(f"⏱️  Logging status took: {status_time:.3f}s")

            # VERBOSE LOGGING (Option 3): Uncomment below for per-message success logging
            # logging.info("🎉 Enhanced ticket processing completed successfully")
            return True

        except Exception as e:
            return self._handle_processing_error(e, ticket_summary)

    def _prepare_ticket_data(self, ticket_summary: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare and transform ticket data for database insertion."""
        # Convert JSON to format aligned with Enhanced Memgraph schema
        ticket_summary = Helpers.graph_json_adapter(ticket_summary)

        # Replace Null like values to None
        ticket_summary = Helpers.normalise_None(ticket_summary)

        # Normalize knowledge graph list fields: convert None to [] for consistency
        for op_status in ticket_summary.get("operational_status", []):
            if op_status.get("users") is None:
                op_status["users"] = []
            if op_status.get("contacts") is None:
                op_status["contacts"] = []
            if op_status.get("vendors") is None:
                op_status["vendors"] = []
            if op_status.get("tasks") is None:
                op_status["tasks"] = []
            if op_status.get("configuration_items") is None:
                op_status["configuration_items"] = []

        # Cast all operational status fields
        self._cast_operational_status_fields(ticket_summary)

        # Convert objects into simpler, serializable formats
        return Helpers.recursive_serialize(ticket_summary)

    def _cast_operational_status_fields(self, ticket_summary: Dict[str, Any]):
        """Cast fields in operational status to appropriate data types."""
        for op_status in ticket_summary.get("operational_status", []):
            self._cast_outage_info_fields(op_status)
            self._cast_ticket_info_fields(op_status)
            self._cast_fault_info_fields(op_status)
            self._cast_vendor_fields(op_status)
            self._cast_task_fields(op_status)

    def _cast_outage_info_fields(self, op_status: Dict[str, Any]):
        """Cast outage_info fields to appropriate types."""
        outage_info = op_status.get("outage_info", {})
        self.cast_numeric_fields(outage_info, ["outage_total", "mttr"])
        self.cast_boolean_fields(outage_info, ["is_worked_ticket"])

    def _cast_ticket_info_fields(self, op_status: Dict[str, Any]):
        """Cast ticket_info fields to appropriate types."""
        tkt_info = op_status.get("ticket_info", {})
        self.cast_numeric_fields(
            tkt_info, ["priority", "ticket_escalation_level", "next_action_date_notification_counter"]
        )
        self.cast_boolean_fields(tkt_info, ["is_master_ticket"])

    def _cast_fault_info_fields(self, op_status: Dict[str, Any]):
        """Cast fault_info fields to appropriate types (renamed from incident_info)."""
        fault_info = op_status.get("fault_info", {})
        self.cast_boolean_fields(fault_info, ["is_customer_impacting"])

    def _cast_task_fields(self, op_status: Dict[str, Any]):
        """Cast task fields to appropriate types (NEW: TSM tasks)."""
        tasks = op_status.get("tasks", [])
        if tasks is None:
            return
        for task in tasks:
            self.cast_numeric_fields(task, ["priority"])
            self.cast_boolean_fields(task, ["is_pending"])

    def _cast_vendor_fields(self, op_status: Dict[str, Any]):
        """Cast vendor downtime fields to float."""
        vendors = op_status.get("vendors", [])
        if vendors is None:
            return
        for vendor in vendors:
            if "vendor_downtime" in vendor and vendor["vendor_downtime"] is not None:
                try:
                    vendor["vendor_downtime"] = float(vendor["vendor_downtime"])
                except (ValueError, TypeError):
                    vendor["vendor_downtime"] = 0.0

    async def _batch_load_all_nodes(self, ticket_summary_dict: Dict[str, Any]) -> str:
        """Batch load ALL nodes using UNWIND for maximum speed"""
        # VERBOSE LOGGING (Option 3): Uncomment below for detailed per-message node loading info
        # logging.info("🔄 Using BATCH operations with UNWIND for Memgraph")

        operational_status = ticket_summary_dict.get("operational_status", [])
        client_info = ticket_summary_dict.get("client_info", {})

        # Get NOC info from first operational_status
        noc_info = {}
        if operational_status:
            noc_info = operational_status[0].get("noc_info", {}) or {}

        # Load client node (single)
        success = await self.batch_loader.load_client_node(client_info, noc_info)
        client_id = client_info.get("cl_id") if success else None

        # Batch load operational status nodes
        node_counts = []
        node_counts.append(await self.batch_loader.batch_load_services(operational_status))
        node_counts.append(await self.batch_loader.batch_load_faults(operational_status))  # Renamed from incidents
        node_counts.append(await self.batch_loader.batch_load_tickets(operational_status))
        node_counts.append(await self.batch_loader.batch_load_outage_info(operational_status))
        node_counts.append(await self.batch_loader.batch_load_tasks(operational_status))  # NEW: TSM tasks

        # VERBOSE LOGGING (Option 3): Uncomment below for detailed per-message node loading info
        # total_ops_nodes = sum(node_counts)
        # logging.info(f"✅ Batch loaded {total_ops_nodes} operational status nodes")

        # Batch load knowledge graph nodes
        kg_counts = []

        # User nodes: SERIALIZED to prevent conflicts on shared UserInfo node creation
        async with _user_node_lock:
            kg_counts.append(await self.batch_loader.batch_load_users(operational_status))

        # Other nodes: PARALLEL (no shared node conflicts or unique per ticket)
        kg_counts.append(await self.batch_loader.batch_load_contacts(operational_status))
        kg_counts.append(await self.batch_loader.batch_load_vendors(operational_status))
        kg_counts.append(await self.batch_loader.batch_load_maintenance_windows(operational_status))
        kg_counts.append(await self.batch_loader.batch_load_surveys(operational_status))
        kg_counts.append(await self.batch_loader.batch_load_configuration_items(operational_status))  # NEW: CI nodes

        # VERBOSE LOGGING (Option 3): Uncomment below for detailed per-message node loading info
        # total_kg_nodes = sum(kg_counts)
        # logging.info(f"✅ Batch loaded {total_kg_nodes} knowledge graph nodes")

        return client_id

    async def _batch_load_all_relationships(self, ticket_summary_dict: Dict[str, Any], client_id: str):
        """Batch load ALL relationships using UNWIND for maximum speed"""
        operational_status = ticket_summary_dict.get("operational_status", [])

        # Batch load core relationships (parallel - no shared node conflicts)
        core_count = await self.batch_loader.batch_load_core_relationships(operational_status, client_id)
        # VERBOSE LOGGING (Option 3): Uncomment below for detailed per-message relationship loading info
        # logging.info(f"✅ Batch loaded {core_count} core relationships")

        # Batch load knowledge graph relationships
        kg_rel_counts = []

        # User relationships: SERIALIZED to prevent conflicts on shared UserInfo nodes
        async with _user_relationship_lock:
            kg_rel_counts.append(await self.batch_loader.batch_load_user_relationships(operational_status))

        # Vendor relationships: SERIALIZED to prevent conflicts on shared VendorInfo nodes
        async with _vendor_relationship_lock:
            kg_rel_counts.append(await self.batch_loader.batch_load_vendor_relationships(operational_status))

        # Other relationships: PARALLEL (no shared node conflicts)
        kg_rel_counts.append(await self.batch_loader.batch_load_contact_relationships(operational_status))
        kg_rel_counts.append(await self.batch_loader.batch_load_ticket_hierarchy_relationships(operational_status))
        kg_rel_counts.append(await self.batch_loader.batch_load_auxiliary_relationships(operational_status))

        # NEW: TSM task and FK relationships
        kg_rel_counts.append(await self.batch_loader.batch_load_task_relationships(operational_status))
        kg_rel_counts.append(await self.batch_loader.batch_load_tsm_fk_relationships(operational_status))
        kg_rel_counts.append(await self.batch_loader.batch_load_ci_relationships(operational_status))  # NEW: CI relationships

        # VERBOSE LOGGING (Option 3): Uncomment below for detailed per-message relationship loading info
        # total_kg_rels = sum(kg_rel_counts)
        # logging.info(f"✅ Batch loaded {total_kg_rels} knowledge graph relationships")

    async def _log_processing_status(self):
        """Log node and relationship counts for monitoring."""
        # Print enhanced node counts
        records = self.memgraphClient.execute(
            "MATCH (n) RETURN labels(n) AS node_label, count(n) AS node_count;"
        )
        node_data = [record.data() for record in records]
        node_counts = pl.DataFrame(node_data) if node_data else pl.DataFrame()
        logging.info(f"📊 Node counts: {node_counts.to_dicts()}")

        # Print enhanced relationship counts
        records = self.memgraphClient.execute(
            "MATCH ()-[r]->() RETURN type(r) AS rel_type, count(r) AS count;"
        )
        rel_data = [record.data() for record in records]
        rel_counts = pl.DataFrame(rel_data) if rel_data else pl.DataFrame()
        logging.info(f"📊 Relationship counts: {rel_counts.to_dicts()}")

    def _handle_processing_error(self, error: Exception, ticket_summary: Dict[str, Any]) -> bool:
        """Handle processing errors with proper logging."""
        try:
            client_name = ticket_summary.get("client_info", {}).get("client_name", "Unknown")
            logging.error(f"❌ Error processing ticket for client '{client_name}': {error}")
            logging.debug(f"🔍 Ticket summary preview: {json.dumps(ticket_summary, indent=2)[:1000]}")
        except Exception as log_error:
            logging.error(
                f"❌ Error processing ticket (and error logging ticket data): {error} | Logging error: {log_error}"
            )
        return False

    @staticmethod
    def cast_numeric_fields(obj: dict, numeric_fields: list[str]) -> dict:
        """Casts specified fields in a dict to int if possible."""
        for field in numeric_fields:
            value = obj.get(field)
            if isinstance(value, str):
                try:
                    obj[field] = int(value.strip())
                except ValueError:
                    obj[field] = 0 if field == "outage_total" else None
            elif isinstance(value, (int, float)):
                obj[field] = int(value)
            elif value is None:
                obj[field] = 0 if field == "outage_total" else None
            else:
                obj[field] = 0 if field == "outage_total" else None
        return obj

    @staticmethod
    def cast_boolean_fields(obj: dict, fields: list) -> dict:
        """Cast specified fields to boolean, handling string representations."""
        for field in fields:
            if field in obj and obj[field] is not None:
                if isinstance(obj[field], str):
                    obj[field] = obj[field].lower() in ("true", "1", "yes", "on")
                else:
                    obj[field] = bool(obj[field])
            elif field in obj:
                obj[field] = False  # Default for null boolean fields
        return obj
