#!/usr/bin/env python3
"""
Synthetic Fault Description Generator
Generates realistic fault descriptions for testing vector search
"""
import random
import json
from datetime import datetime, timedelta
from typing import List, Dict, Any
from pathlib import Path


class SyntheticFaultDescriptionGenerator:
    """Generate synthetic fault descriptions for testing"""

    def __init__(self, templates_file: str = None):
        """Initialize with fault description templates"""
        self.templates = self._load_templates(templates_file) if templates_file else self._get_default_templates()
        self.long_samples = self._load_long_samples()  # Load production-like long samples

    def _load_templates(self, templates_file: str) -> List[Dict[str, Any]]:
        """Load fault description templates from obfuscated samples"""
        try:
            with open(templates_file, 'r') as f:
                data = json.load(f)
                return data.get('fault_descriptions', [])
        except Exception as e:
            print(f"Warning: Could not load templates from {templates_file}: {e}")
            return self._get_default_templates()

    def _load_long_samples(self) -> List[Dict[str, Any]]:
        """Load long fault description samples from obfuscated data"""
        long_samples_file = Path(__file__).parent / "long_fault_descriptions_obfuscated.json"
        try:
            with open(long_samples_file, 'r') as f:
                data = json.load(f)
                samples = data.get('fault_descriptions', [])
                # Convert to template format
                templates = []
                for sample in samples:
                    templates.append({
                        "template": sample['obfuscated_description'],
                        "length": sample['category'],  # 'long' or 'very_long'
                        "original_length": sample['fault_length']
                    })
                return templates
        except Exception as e:
            print(f"Warning: Could not load long samples: {e}")
            return []

    def _get_default_templates(self) -> List[Dict[str, Any]]:
        """Default fault description templates based on common network issues"""
        return [
            {
                "category": "fiber_outage",
                "template": "Fiber cable cut at {location}. Service down for {affected_services}. Estimated repair time: {eta}.",
                "length": "short"
            },
            {
                "category": "bgp_issues",
                "template": "BGP session down between {router1} and {router2}. Routes withdrawn: {route_count}. Investigating peering issues.",
                "length": "short"
            },
            {
                "category": "latency",
                "template": "High latency detected on circuit {circuit_id}. Current latency: {latency}ms (normal: <50ms). Customer reports slow application performance.",
                "length": "medium"
            },
            {
                "category": "packet_loss",
                "template": "Intermittent packet loss on {interface}. Loss rate: {loss_percent}%. Customer experiencing VoIP quality issues. Monitoring interface errors.",
                "length": "medium"
            },
            {
                "category": "power_outage",
                "template": "Power outage at {datacenter}. UPS runtime remaining: {ups_minutes} minutes. Generator startup in progress. All circuits affected: {circuit_count}.",
                "length": "medium"
            },
            {
                "category": "configuration_error",
                "template": "Configuration change on {device} caused routing loop. Rolling back to previous config. Affected VLANs: {vlans}. Service restoration in progress.",
                "length": "medium"
            },
            {
                "category": "hardware_failure",
                "template": "Line card failure on {device_name} slot {slot_number}. Hardware diagnostics show CRC errors. RMA initiated. Temporary rerouting via backup path.",
                "length": "long"
            },
            {
                "category": "dns_issues",
                "template": "DNS resolution failures for {domain}. Nameservers not responding. Customer cannot access cloud services. Investigating upstream DNS provider.",
                "length": "medium"
            },
            {
                "category": "ddos_attack",
                "template": "DDoS attack detected targeting {target_ip}. Traffic volume: {gbps} Gbps. Mitigation activated. Customer services degraded. Monitoring attack patterns.",
                "length": "long"
            },
            {
                "category": "maintenance_impact",
                "template": "Planned maintenance window overrun. Circuit {circuit_id} still down. Vendor on-site working to restore service. ETA: {eta}.",
                "length": "medium"
            }
        ]

    def generate_fault_description_summary(
        self,
        num_clients: int = 5,
        tickets_per_client: int = 20,
        use_realistic_distribution: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Generate FaultDescriptionSummary messages (grouped by client)

        Args:
            num_clients: Number of clients
            tickets_per_client: Average tickets per client
            use_realistic_distribution: Use realistic length distribution from production data

        Returns:
            List of FaultDescriptionSummary messages (JSON-serializable dicts)
        """
        summaries = []

        for client_num in range(1, num_clients + 1):
            client_id = f"CLIENT{client_num:03d}"

            # Vary tickets per client
            num_tickets = random.randint(
                max(1, tickets_per_client - 5),
                tickets_per_client + 5
            )

            fault_descriptions = []

            for ticket_num in range(1, num_tickets + 1):
                ticket_id = f"INC{client_num:03d}{ticket_num:04d}"

                # Generate fault description
                fault_desc = self._generate_single_fault_description(
                    ticket_id,
                    use_realistic_distribution
                )

                fault_descriptions.append({
                    "fault_description_id": ticket_id,
                    "ticket_id": ticket_id,
                    "fault_description": fault_desc,
                    "fault_occured_date": self._random_datetime().isoformat()
                })

            # Create FaultDescriptionSummary (single part for now - splitting logic later)
            summary = {
                "fault_description_summary_id": f"{client_id}_part_1_of_1",
                "client_id": client_id,
                "part_number": 1,
                "total_parts": 1,
                "fault_descriptions": fault_descriptions
            }

            summaries.append(summary)

        return summaries

    def _generate_single_fault_description(
        self,
        ticket_id: str,
        use_realistic_distribution: bool = True
    ) -> str:
        """Generate a single fault description"""

        # Select template based on realistic distribution if enabled
        if use_realistic_distribution and self.long_samples:
            # From production data: ~50% short, ~30% medium, ~15% long, ~5% very_long
            length_choice = random.choices(
                ['short', 'medium', 'long', 'very_long'],
                weights=[50, 30, 15, 5],  # Realistic production distribution
                k=1
            )[0]

            # Use production samples for long/very_long
            if length_choice in ['long', 'very_long']:
                long_templates = [t for t in self.long_samples if t.get('length') == length_choice]
                if long_templates:
                    template_data = random.choice(long_templates)
                    # Return production sample as-is (already realistic)
                    return template_data['template']

            # Use default templates for short/medium
            templates = [t for t in self.templates if t.get('length') == length_choice]
        else:
            templates = self.templates

        if not templates:
            templates = self.templates  # Fallback

        template_data = random.choice(templates)
        template_str = template_data['template']

        # Fill in template variables
        fault_desc = template_str.format(
            location=random.choice(["Main Street", "Building A", "DataCenter 1", "Campus Network"]),
            affected_services=random.choice(["Internet", "MPLS", "VPN", "Voice services"]),
            eta=f"{random.randint(1, 8)} hours",
            router1=f"RTR-{random.randint(1, 10):02d}",
            router2=f"RTR-{random.randint(11, 20):02d}",
            route_count=random.randint(10, 500),
            circuit_id=f"CKT{random.randint(1000, 9999)}",
            latency=random.randint(100, 500),
            interface=f"GigabitEthernet0/{random.randint(1, 24)}",
            loss_percent=random.randint(5, 30),
            datacenter=random.choice(["DC-EAST", "DC-WEST", "DC-CENTRAL"]),
            ups_minutes=random.randint(15, 120),
            circuit_count=random.randint(5, 50),
            device=f"SWITCH-{random.randint(1, 20):02d}",
            vlans=f"{random.randint(100, 200)}, {random.randint(201, 300)}",
            device_name=f"CORE-RTR-{random.randint(1, 10)}",
            slot_number=random.randint(1, 8),
            domain=random.choice(["example.com", "api.cloud.com", "services.net"]),
            target_ip=f"10.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}",
            gbps=random.randint(10, 100)
        )

        return fault_desc

    def _random_datetime(self) -> datetime:
        """Generate random datetime within last 30 days"""
        days_ago = random.randint(0, 30)
        hours_ago = random.randint(0, 23)
        return datetime.now() - timedelta(days=days_ago, hours=hours_ago)

    def save_to_file(self, summaries: List[Dict[str, Any]], output_file: str):
        """Save generated summaries to JSON file"""
        with open(output_file, 'w') as f:
            json.dump(summaries, f, indent=2)
        print(f"✅ Saved {len(summaries)} FaultDescriptionSummary messages to {output_file}")


def main():
    """Generate synthetic fault descriptions for testing"""
    print("🧪 Generating Synthetic Fault Descriptions for Testing")
    print("=" * 70)

    # Initialize generator
    generator = SyntheticFaultDescriptionGenerator()

    # Generate test data with realistic distribution
    summaries = generator.generate_fault_description_summary(
        num_clients=10,
        tickets_per_client=50,
        use_realistic_distribution=True
    )

    # Calculate statistics
    total_tickets = sum(len(s['fault_descriptions']) for s in summaries)
    total_chars = sum(
        len(fd['fault_description'])
        for s in summaries
        for fd in s['fault_descriptions']
    )
    avg_chars = total_chars / total_tickets if total_tickets > 0 else 0

    print(f"\n📊 Generated Statistics:")
    print(f"   Clients: {len(summaries)}")
    print(f"   Total Tickets: {total_tickets}")
    print(f"   Avg Fault Description Length: {avg_chars:.0f} chars")

    # Show length distribution
    lengths = [
        len(fd['fault_description'])
        for s in summaries
        for fd in s['fault_descriptions']
    ]
    short = sum(1 for l in lengths if l < 400)
    medium = sum(1 for l in lengths if 400 <= l < 900)
    long_count = sum(1 for l in lengths if l >= 900)

    print(f"\n📏 Length Distribution:")
    print(f"   Short (<400 chars): {short} ({short/total_tickets*100:.1f}%)")
    print(f"   Medium (400-900 chars): {medium} ({medium/total_tickets*100:.1f}%)")
    print(f"   Long (900+ chars): {long_count} ({long_count/total_tickets*100:.1f}%)")

    # Save to file
    output_file = Path(__file__).parent / "synthetic_fault_descriptions.json"
    generator.save_to_file(summaries, str(output_file))

    print(f"\n✅ Synthetic data ready for TEST_MODE")


if __name__ == "__main__":
    main()
