import pytest
import asyncio
import sys
from unittest.mock import AsyncMock, MagicMock, patch
from fastmcp import Client
from fastmcp.exceptions import ToolError


class TestMCPClient:
    """Unit tests for MCP client functionality based on test_cypher.py"""

    @pytest.fixture
    def mock_client(self):
        """Create a mock FastMCP client"""
        client = MagicMock(spec=Client)
        client.__aenter__ = AsyncMock(return_value=client)
        client.__aexit__ = AsyncMock(return_value=None)
        return client

    @pytest.fixture
    def mcp_server_url(self):
        """Test server URL"""
        return "http://localhost:8003/mcp"

    @pytest.mark.asyncio
    async def test_server_connectivity_success(self, mcp_server_url):
        """Test successful server connectivity check"""
        with patch('httpx.AsyncClient') as mock_httpx:
            mock_client = AsyncMock()
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_client.get.return_value = mock_response
            mock_httpx.return_value.__aenter__.return_value = mock_client

            from tests.unit.test_mcp_client import wait_for_server
            result = await wait_for_server(mcp_server_url, max_attempts=1)

            assert result is True
            mock_client.get.assert_called_once_with(mcp_server_url)

    @pytest.mark.asyncio
    async def test_server_connectivity_failure(self, mcp_server_url):
        """Test server connectivity failure"""
        with patch('httpx.AsyncClient') as mock_httpx:
            mock_client = AsyncMock()
            mock_client.get.side_effect = Exception("Connection failed")
            mock_httpx.return_value.__aenter__.return_value = mock_client

            from tests.unit.test_mcp_client import wait_for_server
            result = await wait_for_server(mcp_server_url, max_attempts=1, delay=0.1)

            assert result is False

    @pytest.mark.asyncio
    async def test_list_tools_success(self, mock_client):
        """Test successful tool listing"""
        expected_tools = [
            {"name": "ask_tickets_question", "description": "Query ticket database"}
        ]
        mock_client.list_tools.return_value = expected_tools

        tools = await mock_client.list_tools()

        assert tools == expected_tools
        mock_client.list_tools.assert_called_once()

    @pytest.mark.asyncio
    async def test_call_tool_success(self, mock_client):
        """Test successful tool call"""
        user_query = "Show all tickets for client ABC"
        expected_response = [{"ticket_id": "123", "client": "ABC", "status": "open"}]

        mock_client.call_tool.return_value = expected_response

        response = await mock_client.call_tool("ask_tickets_question", {"user_query": user_query})

        assert response == expected_response
        mock_client.call_tool.assert_called_once_with("ask_tickets_question", {"user_query": user_query})

    @pytest.mark.asyncio
    async def test_call_tool_error(self, mock_client):
        """Test tool call error handling"""
        user_query = "Invalid query"

        mock_client.call_tool.side_effect = ToolError("Tool execution failed")

        with pytest.raises(ToolError) as exc_info:
            await mock_client.call_tool("ask_tickets_question", {"user_query": user_query})

        assert "Tool execution failed" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_context_manager_usage(self, mock_client):
        """Test proper context manager usage"""
        async with mock_client as client:
            await client.list_tools()

        mock_client.__aenter__.assert_called_once()
        mock_client.__aexit__.assert_called_once()

    def test_client_configuration(self):
        """Test client configuration structure"""
        mcp_server_url = "http://localhost:8003/mcp"

        config = {
            "mcpServers": {
                "TicketServer": {
                    "url": mcp_server_url,
                    "transport": "streamable-http"
                }
            }
        }

        assert "mcpServers" in config
        assert "TicketServer" in config["mcpServers"]
        assert config["mcpServers"]["TicketServer"]["url"] == mcp_server_url
        assert config["mcpServers"]["TicketServer"]["transport"] == "streamable-http"

    @pytest.mark.asyncio
    async def test_query_processing(self):
        """Test query argument processing"""
        test_args = ["script.py", "Show all open tickets"]

        with patch.object(sys, 'argv', test_args):
            assert len(sys.argv) >= 2
            user_query = sys.argv[1]
            assert user_query == "Show all open tickets"

    @pytest.mark.asyncio
    async def test_integration_workflow(self, mock_client):
        """Test complete integration workflow"""
        # Setup
        user_query = "Find tickets with high priority"
        expected_tools = [{"name": "ask_tickets_question"}]
        expected_response = [{"ticket_id": "456", "priority": "high"}]

        mock_client.list_tools.return_value = expected_tools
        mock_client.call_tool.return_value = expected_response

        # Execute workflow
        async with mock_client as client:
            # List available tools
            tools = await client.list_tools()
            assert len(tools) > 0

            # Call the tool
            response = await client.call_tool("ask_tickets_question", {"user_query": user_query})
            assert response == expected_response

        # Verify calls
        mock_client.list_tools.assert_called()
        mock_client.call_tool.assert_called_once_with("ask_tickets_question", {"user_query": user_query})


# Utility functions for testing (extracted from original test_cypher.py)
async def wait_for_server(url: str, max_attempts: int = 10, delay: float = 1.0) -> bool:
    """Wait for the server to be available."""
    import httpx

    for attempt in range(max_attempts):
        try:
            async with httpx.AsyncClient() as http_client:
                response = await http_client.get(url)
                if response.status_code in [200, 307]:
                    return True
        except Exception:
            if attempt < max_attempts - 1:
                await asyncio.sleep(delay)
    return False


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
