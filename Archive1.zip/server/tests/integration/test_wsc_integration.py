#!/usr/bin/env python3
# flake8: noqa: E226
"""
WS-C Integration Test Script
Tests resolved_tickets_service and servicenow_client with real connections.

Usage:
    # Test Memgraph query only (no ServiceNow credentials needed)
    python test_wsc_integration.py --memgraph-only

    # Test ServiceNow API only (needs credentials in env)
    python test_wsc_integration.py --servicenow-only --sys-id abc123 --ticket-type case

    # Test full flow
    python test_wsc_integration.py --full
"""
import asyncio
import argparse
import sys
import os

# Add app to path (tests/integration/ -> server/app)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'app'))

# Set required env vars if not already set (before importing Config)
os.environ.setdefault("MEMGRAPH_MAX_CONCURRENT", "10")
os.environ.setdefault("MILVUS_MAX_CONCURRENT", "20")

from configs.config import Config  # noqa: E402
from data_access.memgraphClient import MemgraphClient  # noqa: E402
from services.resolved_tickets_service import ResolvedTicketsService  # noqa: E402
from services.servicenow_client import ServiceNowClient  # noqa: E402


async def run_memgraph_query_test():
    """Test querying Memgraph for resolved tickets."""
    print("\n" + "=" * 60)
    print("TEST 1: Memgraph Query for Resolved Tickets")
    print("=" * 60)

    try:
        config = Config()
        memgraph = MemgraphClient(
            uri=config.memgraph_uri,
            user=config.memgraph_user,
            password=config.memgraph_password,
            database=config.memgraph_database
        )
        service = ResolvedTicketsService(memgraph, config)

        # Get stats first
        print("\n📊 Getting notes processing stats...")
        stats = await service.get_notes_processing_stats()
        print(f"   Resolved total: {stats.get('resolved_total', 0)}")
        print(f"   With notes: {stats.get('resolved_with_notes', 0)}")
        print(f"   Pending: {stats.get('resolved_pending', 0)}")

        # Get resolved tickets (limit to 5 for testing)
        print("\n🔍 Querying resolved tickets (first 5)...")
        tickets = await service.get_resolved_tickets(include_already_processed=False)

        if not tickets:
            print("   ⚠️  No resolved tickets found without notes")
            # Try including already processed
            tickets = await service.get_resolved_tickets(include_already_processed=True)
            if tickets:
                print(f"   Found {len(tickets)} resolved tickets (including processed)")

        for i, ticket in enumerate(tickets[:5]):
            print(f"\n   [{i+1}] {ticket.ticket_id}")
            print(f"       sys_id: {ticket.ticket_sys_id}")
            print(f"       type: {ticket.ticket_type}")
            print(f"       client: {ticket.client_name}")

        if len(tickets) > 5:
            print(f"\n   ... and {len(tickets) - 5} more")

        print("\n✅ Memgraph query test PASSED")
        return tickets[:5] if tickets else []

    except Exception as e:
        print(f"\n❌ Memgraph query test FAILED: {e}")
        import traceback
        traceback.print_exc()
        return []


async def run_servicenow_api_test(sys_id: str, ticket_type: str, ticket_id: str = "TEST"):
    """Test ServiceNow API for a specific ticket."""
    print("\n" + "="*60)
    print("TEST 2: ServiceNow API")
    print("="*60)

    config = Config()

    # Check credentials
    if not config.servicenow_username or not config.servicenow_password:
        print("\n⚠️  ServiceNow credentials not set!")
        print("   Set SERVICENOW_USERNAME and SERVICENOW_PASSWORD environment variables")
        return None

    print("\n📡 ServiceNow Config:")
    print(f"   Base URL: {config.servicenow_base_url}")
    print(f"   Username: {config.servicenow_username}")
    print(f"   Timeout: {config.servicenow_timeout}s")
    print(f"   Max concurrent: {config.servicenow_max_concurrent}")

    client = ServiceNowClient(config)

    try:
        print(f"\n🔍 Fetching notes for {ticket_type} {sys_id}...")

        data = await client.fetch_ticket_notes(
            ticket_sys_id=sys_id,
            ticket_id=ticket_id,
            ticket_type=ticket_type
        )

        if not data.fetch_success:
            print(f"\n❌ Fetch failed: {data.error_message}")
            return None

        print(f"\n📋 Results for {data.ticket_id}:")
        print(f"   Notes: {len(data.notes)}")
        print(f"   Emails: {len(data.emails)}")
        print(f"   Field changes: {len(data.field_changes)}")

        # Show sample data
        if data.notes:
            print("\n   Sample note:")
            note = data.notes[0]
            print(f"      [{note.created_on}] ({note.element_type})")
            print(f"      {note.note_text[:200]}..." if len(note.note_text) > 200 else f"      {note.note_text}")

        if data.field_changes:
            print("\n   Sample field changes:")
            for fc in data.field_changes[:3]:
                old = fc.old_value[:50] if fc.old_value else "null"
                new = fc.new_value[:50] if fc.new_value else "null"
                print(f"      {fc.field_name}: {old} → {new}")

        # Test combine for extraction
        print(f"\n📝 Combined text length: {len(client.combine_for_extraction(data))} chars")

        print("\n✅ ServiceNow API test PASSED")
        return data

    except Exception as e:
        print(f"\n❌ ServiceNow API test FAILED: {e}")
        import traceback
        traceback.print_exc()
        return None
    finally:
        await client.close()


async def run_full_flow_test():
    """Test full flow: Memgraph → ServiceNow."""
    print("\n" + "="*60)
    print("TEST 3: Full Flow (Memgraph → ServiceNow)")
    print("="*60)

    # First get tickets from Memgraph
    tickets = await run_memgraph_query_test()

    if not tickets:
        print("\n⚠️  No tickets to test ServiceNow with")
        return

    # Test ServiceNow with first ticket
    ticket = tickets[0]
    print(f"\n🔗 Testing ServiceNow with: {ticket.ticket_id}")

    await run_servicenow_api_test(
        sys_id=ticket.ticket_sys_id,
        ticket_type=ticket.ticket_type,
        ticket_id=ticket.ticket_id
    )


async def main():
    parser = argparse.ArgumentParser(description="WS-C Integration Tests")
    parser.add_argument("--memgraph-only", action="store_true", help="Test Memgraph query only")
    parser.add_argument("--servicenow-only", action="store_true", help="Test ServiceNow API only")
    parser.add_argument("--full", action="store_true", help="Test full flow")
    parser.add_argument("--sys-id", type=str, help="ServiceNow sys_id for testing")
    parser.add_argument("--ticket-type", type=str, default="case", help="Ticket type (case, incident, problem, request)")
    parser.add_argument("--ticket-id", type=str, default="TEST", help="Ticket ID for display")

    args = parser.parse_args()

    print("\n" + "="*60)
    print("WS-C INTEGRATION TEST")
    print("="*60)

    if args.memgraph_only:
        await run_memgraph_query_test()
    elif args.servicenow_only:
        if not args.sys_id:
            print("❌ --sys-id required for ServiceNow-only test")
            sys.exit(1)
        await run_servicenow_api_test(args.sys_id, args.ticket_type, args.ticket_id)
    elif args.full:
        await run_full_flow_test()
    else:
        # Default: run memgraph test
        print("No test specified. Running Memgraph query test...")
        print("Use --help for options")
        await run_memgraph_query_test()


if __name__ == "__main__":
    asyncio.run(main())
