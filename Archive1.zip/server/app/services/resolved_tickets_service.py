"""
Resolved Tickets Service
Queries Memgraph for resolved TSM tickets that need notes processing.

Only TSM tickets (incident, case, problem, request) have ticket_sys_id.
CMD-only tickets cannot fetch notes from ServiceNow API.
"""
import logging
from typing import List, Dict, Optional
from dataclasses import dataclass

from data_access.memgraphClient import MemgraphClient
from configs.config import Config


@dataclass
class ResolvedTicket:
    """Represents a resolved ticket ready for notes fetching"""
    ticket_sys_id: str
    ticket_id: str
    ticket_type: str
    client_name: str
    client_id: Optional[str] = None


class ResolvedTicketsService:
    """
    Service to query Memgraph for resolved tickets that need notes processing.

    Used to identify tickets for ServiceNow API calls.
    """

    # Query for resolved TSM tickets with sys_id
    # Resolved tickets auto-close within 48 hours, so this is naturally bounded
    RESOLVED_TICKETS_QUERY = """
    MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
    WHERE t.ticket_status = 'resolved'
      AND t.ticket_sys_id IS NOT NULL
    RETURN t.ticket_sys_id AS ticket_sys_id,
           t.ticket_id AS ticket_id,
           t.ticket_type AS ticket_type,
           c.client_name AS client_name,
           c.cl_id AS client_id
    ORDER BY t.ticket_id
    """

    # Check if ticket has NoteInfo processed
    NOTES_PROCESSED_QUERY = """
    MATCH (t:Ticket {ticket_sys_id: $ticket_sys_id})
    OPTIONAL MATCH (t)-[:HAS_NOTES]->(n:NoteInfo)
    RETURN n IS NOT NULL AS has_notes
    """

    def __init__(self, memgraph_client: MemgraphClient, config: Config = None):
        self.memgraph_client = memgraph_client
        self.config = config or Config()
        self.logger = logging.getLogger(__name__)

    async def get_resolved_tickets(self) -> List[ResolvedTicket]:
        """
        Get all resolved TSM tickets for notes processing.

        Resolved tickets auto-close within 48 hours, so this query is naturally bounded.
        NoteInfo will be upserted, so reprocessing is safe.

        Returns:
            List of ResolvedTicket objects ready for ServiceNow API calls.
        """
        try:
            self.logger.info("Querying Memgraph for resolved tickets")
            records = await self.memgraph_client.execute(self.RESOLVED_TICKETS_QUERY)

            tickets = []
            for record in records:
                ticket = ResolvedTicket(
                    ticket_sys_id=record["ticket_sys_id"],
                    ticket_id=record["ticket_id"],
                    ticket_type=record["ticket_type"],
                    client_name=record["client_name"],
                    client_id=record.get("client_id")
                )
                tickets.append(ticket)

            self.logger.info(f"Found {len(tickets)} resolved tickets for notes processing")

            # Log breakdown by ticket type
            if tickets:
                type_counts = {}
                for t in tickets:
                    type_counts[t.ticket_type] = type_counts.get(t.ticket_type, 0) + 1
                self.logger.info(f"Breakdown by type: {type_counts}")

            return tickets

        except Exception as e:
            self.logger.error(f"Error querying resolved tickets: {e}", exc_info=True)
            return []

    async def get_resolved_tickets_by_type(self, ticket_type: str) -> List[ResolvedTicket]:
        """
        Get resolved tickets filtered by ticket type.

        Args:
            ticket_type: One of 'incident', 'case', 'problem', 'request'

        Returns:
            List of ResolvedTicket objects of the specified type.
        """
        query = """
        MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
        WHERE t.ticket_status = 'resolved'
          AND t.ticket_sys_id IS NOT NULL
          AND t.ticket_type = $ticket_type
        RETURN t.ticket_sys_id AS ticket_sys_id,
               t.ticket_id AS ticket_id,
               t.ticket_type AS ticket_type,
               c.client_name AS client_name,
               c.cl_id AS client_id
        ORDER BY t.ticket_id
        """

        try:
            self.logger.info(f"Querying resolved tickets of type: {ticket_type}")
            records = await self.memgraph_client.execute(query, {"ticket_type": ticket_type})

            tickets = [
                ResolvedTicket(
                    ticket_sys_id=record["ticket_sys_id"],
                    ticket_id=record["ticket_id"],
                    ticket_type=record["ticket_type"],
                    client_name=record["client_name"],
                    client_id=record.get("client_id")
                )
                for record in records
            ]

            self.logger.info(f"Found {len(tickets)} resolved {ticket_type} tickets")
            return tickets

        except Exception as e:
            self.logger.error(f"Error querying resolved {ticket_type} tickets: {e}", exc_info=True)
            return []

    async def has_notes_processed(self, ticket_sys_id: str) -> bool:
        """
        Check if a ticket already has notes processed.

        Args:
            ticket_sys_id: The ServiceNow sys_id of the ticket

        Returns:
            True if NoteInfo node exists for this ticket, False otherwise.
        """
        try:
            records = await self.memgraph_client.execute(
                self.NOTES_PROCESSED_QUERY,
                {"ticket_sys_id": ticket_sys_id}
            )

            if records:
                return records[0]["has_notes"]
            return False

        except Exception as e:
            self.logger.error(f"Error checking notes for {ticket_sys_id}: {e}")
            return False

    async def get_ticket_count_by_status(self) -> Dict[str, int]:
        """
        Get count of tickets by status for monitoring.

        Returns:
            Dict with status as key and count as value.
        """
        query = """
        MATCH (t:Ticket)
        WHERE t.ticket_sys_id IS NOT NULL
        RETURN t.ticket_status AS status, count(t) AS count
        ORDER BY count DESC
        """

        try:
            records = await self.memgraph_client.execute(query)
            return {record["status"]: record["count"] for record in records}
        except Exception as e:
            self.logger.error(f"Error getting ticket counts: {e}")
            return {}

    async def get_notes_processing_stats(self) -> Dict[str, int]:
        """
        Get statistics on notes processing progress.

        Returns:
            Dict with 'resolved_total', 'resolved_with_notes', 'resolved_pending'
        """
        query = """
        MATCH (t:Ticket)
        WHERE t.ticket_status = 'resolved'
          AND t.ticket_sys_id IS NOT NULL
        WITH t
        OPTIONAL MATCH (t)-[:HAS_NOTES]->(n:NoteInfo)
        RETURN
            count(t) AS resolved_total,
            count(n) AS resolved_with_notes
        """

        try:
            records = await self.memgraph_client.execute(query)
            if records:
                total = records[0]["resolved_total"]
                with_notes = records[0]["resolved_with_notes"]
                return {
                    "resolved_total": total,
                    "resolved_with_notes": with_notes,
                    "resolved_pending": total - with_notes
                }
            return {"resolved_total": 0, "resolved_with_notes": 0, "resolved_pending": 0}

        except Exception as e:
            self.logger.error(f"Error getting notes stats: {e}")
            return {"resolved_total": 0, "resolved_with_notes": 0, "resolved_pending": 0}
