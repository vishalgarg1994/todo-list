"""
Ollama Embedding Service
Handles generating embeddings using Ollama's nomic-embed-text-v1.5 model
"""
import logging
import requests
import asyncio
from concurrent.futures import ThreadPoolExecutor
from typing import List, Optional
from configs.config import Config


class EmbeddingService:
    """Service for generating text embeddings using Ollama"""

    def __init__(self, config: Config = None):
        """
        Initialize embedding service

        Args:
            config: Configuration object with Ollama settings
        """
        self.config = config or Config()
        self.base_url = self.config.ollama_embedding_base_url
        self.model = self.config.ollama_embedding_model
        self.timeout = self.config.ollama_embedding_timeout
        self.max_concurrent = self.config.ollama_max_concurrent
        self.embedding_endpoint = f"{self.base_url}/api/embeddings"

        logging.info(f"Initialized EmbeddingService: {self.base_url}, model={self.model}, "
                    f"timeout={self.timeout}s, max_concurrent={self.max_concurrent}")

    def generate_embedding(self, text: str) -> Optional[List[float]]:
        """
        Generate embedding for a single text

        Args:
            text: Text to embed (fault description)

        Returns:
            768-dim embedding vector or None on error
        """
        try:
            # Truncate text if too long (nomic-embed-text-v1.5 supports 8192 tokens ~30K chars)
            # For safety, truncate at 25K chars
            if len(text) > 25000:
                logging.warning(f"Text length {len(text)} exceeds 25K, truncating...")
                text = text[:25000]

            # Call Ollama API
            response = requests.post(
                self.embedding_endpoint,
                json={
                    "model": self.model,
                    "prompt": text
                },
                timeout=self.timeout
            )

            response.raise_for_status()
            data = response.json()

            # Extract embedding from response
            embedding = data.get("embedding")
            if not embedding:
                logging.error(f"No embedding in response: {data}")
                return None

            # Validate dimension (should be 768 for nomic-embed-text)
            if len(embedding) != 768:
                logging.error(f"Unexpected embedding dimension: {len(embedding)} (expected 768)")
                return None

            logging.debug(f"Generated embedding with dimension: {len(embedding)}")
            return embedding

        except requests.exceptions.Timeout:
            logging.error(f"Timeout generating embedding (>{self.timeout}s)")
            return None
        except requests.exceptions.RequestException as e:
            logging.error(f"HTTP error generating embedding: {e}")
            return None
        except Exception as e:
            logging.error(f"Unexpected error generating embedding: {e}")
            return None

    async def generate_embeddings_batch(
        self,
        texts: List[str],
        batch_size: int = 20,
        max_concurrent: Optional[int] = None
    ) -> List[Optional[List[float]]]:
        """
        Generate embeddings for multiple texts using parallel execution

        Args:
            texts: List of texts to embed
            batch_size: Process in batches for progress tracking
            max_concurrent: Maximum number of concurrent Ollama API calls (default: from config)

        Returns:
            List of 768-dim embeddings (None for failed texts)
        """
        # Use config value if not specified
        if max_concurrent is None:
            max_concurrent = self.max_concurrent

        total = len(texts)
        logging.info(f"Generating embeddings for {total} texts with max_concurrent={max_concurrent}...")

        # Use ThreadPoolExecutor to run sync requests.post() in parallel
        loop = asyncio.get_event_loop()
        executor = ThreadPoolExecutor(max_workers=max_concurrent)

        async def generate_one(text: str) -> Optional[List[float]]:
            """Generate embedding for one text in executor thread"""
            return await loop.run_in_executor(executor, self.generate_embedding, text)

        # Process all texts in parallel batches
        embeddings = []
        for i in range(0, total, batch_size):
            batch = texts[i:i + batch_size]
            batch_num = (i // batch_size) + 1
            total_batches = (total + batch_size - 1) // batch_size

            logging.info(f"Processing batch {batch_num}/{total_batches} ({len(batch)} texts) in parallel...")

            # Generate embeddings for this batch in parallel
            batch_embeddings = await asyncio.gather(*[generate_one(text) for text in batch], return_exceptions=True)

            # Handle exceptions from gather
            for j, result in enumerate(batch_embeddings):
                if isinstance(result, Exception):
                    logging.error(f"Exception generating embedding: {result}")
                    embeddings.append(None)
                else:
                    embeddings.append(result)

            # Log progress
            completed = len(embeddings)
            success_count = sum(1 for e in embeddings if e is not None)
            logging.info(
                f"Progress: {completed}/{total} texts processed, "
                f"{success_count} successful embeddings"
            )

        # Cleanup executor
        executor.shutdown(wait=False)

        # Final summary
        success_count = sum(1 for e in embeddings if e is not None)
        failure_count = total - success_count
        logging.info(
            f"✅ Batch embedding complete: {success_count}/{total} successful, "
            f"{failure_count} failed"
        )

        return embeddings

    def test_connection(self) -> bool:
        """
        Test connection to Ollama service

        Returns:
            True if connection successful, False otherwise
        """
        try:
            # Try to generate embedding for test text
            test_embedding = self.generate_embedding("test connection")

            if test_embedding and len(test_embedding) == 768:
                logging.info(f"✅ Ollama connection test successful")
                return True
            else:
                logging.error(f"❌ Ollama connection test failed: invalid response")
                return False

        except Exception as e:
            logging.error(f"❌ Ollama connection test failed: {e}")
            return False

    def get_model_info(self) -> dict:
        """
        Get information about the loaded model

        Returns:
            Model information dict
        """
        try:
            # Call Ollama tags API to list models
            tags_url = f"{self.base_url}/api/tags"
            response = requests.get(tags_url, timeout=10)
            response.raise_for_status()

            data = response.json()
            models = data.get("models", [])

            # Find our model - extract base name without tag
            # e.g., "telecom-nomic-embed:latest" -> "telecom-nomic-embed"
            model_base = self.model.split(":")[0] if ":" in self.model else self.model

            for model_info in models:
                if model_info.get("name", "").startswith(model_base):
                    logging.info(f"Found model: {model_info}")
                    return {
                        "name": model_info.get("name"),
                        "size": model_info.get("size"),
                        "modified_at": model_info.get("modified_at")
                    }

            logging.warning(f"Model {self.model} not found in loaded models")
            return {"name": self.model, "status": "not_loaded"}

        except Exception as e:
            logging.error(f"Failed to get model info: {e}")
            return {"error": str(e)}
