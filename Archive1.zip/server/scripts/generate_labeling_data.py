#!/usr/bin/env python3
"""
Generate Labeling Data for Fine-tuning

Pulls resolved/closed tickets and generates readable text files for manual labeling.

Usage:
    python generate_labeling_data.py

Output:
    ./labeling_data/{ticket_id}_labeling.txt
"""
import asyncio
import logging
import os
import sys
from datetime import datetime
from pathlib import Path

# Set required env vars with defaults BEFORE importing Config
os.environ.setdefault("MEMGRAPH_MAX_CONCURRENT", "5")
os.environ.setdefault("MILVUS_MAX_CONCURRENT", "10")

# ServiceNow API credentials
os.environ.setdefault("SERVICENOW_USERNAME", "ai_bot.integration.dev")
os.environ.setdefault("SERVICENOW_PASSWORD", "GTT@idev25!")

# Memgraph connection
os.environ.setdefault("MEMGRAPH_URI", "bolt://localhost:7687")
os.environ.setdefault("MEMGRAPH_USER", "")
os.environ.setdefault("MEMGRAPH_PASSWORD", "")

# Add parent app directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "app"))

from configs.config import Config
from data_access.memgraphClient import MemgraphClient
from services.servicenow_client import ServiceNowClient


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Config
OUTPUT_DIR = "./labeling_data"

# Query for resolved AND closed tickets with all original values
CLOSED_TICKETS_QUERY = """
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
WHERE t.ticket_status IN ['resolved', 'closed']
  AND t.ticket_sys_id IS NOT NULL
OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
RETURN t.ticket_sys_id AS ticket_sys_id,
       t.ticket_id AS ticket_id,
       t.ticket_type AS ticket_type,
       t.ticket_status AS ticket_status,
       t.priority AS priority,
       t.responsible_party AS responsible_party,
       t.close_code AS close_code,
       t.created_on AS created_on,
       t.closed_on AS closed_on,
       c.client_name AS client_name,
       c.client_id AS client_id,
       o.mttr AS mttr,
       o.resolution AS resolution_notes,
       o.customer_resolution AS customer_resolution,
       o.rfo AS outage_rfo,
       f.short_description AS fault_description,
       f.rfo AS fault_rfo
ORDER BY t.closed_on DESC
"""


def generate_ticket_file(
    ticket: dict,
    notes_data,
    output_dir: Path
) -> str:
    """Generate a readable labeling file for one ticket"""

    ticket_id = ticket["ticket_id"]
    filename = f"{ticket_id}_labeling.txt"
    filepath = output_dir / filename

    lines = []

    # Header
    lines.append("=" * 80)
    lines.append(f"TICKET: {ticket_id}")
    lines.append(f"SYS_ID: {ticket['ticket_sys_id']}")
    lines.append(f"TYPE: {ticket['ticket_type']}")
    lines.append(f"CLIENT: {ticket['client_name']}")
    lines.append(f"CREATED: {ticket.get('created_on', 'N/A')}")
    lines.append(f"CLOSED: {ticket.get('closed_on', 'N/A')}")
    lines.append("=" * 80)
    lines.append("")

    # Original ServiceNow values
    lines.append("ORIGINAL VALUES (from ServiceNow):")
    lines.append("-" * 40)
    lines.append(f"  priority: {ticket.get('priority')}")
    lines.append(f"  responsible_party: {ticket.get('responsible_party')}")
    lines.append(f"  mttr_minutes: {ticket.get('mttr')}")
    lines.append(f"  close_code: {ticket.get('close_code')}")
    lines.append(f"  rfo: {ticket.get('outage_rfo') or ticket.get('fault_rfo')}")
    lines.append(f"  resolution_notes: {ticket.get('resolution_notes')}")
    lines.append(f"  customer_resolution: {ticket.get('customer_resolution')}")
    lines.append(f"  fault_description: {ticket.get('fault_description')}")
    lines.append("")

    # Notes section
    lines.append("=" * 80)
    lines.append("NOTES")
    lines.append("=" * 80)
    if notes_data.notes:
        for note in sorted(notes_data.notes, key=lambda n: n.created_on):
            lines.append("")
            lines.append(f"[{note.created_on}] ({note.element_type})")
            lines.append("-" * 40)
            lines.append(note.note_text.strip())
    else:
        lines.append("(No notes)")
    lines.append("")

    # Emails section
    lines.append("=" * 80)
    lines.append("EMAILS")
    lines.append("=" * 80)
    if notes_data.emails:
        for email in sorted(notes_data.emails, key=lambda e: e.created_on):
            lines.append("")
            lines.append(f"[{email.created_on}] {email.email_type.upper()}")
            lines.append(f"From: {email.from_address}")
            lines.append(f"To: {email.to_address}")
            lines.append(f"Subject: {email.subject}")
            lines.append("-" * 40)
            # Strip HTML and truncate
            body = _strip_html(email.body)
            if len(body) > 2000:
                body = body[:2000] + "... [TRUNCATED]"
            lines.append(body)
    else:
        lines.append("(No emails)")
    lines.append("")

    # Field changes section
    lines.append("=" * 80)
    lines.append("FIELD CHANGES")
    lines.append("=" * 80)
    if notes_data.field_changes:
        for fc in sorted(notes_data.field_changes, key=lambda f: f.created_on):
            old_val = (fc.old_value[:80] + "...") if fc.old_value and len(fc.old_value) > 80 else fc.old_value
            new_val = (fc.new_value[:80] + "...") if fc.new_value and len(fc.new_value) > 80 else fc.new_value
            lines.append(f"[{fc.created_on}] {fc.field_name}: {old_val} -> {new_val}")
    else:
        lines.append("(No field changes)")
    lines.append("")

    # Labeling section
    lines.append("=" * 80)
    lines.append("YOUR CORRECTIONS (fill in the correct values below)")
    lines.append("=" * 80)
    lines.append("")
    lines.append("# Instructions:")
    lines.append("# - Review the notes/emails above")
    lines.append("# - Fill in what the CORRECT values should be")
    lines.append("# - Leave blank if original value is correct")
    lines.append("# - For fault_type use: HardDown, SoftDown, Degraded, Latency, PacketLoss, Maintenance, Unknown")
    lines.append("# - For responsible_party use: GTT, Customer, Supplier, Delivery, Unknown")
    lines.append("")
    lines.append("priority: ")
    lines.append("fault_type: ")
    lines.append("responsible_party: ")
    lines.append("mttr_minutes: ")
    lines.append("rfo: ")
    lines.append("root_cause: ")
    lines.append("resolution_notes: ")
    lines.append("internal_notes: ")
    lines.append("customer_resolution: ")
    lines.append("")
    lines.append("# End of labeling for " + ticket_id)
    lines.append("=" * 80)

    # Write file
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))

    return filename


def _strip_html(text: str) -> str:
    """Remove HTML tags from text"""
    import re
    text = re.sub(r'<(script|style)[^>]*>.*?</\1>', '', text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<[^>]+>', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


async def main():
    """Main function to generate labeling data"""

    output_path = Path(OUTPUT_DIR)
    output_path.mkdir(parents=True, exist_ok=True)

    logger.info(f"Output directory: {output_path.absolute()}")

    # Initialize clients
    config = Config()
    memgraph_client = MemgraphClient(
        uri=config.memgraph_uri,
        user=config.memgraph_user,
        password=config.memgraph_password
    )
    servicenow_client = ServiceNowClient(config)

    try:
        # Connect to Memgraph
        await memgraph_client.connect()
        logger.info("Connected to Memgraph")

        # Query closed tickets
        logger.info("Querying resolved/closed tickets...")
        records = await memgraph_client.execute(CLOSED_TICKETS_QUERY)
        tickets = [dict(r) for r in records]

        logger.info(f"Found {len(tickets)} resolved/closed tickets")

        if not tickets:
            logger.warning("No tickets found")
            return

        # Fetch notes for each ticket
        logger.info("Fetching notes from ServiceNow API...")

        generated_files = []
        for i, ticket in enumerate(tickets, 1):
            ticket_id = ticket["ticket_id"]
            ticket_sys_id = ticket["ticket_sys_id"]
            ticket_type = ticket["ticket_type"]

            logger.info(f"[{i}/{len(tickets)}] Processing {ticket_id}...")

            # Fetch notes/emails/field_changes
            notes_data = await servicenow_client.fetch_ticket_notes(
                ticket_sys_id=ticket_sys_id,
                ticket_id=ticket_id,
                ticket_type=ticket_type
            )

            if not notes_data.fetch_success:
                logger.warning(f"  Failed to fetch notes: {notes_data.error_message}")
                continue

            # Generate labeling file
            filename = generate_ticket_file(ticket, notes_data, output_path)
            generated_files.append(filename)

            logger.info(f"  Generated {filename} ({len(notes_data.notes)} notes, {len(notes_data.emails)} emails)")

        # Summary
        logger.info("")
        logger.info("=" * 60)
        logger.info(f"COMPLETE: Generated {len(generated_files)} labeling files")
        logger.info(f"Output directory: {output_path.absolute()}")
        logger.info("=" * 60)

        # Write index file
        index_path = output_path / "_index.txt"
        with open(index_path, 'w') as f:
            f.write(f"Labeling Data Generated: {datetime.now().isoformat()}\n")
            f.write(f"Total files: {len(generated_files)}\n")
            f.write("\nFiles:\n")
            for fname in generated_files:
                f.write(f"  {fname}\n")

        logger.info(f"Index written to {index_path}")

    finally:
        await servicenow_client.close()
        await memgraph_client.closeConnection()


if __name__ == "__main__":
    asyncio.run(main())
