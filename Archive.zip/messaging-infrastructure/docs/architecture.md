# Eva Messaging Infrastructure Architecture

**Enterprise messaging backbone for Eva platform applications**

---

## 🏗️ System Architecture

### High-Level Overview

```mermaid
graph TB
    subgraph "Eva Applications Layer"
        APP1[Ticketing Application<br/>Port 8080]
        APP2[Analytics Application<br/>(Future)]
        APP3[CRM Application<br/>(Future)]
    end

    subgraph "Eva Messaging Infrastructure"
        subgraph "API Layer"
            API[Stream Manager API<br/>Port 8080<br/>FastAPI + Swagger]
        end

        subgraph "Messaging Layer"
            NATS[NATS JetStream<br/>Port 4222<br/>Message Broker]
            MON[NATS Monitor<br/>Port 8222<br/>Web UI]
        end

        subgraph "Storage Layer"
            STORE[Persistent Storage<br/>JetStream File Store]
        end

        subgraph "Management Layer"
            INIT[Stream Initializer<br/>One-time Setup]
            UI[Message Viewer<br/>Port 3001<br/>Development Tool]
        end
    end

    subgraph "External Systems"
        DB[(PostgreSQL<br/>Database)]
        KUBE[Kubernetes<br/>Orchestration]
    end

    APP1 --> NATS
    APP2 --> NATS
    APP3 --> NATS

    API --> NATS
    NATS --> STORE
    NATS --> MON

    INIT --> NATS
    UI --> NATS

    APP1 --> DB
    KUBE --> API
    KUBE --> NATS

    style NATS fill:#f9f,stroke:#333,stroke-width:4px
    style API fill:#bbf,stroke:#333,stroke-width:2px
    style APP1 fill:#bfb,stroke:#333,stroke-width:2px
```

---

## 🔧 Component Details

### Core Infrastructure Components

#### **NATS JetStream Server**
- **Purpose**: High-performance message broker with persistence
- **Technology**: NATS Server 2.x with JetStream enabled
- **Deployment**: Docker container (`eva-nats`)
- **Persistence**: File-based storage with configurable retention
- **Clustering**: Ready for multi-node deployment

**Key Features:**
- Message durability and replay
- Stream-based pub/sub with subjects
- Consumer management with acknowledgments
- Built-in monitoring and metrics

#### **Stream Manager API**
- **Purpose**: REST API for stream lifecycle management
- **Technology**: Python FastAPI with automatic OpenAPI docs
- **Deployment**: Docker container (`eva-stream-manager`)
- **Authentication**: Configurable (dev: none, prod: JWT/certs)

**API Capabilities:**
- Stream creation and configuration
- Application provisioning
- Stream validation and health checks
- Swagger UI for interactive testing

#### **Stream Initializer**
- **Purpose**: Automated infrastructure setup
- **Technology**: Python CLI application
- **Deployment**: Init container (runs once)
- **Configuration**: YAML-driven stream definitions

**Initialization Process:**
1. Wait for NATS availability
2. Create domain-specific streams
3. Configure retention policies
4. Validate stream creation
5. Exit successfully

---

## 📡 Message Flow Architecture

### Stream-Based Messaging

```mermaid
sequenceDiagram
    participant App as Application
    participant API as Stream Manager
    participant NATS as NATS JetStream
    participant Store as Persistent Storage

    Note over App,Store: Application Startup
    App->>API: Register application
    API->>NATS: Create streams
    NATS->>Store: Initialize storage

    Note over App,Store: Message Publishing
    App->>NATS: Publish message
    NATS->>Store: Persist message
    NATS-->>App: ACK

    Note over App,Store: Message Consumption
    App->>NATS: Create consumer
    NATS->>App: Deliver messages
    App->>NATS: ACK processed
    NATS->>Store: Update consumer state
```

### Domain-Driven Stream Design

| Stream | Purpose | Subjects | Retention | Applications |
|--------|---------|----------|-----------|--------------|
| **EVA_TICKETING_STREAM** | Ticket lifecycle events | `tickets.*`, `incidents.*`, `maintenance.*` | 72 hours (workqueue) | Ticketing, Support |
| **EVA_ANALYTICS_STREAM** | Business intelligence | `analytics.*`, `metrics.*`, `reports.*` | 30 days (limits) | Analytics, BI |

---

## 🚀 Deployment Architecture

### Container Orchestration

```yaml
# Production Deployment Pattern
services:
  nats:
    image: nats:latest
    replicas: 3                    # HA cluster
    configs:
      - nats-cluster.conf
    networks:
      - eva-messaging

  stream-manager:
    image: eva/stream-manager:v1.0
    replicas: 2                    # Load balanced
    environment:
      - TLS_ENABLED=true
    depends_on:
      - nats

  stream-init:
    image: eva/stream-manager:v1.0
    restart: "no"                  # Run once only
    command: ["create-streams"]
```

### Network Architecture

```mermaid
graph LR
    subgraph "External Network"
        LB[Load Balancer]
        APPS[Eva Applications]
    end

    subgraph "Eva Messaging Network"
        subgraph "API Tier"
            API1[Stream Manager 1]
            API2[Stream Manager 2]
        end

        subgraph "Messaging Tier"
            NATS1[NATS Node 1]
            NATS2[NATS Node 2]
            NATS3[NATS Node 3]
        end

        subgraph "Storage Tier"
            VOL1[Volume 1]
            VOL2[Volume 2]
            VOL3[Volume 3]
        end
    end

    LB --> API1
    LB --> API2
    APPS --> NATS1
    APPS --> NATS2
    APPS --> NATS3

    API1 --> NATS1
    API2 --> NATS2

    NATS1 --> VOL1
    NATS2 --> VOL2
    NATS3 --> VOL3

    NATS1 <--> NATS2
    NATS2 <--> NATS3
    NATS3 <--> NATS1
```

---

## 🔐 Security Architecture

### Authentication & Authorization

#### Development Environment
- **NATS**: Simple user/password authentication
- **Stream Manager**: No authentication (localhost only)
- **TLS**: Disabled for development simplicity

#### Production Environment
- **NATS**: Certificate-based authentication with accounts
- **Stream Manager**: JWT tokens or mutual TLS
- **TLS**: Required for all connections
- **Network**: Pod-to-pod encryption in Kubernetes

### Security Layers

```mermaid
graph TB
    subgraph "Security Layers"
        subgraph "Network Security"
            FW[Firewall Rules]
            NET[Network Policies]
            TLS[TLS Encryption]
        end

        subgraph "Application Security"
            AUTH[Authentication]
            AUTHZ[Authorization]
            RBAC[Role-Based Access]
        end

        subgraph "Data Security"
            ENC[Encryption at Rest]
            AUDIT[Audit Logging]
            BACKUP[Secure Backups]
        end
    end

    FW --> AUTH
    NET --> AUTHZ
    TLS --> RBAC
    AUTH --> ENC
    AUTHZ --> AUDIT
    RBAC --> BACKUP
```

---

## 📊 Scalability & Performance

### Horizontal Scaling

| Component | Scaling Strategy | Max Instances | Bottlenecks |
|-----------|------------------|---------------|-------------|
| **NATS Cluster** | Add nodes to cluster | 10+ nodes | Network bandwidth |
| **Stream Manager** | Load balanced instances | 5-10 instances | NATS connection pool |
| **Applications** | Independent scaling | Unlimited | Message processing rate |

### Performance Characteristics

#### Message Throughput
- **Single NATS Node**: 1M+ messages/second
- **Clustered Setup**: Scales linearly with nodes
- **Persistence Overhead**: ~20% throughput reduction

#### Latency Profile
- **Pub/Sub Latency**: <1ms (memory)
- **Persistent Delivery**: <5ms (SSD storage)
- **Cross-Cluster**: <10ms (network dependent)

#### Storage Requirements
- **Message Storage**: Configurable per stream
- **Consumer State**: ~1KB per consumer
- **Metadata**: ~100MB base overhead

---

## 🔄 Operational Patterns

### High Availability

#### NATS Clustering
```yaml
# 3-node cluster configuration
cluster:
  name: eva-messaging
  listen: 0.0.0.0:6222
  routes:
    - nats://node1:6222
    - nats://node2:6222
    - nats://node3:6222
```

#### Failover Strategy
1. **Automatic Leader Election**: NATS handles Raft consensus
2. **Client Reconnection**: Applications reconnect to available nodes
3. **Message Durability**: No message loss during failover
4. **Consumer Continuity**: Consumers resume from last ACK

### Monitoring & Observability

#### Health Checks
- **NATS Server**: `/healthz` endpoint
- **Stream Manager**: `/health` endpoint with component status
- **Application Integration**: Health check aggregation

#### Metrics Collection
- **NATS Metrics**: Prometheus-compatible metrics
- **JetStream Stats**: Stream/consumer performance data
- **Custom Metrics**: Application-specific measurements

#### Alerting Thresholds
- **Message Queue Depth**: >10K unprocessed messages
- **Consumer Lag**: >5 minutes behind
- **Storage Usage**: >80% of allocated space
- **Connection Count**: >90% of max connections

---

## 🚧 Future Roadmap

### Near-term Enhancements (3-6 months)
- [ ] Message schema validation
- [ ] Dead letter queue management
- [ ] Enhanced monitoring dashboards
- [ ] Automated scaling policies

### Medium-term Features (6-12 months)
- [ ] Multi-region deployment
- [ ] Message encryption at rest
- [ ] Advanced routing rules
- [ ] Integration with service mesh

### Long-term Vision (12+ months)
- [ ] Event sourcing patterns
- [ ] Complex event processing
- [ ] Machine learning integration
- [ ] Serverless function triggers

---

**Architecture Status**: ✅ Production Ready
**Last Updated**: 2025-09-23
**Next Review**: 2025-12-23