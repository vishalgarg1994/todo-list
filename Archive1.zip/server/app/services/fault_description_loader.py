"""
Fault Description Loader
Processes fault description messages and ingests embeddings into Milvus
"""
import logging

from data_access.milvusClient import MilvusClient
from services.embedding_service import EmbeddingService
from configs.config import Config
from services.fault_description_handler import FaultDescriptionMessageHandler


class FaultDescriptionLoader:
    """Loader for processing fault descriptions and storing embeddings in Milvus"""

    def __init__(
        self,
        milvus_client: MilvusClient,
        embedding_service: EmbeddingService,
        nats_url: str,
        stream_name: str,
        subject: str
    ):
        """
        Initialize the fault description loader

        Args:
            milvus_client: Connected Milvus client
            embedding_service: Embedding service for generating vectors
            nats_url: NATS server URL (not used - consumer managed by main.py)
            stream_name: JetStream stream name (not used - consumer managed by main.py)
            subject: NATS subject (not used - consumer managed by main.py)
        """
        self.milvus_client = milvus_client
        self.embedding_service = embedding_service
        self.config = Config()

        # Create message handler
        self.handler = FaultDescriptionMessageHandler(
            milvus_client=self.milvus_client,
            embedding_service=self.embedding_service,
            config=self.config
        )

        self.logger = logging.getLogger(__name__)

    async def handle_fault_description_message(self, msg):
        """
        Delegates message handling to FaultDescriptionMessageHandler

        Philosophy: Log anomalies and move on. ACK bad messages to avoid infinite loops.
        Better to finish with 99% success than get stuck on 1% bad data.

        Args:
            msg: NATS message containing FaultDescriptionSummary
        """
        try:
            await self.handler.handle_message(msg)
        except Exception as e:
            self.logger.error(f"❌ Fault description processing failed: {e}", exc_info=True)
            # Log and move on - ACK to avoid infinite retry loops
            try:
                await msg.ack()
                self.logger.warning("⚠️  ACK'd failed fault description message to continue processing")
            except Exception as ack_error:
                self.logger.error(f"❌ Failed to ACK message: {ack_error}")
