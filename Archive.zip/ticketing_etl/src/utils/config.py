import os
import logging
from typing import Optional


class ConfigurationError(Exception):
    """Exception raised for configuration errors."""
    pass


logger = logging.getLogger(__name__)


class Config:
    """Hierarchical configuration: ENV -> .env.{ENV} -> .env -> minimal defaults"""

    def __init__(self):
        self.env = os.getenv('CONFIG_ENV', 'dev')
        self.dotenv_config = self._load_env_file()
        self._validate_required_config()

    # =========================================================================
    # Data Source Toggle
    # =========================================================================

    def get_data_source(self) -> str:
        """
        Data source: 'api', 'db', or 'both'

        - api: Fetch from ServiceNow SMDS API only (no database required)
        - db: Fetch from PostgreSQL database only (current behavior)
        - both: Fetch from both and merge (API takes precedence for conflicts)
        """
        return self.get("DATA_SOURCE", "db")

    # =========================================================================
    # ServiceNow SMDS API Configuration
    # =========================================================================

    def get_servicenow_base_url(self) -> str:
        """ServiceNow SMDS API base URL"""
        return self.get(
            "SERVICENOW_BASE_URL",
            "https://gttdev.service-now.com/api/x_gttm2_gtt_serv_1/v1/gtt_service_management_data_services"
        )

    def get_servicenow_username(self) -> str:
        """ServiceNow API username for Basic Auth"""
        return self.get("SERVICENOW_USERNAME", "")

    def get_servicenow_password(self) -> str:
        """ServiceNow API password for Basic Auth"""
        return self.get("SERVICENOW_PASSWORD", "")

    def get_servicenow_client_id(self) -> str:
        """ServiceNow OAuth2 client ID (if set, OAuth2 is used instead of Basic Auth)"""
        return self.get("SERVICENOW_CLIENT_ID", "")

    def get_servicenow_client_secret(self) -> str:
        """ServiceNow OAuth2 client secret"""
        return self.get("SERVICENOW_CLIENT_SECRET", "")

    def get_servicenow_timeout(self) -> int:
        """ServiceNow API request timeout in seconds"""
        return self._get_int("SERVICENOW_TIMEOUT", 60)

    def get_servicenow_max_concurrent(self) -> int:
        """Maximum concurrent ServiceNow API requests"""
        return self._get_int("SERVICENOW_MAX_CONCURRENT", 5)

    def get_api_lookback_hours(self) -> int:
        """
        How many hours back to fetch data from API.
        Default is 24 hours. Set lower for testing (e.g., 2 hours).
        Note: ServiceNow API limits to 24 hours max per request.
        """
        return self._get_int("API_LOOKBACK_HOURS", 24)

    def _load_env_file(self):
        """Load environment-specific .env file"""
        from dotenv import dotenv_values

        # Try environment-specific file first
        env_file = f".env.{self.env}"
        if os.path.exists(env_file):
            logger.info(f"Loading configuration from {env_file}")
            return dotenv_values(env_file)

        # Fallback to default .env file
        if os.path.exists('.env'):
            logger.info("Loading configuration from .env")
            return dotenv_values('.env')

        logger.debug("No .env file found, using environment variables and defaults only")
        return {}

    def _validate_required_config(self):
        """Validate that required configuration is present based on data source"""
        data_source = self.get("DATA_SOURCE", "db")

        if data_source == "api":
            # API-only mode: require NATS and ServiceNow API config, not database
            required = ['NATS_URL', 'JETSTREAM_STREAM_NAME', 'SERVICENOW_USERNAME', 'SERVICENOW_PASSWORD']
        elif data_source == "both":
            # Both mode: require all config
            required = [
                'DATABASE_URL',
                'NATS_URL',
                'JETSTREAM_STREAM_NAME',
                'SERVICENOW_USERNAME',
                'SERVICENOW_PASSWORD'
            ]
        else:
            # DB mode (default): require database and NATS
            required = ['DATABASE_URL', 'NATS_URL', 'JETSTREAM_STREAM_NAME']

        missing = [key for key in required if not self.get(key)]

        if missing:
            raise ConfigurationError(
                f"Missing required configuration for DATA_SOURCE={data_source}: {missing}. "
                f"Please set these environment variables or add them to .env file."
            )

    def get(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Get configuration value with priority: Environment -> .env -> default"""
        return os.environ.get(key) or self.dotenv_config.get(key) or default

    def get_nats_url(self) -> str:
        return self.get("NATS_URL")

    def get_nats_user(self) -> str:
        """NATS publisher username for authentication"""
        return self.get("NATS_PUBLISHER_USER", "")

    def get_nats_password(self) -> str:
        """NATS publisher password for authentication"""
        return self.get("NATS_PUBLISHER_PASSWORD", "")

    def get_nats_tls_enabled(self) -> bool:
        """Whether NATS TLS is enabled"""
        if not self.get_tls_enabled():
            return False  # Force disable if TLS master switch is off
        return self.get("NATS_TLS_ENABLED", "false").lower() == "true"

    def get_nats_tls_cert(self) -> str:
        """Get NATS TLS certificate file path"""
        return self.get("NATS_TLS_CERT", "")

    def get_nats_tls_key(self) -> str:
        """Get NATS TLS key file path"""
        return self.get("NATS_TLS_KEY", "")

    def get_nats_tls_ca(self) -> str:
        """Get NATS TLS CA certificate file path"""
        return self.get("NATS_TLS_CA", "")

    def get_nats_tls_verify(self) -> bool:
        """Whether to verify NATS TLS certificates"""
        return self.get("NATS_TLS_VERIFY", "true").lower() == "true"

    def get_jetstream_stream_name(self) -> str:
        return self.get("JETSTREAM_STREAM_NAME")

    def get_ticket_publish_subject(self) -> str:
        return self.get("TICKET_PUBLISH_SUBJECT", "tickets.created")

    def get_ticket_subscribe_subject(self) -> str:
        return self.get("TICKET_SUBSCRIBE_SUBJECT", "tickets.created")

    def get_db_uri(self) -> str:
        return self.get("DATABASE_URL")

    def get_tls_enabled(self) -> bool:
        """Master TLS switch - enables/disables all TLS features"""
        return self.get("TLS_ENABLED", "false").lower() == "true"

    def get_db_ssl_mode(self) -> str:
        """Get database SSL mode (require, prefer, allow, disable)"""
        if not self.get_tls_enabled():
            return "disable"  # Force disable if TLS master switch is off
        return self.get("DATABASE_SSL_MODE", "require")

    def get_db_ssl_cert(self) -> str:
        """Get database SSL certificate file path"""
        return self.get("DATABASE_SSL_CERT", "")

    def get_db_ssl_key(self) -> str:
        """Get database SSL key file path"""
        return self.get("DATABASE_SSL_KEY", "")

    def get_db_ssl_ca(self) -> str:
        """Get database SSL CA certificate file path"""
        return self.get("DATABASE_SSL_CA", "")

    def get_scheduler_interval(self) -> int:
        """Legacy interval setting (deprecated for daily scheduling)"""
        return self._get_int("SCHEDULER_INTERVAL", 86400)  # Default to 24 hours

    def get_daily_schedule_time(self) -> str:
        """Get daily schedule time in HH:MM format (UTC)"""
        return self.get("DAILY_SCHEDULE_TIME", "02:00")

    def get_run_on_startup(self) -> bool:
        """Whether to run processing immediately on startup"""
        return self.get("RUN_ON_STARTUP", "true").lower() == "true"

    def get_testing_mode(self) -> bool:
        """Whether testing mode is enabled for frequent processing"""
        return self.get("TESTING_MODE", "false").lower() == "true"

    def get_testing_interval_minutes(self) -> int:
        """Interval in minutes for testing mode frequent processing"""
        return int(self.get("TESTING_INTERVAL_MINUTES", "5"))

    def get_lookup_interval_minutes(self) -> int:
        """Time window for incremental data processing (minutes)"""
        return self._get_int("LOOKUP_INTERVAL_MINUTES", 1440)  # Default to 24 hours for daily runs

    # DEFAULT_START_TIME removed - use get_initial_load_days() instead

    def get_initial_load_days(self) -> int:
        """Number of days to load on initial run (default: 30 days)"""
        return self._get_int("INITIAL_LOAD_DAYS", 30)

    def get_daily_load_hours(self) -> int:
        """Number of hours to load on daily incremental runs (default: 25 hours for overlap)"""
        return self._get_int("DAILY_LOAD_HOURS", 25)

    # USE_ABSOLUTE_START_TIME removed - always use relative days via get_initial_load_days()

    def _get_int(self, key: str, default: int) -> int:
        try:
            return int(self.get(key, default))
        except ValueError:
            logger.warning(f"Invalid value for {key}, using default: {default}")
            return default
