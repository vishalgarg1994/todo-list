#!/usr/bin/env python3
"""
Simple MCP Tool Tester
Tests all ticket tools without requiring Ollama
"""
import httpx
import asyncio
import json
import argparse
from typing import Dict, Any


async def call_tool(server_url: str, tool_name: str, params: Dict[str, Any]) -> Dict:
    """Call an MCP tool and return the response"""
    # FastMCP 2.9.x uses Streamable HTTP - direct tool endpoint
    tool_url = f"{server_url}/mcp/tools/{tool_name}"

    print(f"\n{'='*60}")
    print(f"Testing Tool: {tool_name}")
    print(f"Parameters: {json.dumps(params, indent=2)}")
    print(f"{'='*60}")

    # FastMCP HTTP mode requires JSON-RPC format with proper Accept headers
    headers = {"Accept": "application/json, text/event-stream"}

    # Wrap parameters in JSON-RPC format
    jsonrpc_request = {
        "jsonrpc": "2.0",
        "method": "tools/call",
        "params": {
            "name": tool_name,
            "arguments": params
        },
        "id": 1
    }

    is_streaming = (tool_name == "ask_tickets_question")

    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            if is_streaming:
                # Handle streaming response
                print(f"\n📡 Streaming response...\n")

                async with client.stream("POST", tool_url, json=jsonrpc_request, headers=headers) as response:
                    if response.status_code != 200:
                        # Read error response
                        error_text = await response.aread()
                        print(f"❌ HTTP ERROR: {response.status_code}")
                        try:
                            error_data = json.loads(error_text)
                            print(json.dumps(error_data, indent=2))
                        except:
                            print(error_text.decode())
                        return None

                    async for line in response.aiter_lines():
                        if line.startswith("data:"):
                            data_str = line[5:].strip()
                            if data_str:
                                try:
                                    data = json.loads(data_str)
                                    if "row" in data:
                                        print(json.dumps(data["row"], indent=2))
                                    elif "message" in data:
                                        print(f"ℹ️  {data['message']}")
                                    elif "status" in data:
                                        print(f"Status: {data['status']}")
                                    elif "error" in data:
                                        print(f"❌ {data['error']}")
                                except json.JSONDecodeError:
                                    print(f"Data: {data_str}")

                print(f"\n✅ Stream completed\n")
                return {"status": "streamed"}
            else:
                # Handle regular JSON response
                response = await client.post(tool_url, json=jsonrpc_request, headers=headers)
                response.raise_for_status()

                result = response.json()
                print(f"\n✅ SUCCESS")
                print(f"\nResponse:")
                print(json.dumps(result, indent=2))
                return result

    except httpx.HTTPStatusError as e:
        print(f"\n❌ ERROR: HTTP {e.response.status_code}")
        try:
            error_detail = e.response.json()
            print(json.dumps(error_detail, indent=2))
        except:
            print(e.response.text)
        return None
    except Exception as e:
        print(f"\n❌ ERROR: {type(e).__name__}: {e}")
        return None


async def test_all_tools(server_url: str):
    """Test suite for all ticket tools"""

    print(f"\n🚀 Starting Tool Test Suite")
    print(f"Server: {server_url}")
    print(f"\nNote: Replace 'EXAMPLE' values with real IDs from your database\n")

    # Test 1: Natural language query
    await call_tool(server_url, "ask_tickets_question", {
        "user_query": "How many tickets are there?"
    })

    # Test 2: Get ticket details
    await call_tool(server_url, "get_ticket_details", {
        "ticket_id": "INC123456"  # Replace with real ticket_id
    })

    # Test 3: Get client tickets
    await call_tool(server_url, "get_client_tickets", {
        "client_name": "Acme Corp",  # Replace with real client_name
        "limit": 5
    })

    # Test 4: Get client summary
    await call_tool(server_url, "get_client_summary", {
        "client_name": "Acme Corp"  # Replace with real client_name
    })

    # Test 5: Get tickets by status
    await call_tool(server_url, "get_tickets_by_status", {
        "status": "Open",
        "limit": 10
    })

    # Test 6: Get high priority tickets
    await call_tool(server_url, "get_high_priority_tickets", {
        "priority_threshold": 2,
        "limit": 10
    })

    # Test 7: Get ticket timeline
    await call_tool(server_url, "get_ticket_timeline", {
        "ticket_id": "INC123456"  # Replace with real ticket_id
    })

    # Test 8: Get ticket relationships
    await call_tool(server_url, "get_ticket_relationships", {
        "ticket_id": "INC123456"  # Replace with real ticket_id
    })

    # Test 9: Trace ticket root cause
    await call_tool(server_url, "trace_ticket_root_cause", {
        "ticket_id": "INC123456",  # Replace with real child ticket_id
        "max_depth": 10
    })

    # Test 10: Get vendor tickets
    await call_tool(server_url, "get_vendor_tickets", {
        "vendor_name": "Acme Vendor",  # Replace with real vendor name
        "limit": 10
    })

    # Test 11: Get service outages
    await call_tool(server_url, "get_service_outages", {
        "technology": "Fiber",  # Replace with real technology
        "limit": 10
    })

    # Test 12: Get tickets by date range
    await call_tool(server_url, "get_tickets_by_date_range", {
        "start_date": "2024-01-01",
        "end_date": "2024-12-31",
        "limit": 10
    })

    # Test 13: Get ticket contacts
    await call_tool(server_url, "get_ticket_contacts", {
        "ticket_id": "INC123456"  # Replace with real ticket_id
    })

    print(f"\n{'='*60}")
    print(f"✅ Test Suite Complete")
    print(f"{'='*60}\n")


async def test_single_tool(server_url: str, tool_name: str, params_json: str):
    """Test a single tool with custom parameters"""
    params = json.loads(params_json)
    await call_tool(server_url, tool_name, params)


def main():
    parser = argparse.ArgumentParser(description="Test MCP Ticket Tools")
    parser.add_argument("--server", default="http://localhost:8003", help="MCP server URL")
    parser.add_argument("--tool", help="Test specific tool (optional)")
    parser.add_argument("--params", help="Tool parameters as JSON (required with --tool)")

    args = parser.parse_args()

    if args.tool:
        if not args.params:
            print("Error: --params required when using --tool")
            parser.print_help()
            return
        asyncio.run(test_single_tool(args.server, args.tool, args.params))
    else:
        asyncio.run(test_all_tools(args.server))


if __name__ == "__main__":
    main()
