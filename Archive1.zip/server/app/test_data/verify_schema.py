"""
Verify the new Milvus collection schema
"""
import sys
sys.path.append('/app')

from data_access.milvusClient import MilvusClient
from configs.config import Config

config = Config()
client = MilvusClient(config)

try:
    client.connect()

    # Check schema
    if client.collection:
        schema = client.collection.schema
        print("New collection schema:")
        print("=" * 50)
        for field in schema.fields:
            print(f"\nField: {field.name}")
            print(f"  Type: {field.dtype}")
            print(f"  Is Primary: {field.is_primary}")
            print(f"  Auto ID: {field.auto_id}")
            if field.is_primary:
                print(f"  ✅ PRIMARY KEY")

        # Check stats
        stats = client.get_collection_stats()
        print("\n" + "=" * 50)
        print(f"Collection: {stats['collection_name']}")
        print(f"Number of entities: {stats['num_entities']}")
        print(f"Index type: {stats['index_type']}")
        print(f"Metric type: {stats['metric_type']}")

    client.disconnect()

except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
