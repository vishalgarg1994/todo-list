import asyncio
import json
import logging
import os
import time
from datetime import datetime
from typing import Any
from fastmcp.exceptions import ToolError
from utils.utilities import Helpers

# Path for logging failed/problematic queries for model improvement
CYPHER_EVOLUTION_LOG = os.environ.get(
    "CYPHER_EVOLUTION_LOG",
    "/app/logs/cypher_evolution_log.jsonl"
)


def log_query_for_evolution(
    user_query: str,
    cypher_query: str,
    error_message: str = None,
    error_type: str = None,
    success: bool = False
):
    """
    Log query executions for model evolution/improvement.

    Failed queries are especially valuable for:
    - Creating negative examples for fine-tuning
    - Identifying patterns the model struggles with
    - Building a dataset for continuous improvement
    """
    try:
        # Ensure log directory exists
        log_dir = os.path.dirname(CYPHER_EVOLUTION_LOG)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)

        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "user_query": user_query,
            "generated_cypher": cypher_query,
            "success": success,
            "error_type": error_type,
            "error_message": error_message,
        }

        with open(CYPHER_EVOLUTION_LOG, "a") as f:
            f.write(json.dumps(log_entry) + "\n")

        if not success:
            logging.info(f"📝 Logged failed query for model evolution: {CYPHER_EVOLUTION_LOG}")
    except Exception as log_error:
        # Don't let logging failures affect the main flow
        logging.warning(f"Could not log query for evolution: {log_error}")


async def ask_tickets_question(user_query: str, services: dict) -> Any:
    try:
        logging.info(f"🔍 Translating question: '{user_query}'")

        baml_client = services["baml_client"]
        memgraph_client = services["memgraph_client"]
        config = services.get("config")

        # Use enhanced schema if available
        if config and getattr(config, "use_enhanced_schema", False):
            schema_description = (
                services.get("enhanced_ticket_schema_description") or services["ticket_schema_description"]
            )
        else:
            schema_description = services["ticket_schema_description"]

        if not baml_client:
            raise ToolError("BAML client not initialized. Cannot translate natural language queries.")

        baml_registry = services.get("baml_registry")

        try:
            cypher_query = baml_client.TranslateToCypher(
                question=user_query,
                schema_description=schema_description["ticket_schema_description"],
                baml_options={"client_registry": baml_registry} if baml_registry else {}
            )
            logging.info(f"✅ Generated Cypher query")
        except Exception as baml_error:
            logging.error(f"❌ BAML translation failed: {str(baml_error)}")
            raise

        cypher_query = (
            str(cypher_query).replace("cypher", "").replace("\\n", " ").replace("\n", " ").replace("```", "").strip()
        )
        logging.info(f"🔧 Query: {cypher_query}")

        if not cypher_query or cypher_query.startswith("//"):
            return {"message": "I could not translate your question into a valid Cypher query. Please try rephrasing."}

        if not memgraph_client:
            raise ToolError("Memgraph client not initialized. Cannot execute query.")

        try:
            query_result = await memgraph_client.execute(cypher_query)
            # Convert Neo4j Result to list of dicts (Memgraph pattern)
            records = [record.data() for record in query_result]
            response_data = records
        except Exception as exec_error:
            # Log failed query for model evolution - these are gold for fine-tuning!
            log_query_for_evolution(
                user_query=user_query,
                cypher_query=cypher_query,
                error_message=str(exec_error),
                error_type=type(exec_error).__name__,
                success=False
            )
            logging.error(f"❌ Query execution failed: {exec_error}")
            raise ToolError(f"Query execution failed: {exec_error}")

        if not response_data:
            return {"message": "No results found in the database for your query."}

        logging.info(f"✅ Returned {len(response_data)} results")
        return Helpers.recursive_serialize(response_data)

    except ToolError:
        raise
    except Exception as e:
        # Log any other failures for evolution tracking
        if 'cypher_query' in locals():
            log_query_for_evolution(
                user_query=user_query,
                cypher_query=cypher_query,
                error_message=str(e),
                error_type=type(e).__name__,
                success=False
            )
        logging.error(f"❌ Error: {e}", exc_info=True)
        raise ToolError(f"An internal error occurred while processing your natural language request: {e}")
