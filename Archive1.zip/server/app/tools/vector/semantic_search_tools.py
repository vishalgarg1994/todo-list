"""
Semantic Search Tools for Vector-based Fault Description Similarity
Provides three levels of semantic search with different enrichment levels
"""
import asyncio
import logging
from typing import Any, Optional
from fastmcp.exceptions import ToolError
from utils.utilities import Helpers
from services.semantic_search_service import SemanticSearchService


async def search_similar_faults(
    query: str,
    services: dict,
    top_k: Optional[int] = 10,
    min_score: Optional[float] = 0.7
) -> Any:
    """
    Search for faults with similar descriptions using AI semantic search.

    This tool uses vector embeddings to find tickets that describe similar technical
    problems, even if they use different words. Returns just the similarity rankings
    without additional ticket details.

    Use this when you want to quickly discover what similar problems exist.

    Args:
        query: Natural language description of the fault (e.g., "fiber cable cut", "BGP routing issues")
        top_k: Number of results to return (default: 10, max: 50)
        min_score: Minimum similarity score 0.0-1.0 (default: 0.7)

    Returns:
        List of similar fault descriptions ranked by similarity score

    Examples:
        - "fiber cable damaged by construction"
        - "BGP routing protocol instability"
        - "high latency on MPLS circuit"
        - "power outage at datacenter"
    """
    try:
        logging.info(f"FastMCP Tool Call: search_similar_faults - query: '{query}', top_k: {top_k}, min_score: {min_score}")

        # Validate parameters
        if not query or not query.strip():
            raise ToolError("Query cannot be empty")

        if top_k and (top_k < 1 or top_k > 50):
            raise ToolError("top_k must be between 1 and 50")

        if min_score and (min_score < 0.0 or min_score > 1.0):
            raise ToolError("min_score must be between 0.0 and 1.0")

        # Get semantic search service
        search_service = services.get("semantic_search_service")
        if not search_service:
            raise ToolError("Semantic search service not initialized")

        # Execute search
        results = await search_service.search_similar_faults(
            query=query,
            top_k=top_k or 10,
            min_score=min_score or 0.5
        )

        if not results:
            return {
                "message": f"No similar faults found for query: '{query}'",
                "suggestions": [
                    f"Try lowering min_score (current: {min_score or 0.5})",
                    "Use different keywords or phrases",
                    f"Increase top_k to see more results (current: {top_k or 10})"
                ]
            }

        return Helpers.recursive_serialize({
            "query": query,
            "total_results": len(results),
            "parameters": {
                "top_k": top_k or 10,
                "min_score": min_score or 0.5
            },
            "results": results
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in search_similar_faults: {e}", exc_info=True)
        error_msg = f"Failed to search similar faults: {e}\n\n"
        error_msg += "Possible causes:\n"
        error_msg += "- Ollama embedding service not running (check: docker ps | grep ollama)\n"
        error_msg += "- Milvus vector database not accessible (check: docker ps | grep milvus)\n"
        error_msg += "- No fault descriptions loaded in Milvus (run consumer first)"
        raise ToolError(error_msg)


async def search_similar_tickets(
    query: str,
    services: dict,
    top_k: Optional[int] = 10,
    min_score: Optional[float] = 0.7
) -> Any:
    """
    Search for tickets with similar fault descriptions and their current status.

    This tool combines AI semantic search with ticket metadata from the graph database.
    Use this when you want to see similar problems AND understand their current state
    (status, priority, who's working on them, etc.).

    Great for finding:
    - Duplicate or related open tickets
    - Similar issues handled by specific engineers
    - Pattern detection across clients

    Args:
        query: Natural language description of the fault
        top_k: Number of results to return (default: 10, max: 50)
        min_score: Minimum similarity score 0.0-1.0 (default: 0.7)

    Returns:
        List of similar tickets with status, priority, client, engineer, and similarity score

    Examples:
        - "fiber cable cut at datacenter" → Find similar incidents with their status
        - "BGP routing issues" → See who handled similar routing problems
        - "customer reporting slow performance" → Find related latency tickets
    """
    try:
        logging.info(f"FastMCP Tool Call: search_similar_tickets - query: '{query}', top_k: {top_k}, min_score: {min_score}")

        # Validate parameters
        if not query or not query.strip():
            raise ToolError("Query cannot be empty")

        if top_k and (top_k < 1 or top_k > 50):
            raise ToolError("top_k must be between 1 and 50")

        if min_score and (min_score < 0.0 or min_score > 1.0):
            raise ToolError("min_score must be between 0.0 and 1.0")

        # Get semantic search service
        search_service = services.get("semantic_search_service")
        if not search_service:
            raise ToolError("Semantic search service not initialized")

        # Execute search
        results = await search_service.search_similar_tickets(
            query=query,
            top_k=top_k or 10,
            min_score=min_score or 0.5
        )

        if not results:
            return {
                "message": f"No similar tickets found for query: '{query}'",
                "suggestions": [
                    f"Try lowering min_score (current: {min_score or 0.5})",
                    "Use different keywords or phrases",
                    f"Increase top_k to see more results (current: {top_k or 10})",
                    "Use search_similar_faults for vector-only search"
                ]
            }

        return Helpers.recursive_serialize({
            "query": query,
            "total_results": len(results),
            "parameters": {
                "top_k": top_k or 10,
                "min_score": min_score or 0.5
            },
            "results": results
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in search_similar_tickets: {e}", exc_info=True)
        error_msg = f"Failed to search similar tickets: {e}\n\n"
        error_msg += "Possible causes:\n"
        error_msg += "- Ollama embedding service not running\n"
        error_msg += "- Milvus vector database not accessible\n"
        error_msg += "- Memgraph graph database connection issue\n"
        error_msg += "- No ticket data loaded (run ticketing_etl first)"
        raise ToolError(error_msg)


async def search_similar_resolutions(
    query: str,
    services: dict,
    top_k: Optional[int] = 10,
    min_score: Optional[float] = 0.7
) -> Any:
    """
    Search for similar problems and learn how they were resolved.

    This is the MOST VALUABLE tool for troubleshooting! It finds tickets with similar
    fault descriptions and shows you:
    - How the problem was fixed (resolution steps)
    - How long it took to resolve (MTTR)
    - Root cause analysis (RFO - Reason for Outage)
    - Problem categorization

    Use this when you're:
    - Troubleshooting a current issue
    - Looking for resolution strategies
    - Learning from past incidents
    - Estimating resolution time

    Args:
        query: Natural language description of the fault
        top_k: Number of results to return (default: 10, max: 50)
        min_score: Minimum similarity score 0.0-1.0 (default: 0.7)

    Returns:
        List of similar tickets with full resolution details (resolution, MTTR, RFO, etc.)

    Examples:
        - "fiber cut emergency" → Learn fastest resolution methods
        - "BGP routing loop" → See how others fixed similar routing issues
        - "customer circuit down" → Find typical MTTRs and resolution steps
    """
    try:
        logging.info(f"FastMCP Tool Call: search_similar_resolutions - query: '{query}', top_k: {top_k}, min_score: {min_score}")

        # Validate parameters
        if not query or not query.strip():
            raise ToolError("Query cannot be empty")

        if top_k and (top_k < 1 or top_k > 50):
            raise ToolError("top_k must be between 1 and 50")

        if min_score and (min_score < 0.0 or min_score > 1.0):
            raise ToolError("min_score must be between 0.0 and 1.0")

        # Get semantic search service
        search_service = services.get("semantic_search_service")
        if not search_service:
            raise ToolError("Semantic search service not initialized")

        # Execute search
        results = await search_service.search_similar_resolutions(
            query=query,
            top_k=top_k or 10,
            min_score=min_score or 0.5
        )

        if not results:
            return {
                "message": f"No similar resolutions found for query: '{query}'",
                "suggestions": [
                    f"Try lowering min_score (current: {min_score or 0.5})",
                    "Use different keywords or phrases",
                    f"Increase top_k to see more results (current: {top_k or 10})",
                    "Some tickets may not have resolution data yet",
                    "Use search_similar_tickets to see if matches exist without resolution data"
                ]
            }

        # Calculate statistics for helpful summary (filter out None results from failed enrichments)
        valid_results = [r for r in results if r is not None and isinstance(r, dict)]
        resolved_count = sum(1 for r in valid_results if isinstance(r.get("resolution_details"), dict) and r.get("resolution_details", {}).get("resolution"))
        avg_mttr = None
        if resolved_count > 0:
            mttrs = [
                r.get("resolution_details", {}).get("mttr")
                for r in valid_results
                if r.get("resolution_details", {}).get("mttr") is not None
            ]
            if mttrs:
                avg_mttr = sum(mttrs) / len(mttrs)

        summary = {
            "total_results": len(results),
            "tickets_with_resolution": resolved_count,
            "average_mttr_hours": round(avg_mttr, 2) if avg_mttr else None
        }

        return Helpers.recursive_serialize({
            "query": query,
            "summary": summary,
            "parameters": {
                "top_k": top_k or 10,
                "min_score": min_score or 0.5
            },
            "results": results
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in search_similar_resolutions: {e}", exc_info=True)
        error_msg = f"Failed to search similar resolutions: {e}\n\n"
        error_msg += "Possible causes:\n"
        error_msg += "- Ollama embedding service not running\n"
        error_msg += "- Milvus vector database not accessible\n"
        error_msg += "- Memgraph graph database connection issue\n"
        error_msg += "- OutageInfo data not loaded (check ticketing_etl configuration)"
        raise ToolError(error_msg)


async def search_similar_services(
    query: str,
    services: dict,
    top_k: Optional[int] = 10,
    min_score: Optional[float] = 0.7
) -> Any:
    """
    Search for similar problems and show affected services.

    This tool finds tickets with similar fault descriptions and shows which services
    were impacted, including NOC monitoring details. Use this for infrastructure
    impact analysis and understanding NOC routing patterns.

    Args:
        query: Natural language description of the fault (e.g., "MPLS circuit experiencing high latency")
        top_k: Number of results to return (default: 10, max: 50)
        min_score: Minimum similarity score 0.0-1.0 (default: 0.7)

    Returns:
        List of similar tickets with service impact details including subcategory,
        technology, and NOC information

    Examples:
        - "MPLS circuit experiencing high latency"
        - "fiber optic service degradation"
        - "BGP routing affecting multiple services"
    """
    try:
        logging.info(f"FastMCP Tool Call: search_similar_services - query: '{query}', top_k: {top_k}, min_score: {min_score}")

        # Validate parameters
        if not query or not query.strip():
            raise ToolError("Query cannot be empty")

        if top_k and (top_k < 1 or top_k > 50):
            raise ToolError("top_k must be between 1 and 50")

        if min_score and (min_score < 0.0 or min_score > 1.0):
            raise ToolError("min_score must be between 0.0 and 1.0")

        # Get semantic search service
        search_service = services.get("semantic_search_service")
        if not search_service:
            raise ToolError("Semantic search service not initialized")

        # Execute search
        results = await search_service.search_similar_services(
            query=query,
            top_k=top_k or 10,
            min_score=min_score or 0.5
        )

        if not results:
            return {
                "message": f"No similar services found for query: '{query}'",
                "suggestions": [
                    f"Try lowering min_score (current: {min_score or 0.5})",
                    "Use different keywords or phrases",
                    f"Increase top_k to see more results (current: {top_k or 10})"
                ]
            }

        return Helpers.recursive_serialize({
            "query": query,
            "total_results": len(results),
            "parameters": {
                "top_k": top_k or 10,
                "min_score": min_score or 0.5
            },
            "results": results
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in search_similar_services: {e}", exc_info=True)
        raise ToolError(f"Failed to search similar services: {e}")


async def search_similar_maintenance_windows(
    query: str,
    services: dict,
    top_k: Optional[int] = 10,
    min_score: Optional[float] = 0.7
) -> Any:
    """
    Search for similar problems and show maintenance windows.

    This tool finds tickets with similar fault descriptions that occurred during
    maintenance windows. Use this to identify patterns in maintenance-related issues
    and analyze planned work impact.

    Args:
        query: Natural language description of the fault (e.g., "service degradation during network upgrade")
        top_k: Number of results to return (default: 10, max: 50)
        min_score: Minimum similarity score 0.0-1.0 (default: 0.7)

    Returns:
        List of similar tickets with maintenance window details including
        planned start/end times and maintenance reason

    Examples:
        - "service degradation during network upgrade"
        - "outage during planned maintenance"
        - "issues following router firmware update"
    """
    try:
        logging.info(f"FastMCP Tool Call: search_similar_maintenance_windows - query: '{query}', top_k: {top_k}, min_score: {min_score}")

        # Validate parameters
        if not query or not query.strip():
            raise ToolError("Query cannot be empty")

        if top_k and (top_k < 1 or top_k > 50):
            raise ToolError("top_k must be between 1 and 50")

        if min_score and (min_score < 0.0 or min_score > 1.0):
            raise ToolError("min_score must be between 0.0 and 1.0")

        # Get semantic search service
        search_service = services.get("semantic_search_service")
        if not search_service:
            raise ToolError("Semantic search service not initialized")

        # Execute search
        results = await search_service.search_similar_maintenance_windows(
            query=query,
            top_k=top_k or 10,
            min_score=min_score or 0.5
        )

        if not results:
            return {
                "message": f"No similar maintenance windows found for query: '{query}'",
                "suggestions": [
                    f"Try lowering min_score (current: {min_score or 0.5})",
                    "Use different keywords or phrases",
                    f"Increase top_k to see more results (current: {top_k or 10})"
                ]
            }

        return Helpers.recursive_serialize({
            "query": query,
            "total_results": len(results),
            "parameters": {
                "top_k": top_k or 10,
                "min_score": min_score or 0.5
            },
            "results": results
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in search_similar_maintenance_windows: {e}", exc_info=True)
        raise ToolError(f"Failed to search similar maintenance windows: {e}")


async def search_similar_engineers(
    query: str,
    services: dict,
    top_k: Optional[int] = 10,
    min_score: Optional[float] = 0.7
) -> Any:
    """
    Search for similar problems and see who handled them.

    This tool finds tickets with similar fault descriptions and shows the complete
    team that worked on them (incident manager, ops specialist, SD engineer, tier2).
    Use this for expert identification and workload distribution analysis.

    Args:
        query: Natural language description of the fault (e.g., "complex routing configuration issue")
        top_k: Number of results to return (default: 10, max: 50)
        min_score: Minimum similarity score 0.0-1.0 (default: 0.7)

    Returns:
        List of similar tickets with team member details including names, emails,
        roles for all engineers involved

    Examples:
        - "complex routing configuration issue"
        - "advanced BGP troubleshooting"
        - "multi-vendor integration problem"
    """
    try:
        logging.info(f"FastMCP Tool Call: search_similar_engineers - query: '{query}', top_k: {top_k}, min_score: {min_score}")

        # Validate parameters
        if not query or not query.strip():
            raise ToolError("Query cannot be empty")

        if top_k and (top_k < 1 or top_k > 50):
            raise ToolError("top_k must be between 1 and 50")

        if min_score and (min_score < 0.0 or min_score > 1.0):
            raise ToolError("min_score must be between 0.0 and 1.0")

        # Get semantic search service
        search_service = services.get("semantic_search_service")
        if not search_service:
            raise ToolError("Semantic search service not initialized")

        # Execute search
        results = await search_service.search_similar_engineers(
            query=query,
            top_k=top_k or 10,
            min_score=min_score or 0.5
        )

        if not results:
            return {
                "message": f"No similar engineers found for query: '{query}'",
                "suggestions": [
                    f"Try lowering min_score (current: {min_score or 0.5})",
                    "Use different keywords or phrases",
                    f"Increase top_k to see more results (current: {top_k or 10})"
                ]
            }

        return Helpers.recursive_serialize({
            "query": query,
            "total_results": len(results),
            "parameters": {
                "top_k": top_k or 10,
                "min_score": min_score or 0.5
            },
            "results": results
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in search_similar_engineers: {e}", exc_info=True)
        raise ToolError(f"Failed to search similar engineers: {e}")


async def search_similar_vendors(
    query: str,
    services: dict,
    top_k: Optional[int] = 10,
    min_score: Optional[float] = 0.7
) -> Any:
    """
    Search for similar problems involving external vendors.

    This tool finds tickets with similar fault descriptions that involved vendors,
    showing vendor names and downtime attribution. Use this for vendor performance
    tracking and escalation pattern analysis.

    Args:
        query: Natural language description of the fault (e.g., "fiber damage requiring vendor repair")
        top_k: Number of results to return (default: 10, max: 50)
        min_score: Minimum similarity score 0.0-1.0 (default: 0.7)

    Returns:
        List of similar tickets with vendor involvement details including
        vendor names and downtime information

    Examples:
        - "fiber optic cable damage requiring vendor repair"
        - "third-party equipment failure"
        - "ISP provider circuit down"
    """
    try:
        logging.info(f"FastMCP Tool Call: search_similar_vendors - query: '{query}', top_k: {top_k}, min_score: {min_score}")

        # Validate parameters
        if not query or not query.strip():
            raise ToolError("Query cannot be empty")

        if top_k and (top_k < 1 or top_k > 50):
            raise ToolError("top_k must be between 1 and 50")

        if min_score and (min_score < 0.0 or min_score > 1.0):
            raise ToolError("min_score must be between 0.0 and 1.0")

        # Get semantic search service
        search_service = services.get("semantic_search_service")
        if not search_service:
            raise ToolError("Semantic search service not initialized")

        # Execute search
        results = await search_service.search_similar_vendors(
            query=query,
            top_k=top_k or 10,
            min_score=min_score or 0.5
        )

        if not results:
            return {
                "message": f"No similar vendors found for query: '{query}'",
                "suggestions": [
                    f"Try lowering min_score (current: {min_score or 0.5})",
                    "Use different keywords or phrases",
                    f"Increase top_k to see more results (current: {top_k or 10})"
                ]
            }

        return Helpers.recursive_serialize({
            "query": query,
            "total_results": len(results),
            "parameters": {
                "top_k": top_k or 10,
                "min_score": min_score or 0.5
            },
            "results": results
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in search_similar_vendors: {e}", exc_info=True)
        raise ToolError(f"Failed to search similar vendors: {e}")


async def search_similar_client_impacts(
    query: str,
    services: dict,
    top_k: Optional[int] = 10,
    min_score: Optional[float] = 0.7
) -> Any:
    """
    Search for similar problems and understand client impact.

    This tool finds tickets with similar fault descriptions and shows the client
    impact including client details, contact information, and customer satisfaction
    survey data. Use this for client relationship management and satisfaction analysis.

    Args:
        query: Natural language description of the fault (e.g., "major outage affecting business-critical services")
        top_k: Number of results to return (default: 10, max: 50)
        min_score: Minimum similarity score 0.0-1.0 (default: 0.7)

    Returns:
        List of similar tickets with client impact details including client info,
        contacts, and customer satisfaction surveys

    Examples:
        - "major outage affecting business-critical services"
        - "widespread service disruption"
        - "critical customer-impacting incident"
    """
    try:
        logging.info(f"FastMCP Tool Call: search_similar_client_impacts - query: '{query}', top_k: {top_k}, min_score: {min_score}")

        # Validate parameters
        if not query or not query.strip():
            raise ToolError("Query cannot be empty")

        if top_k and (top_k < 1 or top_k > 50):
            raise ToolError("top_k must be between 1 and 50")

        if min_score and (min_score < 0.0 or min_score > 1.0):
            raise ToolError("min_score must be between 0.0 and 1.0")

        # Get semantic search service
        search_service = services.get("semantic_search_service")
        if not search_service:
            raise ToolError("Semantic search service not initialized")

        # Execute search
        results = await search_service.search_similar_client_impacts(
            query=query,
            top_k=top_k or 10,
            min_score=min_score or 0.5
        )

        if not results:
            return {
                "message": f"No similar client impacts found for query: '{query}'",
                "suggestions": [
                    f"Try lowering min_score (current: {min_score or 0.5})",
                    "Use different keywords or phrases",
                    f"Increase top_k to see more results (current: {top_k or 10})"
                ]
            }

        return Helpers.recursive_serialize({
            "query": query,
            "total_results": len(results),
            "parameters": {
                "top_k": top_k or 10,
                "min_score": min_score or 0.5
            },
            "results": results
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in search_similar_client_impacts: {e}", exc_info=True)
        raise ToolError(f"Failed to search similar client impacts: {e}")


async def find_similar_faults_by_ticket(
    ticket_id: str,
    services: dict,
    top_k: Optional[int] = 10,
    min_score: Optional[float] = 0.7
) -> Any:
    """
    Find tickets with similar fault descriptions (vector search only).

    Given a ticket ID, this tool finds other tickets with similar fault descriptions
    based on semantic similarity. Returns just the fault descriptions and similarity
    scores without resolution details.

    Use this when you want to:
    - Quickly see what similar faults exist
    - Get a list of similar tickets for further processing
    - Find patterns in fault descriptions

    For resolution details, use get_ticket_resolutions() separately.

    Args:
        ticket_id: The ticket ID to find similar faults for (e.g., "INC9000123")
        top_k: Number of similar tickets to return (default: 10, max: 50)
        min_score: Minimum similarity score 0.0-1.0 (default: 0.7)

    Returns:
        Query ticket info and list of similar tickets with fault descriptions + scores

    Examples:
        - ticket_id: "INC9000123"
        - ticket_id: "TKT2024001"
    """
    try:
        logging.info(f"FastMCP Tool Call: find_similar_faults_by_ticket - ticket_id: '{ticket_id}', top_k: {top_k}, min_score: {min_score}")

        # Validate parameters
        if not ticket_id or not ticket_id.strip():
            raise ToolError("ticket_id cannot be empty")

        if top_k and (top_k < 1 or top_k > 50):
            raise ToolError("top_k must be between 1 and 50")

        if min_score and (min_score < 0.0 or min_score > 1.0):
            raise ToolError("min_score must be between 0.0 and 1.0")

        # Get semantic search service
        search_service = services.get("semantic_search_service")
        if not search_service:
            raise ToolError("Semantic search service not initialized")

        # Execute search
        results = await search_service.find_similar_faults_by_ticket(
            ticket_id=ticket_id,
            top_k=top_k or 10,
            min_score=min_score or 0.7
        )

        if not results:
            return {
                "message": f"No similar faults found for ticket ID: '{ticket_id}'",
                "possible_reasons": [
                    f"Ticket {ticket_id} not found in vector database",
                    f"No similar tickets meet minimum similarity threshold ({min_score or 0.7})"
                ],
                "suggestions": [
                    f"Verify ticket ID is correct: '{ticket_id}'",
                    f"Try lowering min_score (current: {min_score or 0.7})",
                    f"Increase top_k (current: {top_k or 10})"
                ]
            }

        return Helpers.recursive_serialize({
            "query_ticket": results.get("query_ticket"),
            "total_similar_tickets": len(results.get("similar_tickets", [])),
            "parameters": {
                "top_k": top_k or 10,
                "min_score": min_score or 0.7
            },
            "similar_tickets": results.get("similar_tickets", [])
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in find_similar_faults_by_ticket: {e}", exc_info=True)
        error_msg = f"Failed to find similar faults for {ticket_id}: {e}\n\n"
        error_msg += "Possible causes:\n"
        error_msg += "- Ticket not found in Milvus vector database\n"
        error_msg += "- Milvus not accessible (check: docker ps | grep milvus)\n"
        error_msg += "- Fault descriptions not loaded yet (run consumer first)"
        raise ToolError(error_msg)


async def get_ticket_resolutions(
    ticket_ids: list,
    services: dict
) -> Any:
    """
    Get resolution details for a list of ticket IDs.

    Given a list of ticket IDs, this tool fetches resolution information from
    the graph database including resolution summary, RFO, MTTR, and time to resolve.

    Use this to:
    - Get resolution details for tickets found by find_similar_faults_by_ticket()
    - Learn how specific issues were resolved
    - Understand resolution patterns and timing

    Args:
        ticket_ids: List of ticket IDs to get resolutions for (e.g., ["INC9000123", "INC9000124"])

    Returns:
        List of tickets with resolution details including:
        - Resolution summary
        - RFO (Reason for Outage)
        - MTTR (Mean Time To Resolve)
        - Outage duration
        - Ticket status and timing

    Examples:
        - ticket_ids: ["INC9000123"]
        - ticket_ids: ["INC9000123", "INC9000124", "INC9000125"]
    """
    try:
        logging.info(f"FastMCP Tool Call: get_ticket_resolutions - {len(ticket_ids)} ticket(s)")

        # Validate parameters
        if not ticket_ids or not isinstance(ticket_ids, list):
            raise ToolError("ticket_ids must be a non-empty list")

        if len(ticket_ids) > 100:
            raise ToolError("Cannot fetch resolutions for more than 100 tickets at once")

        # Get semantic search service
        search_service = services.get("semantic_search_service")
        if not search_service:
            raise ToolError("Semantic search service not initialized")

        # Execute query
        results = await search_service.get_ticket_resolutions(ticket_ids)

        if not results:
            return {
                "message": f"No resolution data found for the provided ticket IDs",
                "ticket_ids": ticket_ids,
                "possible_reasons": [
                    "Tickets not found in graph database",
                    "Tickets exist but have no resolution data yet"
                ]
            }

        return Helpers.recursive_serialize({
            "total_tickets": len(results),
            "requested_ticket_ids": ticket_ids,
            "resolutions": results
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_ticket_resolutions: {e}", exc_info=True)
        error_msg = f"Failed to get ticket resolutions: {e}\n\n"
        error_msg += "Possible causes:\n"
        error_msg += "- Memgraph not accessible (check: docker ps | grep memgraph)\n"
        error_msg += "- Tickets not loaded in graph database yet"
        raise ToolError(error_msg)
