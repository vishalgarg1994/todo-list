import asyncio
import logging
from enum import Enum
from typing import Dict, Any, Optional, Callable, List
from datetime import datetime, timezone
from dataclasses import dataclass


class ServiceState(Enum):
    """Service operational states"""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNAVAILABLE = "unavailable"


@dataclass
class ServiceStatus:
    """Status information for a service"""

    name: str
    state: ServiceState
    last_check: datetime
    error_count: int = 0
    consecutive_failures: int = 0
    last_error: Optional[str] = None


class DegradationManager:
    """Manage partial functionality during service outages"""

    def __init__(self):
        self.services: Dict[str, ServiceStatus] = {}
        self.degradation_handlers: Dict[str, Callable] = {}
        self.fallback_handlers: Dict[str, Callable] = {}
        self.logger = logging.getLogger(__name__)

        # Configuration
        self.max_consecutive_failures = 3
        self.health_check_interval = 30  # seconds
        self.degradation_timeout = 300  # 5 minutes

    def register_service(
        self, service_name: str, health_check_handler: Callable = None
    ):
        """Register a service for monitoring"""
        self.services[service_name] = ServiceStatus(
            name=service_name,
            state=ServiceState.HEALTHY,
            last_check=datetime.now(timezone.utc),
        )

        if health_check_handler:
            self.degradation_handlers[service_name] = health_check_handler

        self.logger.info(
            f"Registered service for degradation management: {service_name}"
        )

    def register_fallback_handler(self, service_name: str, handler: Callable):
        """Register a fallback handler for when a service is unavailable"""
        self.fallback_handlers[service_name] = handler
        self.logger.info(f"Registered fallback handler for service: {service_name}")

    async def check_service_health(self, service_name: str) -> ServiceState:
        """Check health of a specific service"""
        if service_name not in self.services:
            self.logger.warning(f"Unknown service: {service_name}")
            return ServiceState.UNAVAILABLE

        service = self.services[service_name]

        try:
            # Use custom health check if available
            if service_name in self.degradation_handlers:
                is_healthy = await self.degradation_handlers[service_name]()
            else:
                # Default health check based on error rate
                is_healthy = (
                    service.consecutive_failures < self.max_consecutive_failures
                )

            if is_healthy:
                self._mark_service_healthy(service_name)
                return ServiceState.HEALTHY
            else:
                self._mark_service_degraded(service_name, "Health check failed")
                return ServiceState.DEGRADED

        except Exception as e:
            self._mark_service_unavailable(service_name, str(e))
            return ServiceState.UNAVAILABLE

    def _mark_service_healthy(self, service_name: str):
        """Mark service as healthy"""
        service = self.services[service_name]
        was_unhealthy = service.state != ServiceState.HEALTHY

        service.state = ServiceState.HEALTHY
        service.last_check = datetime.now(timezone.utc)
        service.consecutive_failures = 0
        service.last_error = None

        if was_unhealthy:
            self.logger.info(
                f"Service {service_name} recovered to healthy state",
                extra={"service_name": service_name, "state": service.state.value},
            )

    def _mark_service_degraded(self, service_name: str, error: str):
        """Mark service as degraded"""
        service = self.services[service_name]
        service.state = ServiceState.DEGRADED
        service.last_check = datetime.now(timezone.utc)
        service.consecutive_failures += 1
        service.error_count += 1
        service.last_error = error

        self.logger.warning(
            f"Service {service_name} is degraded",
            extra={
                "service_name": service_name,
                "state": service.state.value,
                "consecutive_failures": service.consecutive_failures,
                "error": error,
            },
        )

    def _mark_service_unavailable(self, service_name: str, error: str):
        """Mark service as unavailable"""
        service = self.services[service_name]
        service.state = ServiceState.UNAVAILABLE
        service.last_check = datetime.now(timezone.utc)
        service.consecutive_failures += 1
        service.error_count += 1
        service.last_error = error

        self.logger.error(
            f"Service {service_name} is unavailable",
            extra={
                "service_name": service_name,
                "state": service.state.value,
                "consecutive_failures": service.consecutive_failures,
                "error": error,
            },
        )

    async def execute_with_fallback(
        self, service_name: str, primary_operation: Callable, *args, **kwargs
    ) -> Any:
        """
        Execute operation with fallback handling

        Args:
            service_name: Name of the service
            primary_operation: Primary operation to execute
            *args, **kwargs: Arguments for the operation

        Returns:
            Result of primary operation or fallback
        """
        service_state = await self.check_service_health(service_name)

        # Try primary operation if service is healthy or degraded
        if service_state in [ServiceState.HEALTHY, ServiceState.DEGRADED]:
            try:
                result = (
                    await primary_operation(*args, **kwargs)
                    if asyncio.iscoroutinefunction(primary_operation)
                    else primary_operation(*args, **kwargs)
                )
                self._mark_service_healthy(service_name)
                return result

            except Exception as e:
                self.logger.error(
                    f"Primary operation failed for service {service_name}",
                    extra={"service_name": service_name, "error": str(e)},
                    exc_info=True,
                )
                self._mark_service_unavailable(service_name, str(e))

        # Use fallback if available
        if service_name in self.fallback_handlers:
            try:
                self.logger.info(
                    f"Using fallback handler for service {service_name}",
                    extra={"service_name": service_name},
                )

                fallback_handler = self.fallback_handlers[service_name]
                return (
                    await fallback_handler(*args, **kwargs)
                    if asyncio.iscoroutinefunction(fallback_handler)
                    else fallback_handler(*args, **kwargs)
                )

            except Exception as e:
                self.logger.error(
                    f"Fallback handler failed for service {service_name}",
                    extra={"service_name": service_name, "error": str(e)},
                    exc_info=True,
                )
                raise
        else:
            self.logger.error(
                f"No fallback handler available for service {service_name}",
                extra={"service_name": service_name},
            )
            raise RuntimeError(
                f"Service {service_name} is unavailable and no fallback is configured"
            )

    def get_service_status(self, service_name: str) -> Optional[ServiceStatus]:
        """Get status of a specific service"""
        return self.services.get(service_name)

    def get_all_service_status(self) -> Dict[str, ServiceStatus]:
        """Get status of all services"""
        return self.services.copy()

    def get_unhealthy_services(self) -> List[str]:
        """Get list of services that are not healthy"""
        return [
            name
            for name, service in self.services.items()
            if service.state != ServiceState.HEALTHY
        ]

    def is_system_degraded(self) -> bool:
        """Check if the overall system is in a degraded state"""
        unhealthy_services = self.get_unhealthy_services()
        return len(unhealthy_services) > 0

    async def handle_database_degradation(self) -> bool:
        """Handle database service degradation"""
        self.logger.warning(
            "Database service is degraded - implementing degradation strategy"
        )

        # Strategies for database degradation:
        # 1. Reduce query frequency
        # 2. Use cached data if available
        # 3. Skip non-critical operations
        # 4. Store data locally for later processing

        try:
            # Example: Reduce processing frequency
            await asyncio.sleep(5)  # Wait longer between operations
            return True
        except Exception as e:
            self.logger.error(f"Database degradation handling failed: {e}")
            return False

    async def handle_nats_degradation(self) -> bool:
        """Handle NATS service degradation"""
        self.logger.warning(
            "NATS service is degraded - implementing degradation strategy"
        )

        # Strategies for NATS degradation:
        # 1. Store messages locally for later delivery
        # 2. Use alternative messaging mechanism
        # 3. Batch messages when service recovers

        try:
            # Example: Store messages in local queue
            # This would be implemented with actual local storage
            return True
        except Exception as e:
            self.logger.error(f"NATS degradation handling failed: {e}")
            return False

    async def monitor_services(self):
        """Continuous monitoring of registered services"""
        self.logger.info("Starting service monitoring")

        while True:
            try:
                for service_name in self.services.keys():
                    await self.check_service_health(service_name)

                # Log overall system health
                unhealthy_services = self.get_unhealthy_services()
                if unhealthy_services:
                    self.logger.warning(
                        f"System degraded - unhealthy services: {unhealthy_services}",
                        extra={"unhealthy_services": unhealthy_services},
                    )

                await asyncio.sleep(self.health_check_interval)

            except Exception as e:
                self.logger.error(f"Service monitoring error: {e}", exc_info=True)
                await asyncio.sleep(self.health_check_interval)


# Global degradation manager instance
degradation_manager = DegradationManager()
