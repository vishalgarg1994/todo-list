#!/usr/bin/env python3
"""
E2E Consumer Test - Consumes from NATS and loads into Memgraph
Tests the actual batch_graph_loader.py and message_handler.py code paths
"""

import sys
import os
import asyncio
import signal

# Add app directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'app'))

import nats  # noqa: E402
from nats.js.api import ConsumerConfig, AckPolicy, DeliverPolicy  # noqa: E402

# Now import app modules
from services.message_handler import TicketMessageHandler  # noqa: E402
from data_access.memgraphClient import MemgraphClient  # noqa: E402
from configs.config import Config  # noqa: E402
from utils.utilities import Helpers  # noqa: E402


class E2EConsumerTest:
    """End-to-end consumer test"""

    def __init__(self):
        self.nc = None
        self.js = None
        self.sub = None
        self.memgraph_client = None
        self.message_handler = None
        self.messages_processed = 0
        self.running = True

    async def setup(self):
        """Set up NATS and Memgraph connections"""
        print("Setting up E2E consumer...")

        # Connect to NATS with authentication
        nats_url = os.environ.get("NATS_URL", "nats://localhost:4222")
        nats_user = os.environ.get("NATS_CONSUMER_USER", "mcp-consumer")
        nats_pass = os.environ.get("NATS_CONSUMER_PASSWORD", "changeme-consumer")
        self.nc = await nats.connect(nats_url, user=nats_user, password=nats_pass)
        self.js = self.nc.jetstream()
        print(f"Connected to NATS: {nats_url} (user: {nats_user})")

        # Set up Memgraph
        config = Config()
        memgraph_uri = os.environ.get("MEMGRAPH_URI", "bolt://localhost:7687")
        config._memgraph_uri = memgraph_uri

        cyphers_yaml_dict = Helpers.load_cypher_configs(config.schema_desc_path)
        self.memgraph_client = MemgraphClient(
            uri=memgraph_uri,
            user=config.memgraph_user,
            password=config.memgraph_password,
            database=config.memgraph_database,
            cyphers_dict=cyphers_yaml_dict
        )
        await self.memgraph_client.connect()
        print(f"Connected to Memgraph: {memgraph_uri}")

        # Initialize message handler (uses batch_graph_loader internally)
        self.message_handler = TicketMessageHandler(self.memgraph_client, config)
        print("Message handler initialized")

    async def process_message(self, msg):
        """Process a single message using the actual message handler"""
        try:
            # Decompress message (same as handle_ticket_message)
            payload = Helpers.decompress_message(msg.data)

            if not isinstance(payload, dict):
                print(f"Unexpected payload type: {type(payload)}")
                await msg.ack()
                return

            # Process using batch graph loader (actual code path)
            success = await self.message_handler.process_ticket(payload)

            if success:
                self.messages_processed += 1
                client_name = payload.get("client_info", {}).get("client_name", "Unknown")
                ticket_count = len(payload.get("operational_status", []))
                print(f"[{self.messages_processed}] Processed: {client_name} ({ticket_count} tickets)")
                await msg.ack()
            else:
                print("Failed to process message")
                await msg.ack()  # ACK to avoid retry loop in test

        except Exception as e:
            print(f"Error processing message: {e}")
            import traceback
            traceback.print_exc()
            await msg.ack()

    async def consume(self, max_messages=10, timeout=30):
        """Consume messages from NATS"""
        stream_name = os.environ.get("JETSTREAM_STREAM_NAME", "EVA_TICKETING_STREAM")
        subject = os.environ.get("TICKET_SUBSCRIBE_SUBJECT", "tickets.created")

        print(f"\nSubscribing to {stream_name} / {subject}")
        print(f"Waiting for up to {max_messages} messages (timeout: {timeout}s)...")

        # Create durable consumer with unique name
        import time
        consumer_name = f"e2e-test-{int(time.time())}"
        consumer_config = ConsumerConfig(
            name=consumer_name,
            durable_name=consumer_name,
            ack_policy=AckPolicy.EXPLICIT,
            deliver_policy=DeliverPolicy.NEW,  # Only new messages
        )

        try:
            self.sub = await self.js.pull_subscribe(
                subject,
                durable=consumer_name,
                stream=stream_name,
                config=consumer_config
            )

            start_time = asyncio.get_event_loop().time()
            while self.running and self.messages_processed < max_messages:
                elapsed = asyncio.get_event_loop().time() - start_time
                if elapsed > timeout:
                    print(f"\nTimeout reached after {timeout}s")
                    break

                try:
                    messages = await self.sub.fetch(batch=1, timeout=5)
                    for msg in messages:
                        await self.process_message(msg)
                except nats.errors.TimeoutError:
                    # No messages available, continue waiting
                    pass

        except Exception as e:
            print(f"Consumer error: {e}")
            import traceback
            traceback.print_exc()

    async def validate_graph(self):
        """Validate data was loaded into Memgraph"""
        print("\n--- GRAPH VALIDATION ---")

        try:
            # Node counts
            records = await self.memgraph_client.execute(
                "MATCH (n) RETURN labels(n) AS label, count(n) AS cnt ORDER BY cnt DESC"
            )
            node_counts = [dict(r) for r in records]

            print("\nNode counts:")
            total_nodes = 0
            for row in node_counts:
                print(f"  {row['label']}: {row['cnt']}")
                total_nodes += row['cnt']
            print(f"  TOTAL: {total_nodes}")

            # Relationship counts
            records = await self.memgraph_client.execute(
                "MATCH ()-[r]->() RETURN type(r) AS rel, count(r) AS cnt ORDER BY cnt DESC"
            )
            rel_counts = [dict(r) for r in records]

            print("\nRelationship counts:")
            total_rels = 0
            for row in rel_counts:
                print(f"  {row['rel']}: {row['cnt']}")
                total_rels += row['cnt']
            print(f"  TOTAL: {total_rels}")

            # Ticket types
            records = await self.memgraph_client.execute(
                "MATCH (t:Ticket) RETURN t.ticket_type AS type, count(*) AS cnt"
            )
            ticket_types = [dict(r) for r in records]

            if ticket_types:
                print("\nTicket types:")
                for row in ticket_types:
                    print(f"  {row['type']}: {row['cnt']}")

            # FK relationships
            print("\nFK relationships:")
            for rel_type in ['RAISED_BY_INCIDENT', 'BELONGS_TO_CASE', 'RELATED_TO_PROBLEM', 'CHILD_OF']:
                records = await self.memgraph_client.execute(
                    f"MATCH ()-[r:{rel_type}]->() RETURN count(r) AS cnt"
                )
                data = [dict(r) for r in records]
                cnt = data[0]['cnt'] if data else 0
                if cnt > 0:
                    print(f"  {rel_type}: {cnt}")

            return total_nodes > 0

        except Exception as e:
            print(f"Validation error: {e}")
            return False

    async def cleanup(self):
        """Clean up connections"""
        print("\nCleaning up...")
        if self.sub:
            await self.sub.unsubscribe()
        if self.nc:
            await self.nc.close()
        if self.memgraph_client:
            await self.memgraph_client.shutdown()
        print("Cleanup complete")

    async def run(self, max_messages=10, timeout=30):
        """Run the E2E test"""
        print("=" * 60)
        print("E2E CONSUMER TEST")
        print("=" * 60)

        try:
            await self.setup()
            await self.consume(max_messages, timeout)
            success = await self.validate_graph()

            print("\n" + "=" * 60)
            if self.messages_processed > 0 and success:
                print(f"SUCCESS: Processed {self.messages_processed} messages")
            elif self.messages_processed == 0:
                print("NO MESSAGES: No messages received from NATS")
                print("Run the ETL to publish test data first")
            else:
                print("PARTIAL: Messages processed but validation failed")
            print("=" * 60)

            return self.messages_processed > 0 and success

        except Exception as e:
            print(f"E2E test failed: {e}")
            import traceback
            traceback.print_exc()
            return False

        finally:
            await self.cleanup()


def main():
    import argparse
    parser = argparse.ArgumentParser(description="E2E Consumer Test")
    parser.add_argument("--max-messages", type=int, default=10, help="Max messages to process")
    parser.add_argument("--timeout", type=int, default=30, help="Timeout in seconds")
    args = parser.parse_args()

    test = E2EConsumerTest()

    # Handle Ctrl+C gracefully
    def signal_handler(sig, frame):
        print("\nInterrupted, stopping...")
        test.running = False

    signal.signal(signal.SIGINT, signal_handler)

    success = asyncio.run(test.run(args.max_messages, args.timeout))
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
