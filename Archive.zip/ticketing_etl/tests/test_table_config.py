import pytest
import os
import sys
from unittest.mock import patch, mock_open

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from domain.table_config import TableConfig, TableRegistry


class TestTableConfigNew:
    def test_table_config_creation(self):
        """Test TableConfig creation with all required fields"""
        config = TableConfig(
            name="test_table",
            columns=["id", "name", "status"],
            topic="test.topic",
            transformer_class="TestTransformer",
        )

        assert config.name == "test_table"
        assert config.columns == ["id", "name", "status"]
        assert config.topic == "test.topic"
        assert config.transformer_class == "TestTransformer"
        assert config.enabled is True  # Default value
        assert config.filters is None  # Default value

    def test_table_config_with_optional_fields(self):
        """Test TableConfig creation with optional fields"""
        config = TableConfig(
            name="test_table",
            columns=["id"],
            topic="test.topic",
            transformer_class="TestTransformer",
            enabled=False,
            filters={"status": "active"},
        )

        assert config.enabled is False
        assert config.filters == {"status": "active"}

    def test_table_config_validation(self):
        """Test TableConfig validation"""
        # Empty name should raise error
        with pytest.raises(ValueError) as exc_info:
            TableConfig(
                name="",
                columns=["id"],
                topic="test.topic",
                transformer_class="TestTransformer",
            )
        assert "Table name cannot be empty" in str(exc_info.value)

        # Empty columns should raise error
        with pytest.raises(ValueError):
            TableConfig(
                name="test",
                columns=[],
                topic="test.topic",
                transformer_class="TestTransformer",
            )


class TestTableRegistryNew:
    @pytest.fixture
    def empty_registry(self):
        """Create registry with non-existent config file"""
        with patch("pathlib.Path.exists", return_value=False):
            return TableRegistry(config_path="nonexistent.yaml")

    @pytest.fixture
    def sample_yaml_config(self):
        """Sample YAML configuration content"""
        return """
tables:
  test_table:
    columns:
      - id
      - name
      - status
    topic: "test.topic"
    transformer_class: "TestTransformer"
    enabled: true

  disabled_table:
    columns:
      - id
    topic: "disabled.topic"
    transformer_class: "DisabledTransformer"
    enabled: false
"""

    def test_registry_initialization_with_default_config(self):
        """Test registry initialization creates default config when file not found"""
        with patch("pathlib.Path.exists", return_value=False):
            registry = TableRegistry(config_path="nonexistent.yaml")

        # Should have default rds.v_servicenow_cmd_ticket configuration
        assert "rds.v_servicenow_cmd_ticket" in registry.configs
        config = registry.configs["rds.v_servicenow_cmd_ticket"]
        assert config.name == "rds.v_servicenow_cmd_ticket"
        assert config.transformer_class == "TicketTransformer"
        assert config.enabled is True

    def test_registry_load_yaml_config(self, sample_yaml_config):
        """Test loading configuration from YAML file"""
        with patch("pathlib.Path.exists", return_value=True):
            with patch("builtins.open", mock_open(read_data=sample_yaml_config)):
                registry = TableRegistry(config_path="test.yaml")

        assert len(registry.configs) == 2
        assert "test_table" in registry.configs
        assert "disabled_table" in registry.configs

        test_config = registry.configs["test_table"]
        assert test_config.columns == ["id", "name", "status"]
        assert test_config.topic == "test.topic"
        assert test_config.enabled is True

    def test_get_table_config(self, empty_registry):
        """Test getting specific table configuration"""
        # Should return rds.v_servicenow_cmd_ticket config (default)
        config = empty_registry.get_table_config("rds.v_servicenow_cmd_ticket")
        assert config is not None
        assert config.name == "rds.v_servicenow_cmd_ticket"

        # Non-existent config should return None
        config = empty_registry.get_table_config("nonexistent")
        assert config is None

    def test_get_all_configs(self, empty_registry):
        """Test getting all configurations"""
        all_configs = empty_registry.get_all_configs()
        assert isinstance(all_configs, dict)
        assert "rds.v_servicenow_cmd_ticket" in all_configs

        # Should be a copy, not the original
        assert all_configs is not empty_registry.configs

    def test_get_enabled_configs(self):
        """Test getting only enabled configurations"""
        yaml_config = """
tables:
  enabled_table:
    columns: ["id"]
    topic: "enabled.topic"
    transformer_class: "EnabledTransformer"
    enabled: true

  disabled_table:
    columns: ["id"]
    topic: "disabled.topic"
    transformer_class: "DisabledTransformer"
    enabled: false
"""

        with patch("pathlib.Path.exists", return_value=True):
            with patch("builtins.open", mock_open(read_data=yaml_config)):
                registry = TableRegistry(config_path="test.yaml")

        enabled_configs = registry.get_enabled_configs()
        assert "enabled_table" in enabled_configs
        assert "disabled_table" not in enabled_configs

    def test_add_table_config(self, empty_registry):
        """Test adding new table configuration"""
        new_config = TableConfig(
            name="new_table",
            columns=["id", "data"],
            topic="new.topic",
            transformer_class="NewTransformer",
        )

        empty_registry.add_table_config(new_config)

        assert "new_table" in empty_registry.configs
        retrieved = empty_registry.get_table_config("new_table")
        assert retrieved.name == "new_table"

    def test_enable_disable_table(self, empty_registry):
        """Test enabling and disabling tables"""
        # Add a test config
        test_config = TableConfig(
            name="toggle_table",
            columns=["id"],
            topic="toggle.topic",
            transformer_class="ToggleTransformer",
            enabled=True,
        )
        empty_registry.add_table_config(test_config)

        # Disable it
        empty_registry.disable_table("toggle_table")
        config = empty_registry.get_table_config("toggle_table")
        assert config.enabled is False

        # Enable it back
        empty_registry.enable_table("toggle_table")
        config = empty_registry.get_table_config("toggle_table")
        assert config.enabled is True

        # Disabling non-existent table should not raise error
        empty_registry.disable_table("nonexistent")

    def test_reload_configs(self, sample_yaml_config):
        """Test reloading configurations"""
        with patch("pathlib.Path.exists", return_value=True):
            with patch("builtins.open", mock_open(read_data=sample_yaml_config)):
                registry = TableRegistry(config_path="test.yaml")

        # Should have loaded configs
        assert "test_table" in registry.configs

        # Reload should work
        with patch("pathlib.Path.exists", return_value=True):
            with patch("builtins.open", mock_open(read_data=sample_yaml_config)):
                registry.reload_configs()

        assert "test_table" in registry.configs


class TestGlobalTableRegistryNew:
    def test_global_registry_exists(self):
        """Test that global registry instance exists"""
        from domain.table_config import table_registry

        assert isinstance(table_registry, TableRegistry)
        assert table_registry.config_path == "config/tables.yaml"

    def test_global_registry_has_default_config(self):
        """Test that global registry has default configuration"""
        from domain.table_config import table_registry

        # Should have at least the default rds.servicenow_cmd_ticket config
        configs = table_registry.get_all_configs()
        assert len(configs) >= 1

        # Check for rds.servicenow_cmd_ticket specifically
        servicenow_config = table_registry.get_table_config("rds.servicenow_cmd_ticket")
        assert servicenow_config is not None
        assert servicenow_config.transformer_class == "TicketTransformer"
        assert servicenow_config.topic == "tickets.created"
