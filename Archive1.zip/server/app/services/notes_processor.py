"""
Notes Processor Service (Simplified)

Processes ticket notes fetched from ServiceNow API:
1. Combine all notes/emails/field_changes into one text block
2. Single LLM call per ticket for audit
3. Store NoteInfo in Memgraph

Pre-processing pipeline:
- Strip HTML/CSS from field_changes and emails
- Parse ME3 alarm JSON to extract timestamps and status
- Merge all events chronologically into unified timeline
- Mark DOWN/UP events for MTTR calculation
"""
import json
import logging
import re
from datetime import datetime, timezone
from typing import List, Dict, Any, Tuple, Optional

from configs.config import Config
from data_access.memgraphClient import MemgraphClient
from data_access.milvus_notes_client import MilvusNotesClient
from data_access.cyphers.notes_queries import UPSERT_NOTE_INFO
from services.extraction_service import ExtractionService
from services.embedding_service import EmbeddingService
from services.servicenow_client import TicketNotesData
from utils.text_utils import strip_html_css as _strip_html_css_util, sanitize_for_embedding as _sanitize_for_embedding_util


class NotesProcessor:
    """
    Processes ticket notes from ServiceNow API.

    Simplified: One LLM call per ticket (not per note).
    """

    def __init__(
        self,
        memgraph_client: MemgraphClient,
        config: Config = None,
        milvus_client: MilvusNotesClient = None
    ):
        self.config = config or Config()
        self.memgraph_client = memgraph_client
        self.extraction_service = ExtractionService(self.config)
        self.embedding_service = EmbeddingService(self.config)
        self.milvus_client = milvus_client  # Optional - for timeline embedding
        self.logger = logging.getLogger(__name__)

    async def initialize(self):
        """Test extraction and embedding model connections"""
        self.logger.info("Testing Ollama extraction model connection...")
        if not self.extraction_service.test_connection():
            raise RuntimeError(f"Ollama extraction model not available (model={self.config.ollama_extraction_model})")
        self.logger.info(f"Ollama extraction model available (model={self.config.ollama_extraction_model})")

        self.logger.info("Testing Ollama embedding model connection...")
        if not self.embedding_service.test_connection():
            raise RuntimeError("Ollama embedding service not available")
        self.logger.info("Ollama embedding model available")

        # Connect to Milvus if client provided
        if self.milvus_client:
            self.logger.info("Connecting to Milvus for timeline embeddings...")
            self.milvus_client.connect()
            self.logger.info("Connected to Milvus")

    async def _resolve_sys_ids(self, sys_ids: List[str]) -> Dict[str, str]:
        """Resolve sys_ids to human-readable names via Memgraph UserInfo nodes."""
        if not sys_ids:
            return {}
        query = """
        MATCH (u:UserInfo)
        WHERE u.user_id IN $sys_ids
        RETURN u.user_id AS sys_id, u.name AS name
        """
        try:
            records = await self.memgraph_client.execute(query, {"sys_ids": sys_ids})
            return {r["sys_id"]: r["name"] for r in records if r.get("name")}
        except Exception as e:
            self.logger.warning(f"Failed to resolve sys_ids: {e}")
            return {}

    async def close(self):
        """Cleanup connections"""
        if self.milvus_client:
            self.milvus_client.disconnect()
            self.logger.info("Disconnected from Milvus")

    async def process_ticket(
        self,
        notes_data: TicketNotesData,
        ticket_metadata: Dict[str, Any] = None
    ) -> Dict[str, int]:
        """
        Process all notes for a single ticket with ONE LLM call.

        Args:
            notes_data: TicketNotesData from ServiceNowClient
            ticket_metadata: Original ticket data from Memgraph for comparison

        Returns:
            Dict with processing counts
        """
        result = {
            "notes_count": len(notes_data.notes),
            "emails_count": len(notes_data.emails),
            "field_changes_count": len(notes_data.field_changes),
            "audit_stored": 0,
            "timeline_embedded": 0,
        }

        if not notes_data.fetch_success:
            self.logger.warning(f"Skipping {notes_data.ticket_id}: fetch failed - {notes_data.error_message}")
            return result

        ticket_sys_id = notes_data.ticket_sys_id
        ticket_id = notes_data.ticket_id
        ticket_metadata = ticket_metadata or {}

        # Resolve sys_ids in field_changes to human names (e.g. resolved_by)
        sys_id_pattern = re.compile(r'^[0-9a-f]{32}$')
        raw_sys_ids = set()
        for fc in notes_data.field_changes:
            if fc.new_value and sys_id_pattern.match(fc.new_value):
                raw_sys_ids.add(fc.new_value)
            if fc.old_value and sys_id_pattern.match(fc.old_value):
                raw_sys_ids.add(fc.old_value)
        name_lookup = await self._resolve_sys_ids(list(raw_sys_ids)) if raw_sys_ids else {}

        # Build combined text with clear sections
        # Full version (all field_changes) for LLM extraction
        combined_text, computed_facts = self._build_combined_text(notes_data, for_embedding=False, name_lookup=name_lookup)
        # Filtered version (important fields, grouped) for Milvus embedding
        combined_text_for_embedding, _ = self._build_combined_text(notes_data, for_embedding=True, name_lookup=name_lookup)

        if not combined_text.strip():
            self.logger.warning(f"Skipping {ticket_id}: no content to analyze")
            return result

        # Phase 1: Store sanitized (not truncated) context in feedback DB
        try:
            from data_access.feedback_db import insert_raw_context
            # Build untruncated sanitized versions using _strip_html_css
            notes_text = "\n".join(
                f"[{n.created_on}] ({n.element_type}) {self._strip_html_css(n.note_text)}"
                for n in notes_data.notes if n.note_text
            )
            emails_text = "\n".join(
                f"[{e.created_on}] {e.email_type} | {e.subject}\n{self._strip_html_css(e.body) if e.body else ''}"
                for e in notes_data.emails
            )
            field_changes_text = "\n".join(
                f"[{fc.created_on}] {fc.field_name}: {self._strip_html_css(fc.old_value) if fc.old_value else ''} → {self._strip_html_css(fc.new_value) if fc.new_value else ''}"
                for fc in notes_data.field_changes
            )
            insert_raw_context(
                ticket_id=ticket_id,
                ticket_sys_id=ticket_sys_id,
                raw_notes=notes_text,
                emails=emails_text,
                field_changes=field_changes_text,
            )
        except Exception as fb_err:
            self.logger.warning(f"Failed to store feedback context for {ticket_id}: {fb_err}")

        # Build ticket data string for audit prompt
        ticket_data = self._build_ticket_data_string(ticket_id, ticket_sys_id, ticket_metadata)

        # WS-B/C integration: append fault description summary to LLM input (not embedding)
        fault_summary = ticket_metadata.get('fault_description_summary', '')
        if fault_summary:
            combined_text = combined_text + "\n\nFault Description:\n" + fault_summary
            self.logger.debug(f"  {ticket_id}: appended fault description summary ({len(fault_summary)} chars) to LLM input")

        # ONE LLM call per ticket
        self.logger.info(f"Processing {ticket_id}: {result['notes_count']} notes, {result['emails_count']} emails, {result['field_changes_count']} field changes")

        audit_result = await self.extraction_service.audit_ticket_async(
            ticket_id=ticket_id,
            ticket_data=ticket_data,
            all_notes_text=combined_text,
            ticket_type=ticket_metadata.get('ticket_type'),
            ticket_category=ticket_metadata.get('ticket_category'),
        )

        # Post-process: override LLM values with deterministic computed facts
        if audit_result:
            audit_result = self._apply_computed_overrides(audit_result, computed_facts)

        # Store NoteInfo in Memgraph (upsert - one per ticket)
        if audit_result:
            note_info_id = f"ni_{ticket_sys_id}"  # Deterministic ID for upsert
            params = {
                "note_info_id": note_info_id,
                "note_id": note_info_id,
                "ticket_sys_id": ticket_sys_id,
                # Extracted values (from notes analysis)
                "fault_analysis": audit_result.get("fault_analysis"),
                "suggested_category": audit_result.get("suggested_category"),
                "fault_type": audit_result.get("fault_type"),
                "fault_summary": audit_result.get("fault_summary"),
                "responsible_party": audit_result.get("responsible_party"),
                "priority": audit_result.get("priority"),
                "mttr_minutes": audit_result.get("mttr_minutes"),
                "is_flapping": audit_result.get("is_flapping", False),
                "flap_cycles": audit_result.get("flap_cycles", 0),
                "root_cause": audit_result.get("root_cause"),
                "rfo": audit_result.get("rfo"),
                # Taxonomy lookup values (deterministic from YAML)
                "taxonomy_valid": audit_result.get("taxonomy_valid"),
                "taxonomy_priority": audit_result.get("taxonomy_priority"),
                "taxonomy_impact": audit_result.get("taxonomy_impact"),
                "taxonomy_urgency": audit_result.get("taxonomy_urgency"),
                "taxonomy_sla_hours": audit_result.get("taxonomy_sla_hours"),
                "taxonomy_sla": audit_result.get("taxonomy_sla"),
                # Suggested values (LLM generated)
                "suggested_resolution_notes": audit_result.get("suggested_resolution_notes"),
                "suggested_internal_notes": audit_result.get("suggested_internal_notes"),
                "suggested_actual_end_date": audit_result.get("suggested_actual_end_date"),
                # Original ticket values (for comparison)
                "ticket_fault_type": ticket_metadata.get("fault_type"),
                "ticket_responsible_party": ticket_metadata.get("responsible_party"),
                "ticket_priority": ticket_metadata.get("priority"),
                "ticket_mttr_minutes": ticket_metadata.get("mttr_minutes"),
                # Discrepancy tracking
                "differs_from_ticket": audit_result.get("differs_from_ticket", False),
                "confidence": audit_result.get("confidence", 0.0),
                "notes_analyzed": len(notes_data.notes),
                "emails_analyzed": len(notes_data.emails),
                "field_changes_analyzed": len(notes_data.field_changes),
                # Per-field evidence (why AI suggested each value)
                "evidence_priority": (audit_result.get("field_evidence") or {}).get("priority"),
                "evidence_fault_type": (audit_result.get("field_evidence") or {}).get("fault_type"),
                "evidence_responsible_party": (audit_result.get("field_evidence") or {}).get("responsible_party"),
                "evidence_mttr": (audit_result.get("field_evidence") or {}).get("mttr"),
                "processed_at": datetime.now(timezone.utc).isoformat(),
            }

            success = await self.memgraph_client.executeQuery(
                UPSERT_NOTE_INFO,
                params=params,
                message=f"NoteInfo audit {note_info_id}"
            )
            if success:
                result["audit_stored"] = 1
                self.logger.info(
                    f"  {ticket_id}: audit stored, differs={audit_result.get('differs_from_ticket')}, "
                    f"confidence={audit_result.get('confidence')}"
                )
            else:
                self.logger.warning(f"  {ticket_id}: Memgraph insert failed")
        else:
            self.logger.warning(f"  {ticket_id}: LLM audit returned no result")

        # Embed combined_text in Milvus (ticket-level embedding)
        # Use filtered version (important fields only) to stay within token limits
        if self.milvus_client and combined_text_for_embedding:
            try:
                # Sanitize for embedding model (remove problematic chars)
                sanitized_text = self._sanitize_for_embedding(combined_text_for_embedding)

                # Skip embedding if text is too large (needs intelligent preprocessing - see Future Work)
                max_embed_chars = 5500
                if len(sanitized_text) > max_embed_chars:
                    self.logger.warning(f"  {ticket_id}: skipping embedding, text too large ({len(sanitized_text)} chars > {max_embed_chars})")
                    return result

                self.logger.info(f"  {ticket_id}: embedding text length={len(sanitized_text)} chars")
                embedding = self.embedding_service.generate_embedding(sanitized_text)

                if embedding:
                    timeline_id = f"timeline_{ticket_sys_id}"
                    await self.milvus_client.insert(
                        note_ids=[timeline_id],
                        embeddings=[embedding],
                        summary_texts=[sanitized_text[:65535]],  # Store the structured summary
                        ticket_ids=[ticket_sys_id]
                    )
                    result["timeline_embedded"] = 1
                    self.logger.info(f"  {ticket_id}: timeline embedded in Milvus")
                else:
                    self.logger.warning(f"  {ticket_id}: embedding generation failed")
            except Exception as e:
                self.logger.error(f"  {ticket_id}: Milvus timeline insert failed: {e}")

        return result

    def _strip_html_css(self, text: str) -> str:
        """Strip HTML tags and CSS from text. Delegates to shared utility."""
        return _strip_html_css_util(text)

    def _sanitize_for_embedding(self, text: str) -> str:
        """Sanitize text for embedding model. Delegates to shared utility."""
        return _sanitize_for_embedding_util(text)

    def _parse_timestamp(self, ts_str: str) -> Optional[datetime]:
        """Parse various timestamp formats to datetime"""
        if not ts_str:
            return None
        # Try common formats
        formats = [
            "%Y-%m-%dT%H:%M:%SZ",      # ISO with Z
            "%Y-%m-%dT%H:%M:%S",       # ISO without Z
            "%Y-%m-%d %H:%M:%S",       # Standard datetime
            "%Y-%m-%d",                # Date only
        ]
        for fmt in formats:
            try:
                return datetime.strptime(ts_str.strip(), fmt)
            except ValueError:
                continue
        return None

    def _parse_me3_json(self, json_str: str) -> Optional[Dict[str, Any]]:
        """
        Parse ME3 alarm JSON to extract key fields.

        Returns dict with: first_notify, last_notify, status, node, message, alarm_id
        """
        if not json_str:
            return None
        try:
            data = json.loads(json_str)
            return {
                "first_notify": data.get("first_notify"),
                "last_notify": data.get("last_notify"),
                "status": data.get("status"),  # DOWN, UP, CLEARED
                "node": data.get("node"),
                "message": data.get("message"),
                "alarm_id": data.get("alarm_id") or data.get("id"),
                "severity": data.get("severity"),
            }
        except (json.JSONDecodeError, TypeError):
            return None

    def _extract_me3_from_field_change(self, new_value: str) -> Optional[Dict[str, Any]]:
        """
        Extract ME3 alarm data from field_change new_value.
        Handles both raw JSON and HTML-wrapped JSON.
        """
        if not new_value:
            return None

        # Strip HTML first
        cleaned = self._strip_html_css(new_value)

        # Try to find JSON object in the cleaned text
        json_match = re.search(r'\{[^{}]*"first_notify"[^{}]*\}', cleaned)
        if json_match:
            return self._parse_me3_json(json_match.group())

        # Try parsing whole cleaned string as JSON
        return self._parse_me3_json(cleaned)

    def _build_timeline_events(self, notes_data: TicketNotesData, for_embedding: bool = False, name_lookup: Dict[str, str] = None) -> List[Dict[str, Any]]:
        """
        Build chronological list of all events from notes, emails, field_changes.
        Each event has: timestamp, event_type, marker (DOWN/UP/INFO), content

        Args:
            notes_data: The ticket notes data
            for_embedding: If True, filter to important fields and group by timestamp.
                          If False, include all field_changes (for LLM extraction).
        """
        events = []

        # Process notes
        for note in notes_data.notes:
            ts = self._parse_timestamp(note.created_on)
            if not ts:
                continue

            note_text = note.note_text.strip() if note.note_text else ""
            if not note_text:
                continue

            # Detect DOWN/UP indicators in note text
            marker = "INFO"
            text_lower = note_text.lower()
            if any(kw in text_lower for kw in ["down", "outage", "unreachable", "failed", "alarm"]):
                marker = "DOWN"
            elif any(kw in text_lower for kw in ["restored", "cleared", "resolved", "up", "recovered"]):
                marker = "UP"

            events.append({
                "timestamp": ts,
                "event_type": f"NOTE ({note.element_type})",
                "marker": marker,
                "content": note_text[:500] + "..." if len(note_text) > 500 else note_text,
                "user": getattr(note, 'created_by', None) or getattr(note, 'user', ''),
            })

        # Process emails (strip HTML from body)
        for email in notes_data.emails:
            ts = self._parse_timestamp(email.created_on)
            if not ts:
                continue

            body = self._strip_html_css(email.body) if email.body else ""
            if not body:
                continue

            # Build email header
            header = f"From: {email.from_address or 'unknown'} To: {email.to_address or 'unknown'}"
            subject = f"Subject: {email.subject}" if email.subject else ""

            events.append({
                "timestamp": ts,
                "event_type": f"EMAIL ({email.email_type})",
                "marker": "INFO",
                "content": f"{header}\n{subject}\n{body[:400]}..." if len(body) > 400 else f"{header}\n{subject}\n{body}",
                "user": "",
            })

        # Process field_changes
        # Exclude only known noise fields - include everything else for broad search coverage
        EXCLUDED_FIELDS = {
            "u_alarm_history",      # Cumulative HTML table - confuses cycle counting
            "u_alarm_information",  # Cumulative text - redundant with ME3 alarm JSON and u_alarm_status
            "calendar_stc",         # Raw seconds counter (calendar_duration is the readable version)
            "business_stc",         # Raw seconds counter (business_duration is the readable version)
            "work_notes",           # Already captured separately as notes_data.notes
            "comments",             # Already captured separately as notes_data.notes
        }

        if for_embedding:
            # FILTERED + GROUPED: For embedding/search - reduce size
            changes_by_ts = {}
            for change in notes_data.field_changes:
                ts = self._parse_timestamp(change.created_on)
                if not ts:
                    continue

                field_name = change.field_name or "unknown_field"

                # Special handling for alarm-related fields (always include)
                # Note: Skip u_alarm_history - it contains cumulative data that confuses cycle counting
                if field_name in ["u_alarm_status", "alarm"]:
                    me3_data = self._extract_me3_from_field_change(change.new_value)
                    if me3_data:
                        status = (me3_data.get("status") or "").upper()
                        if status in ["DOWN", "CRITICAL", "MAJOR"]:
                            marker = "DOWN"
                        elif status in ["UP", "CLEARED", "OK"]:
                            marker = "UP"
                        else:
                            marker = "ALARM"

                        content_parts = []
                        if me3_data.get("node"):
                            content_parts.append(f"Node: {me3_data['node']}")
                        if me3_data.get("message"):
                            content_parts.append(f"Message: {me3_data['message']}")
                        if me3_data.get("first_notify"):
                            content_parts.append(f"First: {me3_data['first_notify']}")
                        if me3_data.get("last_notify"):
                            content_parts.append(f"Last: {me3_data['last_notify']}")

                        events.append({
                            "timestamp": ts,
                            "event_type": f"ME3_ALARM ({status})",
                            "marker": marker,
                            "content": " | ".join(content_parts) if content_parts else f"Alarm status: {status}",
                            "user": getattr(change, 'user', ''),
                        })
                        continue
                    else:
                        # Handle simple string values like "Clear" (not JSON)
                        new_val = self._strip_html_css(change.new_value) if change.new_value else ""
                        new_val_lower = new_val.lower()
                        if "clear" in new_val_lower:
                            marker = "UP"
                        elif "active" in new_val_lower or "mixed" in new_val_lower:
                            marker = "DOWN"
                        else:
                            self.logger.warning(f"Unknown alarm status value: {new_val}")
                            marker = "INFO"

                        events.append({
                            "timestamp": ts,
                            "event_type": f"ALARM_STATUS",
                            "marker": marker,
                            "content": f"Alarm status changed to: {new_val}",
                            "user": getattr(change, 'user', ''),
                        })
                        continue

                # Filter: exclude known noise fields
                if field_name in EXCLUDED_FIELDS:
                    continue

                # Group by timestamp
                ts_key = ts.strftime("%Y-%m-%d %H:%M:%S")
                if ts_key not in changes_by_ts:
                    changes_by_ts[ts_key] = {"ts": ts, "changes": [], "user": getattr(change, 'user', '')}

                old_val = self._strip_html_css(change.old_value) if change.old_value else "(empty)"
                new_val = self._strip_html_css(change.new_value) if change.new_value else "(empty)"

                # Resolve sys_ids to human names
                if name_lookup:
                    old_val = name_lookup.get(old_val, old_val)
                    new_val = name_lookup.get(new_val, new_val)

                if len(old_val) > 100:
                    old_val = old_val[:100] + "..."
                if len(new_val) > 100:
                    new_val = new_val[:100] + "..."

                marker = "UP" if field_name in ["work_end", "resolved_at", "actual_end", "closed_at"] else "INFO"

                changes_by_ts[ts_key]["changes"].append({
                    "field": field_name,
                    "old": old_val,
                    "new": new_val,
                    "marker": marker,
                })

            # Convert grouped changes to events
            for ts_key, group in changes_by_ts.items():
                if not group["changes"]:
                    continue
                changes = group["changes"]
                if len(changes) == 1:
                    c = changes[0]
                    events.append({
                        "timestamp": group["ts"],
                        "event_type": f"FIELD ({c['field']})",
                        "marker": c["marker"],
                        "content": f"{c['old']} → {c['new']}",
                        "user": group["user"],
                    })
                else:
                    parts = [f"{c['field']}: {c['new']}" for c in changes]
                    marker = "UP" if any(c["marker"] == "UP" for c in changes) else "INFO"
                    events.append({
                        "timestamp": group["ts"],
                        "event_type": f"FIELDS ({len(changes)})",
                        "marker": marker,
                        "content": " | ".join(parts),
                        "user": group["user"],
                    })
        else:
            # FULL: For LLM extraction - include ALL field_changes
            for change in notes_data.field_changes:
                ts = self._parse_timestamp(change.created_on)
                if not ts:
                    continue

                field_name = change.field_name or "unknown_field"

                # Special handling for alarm-related fields
                # Note: Skip u_alarm_history - it contains cumulative data that confuses cycle counting
                # u_alarm_status provides clean state transitions (Active/Clear)
                if field_name in ["u_alarm_status", "alarm"]:
                    me3_data = self._extract_me3_from_field_change(change.new_value)
                    if me3_data:
                        status = (me3_data.get("status") or "").upper()
                        if status in ["DOWN", "CRITICAL", "MAJOR"]:
                            marker = "DOWN"
                        elif status in ["UP", "CLEARED", "OK"]:
                            marker = "UP"
                        else:
                            marker = "ALARM"

                        content_parts = []
                        if me3_data.get("node"):
                            content_parts.append(f"Node: {me3_data['node']}")
                        if me3_data.get("message"):
                            content_parts.append(f"Message: {me3_data['message']}")
                        if me3_data.get("first_notify"):
                            content_parts.append(f"First: {me3_data['first_notify']}")
                        if me3_data.get("last_notify"):
                            content_parts.append(f"Last: {me3_data['last_notify']}")

                        events.append({
                            "timestamp": ts,
                            "event_type": f"ME3_ALARM ({status})",
                            "marker": marker,
                            "content": " | ".join(content_parts) if content_parts else f"Alarm status: {status}",
                            "user": getattr(change, 'user', ''),
                        })
                        continue
                    else:
                        # Handle simple string values like "Clear" (not JSON)
                        new_val = self._strip_html_css(change.new_value) if change.new_value else ""
                        new_val_lower = new_val.lower()
                        if "clear" in new_val_lower:
                            marker = "UP"
                        elif "active" in new_val_lower or "mixed" in new_val_lower:
                            marker = "DOWN"
                        else:
                            self.logger.warning(f"Unknown alarm status value: {new_val}")
                            marker = "INFO"

                        events.append({
                            "timestamp": ts,
                            "event_type": f"ALARM_STATUS",
                            "marker": marker,
                            "content": f"Alarm status changed to: {new_val}",
                            "user": getattr(change, 'user', ''),
                        })
                        continue

                # Special handling for resolution timestamps
                if field_name in ["work_end", "resolved_at", "actual_end", "closed_at"]:
                    new_val = self._strip_html_css(change.new_value) if change.new_value else "(empty)"
                    events.append({
                        "timestamp": ts,
                        "event_type": f"FIELD ({field_name})",
                        "marker": "UP",
                        "content": f"{new_val[:200]}" if len(new_val) > 200 else f"{new_val}",
                        "user": getattr(change, 'user', ''),
                    })
                    continue

                # Standard field change
                old_val = self._strip_html_css(change.old_value) if change.old_value else "(empty)"
                new_val = self._strip_html_css(change.new_value) if change.new_value else "(empty)"

                # Resolve sys_ids to human names
                if name_lookup:
                    old_val = name_lookup.get(old_val, old_val)
                    new_val = name_lookup.get(new_val, new_val)

                if len(old_val) > 200:
                    old_val = old_val[:200] + "..."
                if len(new_val) > 200:
                    new_val = new_val[:200] + "..."

                events.append({
                    "timestamp": ts,
                    "event_type": f"FIELD ({field_name})",
                    "marker": "INFO",
                    "content": f"{old_val} → {new_val}",
                    "user": getattr(change, 'user', ''),
                })

        # Sort by timestamp
        events.sort(key=lambda e: e["timestamp"])
        return events

    def _calculate_outage_periods(self, events: List[Dict[str, Any]]) -> List[Tuple[datetime, datetime, int]]:
        """
        Calculate outage periods from ALARM_STATUS events only.
        Returns list of (start, end, duration_minutes) tuples.

        Flapping detection: count how many times alarm goes to Clear.
        - 1 Clear = normal ticket (not flapping)
        - 2+ Clears = flapping pattern
        Only ALARM_STATUS (u_alarm_status) provides clean state transitions.
        Alarm can go Active → Mixed → Clear, so we track first DOWN to each Clear.
        """
        periods = []
        down_start = None

        for event in events:
            # Only use u_alarm_status for cycle counting
            if event.get("event_type") != "ALARM_STATUS":
                continue

            marker = event.get("marker", "INFO")
            ts = event["timestamp"]

            if marker == "DOWN" and down_start is None:
                down_start = ts
            elif marker == "UP" and down_start is not None:
                duration = int((ts - down_start).total_seconds() / 60)
                periods.append((down_start, ts, duration))
                down_start = None

        return periods

    def _extract_service_info_from_note(self, note_text: str) -> Dict[str, Any]:
        """Extract service/client info from ME3 alarm JSON in note text"""
        info = {}
        if not note_text:
            return info

        # Try to find JSON in note
        try:
            # Look for JSON block in note
            json_match = re.search(r'\{.*"services".*\}', note_text, re.DOTALL)
            if json_match:
                data = json.loads(json_match.group())

                # Extract from ME3 alarm structure
                if data.get("services") and len(data["services"]) > 0:
                    svc = data["services"][0]
                    info["service_id"] = svc.get("service_id")
                    info["service_sys_id"] = svc.get("sys_id")
                    info["gnid"] = svc.get("gnid")
                    info["service_type"] = svc.get("type")
                    if svc.get("client"):
                        info["client_id"] = svc["client"].get("id")
                        info["client_name"] = svc["client"].get("name")
                    if svc.get("site"):
                        info["site_id"] = svc["site"].get("id")
                        info["site_address"] = svc["site"].get("address")

                if data.get("node"):
                    node = data["node"]
                    info["device_name"] = node.get("name")
                    info["device_class"] = node.get("class")
                    info["device_source"] = node.get("source")

                if data.get("event"):
                    event = data["event"]
                    info["alarm_severity"] = event.get("severity")
                    info["alarm_message"] = event.get("message")

                info["alarm_name"] = data.get("name")
                info["alarm_status"] = data.get("status")
                info["first_notify"] = data.get("first_notify")
                info["last_notify"] = data.get("last_notify")
                info["alarm_count"] = data.get("count")
                info["alarm_acknowledged"] = data.get("acknowledged")
                info["alarm_timestamp"] = data.get("timestamp")

        except (json.JSONDecodeError, TypeError, KeyError):
            pass

        return info

    def _extract_ticket_status_from_field_changes(self, field_changes, name_lookup: Dict[str, str] = None) -> Dict[str, Any]:
        """Extract ticket status fields from field_changes. Resolves sys_ids to names using name_lookup."""
        status = {}
        alarm_clear_timestamps = []  # Track all clear timestamps for flapping
        name_lookup = name_lookup or {}

        # Track latest value for each field
        for change in field_changes:
            field = change.field_name
            new_val = self._strip_html_css(change.new_value) if change.new_value else None

            if field == "state":
                status["state"] = new_val
            elif field == "priority":
                status["priority"] = new_val
            elif field == "u_responsible_party":
                status["responsible_party"] = new_val
            elif field == "resolution_code":
                status["resolution_code"] = new_val
            elif field == "close_notes":
                status["close_notes"] = new_val
            elif field == "resolved_by":
                status["resolved_by"] = name_lookup.get(new_val, new_val) if new_val else new_val
            elif field == "resolved_at":
                status["resolved_at"] = new_val
            elif field == "work_end":
                status["work_end"] = new_val
            elif field == "auto_close":
                status["auto_close"] = new_val
            elif field == "first_response_time":
                status["first_response_time"] = new_val
            elif field == "u_adjusted_business_elapsed_time":
                # Parse duration from 1970-01-01 00:10:36 format
                if new_val and "1970-01-01" in new_val:
                    time_part = new_val.replace("1970-01-01 ", "")
                    status["system_mttr"] = time_part
            elif field == "u_mttr":
                # Raw minutes (e.g., 149496.97) - fallback if no other MTTR source
                if new_val and "system_mttr" not in status:
                    try:
                        mttr_min = int(float(new_val))
                        days = mttr_min // (24 * 60)
                        remaining = mttr_min % (24 * 60)
                        hours = remaining // 60
                        mins = remaining % 60
                        if days > 0:
                            status["system_mttr"] = f"{days}d {hours}h {mins}m ({mttr_min} min)"
                        elif hours > 0:
                            status["system_mttr"] = f"{hours}h {mins}m ({mttr_min} min)"
                        else:
                            status["system_mttr"] = f"{mins}m"
                    except (ValueError, TypeError):
                        pass
            elif field == "business_duration":
                # Epoch format (e.g., 1970-01-25 16:00:00) - fallback if no other MTTR source
                if new_val and "1970-" in new_val and "system_mttr" not in status:
                    time_part = new_val.replace("1970-", "")
                    status["system_mttr"] = time_part
            elif field == "u_alarm_status":
                status["alarm_status"] = new_val
                # Track timestamp when alarm cleared (for Alarm End)
                if new_val and "clear" in new_val.lower():
                    ts = self._parse_timestamp(change.created_on)
                    if ts:
                        alarm_clear_timestamps.append(ts)

        # Use the LAST clear timestamp as alarm end (handles flapping)
        if alarm_clear_timestamps:
            status["alarm_cleared_at"] = max(alarm_clear_timestamps).strftime("%Y-%m-%d %H:%M:%S")

        # Auto-closed tickets: override resolved_by with system name
        if status.get("auto_close") == "1":
            status["resolved_by"] = "GEARS (automated)"

        return status

    def _extract_site_contact_from_email(self, email_body: str) -> Dict[str, Any]:
        """Extract site contact info from email body"""
        info = {}
        if not email_body:
            return info

        body = self._strip_html_css(email_body)

        # Look for site contact patterns
        contact_match = re.search(r'Site Contact Name\s*[:\|]?\s*([A-Z][A-Z\s]+)', body)
        if contact_match:
            info["site_contact_name"] = contact_match.group(1).strip()

        phone_match = re.search(r'Site Contact Number\s*[:\|]?\s*(\d+)', body)
        if phone_match:
            info["site_contact_phone"] = phone_match.group(1)

        hours_match = re.search(r'Access Hours\s*[:\|]?\s*(\d+\s*-\s*\d+)', body)
        if hours_match:
            info["access_hours"] = hours_match.group(1)

        # Extract PON info
        pon_match = re.search(r'GTT PON\s*[:\|]?\s*(\d+)', body)
        if pon_match:
            info["gtt_pon"] = pon_match.group(1)

        cpon_match = re.search(r'CPON/Client Item Label\s*[:\|]?\s*(\S+)', body)
        if cpon_match:
            info["cpon"] = cpon_match.group(1)

        # Extract sub-category
        subcat_match = re.search(r'Sub-Category\s*[:\|]?\s*([^\n<]+)', body)
        if subcat_match:
            info["sub_category"] = subcat_match.group(1).strip()

        return info

    def _format_timeline_event(self, event: Dict[str, Any]) -> str:
        """Format a single timeline event as prose"""
        ts = event["timestamp"].strftime("%H:%M:%S")
        event_type = event["event_type"]
        content = event["content"]
        user = event.get("user", "")

        # Clean up content - remove excessive newlines, collapse spaces
        content = re.sub(r'\s+', ' ', content).strip()

        # Format based on event type
        if "NOTE" in event_type:
            user_str = f" by {user}" if user else ""
            return f"At {ts}, {user_str.strip()} added {event_type.lower()}: {content}"
        elif "EMAIL" in event_type:
            # Simplify email - just show type and key info
            if "Opened" in content or "opened" in content.lower():
                return f"At {ts}, an Incident Opened email was sent."
            elif "Resolved" in content or "resolved" in content.lower():
                return f"At {ts}, an Incident Resolved email was sent."
            else:
                return f"At {ts}, an email was sent ({event_type})."
        elif "ME3_ALARM" in event_type:
            return f"At {ts}, {content}"
        elif "FIELD" in event_type:
            field_name = event_type.replace("FIELD (", "").replace(")", "")
            user_str = f"{user}" if user else "system"
            return f"At {ts}, {user_str} set {field_name}: {content}"
        else:
            return f"At {ts}, {event_type}: {content}"

    def _build_combined_text(self, notes_data: TicketNotesData, max_size: int = 25000, for_embedding: bool = False, name_lookup: Dict[str, str] = None) -> tuple:
        """
        Build structured summary from notes, emails, field_changes.

        Returns:
            Tuple of (text, computed_facts) where computed_facts is a dict with:
            - outage_window_minutes: int
            - is_flapping: bool
            - flap_cycles: int
            - total_down_minutes: int

        Format:
        Case Summary: (prose intro paragraph)
        Affected Service: (client, service, device, site info)
        Cause: (alarm severity and message)
        Outage Period: (alarm start/end, duration, system MTTR)
        Timeline: (chronological events with newlines)
        Communications: (email events)
        Resolution: (resolution code, close notes, responsible party)
        People: (assigned, resolved_by, site contact)

        If total size > max_size, truncate timeline to first N + last N events.
        """
        # Extract static info from notes (ME3 alarm JSON)
        service_info = {}
        for note in notes_data.notes:
            extracted = self._extract_service_info_from_note(note.note_text)
            if extracted:
                service_info.update(extracted)
                break  # Usually first note has the alarm JSON

        # Extract site contact from emails
        for email in notes_data.emails:
            extracted = self._extract_site_contact_from_email(email.body)
            if extracted:
                service_info.update(extracted)
                break

        # Extract ticket status from field_changes
        ticket_status = self._extract_ticket_status_from_field_changes(notes_data.field_changes, name_lookup=name_lookup)

        # Build chronological events
        events = self._build_timeline_events(notes_data, for_embedding=for_embedding, name_lookup=name_lookup)

        empty_facts = {"outage_window_minutes": 0, "is_flapping": False, "flap_cycles": 0, "total_down_minutes": 0}
        if not events:
            return ("", empty_facts)

        # Calculate outage periods for flapping detection
        outage_periods = self._calculate_outage_periods(events)
        is_flapping = len(outage_periods) > 1

        # Calculate outage window (first DOWN to last UP) - more reliable than summing periods
        first_down_ts = None
        last_up_ts = None
        for event in events:
            if event.get("marker") == "DOWN" and first_down_ts is None:
                first_down_ts = event["timestamp"]
            if event.get("marker") == "UP":
                last_up_ts = event["timestamp"]

        # Calculate window duration in minutes
        outage_window_minutes = 0
        if first_down_ts and last_up_ts and last_up_ts > first_down_ts:
            outage_window_minutes = int((last_up_ts - first_down_ts).total_seconds() / 60)

        lines = []

        # === CASE SUMMARY (prose intro) ===
        lines.append("Case Summary:")
        summary_parts = [f"{notes_data.ticket_id} is a"]
        if ticket_status.get("priority"):
            summary_parts.append(f"Priority {ticket_status.get('priority')}")
        if service_info.get("alarm_severity"):
            # Map ME3 severity to human-readable
            severity_map = {
                "10": "Clear", "20": "Warning", "30": "Minor",
                "40": "Major", "50": "Critical"
            }
            sev = str(service_info.get("alarm_severity"))
            sev_label = severity_map.get(sev, f"severity {sev}")
            summary_parts.append(sev_label)
        summary_parts.append("incident")
        if service_info.get("client_name"):
            summary_parts.append(f"for {service_info.get('client_name')}.")
        else:
            summary_parts[-1] += "."

        alarm_desc = ""
        if service_info.get("alarm_name"):
            alarm_desc = f"A {service_info.get('alarm_name')} alarm"
        elif service_info.get("alarm_message"):
            alarm_desc = f"An alarm ({service_info.get('alarm_message')})"
        else:
            alarm_desc = "An alarm"

        if service_info.get("device_name"):
            alarm_desc += f" was detected on device {service_info.get('device_name')}"
        if service_info.get("site_address"):
            alarm_desc += f" at site {service_info.get('site_address')}"
        if service_info.get("service_id"):
            alarm_desc += f", affecting service {service_info.get('service_id')}"
            if service_info.get("gnid"):
                alarm_desc += f" (GNID: {service_info.get('gnid')})"
        alarm_desc += "."

        resolution_desc = ""
        if ticket_status.get("resolved_by"):
            if "gears" in ticket_status.get("resolved_by", "").lower():
                resolution_desc = "The issue was automatically resolved by GEARS when the alarm cleared."
            else:
                resolution_desc = f"The issue was resolved by {ticket_status.get('resolved_by')}."

        lines.append(" ".join(summary_parts) + " " + alarm_desc + (" " + resolution_desc if resolution_desc else ""))

        # === AFFECTED SERVICE ===
        lines.append("")
        lines.append("Affected Service:")
        if service_info.get("client_name"):
            client_line = f"- Client: {service_info.get('client_name')}"
            if service_info.get("client_id"):
                client_line += f" (Client ID: {service_info.get('client_id')})"
            lines.append(client_line)

        if service_info.get("service_id"):
            svc_line = f"- Service: {service_info.get('service_id')}"
            if service_info.get("gnid"):
                svc_line += f" (GNID: {service_info.get('gnid')})"
            lines.append(svc_line)

        if service_info.get("device_name"):
            device_line = f"- Device: {service_info.get('device_name')}"
            if service_info.get("device_class"):
                device_line += f" (device_class: {service_info.get('device_class')}"
                if service_info.get("device_source"):
                    device_line += f", source: {service_info.get('device_source')}"
                device_line += ")"
            lines.append(device_line)

        if service_info.get("site_address"):
            site_line = f"- Site: {service_info.get('site_address')}"
            if service_info.get("site_id"):
                site_line += f" (Site ID: {service_info.get('site_id')})"
            lines.append(site_line)

        if service_info.get("site_contact_name"):
            contact_line = f"- Site Contact: {service_info.get('site_contact_name')}"
            if service_info.get("site_contact_phone"):
                contact_line += f", Phone: {service_info.get('site_contact_phone')}"
            if service_info.get("access_hours"):
                contact_line += f", Access Hours: {service_info.get('access_hours')}"
            lines.append(contact_line)

        if service_info.get("gtt_pon") or service_info.get("cpon"):
            pon_line = "- "
            if service_info.get("gtt_pon"):
                pon_line += f"GTT PON: {service_info.get('gtt_pon')}"
            if service_info.get("cpon"):
                pon_line += f", CPON: {service_info.get('cpon')}" if service_info.get("gtt_pon") else f"CPON: {service_info.get('cpon')}"
            lines.append(pon_line)

        # === CAUSE ===
        lines.append("")
        lines.append("Cause:")
        cause_parts = []
        if service_info.get("alarm_name"):
            cause_parts.append(f"{service_info.get('alarm_name')} alarm")
        if service_info.get("alarm_severity"):
            cause_parts.append(f"(severity: {service_info.get('alarm_severity')})")
        if service_info.get("alarm_message"):
            cause_parts.append(f'- "{service_info.get("alarm_message")}"')
        if cause_parts:
            lines.append(" ".join(cause_parts))
        else:
            lines.append("Unknown cause")

        # === OUTAGE PERIOD ===
        lines.append("")
        lines.append("Outage Period:")
        if service_info.get("first_notify"):
            lines.append(f"- Alarm Start: {service_info.get('first_notify')} UTC")
        # Use alarm_cleared_at (timestamp when u_alarm_status became Clear) as the actual service restoration
        if ticket_status.get("alarm_cleared_at"):
            lines.append(f"- Alarm End: {ticket_status.get('alarm_cleared_at')} UTC")
        elif service_info.get("last_notify") and service_info.get("last_notify") != service_info.get("first_notify"):
            # Fallback: use last_notify only if it differs from first_notify
            lines.append(f"- Alarm End: {service_info.get('last_notify')} UTC")

        # Show outage window (first DOWN to last UP)
        if outage_window_minutes > 0:
            days = outage_window_minutes // (24 * 60)
            remaining = outage_window_minutes % (24 * 60)
            hours = remaining // 60
            minutes = remaining % 60
            if days > 0:
                lines.append(f"- Outage Window: {days} days {hours} hours {minutes} minutes ({outage_window_minutes} min)")
            elif hours > 0:
                lines.append(f"- Outage Window: {hours} hours {minutes} minutes ({outage_window_minutes} min)")
            else:
                lines.append(f"- Outage Window: {minutes} minutes")

        # Note flapping pattern and calculate total DOWN time
        if is_flapping:
            total_down_minutes = sum(period[2] for period in outage_periods)
            lines.append(f"- Pattern: Flapping ({len(outage_periods)} cycles detected)")
            lines.append(f"- Total Down Time: {total_down_minutes} minutes (sum of DOWN periods)")
            lines.append(f"- Note: Use Total Down Time for MTTR, not Outage Window")

        if ticket_status.get("system_mttr"):
            lines.append(f"- System MTTR: {ticket_status.get('system_mttr')} (from ticket creation)")

        # === RESOLUTION === (before Timeline so it's preserved if truncated)
        lines.append("")
        lines.append("Resolution:")
        if ticket_status.get("resolution_code"):
            lines.append(f"Resolution code: {ticket_status.get('resolution_code')}.")
        if ticket_status.get("close_notes"):
            lines.append(f"Close notes: \"{ticket_status.get('close_notes')}\"")
        if ticket_status.get("responsible_party"):
            lines.append(f"Responsible party: {ticket_status.get('responsible_party')}.")
        if not any([ticket_status.get("resolution_code"), ticket_status.get("close_notes"),
                    ticket_status.get("responsible_party")]):
            if resolution_desc:
                lines.append(resolution_desc)
            else:
                lines.append("Resolution details not available.")

        # === PEOPLE === (before Timeline so it's preserved if truncated)
        lines.append("")
        lines.append("People:")
        people_found = False
        if ticket_status.get("resolved_by"):
            lines.append(f"- Resolved by: {ticket_status.get('resolved_by')}")
            people_found = True
        if service_info.get("site_contact_name"):
            contact_str = f"- Site Contact: {service_info.get('site_contact_name')}"
            if service_info.get("site_contact_phone"):
                contact_str += f" ({service_info.get('site_contact_phone')})"
            lines.append(contact_str)
            people_found = True
        if not people_found:
            lines.append("No people information available.")

        # === BUILD TIMELINE AND COMMUNICATIONS ===
        # Separate timeline events from email events
        timeline_lines = []
        email_lines = []
        for event in events:
            formatted = self._format_timeline_event(event)
            if "EMAIL" in event["event_type"]:
                email_lines.append(formatted)
            else:
                timeline_lines.append(formatted)

        # Build Communications section
        comms_lines = ["", "Communications:"]
        if email_lines:
            comms_lines.extend(email_lines)
        else:
            comms_lines.append("No email communications recorded.")

        # Build Metadata section
        metadata_lines = ["", f"Events analyzed: {len(events)} ({len(notes_data.notes)} notes, {len(notes_data.emails)} emails, {len(notes_data.field_changes)} field_changes)"]

        # Calculate sizes
        header_text = "\n".join(lines)  # Everything before Timeline
        comms_text = "\n".join(comms_lines)
        metadata_text = "\n".join(metadata_lines)
        full_timeline = "\n".join(timeline_lines)

        # For embedding: truncate Timeline to fit 5500 total
        if for_embedding:
            target_size = 5500
            fixed_size = len(header_text) + len(comms_text) + len(metadata_text) + 20  # 20 for "Timeline:" header + newlines

            # If fixed sections alone exceed limit, skip embedding entirely
            if fixed_size > target_size:
                self.logger.warning(f"Fixed sections too large for embedding ({fixed_size} chars > {target_size}), skipping")
                return ("", empty_facts)

            available_for_timeline = target_size - fixed_size

            if available_for_timeline < len(full_timeline) and len(timeline_lines) > 6:
                # Need to truncate - calculate how many events fit
                chars_per_event = len(full_timeline) / len(timeline_lines) if timeline_lines else 100
                events_to_keep = max(6, int(available_for_timeline / chars_per_event))

                first_n = events_to_keep // 2
                last_n = events_to_keep - first_n

                if first_n + last_n < len(timeline_lines):
                    omitted_count = len(timeline_lines) - first_n - last_n
                    first_events = timeline_lines[:first_n]
                    last_events = timeline_lines[-last_n:]

                    # Get time range of omitted events
                    non_email_events = [e for e in events if "EMAIL" not in e["event_type"]]
                    if len(non_email_events) > first_n + last_n:
                        first_omitted_ts = non_email_events[first_n]["timestamp"].strftime("%H:%M:%S")
                        last_omitted_ts = non_email_events[-last_n - 1]["timestamp"].strftime("%H:%M:%S")
                        truncated_timeline = first_events + [
                            f"[... {omitted_count} events omitted from {first_omitted_ts} to {last_omitted_ts} ...]"
                        ] + last_events
                    else:
                        truncated_timeline = first_events + [f"[... {omitted_count} events omitted ...]"] + last_events

                    lines.append("")
                    lines.append("Timeline:")
                    lines.extend(truncated_timeline)
                    self.logger.info(f"Timeline truncated: {len(timeline_lines)} events -> {first_n} + {last_n}, omitted {omitted_count}")
                else:
                    # No need to truncate after all
                    lines.append("")
                    lines.append("Timeline:")
                    lines.extend(timeline_lines)
            else:
                # Fits within limit
                lines.append("")
                lines.append("Timeline:")
                lines.extend(timeline_lines)
        else:
            # LLM version: no truncation - needs full data for accurate extraction
            lines.append("")
            lines.append("Timeline:")
            lines.extend(timeline_lines)

        # Add Communications and Metadata
        lines.extend(comms_lines)
        lines.extend(metadata_lines)

        text = "\n".join(lines)

        # Debug: log section sizes for embedding to find what's bloated
        if for_embedding:
            logging.debug(f"Embedding text breakdown - header: {len(header_text)}, timeline: {len(full_timeline)}, "
                         f"emails: {sum(len(e) for e in email_lines)}, total: {len(text)}")

        computed_facts = {
            "outage_window_minutes": outage_window_minutes,
            "is_flapping": is_flapping,
            "flap_cycles": len(outage_periods),
            "total_down_minutes": sum(period[2] for period in outage_periods) if is_flapping else 0,
        }

        return (text, computed_facts)

    async def process_batch(
        self,
        notes_data_list: List[TicketNotesData],
        ticket_metadata_map: Dict[str, Dict[str, Any]] = None
    ) -> Dict[str, int]:
        """
        Process notes for multiple tickets.

        Args:
            notes_data_list: List of TicketNotesData from ServiceNowClient
            ticket_metadata_map: Dict mapping ticket_sys_id to metadata

        Returns:
            Aggregated processing counts
        """
        ticket_metadata_map = ticket_metadata_map or {}

        totals = {
            "tickets_processed": 0,
            "tickets_with_content": 0,
            "audits_stored": 0,
            "timelines_embedded": 0,
        }

        for i, notes_data in enumerate(notes_data_list, 1):
            self.logger.info(f"[{i}/{len(notes_data_list)}] Processing {notes_data.ticket_id}...")

            metadata = ticket_metadata_map.get(notes_data.ticket_sys_id, {})
            result = await self.process_ticket(notes_data, metadata)

            totals["tickets_processed"] += 1
            if result["notes_count"] > 0 or result["emails_count"] > 0:
                totals["tickets_with_content"] += 1
            totals["audits_stored"] += result["audit_stored"]
            totals["timelines_embedded"] += result.get("timeline_embedded", 0)

        # Flush Milvus after batch
        if self.milvus_client and totals["timelines_embedded"] > 0:
            try:
                self.milvus_client.flush()
            except Exception as e:
                self.logger.warning(f"Milvus flush failed: {e}")

        self.logger.info(
            f"Batch complete: {totals['tickets_processed']} tickets, "
            f"{totals['tickets_with_content']} with content, "
            f"{totals['audits_stored']} audits stored, "
            f"{totals['timelines_embedded']} timelines embedded"
        )

        return totals

    def _apply_computed_overrides(self, audit_result: Dict, computed_facts: Dict) -> Dict:
        """
        Override LLM output with deterministic computed values.

        The LLM handles inference (fault_type, responsible_party, RFO, resolutions).
        Code handles arithmetic (MTTR, flapping) — no text parsing, just numbers.

        Args:
            audit_result: LLM output dict
            computed_facts: Dict with outage_window_minutes, is_flapping, flap_cycles, total_down_minutes
        """
        is_flapping = computed_facts.get("is_flapping", False)
        flap_cycles = computed_facts.get("flap_cycles", 0)
        outage_window_minutes = computed_facts.get("outage_window_minutes", 0)
        total_down_minutes = computed_facts.get("total_down_minutes", 0)

        # --- Flapping ---
        audit_result["is_flapping"] = is_flapping
        audit_result["flap_cycles"] = flap_cycles

        if is_flapping:
            base_fault = audit_result.get("fault_type") or "Unknown"
            # Remove any flapping suffix the LLM may have already added
            base_fault = re.sub(r'\s*-\s*Flapping$', '', base_fault)
            audit_result["fault_type"] = f"{base_fault} - Flapping"

        # --- MTTR ---
        # Flapping: use total down time (sum of actual DOWN periods)
        # Non-flapping: use outage window (first DOWN to last UP)
        if is_flapping and total_down_minutes > 0:
            audit_result["mttr_minutes"] = total_down_minutes
            audit_result.setdefault("field_evidence", {})
            audit_result["field_evidence"]["mttr"] = f"Total Down Time: {total_down_minutes} min (code computed, {flap_cycles} cycles)"
        elif outage_window_minutes > 0:
            audit_result["mttr_minutes"] = outage_window_minutes
            audit_result.setdefault("field_evidence", {})
            audit_result["field_evidence"]["mttr"] = f"Outage Window: {outage_window_minutes} min (code computed)"

        return audit_result

    def _build_ticket_data_string(
        self,
        ticket_id: str,
        ticket_sys_id: str,
        metadata: Dict[str, Any]
    ) -> str:
        """Build ticket data string for audit prompt with original values"""
        lines = [
            f"ticket_id: {ticket_id}",
            f"ticket_sys_id: {ticket_sys_id}"
        ]

        if metadata:
            field_mapping = [
                ("priority", "priority"),
                ("fault_type", "fault_type"),
                ("responsible_party", "responsible_party"),
                ("mttr_minutes", "mttr_minutes"),
                ("resolution_code", "resolution_code"),
                ("resolution_notes", "resolution_notes"),
                ("short_description", "short_description"),
                ("ticket_status", "ticket_status"),
            ]

            for key, label in field_mapping:
                if metadata.get(key):
                    lines.append(f"{label}: {metadata.get(key)}")

        return "\n".join(lines)
