# Ticketing ETL - Pending Tasks

## Switch to dwh_date_modified for ETL (Tomorrow - After DB Index)

**Status:** Temporarily using `updated_on` for filtering (has existing DB index)

**Tomorrow's Tasks:**
1. **Get DB team to add index:**
   ```sql
   CREATE INDEX IF NOT EXISTS idx_servicenow_cmd_ticket_dwh_date_modified
   ON rds.servicenow_cmd_ticket(dwh_date_modified);
   ```

2. **After index confirmed, update app_service.py:**
   - Line 186-190: Change `updated_on` → `dwh_date_modified`
   - Line 283: Change `"updated_on"` → `"dwh_date_modified"`

3. **Reduce timeout back to normal:**
   - connection_manager.py line 71: Change `1200` → `300` (5 minutes)

4. **Increase initial load back:**
   - docker-compose.override.yml line 18: Change `INITIAL_LOAD_DAYS=1` → `INITIAL_LOAD_DAYS=3`

**Why dwh_date_modified is better:**
- Catches historical data re-processing
- More reliable for ETL (tracks DWH changes, not just ticket updates)

---

## Add Notes Table Feed for Enhanced Context

**Objective:** Use notes table to supplement fault_description with ticket journey over time

**Value Proposition:**
- Notes capture the complete ticket lifecycle (updates, communications, status changes)
- Provides rich temporal context for vector database semantic search
- Enhances ticket understanding beyond initial fault description

**Implementation Steps:**
1. Get notes table schema from PostgreSQL
   - Table name: `ods_cmd.ticket_entry` ✅
   - Key columns needed: note_id, ticket_id, note_text, created_on, created_by, note_type

2. Update `config/tables.yaml`
   - Uncomment and configure `eds.notes` section
   - Add actual column names from schema

3. Create/update NotesTransformer in `src/domain/transformers.py`
   - Currently has placeholder implementation (line 380-413)
   - Transform notes into structured messages

4. Configure NATS topic
   - Topic: `notes.created` (already defined in commented config)
   - Consider: Should notes be sent to vector DB separately or merged with tickets?

5. Update mcp_ticket ingestion
   - Add notes ingestion handler
   - Link notes to tickets via ticket_id
   - Feed to vector database for enhanced semantic search

**Design Consideration:**
- Should notes be:
  - A) Separate messages to vector DB (preserves temporal sequence)
  - B) Aggregated with ticket summary (simpler, loses time granularity)
  - C) Both (most comprehensive, more storage)

**Priority:** Medium - Can add after initial pipeline is stable with ticket data

**Dependencies:**
- PostgreSQL notes table schema
- Vector DB ingestion strategy decision
