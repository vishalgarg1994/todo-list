"""
Milvus Vector Database Client
Handles connection, collection management, and vector search operations
"""
import logging
import asyncio
from typing import List, Dict, Any, Optional
from pymilvus import (
    connections,
    Collection,
    CollectionSchema,
    FieldSchema,
    DataType,
    utility
)
from configs.config import Config


class MilvusClient:
    """Client for interacting with Milvus vector database"""

    def __init__(self, config: Config = None, connection_alias: str = "default"):
        """
        Initialize Milvus client with configuration

        Args:
            config: Configuration object with Milvus settings
            connection_alias: pymilvus connection alias (use unique names for
                short-lived clients to avoid killing shared connections on disconnect)
        """
        self.config = config or Config()
        self.collection_name = self.config.milvus_collection_name
        self.collection: Optional[Collection] = None
        self.is_connected = False
        self._alias = connection_alias

        logging.info(f"Initialized MilvusClient for collection: {self.collection_name} (alias={self._alias})")

    def connect(self):
        """Establish connection to Milvus"""
        try:
            connect_kwargs = {
                "alias": self._alias,
                "host": self.config.milvus_host,
                "port": self.config.milvus_port,
            }
            if self.config.milvus_user and self.config.milvus_password:
                connect_kwargs["user"] = self.config.milvus_user
                connect_kwargs["password"] = self.config.milvus_password
            connections.connect(**connect_kwargs)
            self.is_connected = True
            logging.info(f"✅ Connected to Milvus at {self.config.milvus_host}:{self.config.milvus_port} (alias={self._alias})")

            # Check if collection exists, create if not
            if utility.has_collection(self.collection_name, using=self._alias):
                self.collection = Collection(self.collection_name, using=self._alias)
                logging.info(f"✅ Loaded existing collection: {self.collection_name}")
            else:
                self._create_collection()
                logging.info(f"✅ Created new collection: {self.collection_name}")

        except Exception as e:
            logging.error(f"❌ Failed to connect to Milvus: {e}")
            self.is_connected = False
            raise

    def disconnect(self):
        """Disconnect from Milvus"""
        try:
            if self.is_connected:
                connections.disconnect(self._alias)
                self.is_connected = False
                logging.info(f"✅ Disconnected from Milvus (alias={self._alias})")
        except Exception as e:
            logging.error(f"❌ Error disconnecting from Milvus: {e}")

    def _create_collection(self):
        """Create Milvus collection with schema and index for fault descriptions"""
        # Define schema
        fields = [
            FieldSchema(
                name="fault_description_id",
                dtype=DataType.VARCHAR,
                max_length=50,
                is_primary=True,
                auto_id=False,
                description="Ticket ID (primary key for deduplication)"
            ),
            FieldSchema(
                name="embedding",
                dtype=DataType.FLOAT_VECTOR,
                dim=768,  # nomic-embed-text dimension
                description="768-dim fault description embedding"
            ),
            FieldSchema(
                name="fault_description_text",
                dtype=DataType.VARCHAR,
                max_length=65535,  # Support long fault descriptions (~1300 lines)
                description="Sanitized fault description text"
            ),
            FieldSchema(
                name="fault_description_summary",
                dtype=DataType.VARCHAR,
                max_length=1000,
                description="LLM-generated summary of fault description (100-500 chars)"
            )
        ]

        schema = CollectionSchema(
            fields=fields,
            description="Fault description embeddings for semantic search"
        )

        # Create collection
        self.collection = Collection(
            name=self.collection_name,
            schema=schema,
            using=self._alias
        )

        logging.info(f"✅ Created collection schema with 768-dim embeddings")

        # Immediately create index after collection creation
        # This ensures the collection is always ready for loading and search
        self._create_index_internal()
        logging.info(f"✅ Created index for new collection")

    def _create_index_internal(self):
        """
        Internal method to create index on embedding field.
        Used during collection creation and by the public create_index() method.
        """
        index_params = {
            "index_type": self.config.milvus_index_type,  # IVF_FLAT
            "metric_type": self.config.milvus_metric_type,  # COSINE
            "params": {"nlist": self.config.milvus_nlist}  # 1024 clusters
        }

        try:
            self.collection.create_index(
                field_name="embedding",
                index_params=index_params
            )
            logging.info(f"✅ Created {self.config.milvus_index_type} index with nlist={self.config.milvus_nlist}")
        except Exception as e:
            # Check if index already exists
            if "index already exist" in str(e).lower():
                logging.info(f"✅ Index already exists for collection '{self.collection_name}'")
            else:
                logging.error(f"❌ Failed to create index: {e}")
                raise

    def create_index(self):
        """
        Public method to create IVF_FLAT index on embedding field.
        Typically used for manual index recreation or optimization.

        Note: Index is automatically created during collection creation,
        so this method is rarely needed in normal operation.
        """
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")

        self._create_index_internal()

    async def insert(
        self,
        fault_description_ids: List[str],
        embeddings: List[List[float]],
        fault_description_texts: List[str],
        fault_description_summaries: List[str] = None
    ) -> int:
        """
        Upsert fault description embeddings into Milvus (insert or update)

        With fault_description_id as primary key, this automatically handles:
        - New records: Inserted
        - Existing records: Updated with new embedding

        Args:
            fault_description_ids: List of ticket IDs (primary keys)
            embeddings: List of 768-dim embedding vectors
            fault_description_texts: List of sanitized fault description text
            fault_description_summaries: List of LLM-generated summaries (optional for backward compat)

        Returns:
            Number of entities upserted
        """
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")

        n = len(fault_description_ids)
        if len(embeddings) != n or len(fault_description_texts) != n:
            raise ValueError("fault_description_ids, embeddings, and fault_description_texts must have same length")

        # Default summaries to empty strings if not provided
        if fault_description_summaries is None:
            fault_description_summaries = [""] * n
        elif len(fault_description_summaries) != n:
            raise ValueError("fault_description_summaries must have same length as other fields")

        try:
            # Prepare data for upsert
            entities = [
                fault_description_ids,          # fault_description_id field (primary key)
                embeddings,                     # embedding field
                fault_description_texts,        # fault_description_text field
                fault_description_summaries     # fault_description_summary field
            ]

            # Upsert (insert new or update existing based on primary key)
            # Run in thread pool to avoid blocking event loop
            upsert_result = await asyncio.to_thread(self.collection.upsert, entities)
            num_upserted = upsert_result.upsert_count

            logging.info(f"✅ Upserted {num_upserted} embeddings into Milvus (new + updated)")
            return num_upserted

        except Exception as e:
            logging.error(f"❌ Failed to upsert embeddings: {e}")
            raise

    def load_collection(self):
        """Load collection into memory for search"""
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")

        try:
            self.collection.load()
            logging.info(f"✅ Loaded collection '{self.collection_name}' into memory")
        except Exception as e:
            logging.error(f"❌ Failed to load collection: {e}")
            raise

    async def get_vector_by_id(self, fault_description_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve the embedding vector and fault description for a specific ticket ID

        Args:
            fault_description_id: Ticket ID to retrieve

        Returns:
            Dict with embedding, fault_description_text, or None if not found
        """
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")

        try:
            # Query by primary key
            result = await asyncio.to_thread(
                self.collection.query,
                expr=f'fault_description_id == "{fault_description_id}"',
                output_fields=["fault_description_id", "embedding", "fault_description_text", "fault_description_summary"]
            )

            if not result or len(result) == 0:
                logging.warning(f"No vector found for ticket_id: {fault_description_id}")
                return None

            entity = result[0]
            return {
                "fault_description_id": entity.get("fault_description_id"),
                "embedding": entity.get("embedding"),
                "fault_description_text": entity.get("fault_description_text"),
                "fault_description_summary": entity.get("fault_description_summary", "")
            }

        except Exception as e:
            logging.error(f"❌ Failed to retrieve vector for {fault_description_id}: {e}")
            raise

    async def search(
        self,
        query_embedding: List[float],
        top_k: int = 10,
        nprobe: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Search for similar fault descriptions

        Args:
            query_embedding: 768-dim query embedding
            top_k: Number of results to return
            nprobe: Number of clusters to search (default: from config)

        Returns:
            List of search results with fault_description_id and distance
        """
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")

        # Use config nprobe if not specified
        if nprobe is None:
            nprobe = self.config.milvus_nprobe

        search_params = {
            "metric_type": self.config.milvus_metric_type,
            "params": {"nprobe": nprobe}
        }

        try:
            # Run in thread pool to avoid blocking event loop
            results = await asyncio.to_thread(
                self.collection.search,
                data=[query_embedding],
                anns_field="embedding",
                param=search_params,
                limit=top_k,
                output_fields=["fault_description_id", "fault_description_text", "fault_description_summary"]
            )

            # Parse results
            search_results = []
            for hits in results:
                for hit in hits:
                    search_results.append({
                        "fault_description_id": hit.entity.get("fault_description_id"),
                        "fault_description_text": hit.entity.get("fault_description_text"),
                        "fault_description_summary": hit.entity.get("fault_description_summary", ""),
                        "distance": hit.distance,
                        "score": hit.score  # Similarity score (1 - distance for COSINE)
                    })

            logging.debug(f"✅ Search returned {len(search_results)} results")
            return search_results

        except Exception as e:
            logging.error(f"❌ Search failed: {e}")
            raise

    async def get_summaries_batch(self, ids: List[str]) -> Dict[str, str]:
        """
        Batch query fault description summaries by ticket IDs.

        Args:
            ids: List of ticket IDs (fault_description_id values)

        Returns:
            Dict mapping ticket_id to summary string
        """
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")

        if not ids:
            return {}

        try:
            # Build IN expression for batch query
            ids_str = ", ".join(f'"{id}"' for id in ids)
            expr = f"fault_description_id in [{ids_str}]"

            result = await asyncio.to_thread(
                self.collection.query,
                expr=expr,
                output_fields=["fault_description_id", "fault_description_summary"]
            )

            summaries = {}
            for entity in result:
                fid = entity.get("fault_description_id")
                summary = entity.get("fault_description_summary", "")
                if fid and summary:
                    summaries[fid] = summary

            logging.debug(f"Retrieved {len(summaries)} summaries for {len(ids)} requested IDs")
            return summaries

        except Exception as e:
            logging.error(f"❌ Failed to batch query summaries: {e}")
            return {}

    def flush(self):
        """Flush collection data to disk"""
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")

        try:
            self.collection.flush()
            logging.info(f"✅ Flushed collection '{self.collection_name}' to disk")
        except Exception as e:
            logging.error(f"❌ Failed to flush collection: {e}")
            raise

    def get_collection_stats(self) -> Dict[str, Any]:
        """Get collection statistics"""
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")

        try:
            stats = self.collection.num_entities
            return {
                "collection_name": self.collection_name,
                "num_entities": stats,
                "index_type": self.config.milvus_index_type,
                "metric_type": self.config.milvus_metric_type
            }
        except Exception as e:
            logging.error(f"❌ Failed to get collection stats: {e}")
            raise

    def drop_collection(self):
        """Drop collection (use with caution!)"""
        if not self.collection:
            raise ValueError("Collection not initialized")

        try:
            utility.drop_collection(self.collection_name, using=self._alias)
            self.collection = None
            logging.warning(f"⚠️  Dropped collection: {self.collection_name}")
        except Exception as e:
            logging.error(f"❌ Failed to drop collection: {e}")
            raise

    def __enter__(self):
        """Context manager entry"""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.disconnect()
