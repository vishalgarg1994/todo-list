# CMD Service Delivery — MCP Server

An MCP (Model Context Protocol) server for querying CMD (Circuit Management & Delivery) service order data.
Built as the service delivery counterpart to the `mcp_ticket` ticketing server.

## Architecture

```
                    ┌─────────────────────┐
                    │   Mock CMD Server   │
                    │  (GraphQL + REST)   │
                    └────────┬────────────┘
                             │ Extract
                    ┌────────▼────────────┐
                    │    ETL Pipeline     │
                    │ (extractor/loader)  │
                    └──┬──────────────┬───┘
                       │              │
              ┌────────▼──────┐ ┌─────▼─────────┐
              │   Memgraph    │ │    Milvus      │
              │  (Graph DB)   │ │  (Vector DB)   │
              │               │ │  + OpenAI      │
              │ Orders,Segs,  │ │  (Embeddings)  │
              │ Vendors,Tasks │ │  Note vectors  │
              └────────┬──────┘ └─────┬──────────┘
                       │              │
                    ┌──▼──────────────▼───┐
                    │   FastMCP Server    │
                    │   (30 MCP Tools)    │
                    └─────────────────────┘
```

## Graph Model

| Node | Key Properties |
|------|---------------|
| **Order** | id, latest_status, client_id, status_label |
| **Service** | id, service_type, foc dates |
| **Segment** | id, a/z company, city, vendor_circuit_id |
| **Vendor** | id, name, legal_name |
| **Task** | task_id, summary, status (1-5) |
| **Note** | note_id, subject, body |
| **Client** | id |

| Relationship | From → To |
|-------------|-----------|
| HAS_SERVICE | Order → Service |
| HAS_SEGMENT | Service/Order → Segment |
| HAS_A_VENDOR | Segment → Vendor |
| HAS_Z_VENDOR | Segment → Vendor |
| HAS_TASK | Order → Task |
| HAS_NOTE | Order → Note |
| BELONGS_TO_CLIENT | Order → Client |

## MCP Tools (30 total)

### Order Tools
| Tool | Description |
|------|-------------|
| `get_order_details` | Full order details with service, segments, vendors, tasks, notes |
| `list_orders` | List all orders with summary |
| `get_orders_by_status` | Filter orders by status |
| `get_orders_by_client` | Get orders for a client |
| `search_orders_by_field` | Search orders by any field |
| `get_order_summary_stats` | Aggregate order statistics |

### Segment Tools
| Tool | Description |
|------|-------------|
| `get_segment_details` | Full segment with vendors and parent order |
| `get_segments_by_vendor` | Segments for a vendor |
| `search_segments_by_company` | Search by A/Z company name |
| `get_segments_by_location` | Search by city |

### Vendor Tools
| Tool | Description |
|------|-------------|
| `get_vendor_details` | Vendor info with order/segment counts |
| `list_vendors` | All vendors ranked by usage |
| `get_vendor_orders` | Orders involving a vendor |
| `search_vendor_by_name` | Search vendors by name |

### Task Tools
| Tool | Description |
|------|-------------|
| `get_order_tasks` | Tasks for an order |
| `get_tasks_by_status` | Filter tasks by status code |
| `get_tasks_by_type` | Filter by task type/summary |
| `get_task_summary_stats` | Aggregate task statistics |

### Note Tools
| Tool | Description |
|------|-------------|
| `get_order_notes` | Notes for an order |
| `search_notes_by_subject` | Search notes by subject |
| `search_notes_by_content` | Search notes by body keyword |
| `get_note_count_by_order` | Orders ranked by note count |

### Semantic Search Tools
| Tool | Description |
|------|-------------|
| `search_similar_notes` | Vector similarity search across notes |
| `find_similar_orders` | Find orders with similar patterns |

### Relational / Graph Tools
| Tool | Description |
|------|-------------|
| `get_order_relationships` | Full relationship graph for an order |
| `trace_order_to_vendors` | Order → Service → Segments → Vendors chain |
| `get_vendor_impact` | Vendor's impact across all orders |
| `get_client_order_graph` | Full client relationship graph |
| `find_orders_sharing_vendor` | Orders sharing the same vendor |

### Analytics Tools
| Tool | Description |
|------|-------------|
| `ask_orders_question` | Natural language → Cypher query |
| `get_graph_stats` | Graph database statistics |

## Quick Start

### Option 1: Full Docker Compose Stack

```bash
cd cmd_service_delivery

# Set your API key and sample data path
export OPENAI_API_KEY=sk-your-key-here
export SAMPLE_DATA_DIR=/path/to/sample_data/data

# Start everything (Memgraph, Milvus, Mock CMD, MCP Server)
docker compose up -d

# Trigger ETL to load data
curl -X POST http://localhost:8003/etl/run

# Check health
curl http://localhost:8003/health
```

### Option 2: Local Development

Prerequisites:
- Memgraph running on `bolt://localhost:7687`
- Milvus running on `localhost:19530` (optional, for semantic search)
- OpenAI API key

```bash
cd cmd_service_delivery

pip install -r requirements.txt

# Set your API key and sample data path
export OPENAI_API_KEY=sk-your-key-here
export SAMPLE_DATA_DIR=/path/to/sample_data/data

# Start the MCP server
python server.py
```

Then load data:
```bash
curl -X POST http://localhost:8003/etl/run
```

### Option 3: With Mock CMD Server

```bash
# Terminal 1: Start mock CMD
cd /path/to/mcp_service_delivery-dev/cmd-pipeline
export MOCK_DATA_DIR=/path/to/sample_data/data
python -m uvicorn server:app --host 0.0.0.0 --port 8000

# Terminal 2: Start MCP server (API-based ETL)
cd cmd_service_delivery
export CMD_GRAPHQL_URL=http://localhost:8000/graphql/
python server.py
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check |
| `/etl/run` | POST | Trigger ETL pipeline |
| `/etl/status` | GET | Graph database stats |
| `/mcp` | POST | MCP protocol endpoint |

## Connecting from Claude Desktop / Cursor

Add to your MCP config:
```json
{
  "mcpServers": {
    "cmd-service-delivery": {
      "url": "http://localhost:8003/mcp"
    }
  }
}
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `OPENAI_API_KEY` | (required) | OpenAI API key for embeddings and NL→Cypher |
| `OPENAI_EMBEDDING_MODEL` | `text-embedding-3-small` | OpenAI embedding model |
| `OPENAI_CHAT_MODEL` | `gpt-4o-mini` | OpenAI chat model for NL→Cypher |
| `EMBEDDING_DIM` | `1536` | Embedding vector dimension |
| `MEMGRAPH_URI` | `bolt://localhost:7687` | Memgraph connection |
| `MILVUS_HOST` | `localhost` | Milvus host |
| `MILVUS_PORT` | `19530` | Milvus port |
| `CMD_GRAPHQL_URL` | `http://localhost:8000/graphql/` | Mock/real CMD GraphQL |
| `SAMPLE_DATA_DIR` | (empty) | Path to sample data for file-based ETL |
| `SERVER_PORT` | `8003` | MCP server port |
