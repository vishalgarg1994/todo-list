"""
Stream Validator for Eva Messaging Infrastructure
Validates that required streams exist without creating them.
Waits with exponential backoff for streams to become available.
"""

import asyncio
import logging
from typing import List, Optional
from utils.config import Config

logger = logging.getLogger(__name__)


class StreamValidator:
    """Validates that Eva messaging infrastructure streams exist"""

    def __init__(
        self,
        max_retries: int = 10,
        initial_backoff: float = 2.0,
        max_backoff: float = 60.0,
    ):
        self.config = Config()
        self.max_retries = max_retries
        self.initial_backoff = initial_backoff
        self.max_backoff = max_backoff

    async def validate_streams(self, nats_connection) -> bool:
        """
        Validate that required streams exist in Eva messaging infrastructure.
        Retries with exponential backoff until streams are available.

        Returns:
            bool: True if all required streams exist, False otherwise
        """
        if not nats_connection or not nats_connection.is_connected:
            logger.error("NATS connection is not established")
            return False

        js = nats_connection.jetstream()
        required_streams = self._get_required_streams()

        logger.info(f"Waiting for {len(required_streams)} required Eva streams...")

        backoff = self.initial_backoff

        for attempt in range(1, self.max_retries + 1):
            missing_streams = []

            for stream_name in required_streams:
                try:
                    stream_info = await js.stream_info(stream_name)
                    logger.info(
                        f"✅ Stream '{stream_name}' exists with {stream_info.state.messages} messages"
                    )
                except Exception as e:
                    if (
                        "stream not found" in str(e).lower()
                        or "not found" in str(e).lower()
                    ):
                        missing_streams.append(stream_name)
                    else:
                        logger.error(f"❌ Error checking stream '{stream_name}': {e}")
                        return False

            if not missing_streams:
                logger.info("✅ All required Eva streams are available")
                return True

            if attempt < self.max_retries:
                logger.warning(
                    f"⏳ Attempt {attempt}/{self.max_retries}: Waiting for streams: {', '.join(missing_streams)}. "
                    f"Retrying in {backoff:.1f}s..."
                )
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, self.max_backoff)
            else:
                logger.error(
                    f"❌ Streams not available after {self.max_retries} attempts: {', '.join(missing_streams)}"
                )
                logger.error(
                    "Ensure messaging-infrastructure is running and streams are initialized"
                )
                return False

        return False

    def _get_required_streams(self) -> List[str]:
        """Get list of streams required by this application"""
        # Get the primary stream name from config
        primary_stream = self.config.get_jetstream_stream_name()

        # Only require the configured stream
        return [primary_stream]

    async def get_stream_info(
        self, nats_connection, stream_name: str
    ) -> Optional[dict]:
        """Get detailed information about a specific stream"""
        try:
            js = nats_connection.jetstream()
            stream_info = await js.stream_info(stream_name)

            return {
                "name": stream_info.config.name,
                "subjects": stream_info.config.subjects,
                "messages": stream_info.state.messages,
                "bytes": stream_info.state.bytes,
                "first_seq": stream_info.state.first_seq,
                "last_seq": stream_info.state.last_seq,
                "consumers": stream_info.state.consumer_count,
                "max_age": stream_info.config.max_age,
                "max_bytes": stream_info.config.max_bytes,
                "retention": stream_info.config.retention,
                "storage": stream_info.config.storage,
            }
        except Exception as e:
            logger.error(f"Failed to get stream info for '{stream_name}': {e}")
            return None
