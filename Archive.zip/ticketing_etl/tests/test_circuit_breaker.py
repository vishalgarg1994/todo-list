import pytest
import time
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from utils.circuit_breaker import (
    CircuitBreaker,
    CircuitState,
    CircuitBreakerOpenError,
    circuit_breaker,
    CircuitBreakerRegistry,
)


class TestCircuitBreaker:
    @pytest.fixture
    def breaker(self):
        return CircuitBreaker(
            failure_threshold=3,
            recovery_timeout=5,
            expected_exception=ValueError,
            name="test_breaker",
        )

    @pytest.mark.asyncio
    async def test_successful_call(self, breaker):
        """Test successful function execution"""

        async def success_func():
            return "success"

        result = await breaker.call(success_func)

        assert result == "success"
        assert breaker.get_state() == CircuitState.CLOSED
        assert breaker.failure_count == 0

    @pytest.mark.asyncio
    async def test_sync_function_call(self, breaker):
        """Test circuit breaker with synchronous function"""

        def sync_func():
            return "sync_success"

        result = await breaker.call(sync_func)

        assert result == "sync_success"
        assert breaker.get_state() == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_failure_threshold_reached(self, breaker):
        """Test circuit breaker opens after failure threshold"""

        async def failing_func():
            raise ValueError("Test error")

        # Trigger enough failures to open circuit
        for i in range(3):
            with pytest.raises(ValueError):
                await breaker.call(failing_func)

            if i < 2:  # Should still be closed
                assert breaker.get_state() == CircuitState.CLOSED
            else:  # Should be open after 3rd failure
                assert breaker.get_state() == CircuitState.OPEN

        assert breaker.failure_count == 3

    @pytest.mark.asyncio
    async def test_circuit_open_fails_fast(self, breaker):
        """Test that open circuit fails fast without calling function"""
        call_count = 0

        async def tracked_func():
            nonlocal call_count
            call_count += 1
            raise ValueError("Test error")

        # Trigger failures to open circuit
        for _ in range(3):
            with pytest.raises(ValueError):
                await breaker.call(tracked_func)

        assert breaker.get_state() == CircuitState.OPEN
        initial_call_count = call_count

        # Now calls should fail fast
        with pytest.raises(CircuitBreakerOpenError):
            await breaker.call(tracked_func)

        # Function should not have been called
        assert call_count == initial_call_count

    @pytest.mark.asyncio
    async def test_recovery_after_timeout(self, breaker):
        """Test circuit breaker recovery after timeout"""

        async def failing_then_success_func():
            if breaker.failure_count >= 3:
                return "recovered"
            raise ValueError("Test error")

        # Open the circuit
        for _ in range(3):
            with pytest.raises(ValueError):
                await breaker.call(failing_then_success_func)

        assert breaker.get_state() == CircuitState.OPEN

        # Fast forward time by modifying last_failure_time
        breaker.last_failure_time = time.time() - breaker.recovery_timeout - 1

        # Next call should move to half-open and succeed
        result = await breaker.call(failing_then_success_func)
        assert result == "recovered"
        assert breaker.get_state() == CircuitState.HALF_OPEN

    @pytest.mark.asyncio
    async def test_half_open_to_closed_transition(self, breaker):
        """Test transition from half-open to closed after successful calls"""
        breaker.state = CircuitState.HALF_OPEN
        breaker.failure_count = 0

        async def success_func():
            return "success"

        # First two successful calls should keep it half-open
        for i in range(2):
            result = await breaker.call(success_func)
            assert result == "success"
            assert breaker.get_state() == CircuitState.HALF_OPEN

        # Third successful call should close the circuit
        result = await breaker.call(success_func)
        assert result == "success"
        assert breaker.get_state() == CircuitState.CLOSED

    @pytest.mark.asyncio
    async def test_half_open_failure_reopens_circuit(self, breaker):
        """Test that failure in half-open state reopens circuit"""
        breaker.state = CircuitState.HALF_OPEN
        breaker.failure_count = 2  # Just below threshold

        async def failing_func():
            raise ValueError("Test error")

        with pytest.raises(ValueError):
            await breaker.call(failing_func)

        assert breaker.get_state() == CircuitState.OPEN
        assert breaker.failure_count == 3

    @pytest.mark.asyncio
    async def test_unexpected_exception_passthrough(self, breaker):
        """Test that unexpected exceptions don't count as failures"""

        async def unexpected_error_func():
            raise RuntimeError("Unexpected error")

        with pytest.raises(RuntimeError):
            await breaker.call(unexpected_error_func)

        # Should remain closed and no failures counted
        assert breaker.get_state() == CircuitState.CLOSED
        assert breaker.failure_count == 0

    def test_manual_reset(self, breaker):
        """Test manual circuit breaker reset"""
        # Simulate some state
        breaker.state = CircuitState.OPEN
        breaker.failure_count = 5
        breaker.success_count = 2
        breaker.last_failure_time = time.time()

        breaker.reset()

        assert breaker.get_state() == CircuitState.CLOSED
        assert breaker.failure_count == 0
        assert breaker.success_count == 0
        assert breaker.last_failure_time is None

    def test_get_stats(self, breaker):
        """Test circuit breaker statistics"""
        stats = breaker.get_stats()

        expected_keys = {
            "name",
            "state",
            "failure_count",
            "success_count",
            "failure_threshold",
            "recovery_timeout",
            "last_failure_time",
            "time_since_last_failure",
        }

        assert set(stats.keys()) == expected_keys
        assert stats["name"] == "test_breaker"
        assert stats["state"] == CircuitState.CLOSED.value


class TestCircuitBreakerDecorator:
    @pytest.mark.asyncio
    async def test_async_decorator(self):
        """Test circuit breaker decorator with async function"""

        @circuit_breaker(failure_threshold=2, name="test_async_decorator")
        async def decorated_async_func(should_fail=False):
            if should_fail:
                raise ValueError("Test error")
            return "success"

        # Successful call
        result = await decorated_async_func()
        assert result == "success"

        # Check that circuit breaker is attached
        assert hasattr(decorated_async_func, "_circuit_breaker")
        cb = decorated_async_func._circuit_breaker
        assert cb.get_state() == CircuitState.CLOSED

        # Trigger failures
        for _ in range(2):
            with pytest.raises(ValueError):
                await decorated_async_func(should_fail=True)

        # Circuit should be open now
        assert cb.get_state() == CircuitState.OPEN

    @pytest.mark.asyncio
    async def test_sync_decorator(self):
        """Test circuit breaker decorator with sync function"""

        @circuit_breaker(failure_threshold=2, name="test_sync_decorator")
        def decorated_sync_func(should_fail=False):
            if should_fail:
                raise ValueError("Test error")
            return "sync_success"

        # Note: decorated sync functions return coroutines
        result = await decorated_sync_func()
        assert result == "sync_success"


class TestCircuitBreakerRegistry:
    @pytest.fixture
    def registry(self):
        return CircuitBreakerRegistry()

    @pytest.fixture
    def sample_breaker(self):
        return CircuitBreaker(name="sample_breaker")

    def test_register_breaker(self, registry, sample_breaker):
        """Test registering circuit breaker"""
        registry.register(sample_breaker)

        assert "sample_breaker" in registry.breakers
        assert registry.get_breaker("sample_breaker") == sample_breaker

    def test_get_nonexistent_breaker(self, registry):
        """Test getting non-existent breaker returns None"""
        result = registry.get_breaker("nonexistent")
        assert result is None

    def test_get_all_stats(self, registry):
        """Test getting stats for all breakers"""
        breaker1 = CircuitBreaker(name="breaker1")
        breaker2 = CircuitBreaker(name="breaker2")

        registry.register(breaker1)
        registry.register(breaker2)

        stats = registry.get_all_stats()

        assert "breaker1" in stats
        assert "breaker2" in stats
        assert stats["breaker1"]["name"] == "breaker1"
        assert stats["breaker2"]["name"] == "breaker2"

    def test_reset_all(self, registry):
        """Test resetting all circuit breakers"""
        breaker1 = CircuitBreaker(name="breaker1")
        breaker2 = CircuitBreaker(name="breaker2")

        # Set some state
        breaker1.state = CircuitState.OPEN
        breaker1.failure_count = 5
        breaker2.state = CircuitState.HALF_OPEN
        breaker2.failure_count = 2

        registry.register(breaker1)
        registry.register(breaker2)

        registry.reset_all()

        assert breaker1.get_state() == CircuitState.CLOSED
        assert breaker1.failure_count == 0
        assert breaker2.get_state() == CircuitState.CLOSED
        assert breaker2.failure_count == 0

    def test_get_open_breakers(self, registry):
        """Test getting list of open circuit breakers"""
        closed_breaker = CircuitBreaker(name="closed")
        open_breaker = CircuitBreaker(name="open")
        half_open_breaker = CircuitBreaker(name="half_open")

        open_breaker.state = CircuitState.OPEN
        half_open_breaker.state = CircuitState.HALF_OPEN

        registry.register(closed_breaker)
        registry.register(open_breaker)
        registry.register(half_open_breaker)

        open_breakers = registry.get_open_breakers()

        assert open_breakers == ["open"]
