#!/bin/bash
# Enhanced MCP Ticket System - Deployment Verification Script

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verify Docker files
verify_docker_files() {
    log_info "Verifying Docker configuration files..."

    local files=(
        "Dockerfile"
        ".dockerignore"
        "docker-compose.yml"
        "docker-compose.override.yml"
    )

    for file in "${files[@]}"; do
        if [ -f "$file" ]; then
            log_success "✓ $file exists"
        else
            log_error "✗ $file missing"
            return 1
        fi
    done
}

# Verify Kubernetes files
verify_k8s_files() {
    log_info "Verifying Kubernetes manifest files..."

    local files=(
        "k8s/namespace.yaml"
        "k8s/configmap.yaml"
        "k8s/secret.yaml"
        "k8s/pvc.yaml"
        "k8s/rbac.yaml"
        "k8s/nats-deployment.yaml"
        "k8s/mcp-ticket-deployment.yaml"
        "k8s/ingress.yaml"
        "k8s/hpa.yaml"
        "k8s/kustomization.yaml"
    )

    for file in "${files[@]}"; do
        if [ -f "$file" ]; then
            log_success "✓ $file exists"
        else
            log_error "✗ $file missing"
            return 1
        fi
    done
}

# Verify application files
verify_app_files() {
    log_info "Verifying application files..."

    local files=(
        "main.py"
        "message_handler.py"
        "system_health_check.py"
        "requirements.txt"
        "data_access/memgraphClient.py"
        "data_access/cyphers/ticket_schema_description.yaml"
        "configs/config.py"
        "utils/utilities.py"
    )

    for file in "${files[@]}"; do
        if [ -f "$file" ]; then
            log_success "✓ $file exists"
        else
            log_error "✗ $file missing"
            return 1
        fi
    done
}

# Test Docker build
test_docker_build() {
    log_info "Testing Docker build (dry run)..."

    if command -v docker &> /dev/null; then
        # Check if Docker is running
        if docker info > /dev/null 2>&1; then
            log_info "Building Docker image (this may take a few minutes)..."
            if docker build -t mcp-ticket-server:test . > /dev/null 2>&1; then
                log_success "✓ Docker image builds successfully"
                # Clean up test image
                docker rmi mcp-ticket-server:test > /dev/null 2>&1 || true
                return 0
            else
                log_error "✗ Docker build failed"
                return 1
            fi
        else
            log_warning "⚠ Docker is not running, skipping build test"
            return 0
        fi
    else
        log_warning "⚠ Docker not installed, skipping build test"
        return 0
    fi
}

# Validate Kubernetes manifests
validate_k8s_manifests() {
    log_info "Validating Kubernetes manifests..."

    if command -v kubectl &> /dev/null; then
        local k8s_files=(k8s/*.yaml)
        local all_valid=true

        for file in "${k8s_files[@]}"; do
            if kubectl apply --dry-run=client -f "$file" > /dev/null 2>&1; then
                log_success "✓ $file is valid"
            else
                log_error "✗ $file has validation errors"
                all_valid=false
            fi
        done

        if [ "$all_valid" = true ]; then
            return 0
        else
            return 1
        fi
    else
        log_warning "⚠ kubectl not installed, skipping K8s validation"
        return 0
    fi
}

# Test Python dependencies
test_python_deps() {
    log_info "Testing Python dependencies..."

    if [ -f "requirements.txt" ]; then
        # Count total dependencies
        local total_deps=$(grep -v '^#' requirements.txt | grep -v '^$' | wc -l)
        log_info "Found $total_deps dependencies in requirements.txt"

        # Check for critical dependencies
        local critical_deps=("fastmcp" "neo4j" "polars" "nats-py" "fastapi")
        local missing_deps=()

        for dep in "${critical_deps[@]}"; do
            if grep -q "^$dep" requirements.txt; then
                log_success "✓ $dep found in requirements.txt"
            else
                missing_deps+=("$dep")
                log_error "✗ $dep missing from requirements.txt"
            fi
        done

        if [ ${#missing_deps[@]} -eq 0 ]; then
            return 0
        else
            log_error "Missing critical dependencies: ${missing_deps[*]}"
            return 1
        fi
    else
        log_error "✗ requirements.txt not found"
        return 1
    fi
}

# Generate deployment summary
generate_summary() {
    log_info "Generating deployment summary..."

    cat << EOF

📋 DEPLOYMENT SUMMARY
====================

🐳 Docker Components:
   ✓ Dockerfile (production-ready)
   ✓ .dockerignore (optimized)
   ✓ docker-compose.yml (full stack)
   ✓ docker-compose.override.yml (development)

☸️  Kubernetes Components:
   ✓ namespace.yaml (mcp-ticket-system)
   ✓ configmap.yaml (app configuration)
   ✓ secret.yaml (sensitive data)
   ✓ pvc.yaml (persistent storage)
   ✓ rbac.yaml (security)
   ✓ nats-deployment.yaml (messaging)
   ✓ mcp-ticket-deployment.yaml (main app)
   ✓ ingress.yaml (external access)
   ✓ hpa.yaml (auto-scaling)
   ✓ kustomization.yaml (config management)

🚀 Deployment Options:
   • Docker Compose: docker-compose up -d
   • Kubernetes: kubectl apply -k k8s/
   • Automated: ./scripts/build-and-deploy.sh all

📖 Documentation:
   • DEPLOYMENT_GUIDE.md (comprehensive guide)
   • README_SYSTEM_STATUS.md (system status)
   • system_health_check.py (health monitoring)

EOF
}

# Main execution
main() {
    log_info "🚀 Starting Enhanced MCP Ticket System deployment verification..."
    echo

    local errors=0

    # Run verification checks
    verify_docker_files || ((errors++))
    echo

    verify_k8s_files || ((errors++))
    echo

    verify_app_files || ((errors++))
    echo

    test_python_deps || ((errors++))
    echo

    test_docker_build || ((errors++))
    echo

    validate_k8s_manifests || ((errors++))
    echo

    # Generate summary
    generate_summary

    # Final status
    if [ $errors -eq 0 ]; then
        log_success "🎉 All deployment verification checks passed!"
        log_info "Your Enhanced MCP Ticket System is ready for deployment."
        echo
        log_info "Next steps:"
        echo "  1. Review DEPLOYMENT_GUIDE.md for detailed instructions"
        echo "  2. For local testing: docker-compose up -d"
        echo "  3. For production: ./scripts/build-and-deploy.sh all"
        echo
        return 0
    else
        log_error "❌ $errors verification check(s) failed."
        log_info "Please review the errors above and fix them before deployment."
        return 1
    fi
}

# Run main function
main "$@"