#!/usr/bin/env python3
"""
TSM Ingestion Test for MCP Ticket System
Tests the TSM schema with Fault nodes, Task nodes, and FK relationships
"""

import sys
import os
import json
import asyncio
from pathlib import Path

# Add the app directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'app'))

from services.message_handler import TicketMessageHandler  # noqa: E402
from data_access.memgraphClient import MemgraphClient  # noqa: E402
from configs.config import Config  # noqa: E402
from utils.utilities import Helpers  # noqa: E402


class TSMIngestionTest:
    """Test class for TSM schema ingestion"""

    def __init__(self):
        self.test_db_uri = None
        self.memgraph_client = None
        self.message_handler = None
        self.config = None

    def setup_test_environment(self):
        """Set up a temporary test environment"""
        print("Setting up test environment...")

        # Use test Memgraph instance
        self.test_db_uri = "bolt://localhost:7687"
        print(f"Test database: {self.test_db_uri}")

        # Initialize test config
        self.config = Config()
        self.config._memgraph_uri = self.test_db_uri

        # Load cypher configs for MemgraphClient
        cyphers_yaml_dict = Helpers.load_cypher_configs(self.config.cypher_file_path)

        # Initialize Memgraph client with test database
        self.memgraph_client = MemgraphClient(
            uri=self.test_db_uri,
            jsonPath="test/json/path",
            cyphers_dict=cyphers_yaml_dict
        )

        # Initialize message handler
        self.message_handler = TicketMessageHandler(self.memgraph_client, self.config)

        print("Test environment ready")

    def teardown_test_environment(self):
        """Clean up test environment"""
        print("Cleaning up test environment...")

        if self.memgraph_client:
            self.memgraph_client.shutdown()

        print(f"Test database cleaned: {self.test_db_uri}")

    def load_test_data(self, filename):
        """Load test data from JSON file"""
        test_data_path = Path(__file__).parent.parent / "data" / filename

        if not test_data_path.exists():
            raise FileNotFoundError(f"Test data file not found: {test_data_path}")

        with open(test_data_path, 'r') as f:
            return json.load(f)

    def clear_database(self):
        """Clear all data from the database"""
        print("Clearing database...")
        try:
            self.memgraph_client.execute("MATCH (n) DETACH DELETE n")
            print("Database cleared")
        except Exception as e:
            print(f"Warning: Could not clear database: {e}")

    async def test_tsm_ticket_ingestion(self):
        """Test TSM ticket ingestion with multiple ticket types"""
        print("\n--- Testing TSM Ticket Ingestion ---")

        # Load TSM test data
        ticket_data = self.load_test_data("tsm_ticket_payload.json")

        # Process through message handler
        try:
            result = await self.message_handler.process_ticket(ticket_data)

            if result:
                print("TSM ticket processed successfully")
                return True
            else:
                print("TSM ticket processing failed")
                return False

        except Exception as e:
            print(f"Exception during TSM ticket processing: {e}")
            import traceback
            traceback.print_exc()
            return False

    def validate_ticket_nodes(self):
        """Validate that Ticket nodes were created with ticket_type property"""
        print("\n--- Validating Ticket Nodes ---")

        try:
            # Query all Ticket nodes
            result = self.memgraph_client.execute(
                "MATCH (t:Ticket) RETURN t.tkt_id as id, t.ticket_type as type, t.ticket_sys_id as sys_id"
            )
            tickets = [r.data() for r in result]

            print(f"Found {len(tickets)} Ticket nodes:")
            ticket_types = {}
            for t in tickets:
                print(f"  - {t['id']} (type: {t['type']}, sys_id: {t['sys_id']})")
                ticket_type = t['type']
                ticket_types[ticket_type] = ticket_types.get(ticket_type, 0) + 1

            # Check for expected ticket types
            expected_types = ['incident', 'case', 'problem', 'request']
            for expected in expected_types:
                if expected in ticket_types:
                    print(f"  Found {ticket_types[expected]} {expected}(s)")
                else:
                    print(f"  Warning: No {expected} tickets found")

            return len(tickets) >= 4  # Expecting at least 4 tickets

        except Exception as e:
            print(f"Error validating ticket nodes: {e}")
            return False

    def validate_fault_nodes(self):
        """Validate that Fault nodes were created (renamed from Incident)"""
        print("\n--- Validating Fault Nodes ---")

        try:
            result = self.memgraph_client.execute(
                "MATCH (f:Fault) RETURN f.fault_id as id, f.short_description as desc, f.rfo as rfo"
            )
            faults = [r.data() for r in result]

            print(f"Found {len(faults)} Fault nodes:")
            for f in faults:
                print(f"  - {f['id']}: {f['desc']} (RFO: {f['rfo']})")

            return len(faults) >= 1  # Expecting at least 1 fault

        except Exception as e:
            print(f"Error validating fault nodes: {e}")
            return False

    def validate_task_nodes(self):
        """Validate that Task nodes were created"""
        print("\n--- Validating Task Nodes ---")

        try:
            result = self.memgraph_client.execute(
                "MATCH (task:Task) RETURN task.task_sys_id as id, task.task_number as num, task.task_type as type, task.short_description as desc"
            )
            tasks = [r.data() for r in result]

            print(f"Found {len(tasks)} Task nodes:")
            for t in tasks:
                print(f"  - {t['num']} (type: {t['type']}): {t['desc']}")

            return len(tasks) >= 1  # Expecting at least 1 task

        except Exception as e:
            print(f"Error validating task nodes: {e}")
            return False

    def validate_core_relationships(self):
        """Validate core relationships (HAS_TICKET, HAS_FAULT, HAS_SERVICE, HAS_OUTAGE)"""
        print("\n--- Validating Core Relationships ---")

        relationships = [
            ("HAS_TICKET", "MATCH (c:Client)-[r:HAS_TICKET]->(t:Ticket) RETURN count(r) as cnt"),
            ("HAS_FAULT", "MATCH (t:Ticket)-[r:HAS_FAULT]->(f:Fault) RETURN count(r) as cnt"),
            ("HAS_SERVICE", "MATCH (t:Ticket)-[r:HAS_SERVICE]->(s:Service) RETURN count(r) as cnt"),
            ("HAS_OUTAGE", "MATCH (t:Ticket)-[r:HAS_OUTAGE]->(o:Outage_Info) RETURN count(r) as cnt"),
        ]

        all_passed = True
        for rel_name, query in relationships:
            try:
                result = self.memgraph_client.execute(query)
                data = [r.data() for r in result]
                count = data[0]['cnt'] if data else 0
                status = "OK" if count > 0 else "MISSING"
                print(f"  {rel_name}: {count} ({status})")
                if count == 0:
                    all_passed = False
            except Exception as e:
                print(f"  {rel_name}: ERROR - {e}")
                all_passed = False

        return all_passed

    def validate_task_relationships(self):
        """Validate HAS_TASK relationships"""
        print("\n--- Validating Task Relationships ---")

        try:
            result = self.memgraph_client.execute(
                "MATCH (t:Ticket)-[r:HAS_TASK]->(task:Task) RETURN t.tkt_id as ticket, task.task_number as task_num"
            )
            rels = [r.data() for r in result]

            print(f"Found {len(rels)} HAS_TASK relationships:")
            for r in rels:
                print(f"  - Ticket {r['ticket']} -> Task {r['task_num']}")

            return len(rels) >= 1

        except Exception as e:
            print(f"Error validating task relationships: {e}")
            return False

    def validate_fk_relationships(self):
        """Validate TSM FK relationships between ticket types"""
        print("\n--- Validating FK Relationships ---")

        fk_queries = [
            ("RAISED_BY_INCIDENT", "MATCH (c:Ticket {ticket_type: 'case'})-[r:RAISED_BY_INCIDENT]->(i:Ticket {ticket_type: 'incident'}) RETURN count(r) as cnt"),
            ("BELONGS_TO_CASE", "MATCH (req:Ticket {ticket_type: 'request'})-[r:BELONGS_TO_CASE]->(c:Ticket {ticket_type: 'case'}) RETURN count(r) as cnt"),
            ("RELATED_TO_PROBLEM", "MATCH (i:Ticket {ticket_type: 'incident'})-[r:RELATED_TO_PROBLEM]->(p:Ticket {ticket_type: 'problem'}) RETURN count(r) as cnt"),
        ]

        found_any = False
        for rel_name, query in fk_queries:
            try:
                result = self.memgraph_client.execute(query)
                data = [r.data() for r in result]
                count = data[0]['cnt'] if data else 0
                if count > 0:
                    print(f"  {rel_name}: {count} relationships found")
                    found_any = True
                else:
                    print(f"  {rel_name}: 0 (may not exist in test data)")
            except Exception as e:
                print(f"  {rel_name}: ERROR - {e}")

        return found_any  # At least one FK relationship should exist

    def validate_node_counts(self):
        """Print all node counts for debugging"""
        print("\n--- Node Counts Summary ---")

        try:
            result = self.memgraph_client.execute(
                "MATCH (n) RETURN labels(n) AS node_label, count(n) AS node_count ORDER BY node_count DESC"
            )
            node_counts = [r.data() for r in result]

            total = 0
            for row in node_counts:
                label = row['node_label']
                count = row['node_count']
                total += count
                print(f"  {label}: {count}")

            print(f"  TOTAL: {total} nodes")
            return total > 0

        except Exception as e:
            print(f"Error getting node counts: {e}")
            return False

    def validate_relationship_counts(self):
        """Print all relationship counts for debugging"""
        print("\n--- Relationship Counts Summary ---")

        try:
            result = self.memgraph_client.execute(
                "MATCH ()-[r]->() RETURN type(r) AS rel_type, count(r) AS count ORDER BY count DESC"
            )
            rel_counts = [r.data() for r in result]

            total = 0
            for row in rel_counts:
                rel_type = row['rel_type']
                count = row['count']
                total += count
                print(f"  {rel_type}: {count}")

            print(f"  TOTAL: {total} relationships")
            return total > 0

        except Exception as e:
            print(f"Error getting relationship counts: {e}")
            return False

    def run_all_tests(self):
        """Run all tests and return overall result"""
        print("=" * 60)
        print("TSM INGESTION TEST SUITE")
        print("=" * 60)

        try:
            self.setup_test_environment()
            self.clear_database()

            test_results = []

            # Test 1: TSM Ticket Ingestion
            result = asyncio.run(self.test_tsm_ticket_ingestion())
            test_results.append(("TSM Ticket Ingestion", result))

            # Test 2: Ticket Nodes Validation
            result = self.validate_ticket_nodes()
            test_results.append(("Ticket Nodes", result))

            # Test 3: Fault Nodes Validation
            result = self.validate_fault_nodes()
            test_results.append(("Fault Nodes", result))

            # Test 4: Task Nodes Validation
            result = self.validate_task_nodes()
            test_results.append(("Task Nodes", result))

            # Test 5: Core Relationships
            result = self.validate_core_relationships()
            test_results.append(("Core Relationships", result))

            # Test 6: Task Relationships
            result = self.validate_task_relationships()
            test_results.append(("Task Relationships", result))

            # Test 7: FK Relationships
            result = self.validate_fk_relationships()
            test_results.append(("FK Relationships", result))

            # Print node/relationship counts for debugging
            self.validate_node_counts()
            self.validate_relationship_counts()

            # Summary
            print("\n" + "=" * 60)
            print("TEST RESULTS")
            print("=" * 60)

            passed = 0
            failed = 0
            for name, result in test_results:
                status = "PASS" if result else "FAIL"
                print(f"  [{status}] {name}")
                if result:
                    passed += 1
                else:
                    failed += 1

            print(f"\n  {passed}/{len(test_results)} tests passed")

            if failed == 0:
                print("\nALL TESTS PASSED!")
                return True
            else:
                print(f"\n{failed} tests failed.")
                return False

        except Exception as e:
            print(f"Test suite failed with exception: {e}")
            import traceback
            traceback.print_exc()
            return False

        finally:
            self.teardown_test_environment()


def main():
    """Main function to run the tests"""
    test_suite = TSMIngestionTest()
    success = test_suite.run_all_tests()

    # Exit with appropriate code
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
