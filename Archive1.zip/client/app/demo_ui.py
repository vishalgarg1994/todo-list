#!/usr/bin/env python3
"""
Streamlit Demo UI for MCP Ticket Tools
Run: streamlit run demo_ui.py
"""
import streamlit as st
import httpx
import asyncio
import json
import os
import pandas as pd
from typing import Dict, Any

# Page config
st.set_page_config(
    page_title="AI Ticket Audit System",
    page_icon="🎫",
    layout="wide"
)

# Global font sizing
st.markdown("""
<style>
/* Sidebar — bump up 2 levels */
section[data-testid="stSidebar"] p,
section[data-testid="stSidebar"] span,
section[data-testid="stSidebar"] label,
section[data-testid="stSidebar"] li,
section[data-testid="stSidebar"] .stSelectbox,
section[data-testid="stSidebar"] [data-testid="stCaptionContainer"] {
    font-size: 1.15rem !important;
}
section[data-testid="stSidebar"] .stButton button {
    font-size: 1.15rem !important;
}
section[data-testid="stSidebar"] h1 { font-size: 1.6rem !important; }
section[data-testid="stSidebar"] h2 { font-size: 1.4rem !important; }
section[data-testid="stSidebar"] h3 { font-size: 1.3rem !important; }
section[data-testid="stSidebar"] option,
section[data-testid="stSidebar"] select,
section[data-testid="stSidebar"] input {
    font-size: 1.1rem !important;
}
/* Main content body — bump up two levels from default */
section[data-testid="stMain"] p,
section[data-testid="stMain"] label,
section[data-testid="stMain"] li {
    font-size: 1.1rem;
}
/* Table values — one level down from body, more breathing room */
section[data-testid="stMain"] table {
    width: 100% !important;
}
section[data-testid="stMain"] table td {
    font-size: 0.95rem !important;
    padding: 12px 20px !important;
}
section[data-testid="stMain"] table th {
    font-size: 1.0rem !important;
    padding: 12px 20px !important;
}
</style>
""", unsafe_allow_html=True)

# Server URL from environment or default
SERVER_URL = os.environ.get("MCP_SERVER_URL", "http://localhost:8003")

# Tool definitions (from interactive_test.py)
TOOLS = {
    # Core ticket tools
    "1": {
        "name": "ask_tickets_question",
        "description": "Natural language query",
        "category": "Core",
        "params": {
            "user_query": "How many open incidents are there?"
        }
    },
    "2": {
        "name": "get_ticket_details",
        "description": "Get complete ticket details",
        "category": "Core",
        "params": {
            "ticket_id": "INC9002148"
        }
    },
    "3": {
        "name": "get_client_tickets",
        "description": "Get all tickets for a client",
        "category": "Core",
        "params": {
            "client_name": "GTT Network",
            "limit": 10
        }
    },
    "4": {
        "name": "get_client_summary",
        "description": "Get client statistics",
        "category": "Core",
        "params": {
            "client_name": "GTT Network"
        }
    },
    "5": {
        "name": "get_tickets_by_status",
        "description": "Filter tickets by status",
        "category": "Core",
        "params": {
            "status": "Open",
            "limit": 10
        }
    },
    "6": {
        "name": "get_high_priority_tickets",
        "description": "Get urgent tickets",
        "category": "Core",
        "params": {
            "priority_threshold": 2,
            "limit": 10
        }
    },
    "7": {
        "name": "get_ticket_timeline",
        "description": "Get ticket lifecycle timeline",
        "category": "Core",
        "params": {
            "ticket_id": "CS0028143"
        }
    },
    "8": {
        "name": "get_ticket_relationships",
        "description": "Get related tickets (TSM hierarchy)",
        "category": "Core",
        "params": {
            "ticket_id": "INC9002148"
        }
    },
    "9": {
        "name": "trace_ticket_root_cause",
        "description": "Trace ticket to root cause",
        "category": "Core",
        "params": {
            "ticket_id": "CS0028143"
        }
    },
    "10": {
        "name": "get_vendor_tickets",
        "description": "Get tickets by vendor",
        "category": "Core",
        "params": {
            "vendor_name": "Lumen",
            "limit": 10
        }
    },
    "11": {
        "name": "get_service_outages",
        "description": "Get outages by technology",
        "category": "Core",
        "params": {
            "technology": "Fiber",
            "limit": 10
        }
    },
    "12": {
        "name": "get_tickets_by_date_range",
        "description": "Get tickets in date range",
        "category": "Core",
        "params": {
            "start_date": "2024-01-01",
            "end_date": "2025-12-31",
            "limit": 10
        }
    },
    "14": {
        "name": "get_sample_tickets",
        "description": "Get sample tickets (FAST)",
        "category": "Core",
        "params": {
            "limit": 5
        }
    },
    # Analytical tools
    "15": {
        "name": "get_user_performance",
        "description": "User productivity metrics",
        "category": "Analytics",
        "params": {
            "status_filter": "Closed",
            "limit": 10
        }
    },
    "16": {
        "name": "get_vendor_impact",
        "description": "Vendor performance analysis",
        "category": "Analytics",
        "params": {
            "limit": 10
        }
    },
    "17": {
        "name": "get_client_escalations",
        "description": "Client escalation patterns",
        "category": "Analytics",
        "params": {
            "min_escalation_level": 1,
            "limit": 10
        }
    },
    "18": {
        "name": "get_survey_satisfaction",
        "description": "Customer satisfaction",
        "category": "Analytics",
        "params": {
            "limit": 10
        }
    },
    "19": {
        "name": "get_maintenance_impact",
        "description": "Maintenance window impact",
        "category": "Analytics",
        "params": {
            "limit": 10
        }
    },
    # Semantic Search tools
    "20": {
        "name": "search_similar_faults",
        "description": "Search similar faults",
        "category": "Semantic Search",
        "params": {
            "query": "fiber cut outage",
            "top_k": 5
        }
    },
    "21": {
        "name": "search_similar_tickets",
        "description": "Search similar tickets",
        "category": "Semantic Search",
        "params": {
            "query": "network connectivity issue",
            "top_k": 5
        }
    },
    "22": {
        "name": "search_similar_resolutions",
        "description": "Search similar resolutions",
        "category": "Semantic Search",
        "params": {
            "query": "replaced fiber cable",
            "top_k": 5
        }
    },
    "23": {
        "name": "search_similar_services",
        "description": "Search service impacts",
        "category": "Semantic Search",
        "params": {
            "query": "MPLS circuit high latency",
            "top_k": 5
        }
    },
    "28": {
        "name": "find_similar_faults_by_ticket",
        "description": "Find similar faults by ticket ID",
        "category": "Semantic Search",
        "params": {
            "ticket_id": "INC9002148",
            "top_k": 10,
            "min_score": 0.7
        }
    },
    "29": {
        "name": "get_ticket_resolutions",
        "description": "Get resolutions for tickets",
        "category": "Semantic Search",
        "params": {
            "ticket_ids": ["INC9002148", "CS0028143"]
        }
    },
    # TSM-specific tools
    "31": {
        "name": "get_tickets_by_type",
        "description": "Get tickets by type",
        "category": "TSM",
        "params": {
            "ticket_type": "incident",
            "limit": 10
        }
    },
    "32": {
        "name": "get_cases_by_incident",
        "description": "Get cases by incident",
        "category": "TSM",
        "params": {
            "incident_id": "INC9002148"
        }
    },
    "33": {
        "name": "get_requests_by_case",
        "description": "Get requests in case",
        "category": "TSM",
        "params": {
            "case_id": "CS0028143"
        }
    },
    "34": {
        "name": "get_ticket_tasks",
        "description": "Get tasks for ticket",
        "category": "TSM",
        "params": {
            "ticket_id": "PRB0040854"
        }
    },
    "35": {
        "name": "get_related_problem",
        "description": "Get related problem",
        "category": "TSM",
        "params": {
            "incident_id": "INC9002148"
        }
    },
    "37": {
        "name": "get_ticket_hierarchy",
        "description": "Get full ticket hierarchy",
        "category": "TSM",
        "params": {
            "ticket_id": "CS0028143"
        }
    },
    # Audit tools (key for demo)
    "37": {
        "name": "get_ticket_audit",
        "description": "Get ticket audit comparison",
        "category": "AI Audit",
        "params": {
            "ticket_id": "CS0073917"
        }
    },
    "38": {
        "name": "get_extraction_discrepancies",
        "description": "Get all discrepancies",
        "category": "AI Audit",
        "params": {
            "min_confidence": 0.8,
            "limit": 20
        }
    },
    "40": {
        "name": "get_discrepancy_statistics",
        "description": "Get discrepancy stats",
        "category": "AI Audit",
        "params": {
            "min_confidence": 0.7
        }
    },
    "41": {
        "name": "get_tickets_by_extracted_fault_type",
        "description": "Find by AI-extracted fault",
        "category": "AI Audit",
        "params": {
            "fault_type": "HardDown",
            "min_confidence": 0.8,
            "limit": 50
        }
    },
    # Change Management
    "43": {
        "name": "get_clients_affected_by_change",
        "description": "Get clients affected by change",
        "category": "Change Mgmt",
        "params": {
            "change_number": "CHG0031876"
        }
    },
    "44": {
        "name": "get_clients_sharing_ci_with_change",
        "description": "Get blast radius for change",
        "category": "Change Mgmt",
        "params": {
            "change_number": "CHG0031876"
        }
    },
}


async def call_tool_async(tool_name: str, params: Dict[str, Any], server_url: str) -> Dict:
    """Call an MCP tool and return the response"""
    tool_url = f"{server_url}/mcp/tools/{tool_name}"
    headers = {"Accept": "application/json, text/event-stream"}

    jsonrpc_request = {
        "jsonrpc": "2.0",
        "method": "tools/call",
        "params": {
            "name": tool_name,
            "arguments": params
        },
        "id": 1
    }

    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            captured_result = None

            async with client.stream("POST", tool_url, json=jsonrpc_request, headers=headers) as response:
                if response.status_code != 200:
                    error_text = await response.aread()
                    return {"error": f"HTTP {response.status_code}", "details": error_text.decode()}

                async for line in response.aiter_lines():
                    if line.startswith("data:"):
                        data_str = line[5:].strip()
                        if data_str:
                            try:
                                data = json.loads(data_str)
                                if "result" in data:
                                    result = data["result"]
                                    if "isError" in result and result["isError"]:
                                        content = result.get("content", [{}])[0]
                                        return {"error": content.get("text", str(result))}
                                    elif "content" in result:
                                        content = result.get("content", [{}])[0]
                                        result_text = content.get("text", "")
                                        try:
                                            captured_result = json.loads(result_text)
                                        except:
                                            captured_result = {"text": result_text}
                                elif "error" in data:
                                    return {"error": data["error"].get("message", str(data["error"]))}
                            except json.JSONDecodeError:
                                pass

            return captured_result if captured_result else {"status": "completed"}

    except Exception as e:
        return {"error": str(e)}


def call_tool(tool_name: str, params: Dict[str, Any], server_url: str) -> Dict:
    """Sync wrapper for async tool call"""
    return asyncio.run(call_tool_async(tool_name, params, server_url))


def render_formatted_summary(summary: str):
    """Render ticket summary with formatted headers in clean Copilot style"""
    if not summary:
        st.caption("No summary available")
        return

    # Section headers to detect (map to clean display names)
    section_headers = {
        "case summary:": "Case Summary",
        "affected service:": "Affected Service",
        "cause:": "Cause of the Outage",
        "outage period:": "Outage Time Period",
        "resolution:": "Resolution",
        "people:": "People",
        "timeline:": "Timeline",
        "communications:": "Communications",
        # Legacy format fallback
        "affected service:": "Affected Service",
        "ticket status:": "Ticket Status",
        "audit:": "Audit",
    }

    # Split by newlines
    lines = summary.split("\n")
    current_section = None
    section_content = []
    sections_rendered = 0

    for line in lines:
        line_stripped = line.strip()

        # Check if this line is a section header
        is_header = False
        for header_key, display_name in section_headers.items():
            if line_stripped.lower().startswith(header_key):
                # Render previous section if exists
                if current_section and section_content:
                    _render_section(current_section, section_content)
                    sections_rendered += 1
                    section_content = []

                current_section = display_name
                # If there's content after the header on same line, add it
                content_after = line_stripped[len(header_key):].strip()
                if content_after:
                    section_content.append(content_after)
                is_header = True
                break

        if not is_header and line_stripped:
            section_content.append(line)

    # Render last section
    if current_section and section_content:
        _render_section(current_section, section_content)
        sections_rendered += 1

    # If nothing was rendered, show raw text as fallback
    if sections_rendered == 0:
        st.markdown(summary)


def _format_bullet_line(line: str) -> str:
    """Format a single line as a bullet with bold label if it has a colon"""
    line = line.strip()
    if line.startswith("- "):
        line = line[2:]
    if ":" in line and not line.startswith("http"):
        label, value = line.split(":", 1)
        return f"- **{label.strip()}:** {value.strip()}"
    elif line:
        return f"- {line}"
    return ""


def _render_section(section_name: str, content_lines: list):
    """Render a single section in clean Copilot style"""
    section_lower = section_name.lower()

    # Skip header for sections that use expanders
    if "timeline" not in section_lower and "communications" not in section_lower:
        st.markdown(f"**{section_name}**")

    # Case Summary - prose paragraph
    if "case summary" in section_lower:
        content = " ".join([l.strip() for l in content_lines if l.strip()])
        if content:
            st.markdown(content)

    # Timeline - collapsed expander
    elif "timeline" in section_lower:
        with st.expander(f"Chronology ({len(content_lines)} events)", expanded=False):
            bullets = []
            for line in content_lines:
                line = line.strip()
                if line.startswith("At "):
                    parts = line.split(",", 1)
                    if len(parts) == 2:
                        bullets.append(f"- **{parts[0]}** — {parts[1].strip()}")
                    else:
                        bullets.append(f"- {line}")
                elif line.startswith("[..."):
                    bullets.append(f"- ⚠️ {line}")
                elif line:
                    bullets.append(f"- {line}")
            if bullets:
                st.markdown("\n".join(bullets))

    # Communications - collapsed expander
    elif "communications" in section_lower:
        email_count = len([l for l in content_lines if l.strip().startswith("At ")])
        with st.expander(f"Communications ({email_count} emails)", expanded=False):
            bullets = []
            for line in content_lines:
                line = line.strip()
                # Skip metadata lines
                if line.startswith("Events analyzed:"):
                    continue
                if line.startswith("At "):
                    parts = line.split(",", 1)
                    if len(parts) == 2:
                        bullets.append(f"- **{parts[0]}** — {parts[1].strip()}")
                    else:
                        bullets.append(f"- {line}")
                elif line:
                    bullets.append(f"- {line}")
            if bullets:
                st.markdown("\n".join(bullets))

    # All other sections - bulleted list with bold labels
    else:
        bullets = [_format_bullet_line(line) for line in content_lines]
        bullets = [b for b in bullets if b]  # Remove empty
        if bullets:
            st.markdown("\n".join(bullets))


def _save_audit_results(ticket_id: str, result: Dict, server_url: str):
    """Phase 2a: Auto-save audit results to feedback DB when audit is displayed"""
    try:
        orig = result.get("original_values", {})
        sugg = result.get("suggested_values", {})

        payload = {
            "ticket_id": ticket_id,
            "ai_summary": result.get("ticket_summary", ""),
            "chronology": "",  # Populated from audit metadata if available
            "snow_fields": orig,
            "ai_fields": sugg,
        }

        # Extract chronology from audit metadata if available
        metadata = result.get("audit_metadata", {})
        if metadata.get("chronology"):
            payload["chronology"] = metadata["chronology"]

        import httpx
        resp = httpx.post(f"{server_url}/api/feedback", json=payload, timeout=10.0)
        if resp.status_code == 200:
            return True
    except Exception as e:
        # Don't break the UI if feedback save fails
        pass
    return False


def _submit_sme_feedback(ticket_id: str, sme_fields: Dict, server_url: str) -> bool:
    """Phase 2b: Submit SME feedback to feedback DB"""
    try:
        payload = {
            "ticket_id": ticket_id,
            "sme_fields": sme_fields,
        }
        import httpx
        resp = httpx.post(f"{server_url}/api/feedback", json=payload, timeout=10.0)
        return resp.status_code == 200
    except Exception:
        return False


def render_audit_result(result: Dict):
    """Special rendering for ticket audit results"""
    if "error" in result:
        st.error(f"Error: {result['error']}")
        return

    if result.get("status") == "not_processed":
        st.warning(result.get("message", "Ticket not processed yet"))
        return

    ticket_id = result.get("ticket_id", "N/A")

    # Phase 2a: Auto-save audit results to feedback DB (only once per ticket)
    save_key = f"_saved_audit_{ticket_id}"
    if save_key not in st.session_state:
        _save_audit_results(ticket_id, result, st.session_state.server_url)
        st.session_state[save_key] = True

    # Header info
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Ticket", ticket_id)
    with col2:
        confidence = result.get("confidence", 0)
        if isinstance(confidence, str):
            st.metric("Confidence", confidence)
        else:
            st.metric("Confidence", f"{confidence:.0%}")
    with col3:
        has_disc = result.get("has_discrepancies", False)
        st.metric("Discrepancies", "Yes" if has_disc else "No")

    # Sys ID in smaller font below
    sys_id = result.get("ticket_sys_id", "N/A")
    st.caption(f"**Sys ID:** `{sys_id}`")

    st.markdown(f"**Description:** {result.get('short_description', 'N/A')}")

    # Comparison table - All 10 use case fields
    st.subheader("Field Comparison")

    orig = result.get("original_values", {})
    sugg = result.get("suggested_values", {})
    discrepancy_fields = {d["field"] for d in result.get("discrepancies", [])}

    # Key fields (short values - show in table) - All 10 use case fields
    key_fields = [
        ("priority", "Priority"),
        ("fault_type", "Fault Type"),
        ("responsible_party", "Responsible Party"),
        ("mttr_minutes", "MTTR (minutes)"),
        ("rfo", "RFO"),
        ("resolution_code", "Closure Code"),
        ("actual_end_date", "Actual End Date"),
    ]

    table_md = "| Field | Original (SNOW) | AI Suggested | Status |\n"
    table_md += "|-------|-----------------|--------------|--------|\n"

    for field_key, field_label in key_fields:
        orig_val = orig.get(field_key)
        sugg_val = sugg.get(field_key)

        # Determine status and display value
        orig_str = str(orig_val) if orig_val is not None else "null"

        if field_key in discrepancy_fields:
            status = "🟡 Changed"
            sugg_str = str(sugg_val) if sugg_val is not None else orig_str
        elif sugg_val is None:
            # Could not confirm from notes/emails/field_changes - show original value
            status = "⚪ Not confirmed"
            sugg_str = orig_str  # Use original value, not "-"
        elif sugg_val == orig_val:
            status = "🟢 Confirmed"
            sugg_str = str(sugg_val)
        else:
            status = "🟡 Changed"
            sugg_str = str(sugg_val)

        table_md += f"| {field_label} | {orig_str} | {sugg_str} | {status} |\n"

    st.markdown(table_md)

    # Text fields (longer values - show separately)
    st.subheader("Resolution Text Comparison")

    text_fields = [
        ("resolution_notes", "Resolution Notes (Customer-facing)"),
        ("internal_notes", "Internal Resolution Notes"),
    ]

    for field_key, field_label in text_fields:
        orig_val = orig.get(field_key)
        sugg_val = sugg.get(field_key)

        with st.expander(f"**{field_label}**", expanded=False):
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("**Original (SNOW):**")
                st.text(orig_val if orig_val else "(empty)")
            with col2:
                st.markdown("**AI Suggested:**")
                if sugg_val:
                    st.text(sugg_val)
                else:
                    st.caption("No suggestion generated")

    # Discrepancies
    discrepancies = result.get("discrepancies", [])
    if discrepancies:
        st.subheader("Discrepancies Found")
        for d in discrepancies:
            with st.expander(f"**{d['field']}**: {d.get('original', 'N/A')} → {d.get('suggested', 'N/A')}", expanded=True):
                st.markdown(f"**Evidence:** {d.get('evidence', 'No evidence available')}")

    # Ticket Summary (from Milvus embedding)
    ticket_summary = result.get("ticket_summary")
    fault_summary = result.get("fault_description_summary")
    root_cause = result.get("root_cause")
    has_summary_content = ticket_summary or fault_summary or root_cause

    if has_summary_content:
        with st.expander("Ticket Summary (AI Generated)", expanded=False):
            if fault_summary or root_cause:
                st.markdown("**Fault Info**")
                if fault_summary:
                    st.markdown(f"- **Fault Summary:** {fault_summary}")
                if root_cause:
                    st.markdown(f"- **Cause of Outage:** {root_cause}")
            if ticket_summary:
                st.divider()
                render_formatted_summary(ticket_summary)
    else:
        st.caption("No ticket summary available (ticket may not have been processed yet)")

    # Metadata
    with st.expander("Audit Metadata"):
        st.json(result.get("audit_metadata", {}))

    # =========================================================================
    # SME Feedback Section
    # =========================================================================
    st.divider()
    st.subheader("SME Feedback")
    st.caption("Review AI suggestions and provide corrections. Fields left unchanged are treated as 'agree with AI'.")

    # Compact CSS for 4-column feedback form + company colors
    st.markdown("""
    <style>
    .stTextInput > label, .stTextArea > label {
        font-size: 0.75rem !important;
    }
    .stTextInput input, .stTextArea textarea {
        font-size: 0.8rem !important;
    }
    .stMetric label {
        font-size: 1.0rem !important;
    }
    .stMetric [data-testid="stMetricValue"] {
        font-size: 1.1rem !important;
    }
    /* Larger captions — "Demo interface", "Tool:", "Sys ID", etc. */
    [data-testid="stCaptionContainer"], .stCaption, caption {
        font-size: 1.0rem !important;
    }
    .company-header {
        background-color: #206B2B;
        color: white;
        padding: 4px 8px;
        font-size: 0.8rem;
        font-weight: 600;
        border-radius: 3px;
        text-align: center;
    }
    .company-row {
        font-size: 0.8rem;
        padding: 2px 8px;
        border-bottom: 1px solid #d8d8d8;
        min-height: 28px;
        display: flex;
        align-items: center;
    }
    /* Flat table-like inputs — remove boxy appearance */
    [data-testid="stTextInput"] input,
    .stTextInput input,
    .stTextInput > div > div > input,
    input[data-testid="stTextInputRootElement"],
    [data-testid="stTextInput"] > div > div > input {
        background-color: transparent !important;
        background: transparent !important;
        border: none !important;
        border-bottom: 1px solid #d8d8d8 !important;
        border-radius: 0 !important;
        padding: 4px 4px !important;
        box-shadow: none !important;
        outline: none !important;
    }
    [data-testid="stTextInput"] input:focus,
    .stTextInput input:focus {
        border-bottom: 1px solid #206B2B !important;
        box-shadow: none !important;
    }
    [data-testid="stTextInput"] input:disabled,
    .stTextInput input:disabled {
        background-color: white !important;
        background: white !important;
        color: #333 !important;
        -webkit-text-fill-color: #333 !important;
        opacity: 1 !important;
    }
    /* Light green for editable inputs */
    [data-testid="stTextInput"] input:not(:disabled),
    .stTextInput input:not(:disabled) {
        background-color: #f0faf0 !important;
        background: #f0faf0 !important;
    }
    /* Remove the container border/background too */
    [data-testid="stTextInput"] > div,
    .stTextInput > div {
        background: transparent !important;
        border: none !important;
        box-shadow: none !important;
        border-radius: 0 !important;
    }
    /* Compact rows — reduce vertical gaps */
    [data-testid="stHorizontalBlock"] {
        gap: 0.3rem !important;
        margin-bottom: -0.3rem !important;
    }
    /* Smaller grid buttons */
    [data-testid="stVerticalBlockBorderWrapper"] .stButton > button {
        padding: 2px 6px !important;
        font-size: 0.72rem !important;
        min-height: 0 !important;
        line-height: 1.4 !important;
    }
    </style>
    """, unsafe_allow_html=True)

    # Build feedback form — 4 columns: SNOW | AI | SME | Reason
    # Initialize SME fields in session state only once (so edits survive reruns)
    for field_key, field_label in key_fields:
        sme_key = f"sme_{field_key}"
        if sme_key not in st.session_state:
            sugg_val = sugg.get(field_key)
            orig_val = orig.get(field_key)
            st.session_state[sme_key] = str(sugg_val) if sugg_val is not None else (str(orig_val) if orig_val is not None else "null")

    for field_key, field_label in text_fields:
        sme_key = f"sme_text_{field_key}"
        if sme_key not in st.session_state:
            sugg_val = sugg.get(field_key)
            orig_val = orig.get(field_key)
            st.session_state[sme_key] = sugg_val if sugg_val else (orig_val or "")

    feedback_fields = {}

    # Column headers — 5 columns: Field | SNOW | AI | SME | Reason
    h0, h1, h2, h3, h4 = st.columns([1.5, 1.5, 1.5, 1.5, 3])
    with h0:
        st.markdown('<div class="company-header">Field</div>', unsafe_allow_html=True)
    with h1:
        st.markdown('<div class="company-header">SNOW Original</div>', unsafe_allow_html=True)
    with h2:
        st.markdown('<div class="company-header">AI Suggested</div>', unsafe_allow_html=True)
    with h3:
        st.markdown('<div class="company-header">SME Correction</div>', unsafe_allow_html=True)
    with h4:
        st.markdown('<div class="company-header">Reason (optional)</div>', unsafe_allow_html=True)

    # Short fields — 5 columns per row
    for field_key, field_label in key_fields:
        orig_val = orig.get(field_key)
        sugg_val = sugg.get(field_key)

        orig_str = str(orig_val) if orig_val is not None else "null"
        sugg_str = str(sugg_val) if sugg_val is not None else orig_str

        col0, col1, col2, col3, col4 = st.columns([1.5, 1.5, 1.5, 1.5, 3])
        with col0:
            st.text_input("Field", value=field_label, disabled=True, key=f"field_{field_key}", label_visibility="collapsed")
        with col1:
            st.text_input("SNOW", value=orig_str, disabled=True, key=f"snow_{field_key}", label_visibility="collapsed")
        with col2:
            st.text_input("AI", value=sugg_str, disabled=True, key=f"ai_{field_key}", label_visibility="collapsed")
        with col3:
            feedback_fields[field_key] = st.text_input("SME", key=f"sme_{field_key}", label_visibility="collapsed")
        with col4:
            feedback_fields[f"{field_key}_reason"] = st.text_input("Reason", key=f"sme_reason_{field_key}", placeholder="Why?", label_visibility="collapsed")

    # Text fields feedback
    for field_key, field_label in text_fields:
        orig_val = orig.get(field_key)
        sugg_val = sugg.get(field_key)

        sugg_str = sugg_val if sugg_val else (orig_val or "")

        with st.expander(f"SME: {field_label}", expanded=False):
            col1, col2, col3 = st.columns([1, 1, 1])
            with col1:
                st.text_area(
                    "AI Suggested",
                    value=sugg_str,
                    disabled=True,
                    height=100,
                    key=f"ai_text_{field_key}"
                )
            with col2:
                feedback_fields[field_key] = st.text_area(
                    "SME Correction",
                    height=100,
                    key=f"sme_text_{field_key}"
                )
            with col3:
                feedback_fields[f"{field_key}_reason"] = st.text_area(
                    "Reason (optional)",
                    height=100,
                    key=f"sme_reason_{field_key}",
                    placeholder="Why?",
                )

    # Submit feedback button
    if st.button("Submit SME Feedback", type="primary", key="submit_feedback"):
        # Filter out empty values
        sme_fields = {k: v for k, v in feedback_fields.items() if v}
        if sme_fields:
            success = _submit_sme_feedback(ticket_id, sme_fields, st.session_state.server_url)
            if success:
                st.success(f"Feedback saved for {ticket_id}")
            else:
                st.error("Failed to save feedback. Check server connection.")
        else:
            st.warning("No feedback fields to submit.")

    # =========================================================================
    # Raw Context (from feedback DB — for SME reference)
    # =========================================================================
    st.divider()
    st.subheader("Supporting Data")
    try:
        fb_resp = httpx.get(
            f"{st.session_state.server_url}/api/feedback",
            params={"ticket_id": ticket_id},
            timeout=10.0,
        )
        if fb_resp.status_code == 200:
            fb = fb_resp.json()
            if fb:
                with st.expander("Raw Notes", expanded=False):
                    st.text(fb.get("raw_notes", "(none)") or "(none)")
                with st.expander("Emails", expanded=False):
                    st.text(fb.get("emails", "(none)") or "(none)")
                with st.expander("Field Changes", expanded=False):
                    st.text(fb.get("field_changes", "(none)") or "(none)")
            else:
                st.caption("No supporting data available yet (pipeline may not have processed this ticket)")
    except Exception:
        st.caption("Could not load supporting data")


def render_discrepancy_stats(result: Dict):
    """Special rendering for discrepancy statistics"""
    if "error" in result:
        st.error(f"Error: {result['error']}")
        return

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Tickets Audited", result.get("total_tickets_audited", 0))
    with col2:
        st.metric("With Discrepancies", result.get("tickets_with_discrepancies", 0))
    with col3:
        st.metric("Discrepancy Rate", f"{result.get('discrepancy_rate_percent', 0)}%")
    with col4:
        st.metric("Avg Confidence", f"{result.get('average_confidence', 0):.2f}")

    # Breakdown
    st.subheader("Breakdown by Field")
    breakdown = result.get("breakdown", {})
    if breakdown:
        for field, count in breakdown.items():
            st.text(f"{field}: {count}")


def render_semantic_search_result(result: Dict):
    """Render semantic search results with fault description summaries"""
    if "error" in result:
        st.error(f"Error: {result['error']}")
        return

    if "message" in result and "suggestions" in result:
        st.warning(result["message"])
        for s in result.get("suggestions", []):
            st.caption(f"- {s}")
        return

    # Query info
    query = result.get("query")
    query_ticket = result.get("query_ticket")
    total = result.get("total_results") or result.get("total_similar_tickets", 0)

    if query:
        st.markdown(f"**Query:** {query}")
    if query_ticket:
        st.markdown(f"**Source Ticket:** {query_ticket.get('ticket_id', 'N/A')}")
        qs = query_ticket.get("fault_description_summary")
        if qs:
            st.markdown(f"**Fault Summary:** {qs}")

    st.metric("Results", total)

    # Summary stats (for resolutions)
    summary = result.get("summary")
    if summary:
        cols = st.columns(3)
        with cols[0]:
            st.metric("With Resolution", summary.get("tickets_with_resolution", 0))
        with cols[1]:
            avg = summary.get("average_mttr_hours")
            st.metric("Avg MTTR (hrs)", f"{avg:.1f}" if avg else "N/A")

    # Results list
    results_list = result.get("results") or result.get("similar_tickets", [])
    for i, r in enumerate(results_list, 1):
        ticket_id = r.get("fault_description_id", "N/A")
        score = r.get("similarity_score")
        summary_text = r.get("fault_description_summary", "")

        # Build header
        score_str = f" ({score:.0%})" if score is not None else ""
        ticket_details = r.get("ticket_details", {}) or {}
        status = ticket_details.get("status", "")
        client = ticket_details.get("client_name", "")
        header_parts = [f"**{ticket_id}**{score_str}"]
        if client:
            header_parts.append(client)
        if status:
            header_parts.append(status)

        with st.expander(" | ".join(header_parts), expanded=(i <= 3)):
            # Fault summary (the key new field)
            if summary_text:
                st.markdown(f"**Fault Summary:** {summary_text}")

            # Short description from graph enrichment
            fault_details = r.get("fault_details", {}) or {}
            short_desc = fault_details.get("short_description")
            if short_desc:
                st.caption(f"Short Description: {short_desc}")

            # Resolution details if available
            res = r.get("resolution_details", {}) or {}
            if res.get("rfo") or res.get("mttr"):
                res_parts = []
                if res.get("rfo"):
                    res_parts.append(f"**RFO:** {res['rfo']}")
                if res.get("mttr"):
                    res_parts.append(f"**MTTR:** {res['mttr']}")
                if res.get("outage_duration"):
                    res_parts.append(f"**Outage:** {res['outage_duration']}")
                st.markdown(" | ".join(res_parts))

            # Other enrichment sections (service, vendor, team, etc.)
            for section_key, section_label in [
                ("service_impact", "Services"),
                ("vendor_involvement", "Vendors"),
                ("team", "Team"),
                ("client_impact", "Client"),
                ("maintenance_window", "Maintenance"),
            ]:
                section = r.get(section_key)
                if section:
                    st.json(section)


def render_generic_result(result: Dict):
    """Generic JSON rendering"""
    if "error" in result:
        st.error(f"Error: {result['error']}")
        return

    st.json(result)


def render_feedback_viewer(server_url: str):
    """Render the feedback data viewer page"""
    import math

    st.subheader("Feedback Data")
    st.caption("Collected SME feedback for AI model training")

    # Stats
    try:
        stats = httpx.get(f"{server_url}/api/feedback/stats", timeout=10.0).json()
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Records", stats.get("total", 0))
        with col2:
            st.metric("With Raw Context", stats.get("with_raw_context", 0))
        with col3:
            st.metric("With Audit Results", stats.get("with_audit_results", 0))
        with col4:
            st.metric("With SME Feedback", stats.get("with_sme_feedback", 0))
    except Exception as e:
        st.error(f"Could not fetch stats: {e}")
        return

    st.divider()

    # Filter row: radio + ticket search
    # Pre-fill search from button click (must be set BEFORE widget renders)
    if "_fb_search_pending" in st.session_state:
        st.session_state.feedback_ticket_search = st.session_state._fb_search_pending
        del st.session_state._fb_search_pending

    filter_col, search_col = st.columns([2, 1])
    with filter_col:
        view_mode = st.radio(
            "Show",
            ["All records", "With SME feedback only"],
            horizontal=True
        )
    with search_col:
        ticket_search = st.text_input(
            "Look up ticket",
            placeholder="e.g. INC0012345",
            key="feedback_ticket_search"
        )

    # Fetch records
    try:
        resp = httpx.get(f"{server_url}/api/feedback", timeout=10.0)
        records = resp.json()
    except Exception as e:
        st.error(f"Could not fetch records: {e}")
        return

    # Direct ticket lookup — only apply when search value changes
    if ticket_search:
        ticket_search = ticket_search.strip()
        if ticket_search.upper() != (st.session_state.get("_last_feedback_search") or "").upper():
            st.session_state._last_feedback_search = ticket_search
            matched = [r for r in records if r.get("ticket_id", "").upper() == ticket_search.upper()]
            if matched:
                st.session_state.feedback_detail_ticket = matched[0]["ticket_id"]
            else:
                st.warning(f"No feedback record found for {ticket_search}")
    else:
        st.session_state._last_feedback_search = ""

    if view_mode == "With SME feedback only":
        records = [r for r in records if r.get("sme_fields")]

    if not records:
        st.info("No feedback records yet. Run ticket audits and submit SME feedback to populate.")
        return

    # Scrollable 8-column grid of ticket buttons
    # SME reviewed = primary (green bg), unreviewed = secondary, selected = red badge
    selected_ticket = st.session_state.get("feedback_detail_ticket")
    num_cols = 8

    with st.container(height=320):
        for i in range(0, len(records), num_cols):
            cols = st.columns(num_cols)
            for j in range(num_cols):
                idx = i + j
                if idx < len(records):
                    r = records[idx]
                    tid = r.get("ticket_id", "")
                    has_sme = bool(r.get("sme_fields"))
                    is_sel = (tid == selected_ticket)

                    with cols[j]:
                        if is_sel:
                            # Red badge for selected — match Streamlit button size
                            cols[j].markdown(
                                f'<div style="background:#206B2B; color:white; text-align:center; '
                                f'padding:0.4rem 0.75rem; border-radius:0.5rem; font-size:1.0rem; '
                                f'font-weight:400; line-height:1.6; border:1px solid #206B2B; '
                                f'min-height:2.4rem; display:inline-flex; align-items:center; '
                                f'justify-content:center; width:fit-content;">'
                                f'{tid}</div>',
                                unsafe_allow_html=True,
                            )
                        else:
                            btn_type = "primary" if has_sme else "secondary"
                            if cols[j].button(tid, key=f"fb_{tid}", type=btn_type):
                                st.session_state.feedback_detail_ticket = tid
                                st.session_state._fb_search_pending = tid
                                st.session_state._last_feedback_search = tid
                                st.rerun()

    # Detail view
    selected_ticket = st.session_state.get("feedback_detail_ticket")
    if selected_ticket:
        st.divider()
        st.markdown(
            f'<div style="background:#206B2B; color:white; padding:8px 14px; '
            f'font-size:1.0rem; font-weight:600; border-radius:4px; margin-bottom:0px;">'
            f'Feedback Details — {selected_ticket}</div>',
            unsafe_allow_html=True,
        )
        record = next((r for r in records if r.get("ticket_id") == selected_ticket), None)
        if not record:
            st.warning(f"No feedback record found for {selected_ticket}")
        if record:
            # Field comparison: SNOW vs AI vs SME
            snow = record.get("snow_fields") or {}
            ai = record.get("ai_fields") or {}
            sme = record.get("sme_fields") or {}

            if ai or sme:
                # Collect all field keys, excluding _reason keys
                all_fields = sorted(set(
                    k for k in list(snow.keys()) + list(ai.keys()) + list(sme.keys())
                    if not k.endswith("_reason")
                ))

                comparison = []
                for f in all_fields:
                    s_val = str(snow.get(f, "")) if snow.get(f) is not None else "null"
                    a_val = str(ai.get(f, "")) if ai.get(f) is not None else "null"
                    sme_val = str(sme.get(f, "")) if sme.get(f) is not None else "null"

                    # Get reason from the _reason key
                    reason = sme.get(f"{f}_reason", "") if sme else ""
                    if not reason:
                        reason = "No reason given"

                    comparison.append({
                        "Field": f,
                        "SNOW": s_val,
                        "AI": a_val,
                        "SME": sme_val,
                        "Reason for Change": reason,
                    })

                # Build HTML table with word wrap
                html = '<table style="width:100%; border-collapse:collapse; font-size:0.9rem;">'
                html += '<tr>'
                for col in ["Field", "SNOW", "AI", "SME", "Reason for Change"]:
                    html += f'<th style="background:#206B2B; color:white; padding:6px 8px; text-align:left; border:1px solid #d8d8d8;">{col}</th>'
                html += '</tr>'
                for row in comparison:
                    html += '<tr>'
                    for col in ["Field", "SNOW", "AI", "SME", "Reason for Change"]:
                        val = row[col]
                        html += f'<td style="padding:5px 8px; border:1px solid #d8d8d8; word-wrap:break-word; white-space:normal; max-width:300px;">{val}</td>'
                    html += '</tr>'
                html += '</table>'
                st.markdown(html, unsafe_allow_html=True)

    # Export button
    st.divider()
    if st.button("Export Training Data (JSONL)"):
        try:
            resp = httpx.get(f"{server_url}/api/feedback/export", timeout=10.0)
            export_data = resp.json()
            if export_data:
                jsonl = "\n".join(json.dumps(r) for r in export_data)
                st.download_button(
                    "Download JSONL",
                    data=jsonl,
                    file_name="training_data.jsonl",
                    mime="application/jsonl",
                )
                st.success(f"{len(export_data)} records ready for export")
            else:
                st.info("No records with SME feedback to export yet.")
        except Exception as e:
            st.error(f"Export failed: {e}")


def render_help_page():
    """SME Field Guide / Help Page"""
    st.subheader("Field Guide for Ticket Auditing")
    st.caption("Reference guide for Service Managers reviewing AI audit results")

    # --- What This Tool Does ---
    st.subheader("What This Tool Does")
    st.markdown("""
The AI Ticket Audit system reads all ticket notes, emails, and field change history
from ServiceNow, then cross-checks the actual narrative against the SNOW field values
(priority, closure code, MTTR, responsible party, etc.).

It flags **discrepancies** where what happened (according to the notes) doesn't match
what's recorded in the fields. Your job as an SME is to review the AI's suggestions
and either confirm or correct them.
""")

    # --- Status Icons ---
    st.subheader("Status Icons")
    st.markdown("""
| Icon | Meaning |
|------|---------|
| :green_circle: **Confirmed** | AI read the notes and agrees the SNOW field value is correct |
| :yellow_circle: **Changed** | AI found evidence in notes/emails that the field value should be different |
| :white_circle: **Not confirmed** | AI could not find enough evidence in the notes to confirm or deny the value |
""")

    st.divider()

    # --- Field Guide ---
    st.subheader("Field Definitions & Audit Guidelines")

    # Priority
    with st.expander("**Priority**", expanded=True):
        st.markdown("""
**What it is:** Severity level of the incident. P1 is the highest (service down).

**Valid values:** P1, P2, P3, P4

**How to audit:**
- **Hard down** (complete service loss) = **P1**. Correlate with monitoring platform for duration.
- **Packet loss or latency only** (service degraded but not down) = **P2 or P3**, not P1.
- If priority **was P1 and got downgraded**, check if the downgrade was validated by the customer
  or if there's evidence the service didn't actually fail.
- Check the **impact scope** -- is the site isolated or partially down?

**Common errors:** Tickets left at P1 when the issue was only degradation, or downgraded
without customer validation.
""")

    # Fault Type
    with st.expander("**Fault Type**"):
        st.markdown("""
**What it is:** Classification of what kind of fault occurred.

**Key values:**
- **HardDown** -- Complete service outage, no connectivity
- **Degradation** -- Packet loss, latency, jitter, but service not fully down
- **Intermittent** -- Service flapping up/down

**How to audit:**
- Read the ticket notes. If they say "service down", "no connectivity", "circuit down" = HardDown.
- If notes mention "packet loss", "high latency", "jitter" = Degradation, not HardDown.
- Cross-reference with monitoring graphs if available.
""")

    # Responsible Party
    with st.expander("**Responsible Party**"):
        st.markdown("""
**What it is:** Who is responsible for the root cause of the incident.

**Valid values:**
- **GTT** -- Fault was caused by GTT infrastructure or actions
- **Customer** -- Fault was on the customer side (CPE, customer network, CPA line)
- **Supplier** -- Third-party provider/carrier caused the issue
- **Unknown / Cause Undetermined** -- Root cause could not be determined
- **Deliver** -- Related to service delivery/provisioning

**How to audit:**
- Read the RFO and resolution notes to identify who was actually at fault.
- If the service/line impacted is a **CPA** (Customer Provided Access), category should be **Customer**.
- If incident is linked to **third-party planned works**, responsible party is likely **Supplier**.
- If an **RFO request** was raised and answered, the original ticket should be updated --
  watch for tickets still showing "Cause Undetermined" when the RFO has the answer.

**Common error:** Closure code says "Service restored without GTT intervention" but notes
show a supplier fixed it -- responsible party should be **Supplier**, not left ambiguous.
_(Example: CS0080126 -- notes say provider respliced fibre, but RFO said "restored without GTT intervention")_
""")

    # MTTR
    with st.expander("**MTTR (minutes)** -- Mean Time to Repair"):
        st.markdown("""
**What it is:** Duration of the actual outage or degradation in minutes.

**How to audit:**
- Check if the start and end times of the **actual outage** match the MTTR value in SNOW.
- **Exclude** customer awaiting time -- MTTR should reflect actual fault duration only.
- Cross-reference with alarm history, logs, and monitoring graphs.
- The MTTR in SNOW is **frequently wrong** -- it often reflects ticket open-to-close time
  rather than actual outage duration.

**Real-world examples of MTTR errors:**

| Customer | Ticket | MTTR in SNOW | Actual Outage |
|----------|--------|-------------|---------------|
| Barry Callebaut | INC0060796 | 1833 min | 89 min |
| Barry Callebaut | INC0066907 | 474 min | 170 min |

The correct MTTR is usually found in the ticket updates or monitoring tools, not the SNOW field.
""")

    # RFO
    with st.expander("**RFO** -- Reason for Outage"):
        st.markdown("""
**What it is:** The root cause explanation for the incident.

**How to audit:**
- Must reflect the **actual root cause** as described in the ticket notes and resolution.
- Watch for tickets showing **"Cause Undetermined"** where an RFO request was later
  raised and answered -- the original ticket should have been updated but often wasn't.
- Cross-reference with any linked RFO request tickets.

**Common error:** RFO request provides the real root cause, but the original incident
ticket is never updated -- so the incident permanently shows "Cause Undetermined",
making availability calculations incorrect.
""")

    # Closure Code
    with st.expander("**Closure Code** (Resolution Code)"):
        st.markdown("""
**What it is:** How the incident was resolved. Determines responsible party in reports
and affects availability calculations (based on outage minutes + resolution code).

**How to audit:**
- Ensure the closure code is **consistent with the ticket narrative**.
- **"No Response"** -- Investigate: is it "no response" to customer confirmation of resolution,
  or was the actual resolution something else entirely?
- **"No Fault Found"** -- Interrogate systems to understand why a fault was captured
  but then couldn't be found. May need further investigation.
- **Equipment rebooted** -- Check equipment uptime and correct the closure code accordingly.
- **Related to major outage** -- Check if this is a duplicate ticket of a larger incident.
- **TTU (Test & Turn Up)** -- Check if this is from service delivery during a service migration.
- **Post planned works** -- Check if third-party planned works were scheduled before the
  incident (incident may be extension of or follow-on from planned works).
- **CPA line** -- If the impacted service is a CPA, category should be Customer.

**Goal:** Reduce the volume of "No Fault Found" and "Cause Undetermined" closure codes.
These are often fixable with the data already in the ticket.
""")

    # Actual End Date
    with st.expander("**Actual End Date**"):
        st.markdown("""
**What it is:** The timestamp when service was actually restored.

**How to audit:**
- This should be the **service restoration time**, NOT the ticket close time.
- Cross-reference with monitoring platform data for the actual moment connectivity was restored.
- For P1 Hard Down cases, this must be 100% accurate as it directly affects
  availability calculations and SLA reporting.
""")

    # Resolution Notes
    with st.expander("**Resolution Notes** (Customer-facing)"):
        st.markdown("""
**What it is:** A short, customer-facing summary covering:
1. What was the root cause
2. How it was fixed
3. When the service was restored

**How to audit:**
- Should be clear, professional, and accurate.
- Must be consistent with the internal notes and the actual events.
- Should NOT contain internal jargon or blame language.
""")

    # Internal Resolution Notes
    with st.expander("**Internal Resolution Notes**"):
        st.markdown("""
**What it is:** Full internal ticket summary covering the complete timeline and resolution details.

**How to audit:**
- Should cover the full ticket lifecycle from fault detection to resolution.
- Used for internal reporting and knowledge base.
- More detailed than customer-facing notes -- includes internal actions, escalations,
  and technical details.
""")

    st.divider()

    # --- Common Pitfalls ---
    st.subheader("Common Pitfalls")
    st.markdown("""
1. **Closure code set by human error** -- The ticket notes clearly describe a supplier fix,
   but the closure code says "Resolved without GTT intervention." Always read the notes.

2. **MTTR wildly off** -- SNOW calculates MTTR from ticket timestamps, not actual outage times.
   The real outage duration is usually in the notes or monitoring platform.

3. **"Cause Undetermined" is often wrong** -- An RFO request was raised, the root cause was found,
   but nobody went back to update the original incident ticket.

4. **Priority left at P1 for degradation** -- Packet loss ≠ hard down. If the service was
   degraded but not completely down, it should be P2 or P3.

5. **Actual End Date = ticket close time** -- These are different. Service may have been
   restored hours before the ticket was administratively closed.
""")

    st.divider()

    # --- SME Feedback Workflow ---
    st.subheader("How to Submit Feedback")
    st.markdown("""
1. Go to **AI Audit** > **Get ticket audit comparison**
2. Enter a ticket ID and click **Run Tool**
3. Review the **Field Comparison** table -- check the Status column for discrepancies
4. Scroll down to the **SME Feedback** section
5. The three columns show:
   - **SNOW Original** -- What's currently in ServiceNow (read-only)
   - **AI Suggested** -- What the AI thinks the value should be (read-only)
   - **SME Input** -- Pre-filled with AI suggestion. **Edit this** if you disagree.
6. Click **Submit SME Feedback**

Fields you leave unchanged are treated as "agree with AI suggestion."

Your corrections are saved and used to improve the AI model over time.
""")

    # --- Data Sources ---
    st.subheader("What the AI Reads")
    st.markdown("""
The AI bases its suggestions on:
- **Ticket notes** -- All work notes, comments, and updates on the case and related tasks
- **Emails** -- Customer and internal correspondence attached to the ticket
- **Field change history** -- Every time a SNOW field was modified, by whom, and the old/new values
- **Diagnostic notes vs manual notes** -- The AI distinguishes between system-generated
  diagnostic entries and manual engineer/customer updates

_Future: Integration with monitoring platforms (NIS/ME3) for direct timestamp correlation._
""")


# Main UI
def main():
    import os as _os
    _logo_path = _os.path.join(_os.path.dirname(__file__), "assets", "gtt-logo.png")
    if _os.path.exists(_logo_path):
        st.markdown(
            '<div style="margin-top:-3.5rem; margin-bottom:-2rem; text-align:left; padding-left:0;">'
            f'<img src="data:image/png;base64,{__import__("base64").b64encode(open(_logo_path,"rb").read()).decode()}" width="180" style="display:block;">'
            '</div>',
            unsafe_allow_html=True,
        )

    st.title("AI Ticket Audit System")
    st.caption("Demo interface for MCP ticket tools")

    # Initialize state
    if "server_url" not in st.session_state:
        st.session_state.server_url = SERVER_URL
    if "audit_view" not in st.session_state:
        st.session_state.audit_view = "audit"

    # Sidebar - Tool selection
    st.sidebar.header("Select Tool")

    # Group tools by category
    categories = {}
    for key, tool in TOOLS.items():
        cat = tool.get("category", "Other")
        if cat not in categories:
            categories[cat] = []
        categories[cat].append((key, tool))

    def _clear_result():
        st.session_state.pop("last_result", None)
        st.session_state.pop("last_tool", None)
        st.session_state.audit_view = "audit"
        # Clear saved audit flags and SME field state
        for k in list(st.session_state.keys()):
            if k.startswith(("_saved_audit_", "sme_", "snow_", "ai_", "ai_text_", "sme_text_", "sme_reason_", "feedback_detail_", "view_")):
                del st.session_state[k]

    # Category selector
    all_categories = list(categories.keys())
    selected_category = st.sidebar.selectbox(
        "Category",
        all_categories,
        index=all_categories.index("Core") if "Core" in all_categories else 0,
        on_change=_clear_result,
    )

    # Tool selector
    tools_in_category = categories[selected_category]
    tool_options = {f"{t[1]['description']}": t[0] for t in tools_in_category}
    selected_tool_name = st.sidebar.selectbox(
        "Tool",
        list(tool_options.keys()),
        on_change=_clear_result,
    )
    selected_tool_key = tool_options[selected_tool_name]
    selected_tool = TOOLS[selected_tool_key]

    with st.sidebar.expander("Server Config"):
        st.session_state.server_url = st.text_input("Server URL", st.session_state.server_url)

    # AI Audit view buttons — only active when AI Audit category is selected
    is_audit = selected_category == "AI Audit"
    st.sidebar.divider()
    st.sidebar.caption("Eva AI Ticket System")
    if st.sidebar.button("Ticket Audit", width="stretch", disabled=not is_audit,
                          type="primary" if is_audit and st.session_state.audit_view == "audit" else "secondary"):
        st.session_state.audit_view = "audit"
        st.rerun()
    if st.sidebar.button("Feedback Data", width="stretch", disabled=not is_audit,
                          type="primary" if is_audit and st.session_state.audit_view == "feedback" else "secondary"):
        st.session_state.audit_view = "feedback"
        st.rerun()
    if st.sidebar.button("Field Guide", width="stretch", disabled=not is_audit,
                          type="primary" if is_audit and st.session_state.audit_view == "help" else "secondary"):
        st.session_state.audit_view = "help"
        st.rerun()

    # Route: non-AI-Audit categories go straight to tool view
    if not is_audit:
        st.session_state.audit_view = "audit"  # reset for next time

    # Route AI Audit sub-pages
    if is_audit and st.session_state.audit_view == "feedback":
        render_feedback_viewer(st.session_state.server_url)
        return

    if is_audit and st.session_state.audit_view == "help":
        render_help_page()
        return

    # Main area - Parameter inputs
    st.subheader(f"{selected_tool['description']}")
    st.caption(f"Tool: `{selected_tool['name']}`")

    # Generate input fields
    params = {}
    default_params = selected_tool.get("params", {})

    cols = st.columns(min(len(default_params), 3)) if default_params else [st]
    col_idx = 0

    for key, default_value in default_params.items():
        with cols[col_idx % len(cols)]:
            if isinstance(default_value, bool):
                params[key] = st.checkbox(key, value=default_value)
            elif isinstance(default_value, int):
                params[key] = st.number_input(key, value=default_value, step=1)
            elif isinstance(default_value, float):
                params[key] = st.number_input(key, value=default_value, step=0.1)
            elif isinstance(default_value, list):
                list_str = st.text_input(key, value=json.dumps(default_value))
                try:
                    params[key] = json.loads(list_str)
                except:
                    params[key] = default_value
            else:
                params[key] = st.text_input(key, value=str(default_value) if default_value else "")
        col_idx += 1

    # Run button — store result in session state so it survives reruns
    if st.button("Run Tool", type="primary"):
        with st.spinner(f"Calling {selected_tool['name']}..."):
            result = call_tool(selected_tool["name"], params, st.session_state.server_url)
        st.session_state.last_tool = selected_tool["name"]
        st.session_state.last_result = result

    # Render stored result (persists across widget interactions)
    if "last_result" in st.session_state and st.session_state.last_result is not None:
        st.divider()
        SEMANTIC_SEARCH_TOOLS = {
            "search_similar_faults", "search_similar_tickets",
            "search_similar_resolutions", "search_similar_services",
            "search_similar_maintenance_windows", "search_similar_engineers",
            "search_similar_vendors", "search_similar_client_impacts",
            "find_similar_faults_by_ticket", "get_ticket_resolutions",
        }
        if st.session_state.last_tool == "get_ticket_audit":
            render_audit_result(st.session_state.last_result)
        elif st.session_state.last_tool == "get_discrepancy_statistics":
            render_discrepancy_stats(st.session_state.last_result)
        elif st.session_state.last_tool in SEMANTIC_SEARCH_TOOLS:
            render_semantic_search_result(st.session_state.last_result)
        else:
            render_generic_result(st.session_state.last_result)


if __name__ == "__main__":
    main()
