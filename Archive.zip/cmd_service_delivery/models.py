"""
Pydantic models for the CMD service delivery domain.
Defines the graph entity schema used by ETL, Memgraph, and MCP tools.
"""

from __future__ import annotations
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator


# ── Graph node models ────────────────────────────────────────────────────────

class Client(BaseModel):
    id: int
    name: Optional[str] = None


class Vendor(BaseModel):
    id: int
    name: Optional[str] = None
    legal_name: Optional[str] = None


class ServiceType(BaseModel):
    name: Optional[str] = None


class Segment(BaseModel):
    id: int
    product_type: Optional[str] = None
    cpe_hostname: Optional[str] = None
    comments: Optional[str] = None
    category: Optional[int] = None

    # Dates
    created_on: Optional[str] = None
    last_updated_on: Optional[str] = None
    foc_date: Optional[str] = None
    service_start_date: Optional[str] = None
    order_confirmed_date: Optional[str] = None
    equipment_shipment_date: Optional[str] = None
    iw_date: Optional[str] = None
    dlr_date: Optional[str] = None
    cancel_date: Optional[str] = None
    asr_sent_date: Optional[str] = None
    term_end_date: Optional[str] = None
    loop_test_date: Optional[str] = None
    provisioned_date: Optional[str] = None

    # A-end
    a_company_name: Optional[str] = None
    a_company_code: Optional[str] = None
    a_address: Optional[str] = None
    a_floor: Optional[str] = None
    a_room: Optional[str] = None
    a_rack: Optional[str] = None
    a_city: Optional[str] = None
    a_state: Optional[str] = None
    a_country_id: Optional[int] = None
    a_demarc: Optional[str] = None
    a_site_poc: Optional[str] = None
    a_vendor_id: Optional[int] = None

    # Z-end
    z_company_name: Optional[str] = None
    z_company_code: Optional[str] = None
    z_address: Optional[str] = None
    z_floor: Optional[str] = None
    z_room: Optional[str] = None
    z_rack: Optional[str] = None
    z_city: Optional[str] = None
    z_state: Optional[str] = None
    z_country_id: Optional[int] = None
    z_demarc: Optional[str] = None
    z_site_poc: Optional[str] = None
    z_vendor_id: Optional[int] = None

    # Vendor fields
    vendor_circuit_id: Optional[str] = None
    vendor_order_id: Optional[str] = None
    vendor_sla: Optional[str] = None
    vendor_quote_id: Optional[str] = None
    vendor_requested_due_date: Optional[str] = None
    vendor_gateway_ip: Optional[str] = None
    vendor_usable_ip: Optional[str] = None
    vendor_network_ip: Optional[str] = None
    vendor_product_id: Optional[str] = None
    vendor_subnet_mask: Optional[str] = None
    vendor_circuit_gnid: Optional[str] = None
    vendor_pin: Optional[str] = None

    @field_validator(
        "vendor_product_id", "vendor_circuit_gnid", "vendor_circuit_id",
        "vendor_order_id", "vendor_quote_id", "vendor_pin",
        mode="before",
    )
    @classmethod
    def _coerce_str(cls, v):
        return str(v) if v is not None else v


class Service(BaseModel):
    id: int
    service_type: Optional[ServiceType] = None
    gtt_foc_ready: Optional[str] = None
    foc_status_date: Optional[str] = None
    gii_foc_date: Optional[str] = None
    segments: List[Segment] = Field(default_factory=list)


class OrderStatus(BaseModel):
    id: Optional[int] = None
    label: Optional[str] = None
    main: Optional[str] = None


class Task(BaseModel):
    task_id: int
    status: Optional[int] = None
    summary: Optional[str] = None

    @property
    def status_label(self) -> str:
        mapping = {1: "Open", 2: "In Progress", 3: "On Hold", 4: "Cancelled", 5: "Completed"}
        return mapping.get(self.status, "Unknown")


class Note(BaseModel):
    subject: Optional[str] = None
    body: Optional[str] = None
    created_on: Optional[str] = None
    created_by_name: Optional[str] = None


class Order(BaseModel):
    """Root entity: a CMD service order (PON)."""
    id: int
    latest_status: Optional[str] = None
    qj_client_id: Optional[int] = None
    comments: Optional[str] = None
    service: Optional[Service] = None
    service_order_status: Optional[OrderStatus] = None
    tasks: List[Task] = Field(default_factory=list)
    notes: List[Note] = Field(default_factory=list)


# ── ETL payload models ───────────────────────────────────────────────────────

class OrderPayload(BaseModel):
    """Complete payload for a single order, ready for graph loading."""
    order: Order
    segments: List[Segment] = Field(default_factory=list)
    vendors: List[Vendor] = Field(default_factory=list)
