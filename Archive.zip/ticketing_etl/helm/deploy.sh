#!/bin/bash
# Helm deployment script for ticketing-data-processor

set -e  # Exit on error

# Configuration
CHART_NAME="ticketing-data-processor"
NAMESPACE="data-pipeline"
RELEASE_NAME="ticketing-pipeline"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to show help
show_help() {
    cat << EOF
Helm Deployment Script for Ticketing Data Processor

Usage: $0 [ENVIRONMENT] [OPTIONS]

Environments:
  dev         Deploy to development environment
  test     Deploy to test environment  
  prod        Deploy to production environment

Options:
  --dry-run   Perform a dry run without actually deploying
  --upgrade   Upgrade existing deployment
  --debug     Enable debug mode
  --help      Show this help message

Examples:
  $0 dev                    # Deploy to development
  $0 test --dry-run      # Dry run for test
  $0 prod --upgrade         # Upgrade production deployment

EOF
}

# Parse arguments
ENVIRONMENT=""
DRY_RUN=""
UPGRADE=""
DEBUG=""

while [[ $# -gt 0 ]]; do
    case $1 in
        dev|test|prod)
            ENVIRONMENT="$1"
            shift
            ;;
        --dry-run)
            DRY_RUN="--dry-run"
            shift
            ;;
        --upgrade)
            UPGRADE="true"
            shift
            ;;
        --debug)
            DEBUG="--debug"
            shift
            ;;
        --help)
            show_help
            exit 0
            ;;
        *)
            print_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Validate environment
if [[ -z "$ENVIRONMENT" ]]; then
    print_error "Environment is required (dev|test|prod)"
    show_help
    exit 1
fi

# Set environment-specific values
case $ENVIRONMENT in
    dev)
        VALUES_FILE="values-dev.yaml"
        NAMESPACE="data-pipeline-dev"
        ;;
    test)
        VALUES_FILE="values-test.yaml"
        NAMESPACE="data-pipeline-test"
        ;;
    prod)
        VALUES_FILE="values-prod.yaml"
        NAMESPACE="data-pipeline-prod"
        ;;
esac

print_status "Deploying $CHART_NAME to $ENVIRONMENT environment"
print_status "Release: $RELEASE_NAME"
print_status "Namespace: $NAMESPACE"
print_status "Values file: $VALUES_FILE"

# Check if kubectl is available
if ! command -v kubectl &> /dev/null; then
    print_error "kubectl is not installed or not in PATH"
    exit 1
fi

# Check if helm is available
if ! command -v helm &> /dev/null; then
    print_error "helm is not installed or not in PATH"
    exit 1
fi

# Check if values file exists
if [[ ! -f "$VALUES_FILE" && -z "$DRY_RUN" ]]; then
    print_warning "Values file $VALUES_FILE not found, using default values.yaml"
    VALUES_FILE="values.yaml"
fi

# Create namespace if it doesn't exist
if [[ -z "$DRY_RUN" ]]; then
    if ! kubectl get namespace "$NAMESPACE" &> /dev/null; then
        print_status "Creating namespace: $NAMESPACE"
        kubectl create namespace "$NAMESPACE"
    else
        print_status "Namespace $NAMESPACE already exists"
    fi
fi

# Build helm command
HELM_CMD="helm"

if [[ "$UPGRADE" == "true" ]]; then
    if helm list -n "$NAMESPACE" | grep -q "$RELEASE_NAME"; then
        HELM_CMD="$HELM_CMD upgrade"
        print_status "Upgrading existing release..."
    else
        HELM_CMD="$HELM_CMD install"
        print_status "Release not found, performing fresh install..."
    fi
else
    HELM_CMD="$HELM_CMD install"
fi

# Add parameters
HELM_CMD="$HELM_CMD $RELEASE_NAME . -n $NAMESPACE"

if [[ -f "$VALUES_FILE" ]]; then
    HELM_CMD="$HELM_CMD -f $VALUES_FILE"
fi

if [[ -n "$DRY_RUN" ]]; then
    HELM_CMD="$HELM_CMD $DRY_RUN"
fi

if [[ -n "$DEBUG" ]]; then
    HELM_CMD="$HELM_CMD $DEBUG"
fi

# Execute helm command
print_status "Executing: $HELM_CMD"
eval $HELM_CMD

if [[ $? -eq 0 ]]; then
    if [[ -z "$DRY_RUN" ]]; then
        print_status "Deployment successful!"
        
        # Show deployment status
        print_status "Checking deployment status..."
        kubectl get pods -n "$NAMESPACE" -l app.kubernetes.io/name=ticketing-data-processor
        
        # Show service information
        print_status "Service information:"
        kubectl get svc -n "$NAMESPACE" -l app.kubernetes.io/name=ticketing-data-processor
        
        # Show health check endpoint
        SERVICE_IP=$(kubectl get svc "$RELEASE_NAME" -n "$NAMESPACE" -o jsonpath='{.spec.clusterIP}')
        if [[ -n "$SERVICE_IP" ]]; then
            print_status "Health check endpoint: http://$SERVICE_IP:8080/health/live"
        fi
        
        print_status "Deployment completed successfully!"
    else
        print_status "Dry run completed successfully!"
    fi
else
    print_error "Deployment failed!"
    exit 1
fi