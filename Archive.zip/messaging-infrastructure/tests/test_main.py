"""
Test main application entry point and CLI functionality
"""

import pytest
from unittest.mock import patch, Mock
import sys
from pathlib import Path

# Add stream-manager directory to path so we can import main
sys.path.append(str(Path(__file__).parent.parent / "stream-manager"))

from main import logger


class TestMainModule:
    """Test main module functionality"""

    def test_logger_configured(self):
        """Test that logger is properly configured"""
        assert logger is not None
        assert logger.name == 'main'

    def test_imports_work(self):
        """Test that all required modules can be imported"""
        # This test will fail if there are import issues
        try:
            from main import NatsStreamManager, StreamManagerAPI, ApplicationProvisioner, Config
            # If we get here, all imports worked
            assert True
        except ImportError as e:
            pytest.fail(f"Import failed: {e}")

    def test_required_functions_exist(self):
        """Test that main module has expected functions"""
        import main

        # Check for main command functions
        assert hasattr(main, 'create_streams_command')
        assert callable(main.create_streams_command)

    @patch('main.Config')
    @patch('main.NatsStreamManager')
    def test_create_streams_command_structure(self, mock_stream_manager, mock_config):
        """Test that create_streams_command has proper structure"""
        from main import create_streams_command

        # Mock arguments
        mock_args = Mock()

        # Mock config and stream manager
        mock_config_instance = Mock()
        mock_config.return_value = mock_config_instance

        mock_manager_instance = Mock()
        mock_stream_manager.return_value = mock_manager_instance

        # Test the function exists and is callable
        assert callable(create_streams_command)

    def test_module_structure(self):
        """Test that main module has expected structure"""
        import main

        # Check for essential components
        assert hasattr(main, 'logger')
        assert hasattr(main, 'NatsStreamManager')
        assert hasattr(main, 'Config')
        assert hasattr(main, 'StreamManagerAPI')
        assert hasattr(main, 'ApplicationProvisioner')