#!/bin/bash
set -e

# MCP Ticket Server Helm Deployment Script
# Usage: ./deploy.sh [env] [--upgrade|--install|--uninstall] [--dry-run]
# Example: ./deploy.sh dev --install
# Example: ./deploy.sh prod --upgrade

ENVIRONMENT=${1:-dev}
ACTION=${2:-install}
DRY_RUN=${3:-}

RELEASE_NAME="mcp-ticket-server"
NAMESPACE="mcp-servers-${ENVIRONMENT}"
CHART_DIR="."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Validate environment
if [[ ! "$ENVIRONMENT" =~ ^(dev|test|prod)$ ]]; then
    log_error "Invalid environment: $ENVIRONMENT. Use dev, test, or prod"
    exit 1
fi

# Set values file based on environment
if [[ "$ENVIRONMENT" == "dev" ]]; then
    VALUES_FILE="values-dev.yaml"
elif [[ "$ENVIRONMENT" == "test" ]]; then
    VALUES_FILE="values-test.yaml"
else
    VALUES_FILE="values.yaml"
fi

# Check if values file exists
if [[ ! -f "$VALUES_FILE" ]]; then
    log_error "Values file $VALUES_FILE not found"
    exit 1
fi

log_info "Deploying MCP Ticket Server"
log_info "Environment: $ENVIRONMENT"
log_info "Release: $RELEASE_NAME"
log_info "Namespace: $NAMESPACE"
log_info "Values: $VALUES_FILE"
log_info "Action: $ACTION"

# Create namespace if it doesn't exist
if ! kubectl get namespace "$NAMESPACE" &> /dev/null; then
    log_info "Creating namespace: $NAMESPACE"
    kubectl create namespace "$NAMESPACE"
fi

# Build helm command
HELM_CMD="helm"
case "$ACTION" in
    --install|install)
        HELM_CMD="$HELM_CMD install $RELEASE_NAME $CHART_DIR"
        ;;
    --upgrade|upgrade)
        HELM_CMD="$HELM_CMD upgrade $RELEASE_NAME $CHART_DIR"
        ;;
    --uninstall|uninstall)
        HELM_CMD="$HELM_CMD uninstall $RELEASE_NAME"
        ;;
    *)
        log_error "Invalid action: $ACTION. Use --install, --upgrade, or --uninstall"
        exit 1
        ;;
esac

# Add common flags for install/upgrade
if [[ "$ACTION" != *"uninstall"* ]]; then
    HELM_CMD="$HELM_CMD --namespace $NAMESPACE --values $VALUES_FILE --create-namespace"

    # Add install flag for upgrades
    if [[ "$ACTION" == *"upgrade"* ]]; then
        HELM_CMD="$HELM_CMD --install"
    fi
fi

# Add dry-run if specified
if [[ "$DRY_RUN" == "--dry-run" ]]; then
    HELM_CMD="$HELM_CMD --dry-run"
    log_info "DRY RUN - No changes will be applied"
fi

# Execute helm command
log_info "Executing: $HELM_CMD"
eval "$HELM_CMD"

if [[ "$ACTION" != *"uninstall"* && "$DRY_RUN" != "--dry-run" ]]; then
    log_info "Waiting for deployment to be ready..."
    kubectl rollout status deployment/$RELEASE_NAME -n "$NAMESPACE" --timeout=300s

    log_info "Deployment completed successfully!"
    log_info "Check status with: kubectl get pods -n $NAMESPACE"
    log_info "View logs with: kubectl logs -f deployment/$RELEASE_NAME -n $NAMESPACE"

    # Show service endpoints
    kubectl get svc -n "$NAMESPACE" | grep "$RELEASE_NAME" || true
fi