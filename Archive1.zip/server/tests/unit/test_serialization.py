import pytest
import json
import sys
import os
from datetime import datetime, date, time, timedelta
from decimal import Decimal

# Add the app directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'app'))

from utils.utilities import Helpers  # noqa: E402


class TestRecursiveSerialization:
    """Unit tests for recursive_serialize() function"""

    def test_serialize_basic_types(self):
        """Test serialization of basic JSON-safe types"""
        data = {
            "string": "test",
            "int": 123,
            "float": 45.67,
            "bool": True,
            "none": None
        }

        result = Helpers.recursive_serialize(data)

        assert result["string"] == "test"
        assert result["int"] == 123
        assert result["float"] == 45.67
        assert result["bool"] is True
        assert result["none"] is None

        # Should be JSON-serializable
        json_str = json.dumps(result)
        assert json_str is not None

    def test_serialize_datetime(self):
        """Test serialization of datetime objects"""
        dt = datetime(2025, 10, 10, 14, 30, 45)
        data = {"created_on": dt}

        result = Helpers.recursive_serialize(data)

        assert result["created_on"] == "2025-10-10 14:30:45"
        assert isinstance(result["created_on"], str)

        # Should be JSON-serializable
        json.dumps(result)

    def test_serialize_date(self):
        """Test serialization of date objects"""
        d = date(2025, 10, 10)
        data = {"service_date": d}

        result = Helpers.recursive_serialize(data)

        assert result["service_date"] == "2025-10-10"
        assert isinstance(result["service_date"], str)

        # Should be JSON-serializable
        json.dumps(result)

    def test_serialize_time(self):
        """Test serialization of time objects"""
        t = time(14, 30, 0)
        data = {"response_time": t}

        result = Helpers.recursive_serialize(data)

        assert result["response_time"] == "14:30:00"
        assert isinstance(result["response_time"], str)

        # Should be JSON-serializable
        json.dumps(result)

    def test_serialize_timedelta(self):
        """Test serialization of timedelta objects"""
        td = timedelta(hours=24, minutes=30, seconds=15)
        data = {"duration": td}

        result = Helpers.recursive_serialize(data)

        # Should convert to total seconds
        expected_seconds = (24 * 3600) + (30 * 60) + 15  # 88215.0
        assert result["duration"] == expected_seconds
        assert isinstance(result["duration"], float)

        # Should be JSON-serializable
        json.dumps(result)

    def test_serialize_bytes(self):
        """Test serialization of bytes objects"""
        b = b"hello world"
        data = {"binary_data": b}

        result = Helpers.recursive_serialize(data)

        # Should be base64 encoded
        assert isinstance(result["binary_data"], str)
        assert len(result["binary_data"]) > 0

        # Should be JSON-serializable
        json.dumps(result)

        # Verify it's valid base64
        import base64
        decoded = base64.b64decode(result["binary_data"])
        assert decoded == b

    def test_serialize_decimal(self):
        """Test serialization of Decimal objects"""
        dec = Decimal("123.45")
        data = {"amount": dec}

        result = Helpers.recursive_serialize(data)

        assert result["amount"] == 123.45
        assert isinstance(result["amount"], float)

        # Should be JSON-serializable
        json.dumps(result)

    def test_serialize_nested_dict(self):
        """Test serialization of nested dictionaries"""
        data = {
            "ticket": {
                "id": "123",
                "created": datetime(2025, 10, 10, 10, 0, 0),
                "priority": 2
            }
        }

        result = Helpers.recursive_serialize(data)

        assert result["ticket"]["id"] == "123"
        assert result["ticket"]["created"] == "2025-10-10 10:00:00"
        assert result["ticket"]["priority"] == 2

        # Should be JSON-serializable
        json.dumps(result)

    def test_serialize_list(self):
        """Test serialization of lists"""
        data = {
            "contacts": [
                {"name": "John", "email": "john@example.com"},
                {"name": "Jane", "email": "jane@example.com"}
            ]
        }

        result = Helpers.recursive_serialize(data)

        assert len(result["contacts"]) == 2
        assert result["contacts"][0]["name"] == "John"
        assert result["contacts"][1]["name"] == "Jane"

        # Should be JSON-serializable
        json.dumps(result)

    def test_serialize_list_with_dates(self):
        """Test serialization of lists containing date objects"""
        data = {
            "dates": [date(2025, 10, 1), date(2025, 10, 2), date(2025, 10, 3)]
        }

        result = Helpers.recursive_serialize(data)

        assert result["dates"][0] == "2025-10-01"
        assert result["dates"][1] == "2025-10-02"
        assert result["dates"][2] == "2025-10-03"

        # Should be JSON-serializable
        json.dumps(result)

    def test_serialize_mock_polars_data(self):
        """Test serialization with realistic mock Polars .to_dicts() output"""
        # Simulate what Polars returns from Memgraph query
        mock_ticket = {
            # Strings
            "ticket_id": "9068665",
            "ticket_status": "Open",
            "ticket_category": "Incident",

            # Integers
            "priority": 2,
            "mttr": 1440,

            # Booleans
            "is_master_ticket": False,

            # Dates/Times
            "created_on": datetime(2025, 10, 10, 14, 30, 45),
            "service_date": date(2025, 10, 10),

            # Decimals
            "vendor_downtime": Decimal("123.45"),

            # None values
            "closed_on": None,
            "rfo": None,

            # Nested structures
            "outage_info": {
                "duration": timedelta(hours=24),
                "mttr": 1440
            }
        }

        result = Helpers.recursive_serialize(mock_ticket)

        # Verify all types converted correctly
        assert result["ticket_id"] == "9068665"
        assert result["priority"] == 2
        assert result["is_master_ticket"] is False
        assert result["created_on"] == "2025-10-10 14:30:45"
        assert result["service_date"] == "2025-10-10"
        assert result["vendor_downtime"] == 123.45
        assert result["closed_on"] is None
        assert result["outage_info"]["duration"] == 86400.0  # 24 hours in seconds

        # Most importantly: should be JSON-serializable
        json_str = json.dumps(result)
        assert json_str is not None

        # Should be able to decode back
        decoded = json.loads(json_str)
        assert decoded["ticket_id"] == "9068665"

    def test_serialize_empty_structures(self):
        """Test serialization of empty structures"""
        data = {
            "empty_dict": {},
            "empty_list": [],
            "none": None
        }

        result = Helpers.recursive_serialize(data)

        assert result["empty_dict"] == {}
        assert result["empty_list"] == []
        assert result["none"] is None

        # Should be JSON-serializable
        json.dumps(result)

    def test_serialize_preserves_structure(self):
        """Test that serialization preserves data structure"""
        data = {
            "level1": {
                "level2": {
                    "level3": {
                        "value": datetime(2025, 10, 10, 10, 0, 0),
                        "list": [1, 2, 3]
                    }
                }
            }
        }

        result = Helpers.recursive_serialize(data)

        # Structure should be preserved
        assert "level1" in result
        assert "level2" in result["level1"]
        assert "level3" in result["level1"]["level2"]
        assert result["level1"]["level2"]["level3"]["value"] == "2025-10-10 10:00:00"
        assert result["level1"]["level2"]["level3"]["list"] == [1, 2, 3]

        # Should be JSON-serializable
        json.dumps(result)

    def test_json_round_trip(self):
        """Test complete JSON serialization round-trip"""
        data = {
            "string": "test",
            "number": 123,
            "date": date(2025, 10, 10),
            "datetime": datetime(2025, 10, 10, 14, 30, 0),
            "nested": {
                "value": Decimal("99.99")
            }
        }

        # Serialize
        serialized = Helpers.recursive_serialize(data)

        # Convert to JSON string
        json_str = json.dumps(serialized)

        # Decode back
        decoded = json.loads(json_str)

        # Verify values preserved
        assert decoded["string"] == "test"
        assert decoded["number"] == 123
        assert decoded["date"] == "2025-10-10"
        assert decoded["datetime"] == "2025-10-10 14:30:00"
        assert decoded["nested"]["value"] == 99.99


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
