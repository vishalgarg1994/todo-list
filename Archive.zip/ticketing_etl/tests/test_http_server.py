import pytest
import asyncio
import json
from unittest.mock import MagicMock, AsyncMock
from datetime import datetime, timezone
import sys
import os
from urllib.request import urlopen
from urllib.error import URLError, HTTPError

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from services.http_server import HealthHTTPServer
from services.health_service import (
    HealthService,
    HealthStatus,
    ComponentHealth,
    HealthResponse,
)


class TestHealthHTTPServer:
    @pytest.fixture
    def mock_health_service(self):
        """Mock health service for testing"""
        service = MagicMock(spec=HealthService)

        # Mock healthy response
        healthy_components = {
            "database": ComponentHealth(
                HealthStatus.HEALTHY, "Database is healthy", 15.5
            ),
            "nats": ComponentHealth(HealthStatus.HEALTHY, "NATS is healthy", 8.2),
            "scheduler": ComponentHealth(HealthStatus.HEALTHY, "Scheduler is running"),
            "system": ComponentHealth(HealthStatus.HEALTHY, "System resources healthy"),
        }

        healthy_response = HealthResponse(
            status=HealthStatus.HEALTHY,
            timestamp=datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            version="test-1.0.0",
            uptime_seconds=3600.0,
            components=healthy_components,
        )

        service.get_health_status = AsyncMock(return_value=healthy_response)
        service.is_alive = AsyncMock(return_value=True)
        service.is_ready = AsyncMock(return_value=True)

        return service

    @pytest.fixture
    def http_server(self, mock_health_service):
        """Create HTTP server for testing"""
        return HealthHTTPServer(mock_health_service, host="127.0.0.1", port=8081)

    @pytest.mark.asyncio
    async def test_server_initialization(self, http_server):
        """Test HTTP server initialization"""
        assert http_server.host == "127.0.0.1"
        assert http_server.port == 8081
        assert http_server.server is None
        assert http_server.server_task is None
        assert not http_server.is_running()

    @pytest.mark.asyncio
    async def test_server_start_stop(self, http_server):
        """Test starting and stopping the HTTP server"""
        # Start server
        await http_server.start()
        assert http_server.is_running()

        # Give server a moment to fully start
        await asyncio.sleep(0.1)

        # Stop server
        await http_server.stop()
        assert not http_server.is_running()

    @pytest.mark.asyncio
    async def test_health_endpoint_integration(self, http_server):
        """Test health endpoint integration with real HTTP requests"""
        try:
            # Start server
            await http_server.start()
            await asyncio.sleep(0.1)  # Give server time to start

            # Test health endpoint
            try:
                with urlopen("http://127.0.0.1:8081/health", timeout=5) as response:
                    assert response.getcode() == 200
                    assert response.headers.get("Content-type") == "application/json"

                    data = json.loads(response.read().decode("utf-8"))
                    assert data["status"] == "healthy"
                    assert data["version"] == "test-1.0.0"
                    assert "components" in data
                    assert "database" in data["components"]
                    assert "nats" in data["components"]
                    assert "scheduler" in data["components"]
                    assert "system" in data["components"]
            except (URLError, HTTPError) as e:
                pytest.fail(f"Health endpoint request failed: {e}")

        finally:
            await http_server.stop()

    @pytest.mark.asyncio
    async def test_liveness_endpoint_integration(self, http_server):
        """Test liveness endpoint integration"""
        try:
            await http_server.start()
            await asyncio.sleep(0.1)

            try:
                with urlopen(
                    "http://127.0.0.1:8081/health/live", timeout=5
                ) as response:
                    assert response.getcode() == 200
                    data = json.loads(response.read().decode("utf-8"))
                    assert data["status"] == "alive"
                    assert "timestamp" in data
            except (URLError, HTTPError) as e:
                pytest.fail(f"Liveness endpoint request failed: {e}")

        finally:
            await http_server.stop()

    @pytest.mark.asyncio
    async def test_readiness_endpoint_integration(self, http_server):
        """Test readiness endpoint integration"""
        try:
            await http_server.start()
            await asyncio.sleep(0.1)

            try:
                with urlopen(
                    "http://127.0.0.1:8081/health/ready", timeout=5
                ) as response:
                    assert response.getcode() == 200
                    data = json.loads(response.read().decode("utf-8"))
                    assert data["status"] == "ready"
                    assert "timestamp" in data
            except (URLError, HTTPError) as e:
                pytest.fail(f"Readiness endpoint request failed: {e}")

        finally:
            await http_server.stop()

    @pytest.mark.asyncio
    async def test_metrics_endpoint_integration(self, http_server):
        """Test metrics endpoint integration"""
        try:
            await http_server.start()
            await asyncio.sleep(0.1)

            try:
                with urlopen(
                    "http://127.0.0.1:8081/health/metrics", timeout=5
                ) as response:
                    assert response.getcode() == 200
                    assert (
                        response.headers.get("Content-type")
                        == "text/plain; charset=utf-8"
                    )

                    data = response.read().decode("utf-8")
                    assert "application_health_status 2" in data  # 2 = healthy
                    assert "application_uptime_seconds" in data
                    assert 'component_health_status{component="database"} 2' in data
                    assert 'component_health_status{component="nats"} 2' in data
            except (URLError, HTTPError) as e:
                pytest.fail(f"Metrics endpoint request failed: {e}")

        finally:
            await http_server.stop()

    @pytest.mark.asyncio
    async def test_not_found_endpoint(self, http_server):
        """Test 404 response for unknown endpoints"""
        try:
            await http_server.start()
            await asyncio.sleep(0.1)

            try:
                with urlopen("http://127.0.0.1:8081/unknown", timeout=5):
                    pytest.fail("Should have received 404")
            except HTTPError as e:
                assert e.code == 404
                data = json.loads(e.read().decode("utf-8"))
                assert data["error"] == "Not Found"
                assert "Available endpoints" in data["message"]

        finally:
            await http_server.stop()

    @pytest.mark.asyncio
    async def test_unhealthy_service_response(self, http_server):
        """Test HTTP server response when service is unhealthy"""
        # Mock unhealthy response
        unhealthy_components = {
            "database": ComponentHealth(
                HealthStatus.UNHEALTHY, "Database connection failed"
            )
        }

        unhealthy_response = HealthResponse(
            status=HealthStatus.UNHEALTHY,
            timestamp=datetime.now(timezone.utc),
            version="test-1.0.0",
            uptime_seconds=100.0,
            components=unhealthy_components,
        )

        http_server.health_service.get_health_status.return_value = unhealthy_response

        try:
            await http_server.start()
            await asyncio.sleep(0.1)

            try:
                with urlopen("http://127.0.0.1:8081/health", timeout=5):
                    pytest.fail("Should have received 503")
            except HTTPError as e:
                assert e.code == 503
                data = json.loads(e.read().decode("utf-8"))
                assert data["status"] == "unhealthy"

        finally:
            await http_server.stop()

    @pytest.mark.asyncio
    async def test_service_not_ready_response(self, http_server):
        """Test readiness endpoint when service is not ready"""
        http_server.health_service.is_ready.return_value = False

        try:
            await http_server.start()
            await asyncio.sleep(0.1)

            try:
                with urlopen("http://127.0.0.1:8081/health/ready", timeout=5):
                    pytest.fail("Should have received 503")
            except HTTPError as e:
                assert e.code == 503
                data = json.loads(e.read().decode("utf-8"))
                assert data["status"] == "not_ready"

        finally:
            await http_server.stop()

    @pytest.mark.asyncio
    async def test_service_not_alive_response(self, http_server):
        """Test liveness endpoint when service is not alive"""
        http_server.health_service.is_alive.return_value = False

        try:
            await http_server.start()
            await asyncio.sleep(0.1)

            try:
                with urlopen("http://127.0.0.1:8081/health/live", timeout=5):
                    pytest.fail("Should have received 503")
            except HTTPError as e:
                assert e.code == 503
                data = json.loads(e.read().decode("utf-8"))
                assert data["status"] == "dead"

        finally:
            await http_server.stop()

    @pytest.mark.asyncio
    async def test_healthz_alias(self, http_server):
        """Test /healthz as alias for /health/live (Kubernetes convention)"""
        try:
            await http_server.start()
            await asyncio.sleep(0.1)

            try:
                with urlopen("http://127.0.0.1:8081/healthz", timeout=5) as response:
                    assert response.getcode() == 200
                    data = json.loads(response.read().decode("utf-8"))
                    assert data["status"] == "alive"
            except (URLError, HTTPError) as e:
                pytest.fail(f"Healthz endpoint request failed: {e}")

        finally:
            await http_server.stop()

    @pytest.mark.asyncio
    async def test_concurrent_requests(self, http_server):
        """Test server can handle concurrent requests"""
        try:
            await http_server.start()
            await asyncio.sleep(0.1)

            # Make multiple concurrent requests
            tasks = []
            for _ in range(5):
                task = asyncio.create_task(
                    self._make_request("http://127.0.0.1:8081/health")
                )
                tasks.append(task)

            results = await asyncio.gather(*tasks)

            # All requests should succeed
            for result in results:
                assert result["status"] == "healthy"

        finally:
            await http_server.stop()

    async def _make_request(self, url):
        """Helper method to make async HTTP request"""
        loop = asyncio.get_event_loop()

        def _sync_request():
            with urlopen(url, timeout=5) as response:
                return json.loads(response.read().decode("utf-8"))

        return await loop.run_in_executor(None, _sync_request)

    @pytest.mark.asyncio
    async def test_server_error_handling(self, http_server):
        """Test server error handling when health service fails"""
        # Mock health service to raise exception
        http_server.health_service.get_health_status.side_effect = Exception(
            "Health service failed"
        )

        try:
            await http_server.start()
            await asyncio.sleep(0.1)

            try:
                with urlopen("http://127.0.0.1:8081/health", timeout=5):
                    pytest.fail("Should have received 500")
            except HTTPError as e:
                assert e.code == 500
                data = json.loads(e.read().decode("utf-8"))
                assert data["error"] == "Internal Server Error"
                assert "Health service failed" in data["message"]

        finally:
            await http_server.stop()
