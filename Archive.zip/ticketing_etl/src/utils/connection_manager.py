import asyncio
import logging
import asyncpg
import nats
from nats.errors import NoServersError, TimeoutError
from utils.config import Config
from messaging.ticket_publisher import NatsPublisher


class ConnectionManager:
    """Centralized connection lifecycle management for external services"""

    def __init__(self, config: Config):
        self.config = config
        self.db_pool = None
        self.nats_connection = None
        self.js_context = None
        self.logger = logging.getLogger(__name__)

    async def initialize(self):
        """Initialize connections to external services based on DATA_SOURCE setting"""
        data_source = self.config.get_data_source()

        if data_source == "api":
            # API-only mode: skip database, only initialize NATS
            self.logger.info(
                f"DATA_SOURCE={data_source}: Initializing NATS only (API mode)"
            )
            await self._initialize_nats_connection()
            self.logger.info("NATS connection initialized (API-only mode)")
        else:
            # DB or Both mode: initialize database and NATS
            self.logger.info(
                f"DATA_SOURCE={data_source}: Initializing database and NATS"
            )
            await self._initialize_database_pool()
            await self._initialize_nats_connection()
            self.logger.info("External service connections initialized successfully")

    # TEMPORARY: Local testing bypass - initialize NATS without database
    async def initialize_nats_only(self):
        """Initialize only NATS connection, skip database (for local Helm testing)"""
        self.logger.warning("Initializing NATS only - DATABASE CONNECTION SKIPPED")
        await self._initialize_nats_connection()
        self.logger.info("NATS connection initialized (DB bypass mode)")

    # END TEMPORARY

    async def _initialize_database_pool(self):
        """Create database connection pool with TLS-enforced settings"""
        try:
            # Check global TLS setting first
            tls_enabled = self.config.get_tls_enabled()
            ssl_mode = self.config.get_db_ssl_mode()
            ssl_context = None
            db_uri = self.config.get_db_uri()

            if tls_enabled and ssl_mode != "disable":
                import ssl

                ssl_context = ssl.create_default_context()

                # Configure SSL mode
                if ssl_mode == "require":
                    ssl_context.check_hostname = False
                    ssl_context.verify_mode = ssl.CERT_NONE
                elif ssl_mode == "verify-ca":
                    ssl_context.check_hostname = False
                    ssl_context.verify_mode = ssl.CERT_REQUIRED
                elif ssl_mode == "verify-full":
                    ssl_context.check_hostname = True
                    ssl_context.verify_mode = ssl.CERT_REQUIRED

                # Load custom certificates if provided
                ssl_cert = self.config.get_db_ssl_cert()
                ssl_key = self.config.get_db_ssl_key()
                ssl_ca = self.config.get_db_ssl_ca()

                if ssl_cert and ssl_key:
                    ssl_context.load_cert_chain(ssl_cert, ssl_key)

                if ssl_ca:
                    ssl_context.load_verify_locations(ssl_ca)

                self.logger.info(f"Database SSL enabled with mode: {ssl_mode}")
            else:
                # When TLS is disabled, ensure sslmode=disable is in the connection string
                # This explicitly tells PostgreSQL not to attempt SSL negotiation
                if "sslmode=" not in db_uri:
                    separator = "&" if "?" in db_uri else "?"
                    db_uri = f"{db_uri}{separator}sslmode=disable"

                if not tls_enabled:
                    self.logger.info(
                        "Database SSL disabled - TLS_ENABLED=false (development mode)"
                    )
                else:
                    self.logger.warning("Database SSL disabled - ssl_mode=disable")

            self.db_pool = await asyncpg.create_pool(
                db_uri,
                min_size=5,
                max_size=20,
                command_timeout=300,  # 5 minutes timeout
                ssl=ssl_context,
                server_settings={"application_name": "ticketing_data_processor"},
            )
            tls_status = (
                "with TLS enforcement"
                if (tls_enabled and ssl_mode != "disable")
                else "without TLS"
            )
            self.logger.info(f"Database connection pool established {tls_status}")
        except Exception as e:
            self.logger.error(f"Failed to create database pool: {e}", exc_info=True)
            raise

    async def _initialize_nats_connection(self):
        """Connect to external messaging infrastructure with TLS support"""
        retry_count = 0
        max_retries = 10  # Increased for better startup resilience

        while retry_count < max_retries:
            try:
                # Check global TLS setting for Eva messaging connection
                tls_context = None
                tls_enabled = self.config.get_tls_enabled()
                nats_tls_enabled = self.config.get_nats_tls_enabled()

                if tls_enabled and nats_tls_enabled:
                    import ssl

                    tls_context = ssl.create_default_context()

                    # Configure certificate verification
                    if not self.config.get_nats_tls_verify():
                        tls_context.check_hostname = False
                        tls_context.verify_mode = ssl.CERT_NONE

                    # Load custom certificates if provided
                    tls_cert = self.config.get_nats_tls_cert()
                    tls_key = self.config.get_nats_tls_key()
                    tls_ca = self.config.get_nats_tls_ca()

                    if tls_cert and tls_key:
                        tls_context.load_cert_chain(tls_cert, tls_key)

                    if tls_ca:
                        tls_context.load_verify_locations(tls_ca)

                    self.logger.info(
                        "Messaging TLS enabled with certificate verification"
                    )
                else:
                    if not tls_enabled:
                        self.logger.info(
                            "Messaging TLS disabled - TLS_ENABLED=false (development mode)"
                        )
                    elif not nats_tls_enabled:
                        self.logger.info(
                            "Messaging TLS disabled - NATS_TLS_ENABLED=false"
                        )

                # Client connection options for messaging infrastructure
                connection_options = {
                    "name": "ticketing_data_processor",
                    "max_reconnect_attempts": -1,  # Infinite reconnection attempts
                    "reconnect_time_wait": 2,
                    "error_cb": self._nats_error_callback,
                    "disconnected_cb": self._nats_disconnected_callback,
                    "reconnected_cb": self._nats_reconnected_callback,
                }

                # Add NATS authentication (required for messaging infrastructure)
                nats_user = self.config.get_nats_user()
                nats_password = self.config.get_nats_password()
                if nats_user and nats_password:
                    connection_options["user"] = nats_user
                    connection_options["password"] = nats_password
                    self.logger.info(
                        f"Connecting to messaging infrastructure as user: {nats_user}"
                    )
                else:
                    # Infrastructure allows no_auth_user for development
                    self.logger.info(
                        "Connecting to messaging infrastructure with no_auth_user"
                    )

                # Add TLS context if enabled
                if tls_context:
                    connection_options["tls"] = tls_context

                # Connect to messaging infrastructure
                nats_url = self.config.get_nats_url()
                self.nats_connection = await nats.connect(
                    nats_url, **connection_options
                )

                # Get JetStream context from messaging infrastructure
                self.js_context = self.nats_connection.jetstream()

                tls_status = "with TLS" if tls_context else "without TLS"
                self.logger.info(
                    f"Successfully connected to messaging infrastructure at {nats_url} {tls_status}"
                )
                return

            except (NoServersError, TimeoutError, Exception) as e:
                retry_count += 1
                self.logger.warning(
                    f"Messaging connection attempt {retry_count} failed: {e}"
                )
                if retry_count >= max_retries:
                    self.logger.error(
                        "Failed to connect to messaging infrastructure after maximum retries"
                    )
                    raise

                # Exponential backoff with max delay
                delay = min(2**retry_count, 30)  # Max 30 seconds delay
                self.logger.info(f"Retrying NATS connection in {delay} seconds...")
                await asyncio.sleep(delay)

    async def _nats_error_callback(self, e):
        """Handle NATS connection errors gracefully"""
        try:
            self.logger.warning(f"NATS connection error (non-critical): {e}")
        except Exception:
            # Ensure callback doesn't raise exceptions
            pass

    async def _nats_disconnected_callback(self):
        """Handle NATS disconnection events"""
        try:
            self.logger.warning(
                "NATS connection lost - will attempt automatic reconnection"
            )
            # Clear stale references
            self.js_context = None
        except Exception:
            # Ensure callback doesn't raise exceptions
            pass

    async def _nats_reconnected_callback(self):
        """Handle NATS reconnection events"""
        try:
            self.logger.info("NATS connection restored successfully")
            # Restore JetStream context
            if self.nats_connection:
                try:
                    self.js_context = self.nats_connection.jetstream()
                    self.logger.info("JetStream context restored after reconnection")
                except Exception as js_error:
                    self.logger.warning(
                        f"Failed to restore JetStream context: {js_error}"
                    )
                    self.js_context = None
        except Exception as e:
            self.logger.warning(f"Error in NATS reconnection callback: {e}")
            # Ensure callback doesn't raise exceptions
            pass

    def get_database_pool(self):
        """Get the shared database connection pool"""
        if not self.db_pool:
            raise RuntimeError("Database pool not initialized")
        return self.db_pool

    def get_nats_connection(self):
        """Get the connection to messaging infrastructure"""
        if not self.nats_connection:
            self.logger.warning("Messaging connection not initialized")
            return None
        return self.nats_connection

    def get_jetstream_context(self):
        """Get the JetStream context from messaging infrastructure"""
        if not self.js_context:
            self.logger.warning("JetStream context not initialized")
            return None
        return self.js_context

    def get_nats_publisher(self):
        """Create a NATS publisher using connection manager for fresh context access"""
        if not self.nats_connection:
            self.logger.warning("NATS connection not available for publisher")
            return None
        return NatsPublisher(self)

    async def health_check(self):
        """Check health of all external service connections"""
        data_source = self.config.get_data_source()

        health_status = {"database": False, "messaging": False}

        # Check database connection (skip if api-only mode)
        if data_source == "api":
            # In API-only mode, database is not used - mark as N/A (True)
            health_status["database"] = True
        elif self.db_pool:
            try:
                async with self.db_pool.acquire() as conn:
                    await conn.execute("SELECT 1")
                health_status["database"] = True
            except Exception as e:
                self.logger.error(f"Database health check failed: {e}")
        else:
            self.logger.error("Database pool not initialized")

        # Check messaging connection
        try:
            if self.nats_connection and self.nats_connection.is_connected:
                health_status["messaging"] = True
            else:
                # Connection is down, clean up stale references
                if self.nats_connection and not self.nats_connection.is_connected:
                    self.logger.warning(
                        "NATS connection lost - cleaning up stale references"
                    )
                    self.nats_connection = None
                    self.js_context = None
        except Exception as e:
            self.logger.error(f"Messaging health check failed: {e}")
            # Clean up potentially broken connections
            self.nats_connection = None
            self.js_context = None

        return health_status

    async def close(self):
        """Close all connections gracefully"""
        if self.nats_connection:
            try:
                await self.nats_connection.close()
                self.logger.info("Messaging connection closed")
            except Exception as e:
                self.logger.error(f"Error closing messaging connection: {e}")
            finally:
                self.nats_connection = None
                self.js_context = None

        if self.db_pool:
            try:
                await self.db_pool.close()
                self.logger.info("Database connection pool closed")
            except Exception as e:
                self.logger.error(f"Error closing database pool: {e}")
            finally:
                self.db_pool = None
