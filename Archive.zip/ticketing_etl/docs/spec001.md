# Technical Specification: Enterprise Data Pipeline Transformation

**Document**: SPEC-001  
**Version**: v0.02  
**Date**: 2025-01-11  
**Status**: Partially Complete (Phase 1 Health Monitoring Complete)  

## Overview

This specification defines the technical implementation plan to transform the Ticketing Data Processor from a development prototype into an enterprise-ready, multi-table data pipeline system. The implementation addresses critical security vulnerabilities, operational gaps, and architectural limitations while preparing for future multi-table ingestion capabilities.

**Implementation Status**: 
- ✅ **TASK 9 COMPLETE**: Health Monitoring & Observability implemented with comprehensive endpoints, APM integration, and circuit breaker patterns
- ✅ **Knowledge Graph Processing**: Entity extraction for Users, Contacts, Vendors, Maintenance Windows
- ✅ **Testing Framework**: Integration, browser, and manual test suites completed
- 🔄 **Remaining**: 9 tasks for complete enterprise transformation

**Implementation Target**: 10 discrete tasks over 8-week delivery timeline

---

## Implementation Tasks

### **TASK 1: Security Vulnerability Remediation**
**Priority**: P0 (Critical - Blocking)  
**Estimated Effort**: 1 week  
**Dependencies**: None  

#### **Objective**
Eliminate critical security vulnerabilities that prevent production deployment.

#### **Technical Requirements**

##### **1.1 Fix SQL Injection Vulnerability**
**File**: `src/utils/db.py:70`

**Current Code (Vulnerable)**:
```python
query += f" WHERE updated_on >= '{time_value}'"
```

**Implementation**:
```python
# Use parameterized queries with asyncpg
async def fetch_data(self, table_name: str, columns: List[str], 
                     filters: Optional[Dict[str, Any]] = None) -> List[Dict]:
    columns_str = ", ".join(columns) if columns else "*"
    query = f"SELECT {columns_str} FROM {table_name}"
    
    params = []
    if filters and "updated_on" in filters:
        query += " WHERE updated_on >= $1"
        params.append(filters["updated_on"])
    
    query += ";"
    rows = await self.execute_query(query, *params)
    return [dict(row) for row in rows]
```

##### **1.2 Remove Exposed Credentials** 
**File**: `docker-compose.yml:11-13`

**Current Code (Vulnerable)**:
```yaml
DATABASE_URL: "postgresql://evo_etl:Uhxi3ObI4ApVUF2Hc46Z@slo-devgp-mdw..."
NATS_URL: nats://10.250.15.70:4222
```

**Implementation**:
```yaml
# Remove hardcoded values, use environment variables only
environment:
  - CONFIG_ENV=${ENV:-development}
env_file:
  - .env.${ENV:-local}
```

##### **1.3 Eliminate Credential Logging**
**File**: `src/main.py:104-105`

**Implementation**:
```python
# Remove or mask sensitive information
logger.info("Database connection configured")
logger.info("NATS connection configured") 
# Never log URLs with credentials
```

#### **Acceptance Criteria**
- [ ] All database queries use parameterized statements
- [ ] No credentials visible in docker-compose.yml
- [ ] No sensitive data appears in log output
- [ ] Security scanner shows zero SQL injection vulnerabilities
- [ ] Configuration validation prevents credential exposure

---

### **TASK 2: Connection Pool Consolidation**
**Priority**: P0 (Critical)  
**Estimated Effort**: 1 week  
**Dependencies**: Task 1  

#### **Objective**
Eliminate multiple connection creation/destruction cycles and implement single connection pool pattern.

#### **Technical Requirements**

##### **2.1 Create Connection Manager Service**
**New File**: `src/infrastructure/connection_manager.py`

```python
class ConnectionManager:
    """Centralized connection lifecycle management"""
    
    def __init__(self, config: Config):
        self.config = config
        self.db_pool = None
        self.nats_connection = None
        self.js_context = None
        
    async def initialize(self):
        """Initialize all connections once at startup"""
        await self._initialize_database_pool()
        await self._initialize_nats_connection()
        
    async def _initialize_database_pool(self):
        self.db_pool = await asyncpg.create_pool(
            self.config.get_db_uri(),
            min_size=5,
            max_size=20,
            command_timeout=60
        )
        
    async def _initialize_nats_connection(self):
        self.nats_connection = await nats.connect(self.config.get_nats_url())
        self.js_context = self.nats_connection.jetstream()
        
    def get_database_pool(self):
        return self.db_pool
        
    def get_nats_publisher(self):
        return NatsPublisher(self.nats_connection, self.js_context)
```

##### **2.2 Refactor Database Access**
**File**: `src/utils/db.py`

**Implementation**:
```python
class TicketDatabase:
    def __init__(self, connection_manager: ConnectionManager):
        self.connection_manager = connection_manager
        self.logger = logging.getLogger(__name__)
    
    @property
    def pool(self):
        return self.connection_manager.get_database_pool()
        
    # Remove connect() and close() methods - managed by ConnectionManager
```

##### **2.3 Refactor NATS Integration**
**File**: `src/messaging/ticket_publisher.py`

**Implementation**:
```python
class NatsPublisher:
    def __init__(self, nats_connection, js_context):
        self.conn = nats_connection
        self.js = js_context
        # Remove connect() and close() methods
```

#### **Acceptance Criteria**
- [ ] Single database connection pool shared across all components
- [ ] Single NATS connection shared across all publishers
- [ ] No connection creation in individual components
- [ ] Connection health monitoring implemented
- [ ] Graceful shutdown with proper resource cleanup
- [ ] Connection pool metrics available for monitoring

---

### **TASK 3: Configuration Architecture Redesign**
**Priority**: P1 (High)  
**Estimated Effort**: 0.5 weeks  
**Dependencies**: Task 2  

#### **Objective**
Eliminate configuration duplication and implement hierarchical configuration management.

#### **Technical Requirements**

##### **3.1 Configuration Consolidation**
**File**: `src/utils/config.py`

**Implementation**:
```python
class Config:
    """Hierarchical configuration: ENV -> .env -> defaults"""
    
    def __init__(self):
        self.env = os.getenv('CONFIG_ENV', 'development')
        self.dotenv_config = self._load_env_file()
        self._validate_required_config()
        
    def _load_env_file(self):
        env_file = f".env.{self.env}"
        if os.path.exists(env_file):
            return dotenv_values(env_file)
        return dotenv_values('.env') if os.path.exists('.env') else {}
    
    def _validate_required_config(self):
        required = ['DATABASE_URL', 'NATS_URL', 'JETSTREAM_STREAM_NAME']
        missing = [key for key in required if not self.get(key)]
        if missing:
            raise ConfigurationError(f"Missing required config: {missing}")
```

##### **3.2 Environment-Specific Configuration Files**
**New Files**:
- `.env.development`
- `.env.staging` 
- `.env.production`

**Remove**:
- Hardcoded values from `docker-compose.yml`
- Duplicate defaults in `src/utils/config.py`

#### **Acceptance Criteria**
- [ ] Configuration hierarchy: Environment → .env.{ENV} → .env → minimal defaults
- [ ] No configuration duplication across files
- [ ] Startup validation with clear error messages for missing config
- [ ] Environment-specific configuration files
- [ ] No hardcoded values in docker-compose.yml

---

### **TASK 4: Structured Logging & Observability**
**Priority**: P1 (High)  
**Estimated Effort**: 1 week  
**Dependencies**: Task 2  

#### **Objective**
Replace ad-hoc logging with structured, correlatable logging and implement basic monitoring.

#### **Technical Requirements**

##### **4.1 Structured Logging Implementation**
**New File**: `src/infrastructure/logging_config.py`

```python
import structlog

def configure_logging():
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="ISO"),
            structlog.processors.add_log_level,
            structlog.processors.JSONRenderer()
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )
```

##### **4.2 Correlation ID Implementation**
**New File**: `src/infrastructure/correlation.py`

```python
import uuid
from contextvars import ContextVar

correlation_id: ContextVar[str] = ContextVar('correlation_id')

def generate_correlation_id() -> str:
    return str(uuid.uuid4())
    
def get_correlation_id() -> str:
    return correlation_id.get(generate_correlation_id())
```

##### **4.3 Remove Print Statements**
**File**: `src/utils/compress.py:21,24`

**Implementation**:
```python
# Replace print() with structured logging
logger.info("Message compressed successfully", 
           size_bytes=size, 
           compression_ratio=original_size/size)
```

##### **4.4 Processing Metrics**
**New File**: `src/infrastructure/metrics.py`

```python
from prometheus_client import Counter, Histogram, Gauge

RECORDS_PROCESSED = Counter('records_processed_total', 
                           'Total records processed', ['table', 'status'])
PROCESSING_TIME = Histogram('processing_duration_seconds',
                           'Time spent processing records', ['table'])
CONNECTION_POOL_USAGE = Gauge('db_pool_connections_active',
                             'Active database connections')
```

#### **Acceptance Criteria**
- [ ] All logging uses structured format with JSON output
- [ ] Correlation IDs track requests end-to-end
- [ ] No print() statements in production code
- [ ] Processing metrics available for monitoring
- [ ] Log levels properly configured per environment
- [ ] No sensitive data in log output

---

### **TASK 5: Fix Scheduler & Incremental Processing**
**Priority**: P0 (Critical)  
**Estimated Effort**: 0.5 weeks  
**Dependencies**: Task 2  

#### **Objective**
Restore continuous incremental processing by removing temporary TODO logic.

#### **Technical Requirements**

##### **5.1 Remove Broken Logic**
**File**: `src/services/scheduler.py`

**Remove Lines**:
```python
# Lines 17-19: Remove has_run_once flag
# Lines 24-28: Remove skip logic  
# Lines 36-38: Remove pipeline flag setting
```

##### **5.2 Implement Proper Scheduling**
**Implementation**:
```python
class Scheduler:
    def __init__(self, config: Config, pipeline: DataPipelineService):
        self.config = config
        self.pipeline = pipeline
        self.interval_seconds = config.get_scheduler_interval()
        self.scheduler = AsyncIOScheduler()
        self.logger = structlog.get_logger(__name__)

    async def start(self):
        """Start continuous interval-based processing"""
        self.scheduler.add_job(
            self.scheduled_job,
            'interval', 
            seconds=self.interval_seconds,
            id='main_processing_job'
        )
        self.scheduler.start()
        
        # Execute first run immediately
        await self.scheduled_job()
        
        self.logger.info("Scheduler started successfully",
                        interval_seconds=self.interval_seconds)
```

##### **5.3 Processing State Persistence**
**New File**: `src/infrastructure/state_manager.py`

```python
class ProcessingStateManager:
    """Manage processing state for recovery"""
    
    async def save_last_processed_time(self, table_name: str, timestamp: datetime):
        # Store in Redis or database for recovery
        pass
        
    async def get_last_processed_time(self, table_name: str) -> datetime:
        # Retrieve last successful processing time
        pass
```

#### **Acceptance Criteria**
- [ ] Continuous processing every configured interval
- [ ] No "run once" logic preventing operation
- [ ] Processing state persisted for recovery
- [ ] First execution happens immediately at startup
- [ ] Scheduler properly handles shutdown and restart
- [ ] Processing continues correctly after application restart

---

### **TASK 6: Generic Table Ingestion Framework**
**Priority**: P1 (High)  
**Estimated Effort**: 1.5 weeks  
**Dependencies**: Tasks 2, 3, 5  

#### **Objective**
Create configurable multi-table processing with topic-based routing.

#### **Technical Requirements**

##### **6.1 Table Configuration System**
**New File**: `src/domain/table_config.py`

```python
@dataclass
class TableConfig:
    name: str
    columns: List[str]
    topic: str
    transformer_class: str
    schedule_interval: int
    filters: Optional[Dict[str, Any]] = None
    
class TableRegistry:
    """Configuration-driven table definitions"""
    
    def __init__(self, config_path: str):
        self.configs = self._load_table_configs(config_path)
    
    def _load_table_configs(self, path: str) -> Dict[str, TableConfig]:
        with open(path) as f:
            config_data = yaml.safe_load(f)
        
        return {
            name: TableConfig(**config) 
            for name, config in config_data['tables'].items()
        }
```

##### **6.2 Generic Table Processor**
**New File**: `src/services/generic_processor.py`

```python
class GenericTableProcessor:
    def __init__(self, connection_manager: ConnectionManager):
        self.connection_manager = connection_manager
        self.transformers = self._load_transformers()
        
    async def process_table(self, table_config: TableConfig):
        correlation_id = generate_correlation_id()
        
        try:
            # Extract with correlation tracking
            raw_data = await self._extract_data(table_config, correlation_id)
            
            # Transform using table-specific transformer
            transformer = self._get_transformer(table_config.transformer_class)
            transformed_data = await transformer.transform(raw_data)
            
            # Publish to table-specific topic
            await self._publish_to_topic(transformed_data, table_config.topic)
            
        except Exception as e:
            await self._handle_processing_error(table_config.name, e, correlation_id)
```

##### **6.3 Table Configuration File**
**New File**: `config/tables.yaml`

```yaml
tables:
  eds.ticket:
    columns: ["client_id", "client", "ticket_id", "ticket_status", "updated_on"]
    topic: "tickets.created"
    transformer_class: "TicketTransformer"
    schedule_interval: 300
    
  eds.survey:
    columns: ["survey_id", "client_id", "responses", "updated_on"]
    topic: "surveys.updated" 
    transformer_class: "SurveyTransformer"
    schedule_interval: 600
    
  eds.notes:
    columns: ["note_id", "ticket_id", "content", "updated_on"]
    topic: "notes.processed"
    transformer_class: "NotesTransformer" 
    schedule_interval: 900
```

##### **6.4 Transformer Interface**
**New File**: `src/domain/transformers.py`

```python
class BaseTransformer(ABC):
    @abstractmethod
    async def transform(self, raw_data: List[Dict]) -> List[str]:
        """Transform raw data to JSON messages"""
        pass

class TicketTransformer(BaseTransformer):
    # Existing ticket transformation logic
    
class SurveyTransformer(BaseTransformer):
    async def transform(self, raw_data: List[Dict]) -> List[str]:
        # Survey-specific transformation logic
        pass
```

#### **Acceptance Criteria**
- [ ] Configuration-driven table processing
- [ ] Multiple tables can be processed independently
- [ ] Different schedules per table
- [ ] Topic routing based on table configuration
- [ ] Error isolation - failures in one table don't affect others
- [ ] Easy addition of new tables via configuration

---

### **TASK 7: Enhanced Error Handling & Recovery**
**Priority**: P1 (High)  
**Estimated Effort**: 1 week  
**Dependencies**: Task 6  

#### **Objective**
Implement robust error handling with recovery mechanisms and circuit breaker patterns.

#### **Technical Requirements**

##### **7.1 Circuit Breaker Implementation**
**New File**: `src/infrastructure/circuit_breaker.py`

```python
class CircuitBreaker:
    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 30):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failure_count = 0
        self.last_failure_time = None
        self.state = CircuitState.CLOSED
        
    async def call(self, func, *args, **kwargs):
        if self.state == CircuitState.OPEN:
            if time.time() - self.last_failure_time > self.recovery_timeout:
                self.state = CircuitState.HALF_OPEN
            else:
                raise CircuitBreakerOpenError("Circuit breaker is open")
                
        try:
            result = await func(*args, **kwargs)
            self._on_success()
            return result
        except Exception as e:
            self._on_failure()
            raise
```

##### **7.2 Dead Letter Queue Pattern**
**New File**: `src/infrastructure/dead_letter_queue.py`

```python
class DeadLetterQueue:
    def __init__(self, nats_publisher: NatsPublisher):
        self.publisher = nats_publisher
        self.dlq_topic = "dead_letters.failed_processing"
        
    async def send_to_dlq(self, original_message: Dict, error: Exception, 
                         context: Dict):
        dlq_message = {
            "original_message": original_message,
            "error": str(error),
            "error_type": type(error).__name__,
            "context": context,
            "failed_at": datetime.utcnow().isoformat(),
            "retry_count": context.get("retry_count", 0)
        }
        
        await self.publisher.publish(self.dlq_topic, dlq_message)
```

##### **7.3 Retry Logic with Exponential Backoff**
**File**: `src/services/app_service.py`

**Implementation**:
```python
@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=10),
    retry=retry_if_exception_type((ConnectionError, TimeoutError))
)
async def fetch_and_publish_data(self, table_config: TableConfig):
    # Existing logic with enhanced error context
```

##### **7.4 Graceful Degradation**
**New File**: `src/infrastructure/degradation_manager.py`

```python
class DegradationManager:
    """Manage partial functionality during outages"""
    
    async def handle_database_degradation(self):
        # Switch to cached/backup data source
        pass
        
    async def handle_nats_degradation(self):  
        # Store messages locally for later delivery
        pass
```

#### **Acceptance Criteria**
- [ ] Circuit breaker prevents cascade failures
- [ ] Dead letter queue captures failed messages
- [ ] Exponential backoff for transient failures
- [ ] Graceful degradation during partial outages
- [ ] Comprehensive error logging with context
- [ ] Recovery procedures for common failure scenarios

---

### **TASK 8: Data Governance Foundation**
**Priority**: P2 (Medium)  
**Estimated Effort**: 1 week  
**Dependencies**: Task 4  

#### **Objective**
Implement data governance controls including audit logging, data classification, and compliance preparation.

#### **Technical Requirements**

##### **8.1 Audit Logging System**
**New File**: `src/infrastructure/audit_logger.py`

```python
class AuditLogger:
    """Comprehensive audit trail for data operations"""
    
    async def log_data_access(self, table_name: str, action: str, 
                            record_count: int, correlation_id: str):
        audit_record = {
            "timestamp": datetime.utcnow().isoformat(),
            "correlation_id": correlation_id,
            "table_name": table_name,
            "action": action,
            "record_count": record_count,
            "user": self._get_system_user(),
            "application": "ticketing-data-processor"
        }
        
        # Store in dedicated audit database/topic
        await self._store_audit_record(audit_record)
```

##### **8.2 Data Classification System**
**New File**: `src/infrastructure/data_classifier.py`

```python
class DataClassifier:
    """Classify data for governance and compliance"""
    
    PII_PATTERNS = {
        'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        'phone': r'(\+\d{1,3}[-.\s]?)?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}',
        'ssn': r'\b\d{3}-?\d{2}-?\d{4}\b'
    }
    
    def classify_record(self, record: Dict) -> DataClassification:
        classification = DataClassification.PUBLIC
        
        for field, value in record.items():
            if self._contains_pii(str(value)):
                classification = DataClassification.PII
                break
        
        return classification
```

##### **8.3 Field-Level Encryption**
**New File**: `src/infrastructure/encryption.py`

```python
class FieldEncryption:
    """Encrypt sensitive fields before processing"""
    
    def __init__(self, key_manager: KeyManager):
        self.key_manager = key_manager
        
    async def encrypt_sensitive_fields(self, record: Dict, 
                                     classification: DataClassification) -> Dict:
        if classification == DataClassification.PII:
            encrypted_record = record.copy()
            for field in self._get_sensitive_fields(record):
                encrypted_record[field] = await self._encrypt_field(record[field])
            return encrypted_record
        return record
```

##### **8.4 Data Retention Manager**
**New File**: `src/infrastructure/retention_manager.py`

```python
class DataRetentionManager:
    """Manage data lifecycle and retention policies"""
    
    RETENTION_POLICIES = {
        'eds.ticket': timedelta(days=2555),  # 7 years for SOX
        'eds.survey': timedelta(days=1095),  # 3 years
        'eds.notes': timedelta(days=365)     # 1 year
    }
    
    async def apply_retention_policy(self, table_name: str):
        # Implementation for data purging/archival
        pass
```

#### **Acceptance Criteria**
- [ ] Complete audit trail for all data operations
- [ ] Automatic PII detection and classification
- [ ] Field-level encryption for sensitive data
- [ ] Data retention policies implemented
- [ ] Compliance reporting capabilities
- [ ] GDPR/SOX controls preparation

---

### **✅ TASK 9: Health Monitoring & Operational Readiness (COMPLETE)**
**Priority**: P2 (Medium)  
**Estimated Effort**: 1 week  
**Dependencies**: Task 4  
**Status**: ✅ **IMPLEMENTED**  

#### **Objective**
Implement comprehensive health monitoring, metrics export, and operational visibility.

#### **✅ Implementation Complete**

**Implemented Components:**

##### **✅ Health Check Endpoints (Implemented)**
- **Health HTTP Server** on port 8080
- **GET /health** - Comprehensive component health status with JSON response
- **GET /health/live** - Kubernetes liveness probe (200 OK when alive)
- **GET /health/ready** - Kubernetes readiness probe (503 when dependencies unavailable)  
- **GET /healthz** - Kubernetes convention alias for liveness
- **GET /health/metrics** - Prometheus-compatible metrics format

##### **✅ Component Health Monitoring (Implemented)**
- **Database Health**: Connection pool status, query response times
- **NATS Health**: JetStream connectivity, publisher status
- **Scheduler Health**: Active job monitoring and execution status
- **System Health**: CPU, memory, disk utilization monitoring (with psutil fallback)

##### **✅ APM Integration (Implemented)**
- **Prometheus/Grafana**: Native metrics endpoint with time-series data
- **DataDog Integration**: HTTP health check monitoring with structured responses
- **New Relic Compatibility**: Infrastructure monitoring via standardized endpoints
- **Elastic APM**: Compatible health status format

##### **✅ Circuit Breaker & Resilience (Implemented)**
- **Exponential backoff retry** with jitter for external service failures
- **Circuit breaker pattern** to prevent cascade failures during outages
- **Graceful degradation** maintains partial functionality when components fail
- **Connection pool management** with health monitoring and automatic recovery

##### **✅ Comprehensive Test Framework (Implemented)**
- **Integration Tests**: `test_health_integration.py` - Component testing without external dependencies
- **Browser Tests**: `test_health_browser.py` - JSON format validation and browser compatibility
- **Manual Tests**: `test_health_manual.py` - Live 30-second server for manual browser testing
- **pytest Framework**: Async fixtures, manual test markers, and comprehensive coverage

#### **Original Technical Requirements** (Now Superseded)

##### **9.1 Health Check Endpoints**
**New File**: `src/infrastructure/health_server.py`

```python
from aiohttp import web
import aiohttp

class HealthServer:
    def __init__(self, connection_manager: ConnectionManager):
        self.connection_manager = connection_manager
        
    async def start_server(self, port: int = 8080):
        app = web.Application()
        app.router.add_get('/health', self.health_check)
        app.router.add_get('/ready', self.readiness_check)
        app.router.add_get('/metrics', self.metrics_export)
        
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, '0.0.0.0', port)
        await site.start()
        
    async def health_check(self, request):
        """Basic liveness check"""
        return web.json_response({"status": "healthy", "timestamp": datetime.utcnow().isoformat()})
        
    async def readiness_check(self, request):
        """Check if dependencies are ready"""
        checks = {
            "database": await self._check_database(),
            "nats": await self._check_nats()
        }
        
        all_ready = all(checks.values())
        status_code = 200 if all_ready else 503
        
        return web.json_response({
            "ready": all_ready,
            "checks": checks,
            "timestamp": datetime.utcnow().isoformat()
        }, status=status_code)
```

##### **9.2 Prometheus Metrics Integration**
**File**: `src/infrastructure/metrics.py` (Enhanced)

```python
from prometheus_client import Counter, Histogram, Gauge, generate_latest

# Business metrics
RECORDS_PROCESSED = Counter('records_processed_total', 
                           'Total records processed', ['table', 'status'])
PROCESSING_LATENCY = Histogram('processing_duration_seconds',
                              'Processing time per table', ['table'])

# Technical metrics  
DATABASE_CONNECTIONS = Gauge('database_connections_active',
                            'Active database connections')
NATS_MESSAGES_SENT = Counter('nats_messages_sent_total',
                            'NATS messages published', ['topic', 'status'])
ERROR_COUNT = Counter('errors_total', 
                     'Application errors', ['type', 'component'])

async def metrics_handler(request):
    """Prometheus metrics endpoint"""
    return web.Response(text=generate_latest(), content_type='text/plain')
```

##### **9.3 Application Performance Monitoring**
**New File**: `src/infrastructure/apm.py`

```python
class PerformanceMonitor:
    """Monitor application performance and resource usage"""
    
    async def monitor_processing_performance(self, table_name: str):
        start_time = time.time()
        
        try:
            yield  # Context manager usage
        finally:
            duration = time.time() - start_time
            PROCESSING_LATENCY.labels(table=table_name).observe(duration)
            
    async def monitor_resource_usage(self):
        """Monitor memory, CPU, and connection usage"""
        import psutil
        
        process = psutil.Process()
        
        # Update gauges
        DATABASE_CONNECTIONS.set(self.connection_manager.get_active_connections())
        
        # Log resource usage
        logger.info("Resource usage update",
                   memory_mb=process.memory_info().rss / 1024 / 1024,
                   cpu_percent=process.cpu_percent())
```

##### **9.4 Alerting System Integration**
**New File**: `src/infrastructure/alerting.py`

```python
class AlertManager:
    """Integration with alerting systems"""
    
    async def send_critical_alert(self, alert_type: str, message: str, 
                                 context: Dict):
        alert = {
            "severity": "critical",
            "alert_type": alert_type,
            "message": message,
            "context": context,
            "timestamp": datetime.utcnow().isoformat(),
            "application": "ticketing-data-processor"
        }
        
        # Send to alerting system (PagerDuty, Slack, etc.)
        await self._send_alert(alert)
```

#### **✅ Acceptance Criteria (COMPLETE)**
- [✅] HTTP health endpoints for liveness/readiness probes
- [✅] Prometheus metrics available at /metrics endpoint
- [✅] Resource usage monitoring and health checks
- [✅] Processing performance metrics (response times, component status)
- [✅] Integration with external monitoring systems (Prometheus, DataDog, New Relic, Elastic APM)
- [✅] Component-level health monitoring with graceful degradation

---

### **TASK 10: Testing & Documentation**
**Priority**: P2 (Medium)  
**Estimated Effort**: 1 week  
**Dependencies**: All previous tasks  

#### **Objective**
Comprehensive testing suite and operational documentation for production readiness.

#### **Technical Requirements**

##### **10.1 Unit Test Implementation**
**New Directory**: `tests/unit/`

**Test Structure**:
```python
# tests/unit/test_connection_manager.py
class TestConnectionManager:
    @pytest.mark.asyncio
    async def test_database_pool_initialization(self):
        # Test connection pool creation and configuration
        
    @pytest.mark.asyncio  
    async def test_nats_connection_sharing(self):
        # Test NATS connection reuse across components

# tests/unit/test_generic_processor.py  
class TestGenericTableProcessor:
    @pytest.mark.asyncio
    async def test_table_processing_with_valid_config(self):
        # Test successful table processing
        
    @pytest.mark.asyncio
    async def test_error_handling_with_invalid_data(self):
        # Test error handling and recovery
```

##### **10.2 Integration Test Suite**
**New Directory**: `tests/integration/`

```python
# tests/integration/test_end_to_end_pipeline.py
class TestDataPipeline:
    @pytest.mark.asyncio
    async def test_complete_ticket_processing_flow(self):
        # Test: Database → Transform → NATS publishing
        
    @pytest.mark.asyncio
    async def test_multi_table_processing(self):
        # Test: Multiple tables processed independently
        
    @pytest.mark.asyncio
    async def test_error_recovery_scenarios(self):
        # Test: Circuit breaker, DLQ, retry logic
```

##### **10.3 Performance Test Framework**
**New Directory**: `tests/performance/`

```python
# tests/performance/test_processing_capacity.py
class TestProcessingPerformance:
    @pytest.mark.asyncio
    async def test_high_volume_processing(self):
        # Test processing of large record sets
        
    async def test_memory_usage_under_load(self):
        # Test memory stability during extended processing
```

##### **10.4 Security Test Suite**
**New Directory**: `tests/security/`

```python
# tests/security/test_sql_injection_prevention.py
class TestSecurityControls:
    @pytest.mark.asyncio
    async def test_parameterized_query_safety(self):
        # Verify SQL injection prevention
        
    def test_credential_exposure_prevention(self):
        # Verify no credentials in logs or config files
```

##### **10.5 Operational Documentation**
**New Files**:
- `docs/operational-runbook.md`
- `docs/troubleshooting-guide.md`
- `docs/deployment-guide.md`
- `docs/monitoring-setup.md`

**Content Requirements**:
- Deployment procedures and prerequisites
- Configuration management instructions  
- Monitoring setup and dashboard configuration
- Troubleshooting common issues and errors
- Recovery procedures for various failure scenarios
- Performance tuning and optimization guidelines

##### **10.6 API Documentation**
**New File**: `docs/api-documentation.md`

**Health Endpoints Documentation**:
```markdown
## Health Check Endpoints

### GET /health
Returns application liveness status
Response: 200 OK with {"status": "healthy"}

### GET /ready  
Returns application readiness status
Response: 200 OK if ready, 503 if dependencies unavailable

### GET /metrics
Returns Prometheus metrics
Response: 200 OK with metrics in Prometheus format
```

#### **Acceptance Criteria**
- [ ] 80%+ unit test coverage for all business logic
- [ ] Integration tests cover complete data pipeline flows
- [ ] Performance tests validate processing capacity
- [ ] Security tests verify vulnerability remediation
- [ ] Comprehensive operational documentation
- [ ] API documentation for health endpoints
- [ ] Deployment guides and troubleshooting procedures

---

## Implementation Timeline

### **Phase 1: Critical Security & Foundation (Weeks 1-2)**
- **Week 1**: Task 1 (Security Remediation)
- **Week 2**: Task 2 (Connection Management) + Task 3 (Configuration)

### **Phase 2: Core Infrastructure (Weeks 3-4)**  
- **Week 3**: Task 4 (Logging) + Task 5 (Scheduler Fix)
- **Week 4**: Task 6 (Multi-Table Framework)

### **✅ Phase 1.5: Enterprise Monitoring (COMPLETED)**
- ✅ **TASK 9**: Health Monitoring & Observability - Comprehensive implementation complete
- ✅ **Knowledge Graph Processing**: Entity extraction and relationship mapping
- ✅ **Testing Framework**: Integration, browser, and manual test suites

### **Phase 3: Enterprise Features (Weeks 5-6)**
- **Week 5**: Task 7 (Error Handling) + Task 8 (Data Governance)
- **Week 6**: ~~Task 9 (Monitoring)~~ → Additional Task 6 (Multi-Table Framework)

### **Phase 4: Production Readiness (Weeks 7-8)**
- **Week 7-8**: Task 10 (Testing & Documentation) - Partially complete with health monitoring tests

## Success Criteria

### **Security**
- [ ] Zero security vulnerabilities in automated scans
- [ ] All credentials properly managed through environment/secrets
- [ ] Complete audit trail for all data operations

### **Functionality**  
- [ ] Multi-table processing with independent scheduling
- [ ] Topic-based message routing working correctly
- [ ] Continuous processing without manual intervention

### **Operational Readiness**
- [✅] Health endpoints responding correctly
- [✅] Comprehensive monitoring and APM integration
- [✅] Component-level health checks with graceful degradation
- [ ] Complete operational documentation (health monitoring documented in README_HEALTH_TESTS.md)

### **Performance**
- [ ] Processing latency under SLA requirements
- [ ] Resource usage within defined limits  
- [ ] Horizontal scaling capability validated

This specification provides a clear roadmap to transform the current prototype into an enterprise-ready data pipeline system while maintaining architectural integrity and preparing for future extensibility.