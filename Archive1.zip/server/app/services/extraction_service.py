"""
Ollama LLM Extraction Service
Handles calling the fine-tuned LLM for note extraction, summarization, and ticket audit.
"""
import logging
import requests
import json
import asyncio
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Optional
from configs.config import Config
from configs.taxonomy.taxonomy_snap import get_taxonomy


class ExtractionService:
    """Service for extracting structured data from ticket notes using fine-tuned LLM"""

    EXTRACT_PROMPT = """You are an expert telecom support analyst. Extract structured information from this support ticket note.

METADATA:
{metadata}

NOTE TEXT:
{note_text}

EXTRACTION RULES:

1. SOURCE CLASSIFICATION:
   - "Diagnostic": ME3 alarms, JSON data, monitoring alerts
   - "Engineer": Technical troubleshooting by GTT staff
   - "Customer": Customer emails, communications
   - "Supplier": Third-party vendor communications
   - "Gears": GEARS auto-generated messages
   - "System": ServiceNow system messages

2. BOILERPLATE DETECTION (mark is_boilerplate=true):
   - Email signatures, legal disclaimers
   - "NOTICE: This e-mail is only intended for..."
   - Survey links, feedback requests
   - CID image references
   - System auto-close messages

3. TIMELINE EXTRACTION:
   - Look for timestamps in ME3 alarms: "first_notify", "last_notify"
   - Look for Cisco log timestamps: "*Dec 21 15:44:04.295:"
   - Look for email headers: "Sent:", "Date:"
   - Extract: service_down, service_restored, equipment_reboot events

4. FAULT TYPE (one of: HardDown, PacketLoss, Latency, Jitter, PartialDown, Degraded, or null):
   - "hard down", "no connectivity", "unreachable" -> HardDown
   - "packet loss", "drops" -> PacketLoss
   - "latency", "delay", "slow" -> Latency
   - "jitter" -> Jitter
   - "partial", "some services" -> PartialDown
   - "degraded but functional" -> Degraded

5. RESPONSIBLE PARTY (one of: GTT, Customer, Supplier, Delivery, Unknown, or null):
   - Supplier mentioned fixing (Lumen, AT&T, fiber splice) -> Supplier
   - Customer CPE issue, customer config -> Customer
   - GTT equipment, GTT config change -> GTT
   - Unable to determine -> Unknown

6. CLEANED TEXT:
   - Remove all boilerplate, signatures, disclaimers
   - Keep technical content, troubleshooting steps, status updates
   - Keep customer communications (stripped of signatures)

Return a JSON object with these fields:
{{
  "note_source": "<Diagnostic|Engineer|Customer|Supplier|Gears|System>",
  "is_boilerplate": <true|false>,
  "fault_type": "<HardDown|PacketLoss|Latency|Jitter|PartialDown|Degraded|null>",
  "fault_evidence": "<quote from note or null>",
  "responsible_party": "<GTT|Customer|Supplier|Delivery|Unknown|null>",
  "resolution_action": "<action taken or null>",
  "root_cause": "<root cause or null>",
  "equipment_rebooted": <true|false>,
  "supplier_name": "<supplier name or null>",
  "customer_confirmed": <true|false>,
  "cleaned_text": "<note text with boilerplate removed>",
  "extraction_confidence": <0.0-1.0>,
  "timeline_events": [
    {{
      "event_type": "<ServiceDown|ServiceRestored|EquipmentReboot|ConfigChange|...>",
      "timestamp": "<ISO 8601 or null>",
      "description": "<brief description>"
    }}
  ]
}}"""

    FAULT_SUMMARY_PROMPT = """Summarize this fault description in 100-500 characters. Capture the essential technical facts:
- What happened (service down, packet loss, degraded, etc.)
- What service/circuit was affected (circuit ID, device name, location)
- What alarms fired (ME3 alarm type, severity)
- What impact occurred (customer down, partial outage, etc.)

Strip all HTML, CSS, boilerplate, email signatures, and noise. Keep only technical facts.
Return ONLY a JSON object:
{{"summary": "<concise technical summary here>"}}

RAW FAULT DESCRIPTION:
{raw_text}"""

    SUMMARY_PROMPT = """Clean this support ticket note by removing boilerplate while preserving useful content.

RAW TEXT:
{raw_text}

REMOVE:
- Email signatures and sign-offs
- Legal disclaimers ("NOTICE: This e-mail...")
- Survey links and feedback requests
- CID image references [cid:...]
- URL defense wrapped links
- Forwarded message headers (keeping the actual content)
- Auto-generated system messages
- Empty lines and excessive whitespace

KEEP:
- Technical troubleshooting content
- Status updates and timeline information
- Customer requests and responses
- Resolution details
- Device names, IPs, circuit IDs

Return ONLY the cleaned text as a JSON object:
{{"summary": "<cleaned text here>"}}"""

    AUDIT_PROMPT = """You are an expert telecom ticket auditor. Analyze this ticket's Ticket Summary to suggest accurate field values.

TICKET ID: {ticket_id}

CURRENT TICKET DATA:
{ticket_data}

ALL NOTES (chronological):
{all_notes}

=== CORE PRINCIPLE ===

The Ticket Summary contains COMPUTED FACTS and raw data. Your job:
- COMPUTED FACTS in the Summary (Total Down Time, Outage Window, Flapping pattern, System MTTR): USE THEM EXACTLY. Do not recalculate.
- MISSING OR AMBIGUOUS DATA (fault type, RFO, resolution text, responsible party): INFER from evidence.
- PRIORITY: Always infer based on impact evidence (down vs degraded), not just what the ticket says.

=== AUDIT RULES ===

1. FAULT CLASSIFICATION — Two-phase snap-to-grid:

   Phase 1 — REASON FREELY (→ fault_analysis):
   Analyze the alarm evidence, notes, and symptoms. Write a concise free-text explanation
   of what went wrong. Example: "Circuit experienced repeated outage cycles due to fiber
   degradation on supplier side"

   Phase 2 — SNAP TO TAXONOMY (→ suggested_category + fault_type):
   From the taxonomy grid below, pick the CLOSEST matching pair:
   - suggested_category: The impacted service/thing (e.g., "Managed Networking")
   - fault_type: The fault itself (e.g., "Line Down", "Flaps | Instabilities")
   Stay within the taxonomy. If nothing fits perfectly, pick the best available match.

{taxonomy_section}

   FLAPPING: If the Ticket Summary says "Pattern: Flapping (N cycles detected)",
   set is_flapping=true and flap_cycles=N. This is SEPARATE from fault_type —
   do NOT append " - Flapping" to fault_type.

2. RESPONSIBLE PARTY - INFER from evidence (one of):
   - "GTT": GTT network/equipment issue, GTT made the fix
   - "Customer": Customer CPE issue, customer site power, customer rebooted equipment
     * Key indicator: Low CPE uptime at resolution means customer rebooted
   - "Supplier": Third-party carrier fixed the issue (Lumen, AT&T, Zayo, etc.)
     * Key indicator: Supplier name mentioned performing repair (splice, card swap, etc.)
   - "Delivery": New service provisioning issue
   - "Unknown": Cannot determine from available information
     * Key indicator: High CPE uptime but unclear who fixed = Unknown

3. RFO - REASON FOR OUTAGE - INFER from evidence (or null if unclear):
   Only suggest RFO if evidence clearly supports it. Use null if uncertain.
   Examples: "No Fault Found", "Customer CPE Issue", "Fiber Cut", "Hardware Failure",
   "Configuration Error", "Power Issue", "Supplier Issue", "Force Majeure",
   "Planned Maintenance", "Inside Wiring", "Cause Undetermined", or null.

4. MTTR - USE VALUES from Ticket Summary in this priority order:
   - "System MTTR: HH:MM:SS" → convert to minutes and use as mttr_minutes.
     This is ServiceNow's u_adjusted_business_elapsed_time — it correctly handles
     reopened tickets by excluding time the ticket was in resolved state.
   - "Total Down Time: X minutes" → use X as mttr_minutes (flapping tickets only)
   - "Outage Window: ... (X min)" → use ONLY if System MTTR is NOT present.
     WARNING: Outage Window is wall-clock from first alarm to last resolution and
     does NOT account for reopens — it will be too large for reopened tickets.
   - If NONE of the above are present, calculate from state transitions in the
     field_changes: sum time in open states (state=1, state=10), exclude time
     in resolved state (state=6).
   - suggested_actual_end_date: use Alarm End timestamp from the Summary, or the
     last resolved_at timestamp from field_changes.

5. PRIORITY - ALWAYS INFER based on impact:
   - P1: Service down, complete outage, no connectivity
   - P2: Significant degradation, major packet loss, intermittent connectivity
   - P3: Minor degradation, some packet loss, service mostly functional
   - P4/P5: Informational, monitoring, no customer impact
   Base this on the alarm evidence and fault type, not just the ticket's priority field.

6. GENERATE RESOLUTIONS - INFER (these are always missing or generic in SNOW):
   - suggested_resolution_notes: Customer-facing resolution summary (2-3 sentences, professional, suitable for customer communication)
   - suggested_internal_notes: Full technical summary with device names, timestamps, troubleshooting steps

7. EVIDENCE REQUIREMENTS:
   - field_evidence MUST quote actual text/timestamps from the notes
   - For fault_type: quote the alarm message or symptom description
   - For responsible_party: quote who performed the fix action
   - For MTTR: quote the exact computed value from the Summary (e.g. "Total Down Time: 74 minutes")
   - If no clear evidence exists, say "No clear evidence in notes"

8. CONFIDENCE:
   - >0.9: Clear evidence, computed values available in Summary
   - 0.7-0.9: Good evidence, some inference needed
   - <0.7: Limited evidence, significant inference

9. EMBEDDING SUMMARY (for semantic search):
   CRITICAL: Create a DETAILED summary using SECTION TAGS with PROSE (not bullets).
   MINIMUM 1200 characters. This powers semantic search - include ALL facts.

   REQUIRED FORMAT - Use these section tags, write prose within each:

   Case Summary: [ticket_id] is a Priority [X] [fault_type] incident for customer [name] ([client_id]). [2-3 sentences: how detected, what systems involved, outcome.]

   Affected Service: The service is [type] with Service ID [id], connected via device [device_name] at [location]. The issue type was [Host Down/Line Down/Packet Loss/etc].

   Cause: The root cause was [what caused the outage]. The resolution code is [code] and RFO is [reason for outage]. [Any additional cause details.]

   Outage Period: The outage began at [start timestamp UTC] and was resolved at [end timestamp UTC], total duration [X] minutes. [If flapping, state: This was a flapping incident with N cycles, total down time X minutes.]

   Timeline: [Capture ALL events from notes, field_changes, and alarms chronologically. Format: At [time] [event]. Include every significant event.]

   Communications: [Capture ALL emails. If no emails exist, state "No email communications recorded."]

   Resolution: The issue was resolved by [GTT/Customer/Supplier] who [action taken]. Ticket closed as [status], responsible party [party].

   People: [List all people mentioned with their roles.]

   IMPORTANT: Write in PROSE, not bullets. Include ALL details. Target 1500+ characters.

Return a JSON object:
{{
  "ticket_id": "{ticket_id}",
  "fault_analysis": "<free-text analysis of what went wrong>",
  "suggested_category": "<category from taxonomy — the impacted service>",
  "fault_type": "<subcategory from taxonomy — the fault itself>",
  "responsible_party": "<GTT|Customer|Supplier|Delivery|Unknown|null>",
  "priority": <1|2|3|4|5|null>,
  "mttr_minutes": <integer from Summary computed values, or inferred if not present>,
  "is_flapping": <true if Summary says Flapping, false otherwise>,
  "flap_cycles": <N from Summary 'Flapping (N cycles)', 0 if not flapping>,
  "root_cause": "<root cause or null>",
  "rfo": "<reason for outage or null>",
  "suggested_resolution_notes": "<customer-facing resolution summary>",
  "suggested_internal_notes": "<full technical summary>",
  "suggested_actual_end_date": "<ISO 8601 timestamp from Alarm End in Summary, or null>",
  "ticket_fault_type": "<original value from ticket or null>",
  "ticket_responsible_party": "<original value from ticket or null>",
  "ticket_priority": <original value from ticket or null>,
  "ticket_mttr_minutes": <original value from ticket or null>,
  "differs_from_ticket": <true|false>,
  "lifecycle_timeline": [
    {{"timestamp": "<ISO 8601>", "event": "<DOWN|UP|RESOLVED>", "source": "<ME3|field_changes|note>"}}
  ],
  "outage_periods": [
    {{"down": "<ISO 8601>", "up": "<ISO 8601>", "duration_minutes": <integer>}}
  ],
  "field_evidence": {{
    "priority": "<quote: alarm evidence indicating severity>",
    "fault_type": "<quote: alarm message or symptom>",
    "responsible_party": "<quote: who fixed it>",
    "rfo": "<quote: what caused it>",
    "mttr": "<quote the exact computed value from Summary>"
  }},
  "embedding_summary": "<condensed timeline preserving all searchable facts - max 6000 chars>",
  "confidence": <0.0-1.0>,
  "notes_analyzed": <integer>
}}"""

    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.base_url = self.config.ollama_extraction_base_url
        self.model = self.config.ollama_extraction_model
        self.timeout = self.config.ollama_extraction_timeout
        self.generate_endpoint = f"{self.base_url}/api/generate"

        logging.info(f"Initialized ExtractionService: {self.base_url}, model={self.model}, "
                    f"timeout={self.timeout}s")

    def _call_ollama(self, prompt: str, max_retries: int = 2) -> Optional[Dict]:
        """
        Call Ollama /api/generate with JSON format and parse response.

        Args:
            prompt: The full prompt text
            max_retries: Number of retries on JSON parse failure

        Returns:
            Parsed JSON dict or None on error
        """
        for attempt in range(max_retries + 1):
            try:
                response = requests.post(
                    self.generate_endpoint,
                    json={
                        "model": self.model,
                        "prompt": prompt,
                        "format": "json",
                        "stream": False,
                        "options": {
                            "temperature": 0.1,
                            "num_predict": 4096,
                        }
                    },
                    timeout=self.timeout
                )
                response.raise_for_status()
                data = response.json()

                # Extract the generated text
                generated = data.get("response", "")
                if not generated:
                    logging.error(f"Empty response from Ollama (attempt {attempt + 1})")
                    continue

                # Parse JSON from response
                result = json.loads(generated)
                return result

            except json.JSONDecodeError as e:
                logging.warning(f"JSON parse error (attempt {attempt + 1}/{max_retries + 1}): {e}")
                if attempt < max_retries:
                    # Try to extract JSON from malformed response
                    try:
                        # Look for JSON object in response
                        start = generated.find('{')
                        end = generated.rfind('}') + 1
                        if start >= 0 and end > start:
                            result = json.loads(generated[start:end])
                            return result
                    except (json.JSONDecodeError, UnboundLocalError):
                        pass
                    continue
                logging.error(f"Failed to parse JSON after {max_retries + 1} attempts")
                return None

            except requests.exceptions.Timeout:
                logging.error(f"Timeout calling Ollama LLM (>{self.timeout}s)")
                return None
            except requests.exceptions.RequestException as e:
                logging.error(f"HTTP error calling Ollama LLM: {e}")
                return None
            except Exception as e:
                logging.error(f"Unexpected error calling Ollama LLM: {e}")
                return None

        return None

    def extract_from_note(self, note_text: str, metadata: str = "") -> Optional[Dict]:
        """
        Extract structured data from a single note.

        Args:
            note_text: Raw note text
            metadata: Note metadata (sys_id, created_on, created_by, etc.)

        Returns:
            Dict with NoteExtraction fields or None on error
        """
        if not note_text or not note_text.strip():
            logging.warning("Empty note text, skipping extraction")
            return None

        # Truncate very long notes (12B context ~8K tokens)
        if len(note_text) > 15000:
            logging.warning(f"Note text length {len(note_text)} exceeds 15K, truncating...")
            note_text = note_text[:15000]

        prompt = self.EXTRACT_PROMPT.format(
            note_text=note_text,
            metadata=metadata or "No metadata available"
        )

        result = self._call_ollama(prompt)
        if result:
            # Ensure required fields have defaults
            result.setdefault("note_source", "System")
            result.setdefault("is_boilerplate", False)
            result.setdefault("cleaned_text", note_text)
            result.setdefault("extraction_confidence", 0.5)
            result.setdefault("equipment_rebooted", False)
            result.setdefault("customer_confirmed", False)
            result.setdefault("timeline_events", [])
            logging.debug(f"Extraction complete: source={result.get('note_source')}, "
                         f"fault={result.get('fault_type')}, confidence={result.get('extraction_confidence')}")

        return result

    def generate_summary(self, note_text: str) -> Optional[str]:
        """
        Generate cleaned summary text suitable for embedding.

        Args:
            note_text: Raw note text

        Returns:
            Cleaned summary string or None on error
        """
        if not note_text or not note_text.strip():
            return None

        if len(note_text) > 15000:
            note_text = note_text[:15000]

        prompt = self.SUMMARY_PROMPT.format(raw_text=note_text)

        result = self._call_ollama(prompt)
        if result and isinstance(result, dict):
            summary = result.get("summary", "")
            if summary and summary.strip():
                return summary.strip()

        # Fallback: if LLM failed but text is short and non-boilerplate, return as-is
        logging.warning("Summary generation failed, returning None")
        return None

    def summarize_fault_description(self, fault_text: str) -> Optional[str]:
        """
        Summarize a sanitized fault description to 100-500 chars.

        Args:
            fault_text: Sanitized fault description text (HTML/CSS already stripped)

        Returns:
            Summary string or None on error
        """
        if not fault_text or not fault_text.strip():
            return None

        if len(fault_text) > 15000:
            fault_text = fault_text[:15000]

        prompt = self.FAULT_SUMMARY_PROMPT.format(raw_text=fault_text)

        result = self._call_ollama(prompt)
        if result and isinstance(result, dict):
            summary = result.get("summary", "")
            if summary and summary.strip():
                summary = summary.strip()
                # Enforce 100-500 char range
                if len(summary) < 100:
                    logging.warning(f"Fault summary too short ({len(summary)} chars), using as-is")
                elif len(summary) > 500:
                    summary = summary[:497] + "..."
                return summary

        logging.warning("Fault description summarization failed, returning None")
        return None

    async def summarize_fault_description_async(self, fault_text: str) -> Optional[str]:
        """Async wrapper for summarize_fault_description"""
        return await asyncio.to_thread(self.summarize_fault_description, fault_text)

    def audit_ticket(
        self,
        ticket_id: str,
        ticket_data: str,
        all_notes_text: str,
        ticket_type: Optional[str] = None,
        ticket_category: Optional[str] = None,
    ) -> Optional[Dict]:
        """
        Audit a ticket by comparing extracted info vs recorded fields.

        Args:
            ticket_id: Ticket number (INC*, CS*, etc.)
            ticket_data: Current ticket field values as text
            all_notes_text: All notes concatenated chronologically
            ticket_type: Ticket type (incident, case, problem, request)
            ticket_category: Existing ServiceNow category on the ticket

        Returns:
            Dict with TicketAuditResult fields or None on error
        """
        if not all_notes_text or not all_notes_text.strip():
            logging.warning(f"No notes text for ticket {ticket_id}, skipping audit")
            return None

        # Log large inputs for monitoring (Llama 3.3 70B handles 128K tokens, ~500K chars)
        if len(all_notes_text) > 100000:
            logging.info(f"Large combined notes: {len(all_notes_text)} chars")

        # Build taxonomy section for the prompt
        taxonomy_section = ""
        taxonomy_type = None
        taxonomy = get_taxonomy()

        if ticket_type:
            taxonomy_type = taxonomy.get_model_type(ticket_type, ticket_category)
            grid = taxonomy.format_for_prompt(taxonomy_type)
            taxonomy_section = (
                f"   TAXONOMY ({taxonomy_type}):\n{grid}"
            )
            logging.info(f"Audit {ticket_id}: taxonomy_type={taxonomy_type}")

        prompt = self.AUDIT_PROMPT.format(
            ticket_id=ticket_id,
            ticket_data=ticket_data or "No ticket data available",
            all_notes=all_notes_text,
            taxonomy_section=taxonomy_section or "   (No taxonomy available — use your best judgment for fault classification)"
        )

        result = self._call_ollama(prompt)
        if result:
            # Ensure required fields match schema
            result.setdefault("ticket_id", ticket_id)
            result.setdefault("fault_analysis", None)
            result.setdefault("suggested_category", None)
            result.setdefault("fault_type", None)
            result.setdefault("responsible_party", None)
            result.setdefault("priority", None)
            result.setdefault("mttr_minutes", None)
            result.setdefault("is_flapping", False)
            result.setdefault("flap_cycles", 0)
            result.setdefault("root_cause", None)
            result.setdefault("rfo", None)
            result.setdefault("suggested_resolution_notes", None)
            result.setdefault("suggested_internal_notes", None)
            result.setdefault("ticket_fault_type", None)
            result.setdefault("ticket_responsible_party", None)
            result.setdefault("ticket_priority", None)
            result.setdefault("ticket_mttr_minutes", None)
            result.setdefault("differs_from_ticket", False)
            result.setdefault("lifecycle_timeline", [])
            result.setdefault("outage_periods", [])
            result.setdefault("field_evidence", {
                "priority": None,
                "fault_type": None,
                "responsible_party": None,
                "mttr": None
            })
            result.setdefault("confidence", 0.5)
            result.setdefault("notes_analyzed", 0)

            # Deterministic post-processing: taxonomy lookup + compose
            if taxonomy_type:
                taxonomy.enrich_audit_result(result, taxonomy_type)

            logging.info(f"Audit complete for {ticket_id}: confidence={result.get('confidence')}, "
                        f"differs={result.get('differs_from_ticket')}, "
                        f"taxonomy_valid={result.get('taxonomy_valid')}")

        return result

    async def extract_from_note_async(self, note_text: str, metadata: str = "") -> Optional[Dict]:
        """Async wrapper for extract_from_note"""
        return await asyncio.to_thread(self.extract_from_note, note_text, metadata)

    async def generate_summary_async(self, note_text: str) -> Optional[str]:
        """Async wrapper for generate_summary"""
        return await asyncio.to_thread(self.generate_summary, note_text)

    async def audit_ticket_async(
        self,
        ticket_id: str,
        ticket_data: str,
        all_notes_text: str,
        ticket_type: Optional[str] = None,
        ticket_category: Optional[str] = None,
    ) -> Optional[Dict]:
        """Async wrapper for audit_ticket"""
        return await asyncio.to_thread(
            self.audit_ticket, ticket_id, ticket_data, all_notes_text,
            ticket_type, ticket_category
        )

    def test_connection(self) -> bool:
        """
        Test connection to Ollama LLM service.

        Returns:
            True if model is available and responding, False otherwise
        """
        try:
            response = requests.post(
                self.generate_endpoint,
                json={
                    "model": self.model,
                    "prompt": "Reply with exactly: {\"status\": \"ok\"}",
                    "format": "json",
                    "stream": False,
                    "options": {"num_predict": 32}
                },
                timeout=30
            )
            response.raise_for_status()
            data = response.json()
            generated = data.get("response", "")

            if generated:
                logging.info(f"Ollama LLM connection test successful (model={self.model})")
                return True
            else:
                logging.error("Ollama LLM connection test: empty response")
                return False

        except Exception as e:
            logging.error(f"Ollama LLM connection test failed: {e}")
            return False
