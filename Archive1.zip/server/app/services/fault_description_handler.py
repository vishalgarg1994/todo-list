"""
Fault Description Message Handler
Processes FaultDescriptionSummary messages from NATS and stores embeddings in Milvus.

WS-B flow: sanitize → summarize → embed summary → store (vector, sanitized text, summary)
"""
import logging
import json
from typing import List, Dict, Any

from data_access.milvusClient import MilvusClient
from services.embedding_service import EmbeddingService
from services.extraction_service import ExtractionService
from configs.config import Config
from utils.utilities import Helpers
from utils.text_utils import strip_html_css, sanitize_for_embedding


class FaultDescriptionMessageHandler:
    """Handler for processing fault description messages"""

    def __init__(
        self,
        milvus_client: MilvusClient,
        embedding_service: EmbeddingService,
        config: Config,
        extraction_service: ExtractionService = None
    ):
        """
        Initialize the message handler

        Args:
            milvus_client: Connected Milvus client
            embedding_service: Service for generating embeddings
            config: Configuration object
            extraction_service: Service for LLM summarization (optional for backward compat)
        """
        self.milvus_client = milvus_client
        self.embedding_service = embedding_service
        self.extraction_service = extraction_service
        self.config = config
        self.logger = logging.getLogger(__name__)

        # Progress tracking
        self.messages_processed = 0
        self.total_embeddings_inserted = 0
        self.total_embeddings_failed = 0
        self.log_interval = 100  # Log every N messages

    async def handle_message(self, msg):
        """
        Handle incoming NATS message with FaultDescriptionSummary

        Message format:
        {
            "fault_description_summary_id": "...",
            "client_id": "Acme Corp",
            "part_number": 1,
            "total_parts": 5,
            "fault_descriptions": [
                {
                    "fault_description_id": "INC123456",
                    "fault_description": "Fiber cable cut at 123 Main St"
                },
                ...
            ]
        }

        Args:
            msg: NATS message
        """
        try:
            # Decompress message (same as ticket handler)
            data = Helpers.decompress_message(msg.data)

            # Validate it's a FaultDescriptionSummary
            if 'fault_description_summary_id' not in data:
                self.logger.error(f"Invalid message format - missing fault_description_summary_id")
                self.logger.warning(f"⚠️  Acknowledging invalid message to remove from stream (prevent infinite loop)")
                await msg.ack()  # ACK to remove permanently - don't retry invalid messages
                return

            client_id = data.get('client_id')
            part_number = data.get('part_number', 1)
            total_parts = data.get('total_parts', 1)
            fault_descriptions = data.get('fault_descriptions', [])

            # Process batch
            success, failed = await self._process_fault_description_batch(fault_descriptions)

            # Update counters
            self.messages_processed += 1
            self.total_embeddings_inserted += success
            self.total_embeddings_failed += failed

            # Log every N messages
            if self.messages_processed % self.log_interval == 0:
                self.logger.info(
                    f"✅ Processed {self.messages_processed} messages: "
                    f"{self.total_embeddings_inserted} embeddings inserted, "
                    f"{self.total_embeddings_failed} failed"
                )

            # Acknowledge message
            await msg.ack()

        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse NATS message: {e}")
            await msg.ack()  # ACK to avoid infinite retry loop
            self.logger.warning("⚠️  ACK'd failed message to continue processing")
        except Exception as e:
            self.logger.error(f"Error processing NATS message: {e}", exc_info=True)
            await msg.ack()  # ACK to avoid infinite retry loop
            self.logger.warning("⚠️  ACK'd failed message to continue processing")

    async def _process_fault_description_batch(
        self,
        fault_descriptions: List[Dict[str, Any]]
    ) -> tuple[int, int]:
        """
        Process a batch of fault descriptions.

        WS-B flow per description:
        1. Sanitize: strip_html_css + sanitize_for_embedding
        2. Summarize: LLM generates 100-500 char summary
        3. Embed: generate embedding from summary (not raw)
        4. Store: vector (from summary), sanitized text, summary text

        Args:
            fault_descriptions: List of fault description dicts

        Returns:
            Tuple of (success_count, failed_count)
        """
        if not fault_descriptions:
            return 0, 0

        # Extract fault description texts
        raw_texts = [fd['fault_description'] for fd in fault_descriptions]
        fault_description_ids = [fd['fault_description_id'] for fd in fault_descriptions]

        # Step 1: Sanitize each fault description
        MAX_TEXT_LENGTH = 65535
        sanitized_texts = []
        for text in raw_texts:
            sanitized = strip_html_css(text)
            sanitized = sanitize_for_embedding(sanitized)
            if len(sanitized) > MAX_TEXT_LENGTH:
                self.logger.warning(f"⚠️  Truncating sanitized fault description from {len(sanitized)} to {MAX_TEXT_LENGTH} characters")
                sanitized = sanitized[:MAX_TEXT_LENGTH]
            sanitized_texts.append(sanitized)

        # Step 2: Summarize each fault description
        summaries = []
        for i, sanitized in enumerate(sanitized_texts):
            summary = None
            if self.extraction_service:
                try:
                    summary = await self.extraction_service.summarize_fault_description_async(sanitized)
                except Exception as e:
                    self.logger.warning(f"Summarization failed for {fault_description_ids[i]}: {e}")

            if summary:
                summaries.append(summary)
            else:
                # Fallback: use truncated sanitized text as summary
                fallback = sanitized[:500] if len(sanitized) > 500 else sanitized
                summaries.append(fallback)
                self.logger.debug(f"Using sanitized text as fallback summary for {fault_description_ids[i]}")

        # Step 3: Embed from summary (not raw/sanitized)
        embeddings = await self.embedding_service.generate_embeddings_batch(
            summaries,
            batch_size=100
        )

        # Step 4: Separate successful vs failed, store in Milvus
        successful_ids = []
        successful_embeddings = []
        successful_texts = []
        successful_summaries = []
        failed_count = 0

        for i, embedding in enumerate(embeddings):
            if embedding is not None:
                successful_ids.append(fault_description_ids[i])
                successful_embeddings.append(embedding)
                successful_texts.append(sanitized_texts[i])
                successful_summaries.append(summaries[i])
            else:
                failed_count += 1

        # Insert successful embeddings into Milvus
        if successful_ids:
            try:
                inserted_count = await self.milvus_client.insert(
                    fault_description_ids=successful_ids,
                    embeddings=successful_embeddings,
                    fault_description_texts=successful_texts,
                    fault_description_summaries=successful_summaries
                )

            except Exception as e:
                self.logger.error(f"❌ Failed to insert embeddings into Milvus: {e}")
                # Count all as failed if insertion fails
                failed_count = len(fault_descriptions)
                successful_ids = []

        success_count = len(successful_ids)
        return success_count, failed_count
