"""
Test core stream management functionality
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
import sys
from pathlib import Path

# Add stream-manager directory to path so we can import stream_manager
sys.path.append(str(Path(__file__).parent.parent / "stream-manager"))

from stream_manager import NatsStreamManager
from config import Config


class TestNatsStreamManager:
    """Test NATS Stream Manager core functionality"""

    @pytest.fixture
    def mock_config(self):
        """Create a mock configuration for testing"""
        config = Mock(spec=Config)
        config.get_nats_url.return_value = "nats://localhost:4222"
        return config

    @pytest.fixture
    def stream_manager(self, mock_config):
        """Create a NatsStreamManager instance for testing"""
        return NatsStreamManager(mock_config)

    def test_stream_manager_initialization(self, mock_config):
        """Test that NatsStreamManager can be initialized properly"""
        manager = NatsStreamManager(mock_config)

        assert manager is not None
        assert manager.config is mock_config
        assert manager.nc is None  # Should be None before connection
        assert manager.js is None  # Should be None before connection

    def test_config_integration(self, stream_manager, mock_config):
        """Test that stream manager properly uses config"""
        # Verify config is stored
        assert stream_manager.config is mock_config

        # Verify config methods are called as expected
        mock_config.get_nats_url.return_value = "nats://test:4222"
        url = stream_manager.config.get_nats_url()
        assert url == "nats://test:4222"

    @pytest.mark.asyncio
    async def test_connect_method_exists(self, stream_manager):
        """Test that connect method exists and can be called"""
        # This tests the method exists without actually connecting
        assert hasattr(stream_manager, 'connect')
        assert callable(stream_manager.connect)

        # Mock the NATS connection to avoid actual network calls
        with patch('nats.connect') as mock_connect:
            mock_connect.return_value = AsyncMock()
            try:
                await stream_manager.connect()
                # If we get here without exception, the method structure is correct
            except Exception as e:
                # Even if connection fails, the method should exist and be callable
                assert callable(stream_manager.connect)

    def test_stream_manager_has_required_methods(self, stream_manager):
        """Test that stream manager has all expected methods"""
        required_methods = ['connect']

        for method_name in required_methods:
            assert hasattr(stream_manager, method_name), f"Missing method: {method_name}"
            assert callable(getattr(stream_manager, method_name)), f"Method {method_name} is not callable"

    def test_stream_manager_attributes(self, stream_manager):
        """Test that stream manager has expected attributes"""
        # Test initial state
        assert hasattr(stream_manager, 'config')
        assert hasattr(stream_manager, 'nc')
        assert hasattr(stream_manager, 'js')

        # Test initial values
        assert stream_manager.nc is None
        assert stream_manager.js is None