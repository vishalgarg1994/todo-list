"""
Milvus vector database client for CMD note embeddings.
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional

from pymilvus import (
    Collection, CollectionSchema, DataType, FieldSchema,
    connections, utility,
)

from config import Config

logger = logging.getLogger(__name__)


class CMDMilvusClient:
    def __init__(self, config: Config, connection_alias: str = "cmd_default"):
        self.config = config
        self.collection_name = config.milvus_collection_name
        self.collection: Optional[Collection] = None
        self.is_connected = False
        self._alias = connection_alias

    def connect(self):
        kwargs = {
            "alias": self._alias,
            "host": self.config.milvus_host,
            "port": self.config.milvus_port,
        }
        if self.config.milvus_user and self.config.milvus_password:
            kwargs["user"] = self.config.milvus_user
            kwargs["password"] = self.config.milvus_password
        connections.connect(**kwargs)
        self.is_connected = True
        logger.info("Connected to Milvus at %s:%s", self.config.milvus_host, self.config.milvus_port)

        if utility.has_collection(self.collection_name, using=self._alias):
            self.collection = Collection(self.collection_name, using=self._alias)
            logger.info("Loaded existing collection: %s", self.collection_name)
        else:
            self._create_collection()
            logger.info("Created new collection: %s", self.collection_name)

    def disconnect(self):
        if self.is_connected:
            connections.disconnect(self._alias)
            self.is_connected = False
            logger.info("Disconnected from Milvus")

    def _create_collection(self):
        fields = [
            FieldSchema(name="note_id", dtype=DataType.VARCHAR, max_length=64,
                        is_primary=True, auto_id=False),
            FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR,
                        dim=self.config.embedding_dim),
            FieldSchema(name="note_text", dtype=DataType.VARCHAR, max_length=65535),
            FieldSchema(name="note_subject", dtype=DataType.VARCHAR, max_length=1000),
        ]
        schema = CollectionSchema(fields=fields, description="CMD order note embeddings")
        self.collection = Collection(name=self.collection_name, schema=schema, using=self._alias)
        self._create_index()

    def _create_index(self):
        index_params = {
            "index_type": self.config.milvus_index_type,
            "metric_type": self.config.milvus_metric_type,
            "params": {"nlist": self.config.milvus_nlist},
        }
        try:
            self.collection.create_index(field_name="embedding", index_params=index_params)
            logger.info("Created %s index", self.config.milvus_index_type)
        except Exception as e:
            if "already exist" not in str(e).lower():
                raise

    def load_collection(self):
        if self.collection:
            self.collection.load()
            logger.info("Collection loaded into memory")

    async def insert(
        self,
        note_ids: List[str],
        embeddings: List[List[float]],
        note_texts: List[str],
        note_subjects: List[str],
    ) -> int:
        if not self.collection:
            raise ValueError("Collection not initialized")

        entities = [note_ids, embeddings, note_texts, note_subjects]
        result = await asyncio.to_thread(self.collection.upsert, entities)
        return result.upsert_count

    async def search(
        self,
        query_embedding: List[float],
        top_k: int = 10,
    ) -> List[Dict[str, Any]]:
        if not self.collection:
            raise ValueError("Collection not initialized")

        search_params = {
            "metric_type": self.config.milvus_metric_type,
            "params": {"nprobe": self.config.milvus_nprobe},
        }
        results = await asyncio.to_thread(
            self.collection.search,
            data=[query_embedding],
            anns_field="embedding",
            param=search_params,
            limit=top_k,
            output_fields=["note_id", "note_text", "note_subject"],
        )

        search_results = []
        for hits in results:
            for hit in hits:
                search_results.append({
                    "note_id": hit.entity.get("note_id"),
                    "note_text": hit.entity.get("note_text"),
                    "note_subject": hit.entity.get("note_subject", ""),
                    "distance": hit.distance,
                    "score": hit.score,
                })
        return search_results

    def get_stats(self) -> Dict[str, Any]:
        if not self.collection:
            return {"error": "Collection not initialized"}
        return {
            "collection_name": self.collection_name,
            "num_entities": self.collection.num_entities,
        }
