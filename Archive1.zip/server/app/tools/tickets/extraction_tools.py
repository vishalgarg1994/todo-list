"""
Extraction tools for ticket system
Provides access to extracted note data and discrepancy analysis.
"""
import logging
import asyncio
from typing import Any, Optional
from fastmcp.exceptions import ToolError
from utils.utilities import Helpers
from data_access.cyphers.notes_queries import (
    GET_EXTRACTION_DISCREPANCIES,
    GET_DISCREPANCIES_BY_TICKET,
    GET_DISCREPANCY_STATS,
    GET_TICKETS_BY_EXTRACTED_FAULT,
)


async def get_extraction_discrepancies(
    services: dict,
    ticket_number: Optional[str] = None,
    min_confidence: float = 0.8,
    limit: int = 20
) -> Any:
    """
    Get tickets where extracted values differ from recorded values.
    Shows what AI found in notes vs what's in ServiceNow.

    Returns discrepancies in priority, MTTR, responsible party, and fault type
    with extraction evidence explaining each difference.

    Args:
        services: Service container with memgraph_client
        ticket_number: Optional specific ticket to query (e.g., "INC0012345")
        min_confidence: Minimum confidence threshold (0.0-1.0, default 0.8)
        limit: Maximum results to return (default 20)
    """
    try:
        logging.info(f"FastMCP Tool Call: get_extraction_discrepancies "
                    f"(ticket={ticket_number}, min_confidence={min_confidence})")

        memgraph_client = services.get("memgraph_client")
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        if ticket_number:
            # Query for specific ticket
            result = await memgraph_client.execute(
                GET_DISCREPANCIES_BY_TICKET,
                {"ticket_number": ticket_number}
            )
        else:
            # Query for all discrepancies above confidence threshold
            result = await memgraph_client.execute(
                GET_EXTRACTION_DISCREPANCIES,
                {"min_confidence": min_confidence, "limit": limit}
            )

        records = [record.data() for record in result]

        if not records:
            if ticket_number:
                return {"message": f"No extraction data found for ticket: {ticket_number}"}
            return {"message": f"No discrepancies found with confidence >= {min_confidence}"}

        # Format results for display
        formatted_results = []
        for record in records:
            formatted = {
                "ticket_id": record.get("ticket_id"),
                "confidence": record.get("confidence"),
                "differs": record.get("differs", record.get("differs_from_ticket", False)),
            }

            # Add discrepancy details
            discrepancies = []

            if record.get("extracted_fault") != record.get("original_fault"):
                discrepancies.append({
                    "field": "fault_type",
                    "extracted": record.get("extracted_fault"),
                    "original": record.get("original_fault")
                })

            if record.get("extracted_party") != record.get("original_party"):
                discrepancies.append({
                    "field": "responsible_party",
                    "extracted": record.get("extracted_party"),
                    "original": record.get("original_party")
                })

            if record.get("extracted_priority") != record.get("original_priority"):
                discrepancies.append({
                    "field": "priority",
                    "extracted": record.get("extracted_priority"),
                    "original": record.get("original_priority")
                })

            if record.get("extracted_mttr") != record.get("original_mttr"):
                discrepancies.append({
                    "field": "mttr_minutes",
                    "extracted": record.get("extracted_mttr"),
                    "original": record.get("original_mttr")
                })

            formatted["discrepancies"] = discrepancies
            formatted["evidence"] = record.get("evidence", "")
            formatted["root_cause"] = record.get("root_cause")
            formatted["notes_analyzed"] = record.get("notes_analyzed")

            formatted_results.append(formatted)

        return Helpers.recursive_serialize({
            "ticket_number": ticket_number,
            "min_confidence": min_confidence,
            "discrepancy_count": len(formatted_results),
            "discrepancies": formatted_results
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_extraction_discrepancies: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve extraction discrepancies: {e}")


async def get_discrepancy_statistics(
    services: dict,
    min_confidence: float = 0.7
) -> Any:
    """
    Get summary statistics on extraction discrepancies.

    Returns total audited, discrepancy count, and breakdown by field type.

    Args:
        services: Service container with memgraph_client
        min_confidence: Minimum confidence threshold for stats (default 0.7)
    """
    try:
        logging.info(f"FastMCP Tool Call: get_discrepancy_statistics (min_confidence={min_confidence})")

        memgraph_client = services.get("memgraph_client")
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        result = await memgraph_client.execute(
            GET_DISCREPANCY_STATS,
            {"min_confidence": min_confidence}
        )

        records = [record.data() for record in result]

        if not records:
            return {"message": "No extraction statistics available"}

        stats = records[0]

        total_audited = stats.get("total_audited", 0)
        discrepancy_count = stats.get("discrepancy_count", 0)
        discrepancy_rate = (discrepancy_count / total_audited * 100) if total_audited > 0 else 0

        return Helpers.recursive_serialize({
            "min_confidence": min_confidence,
            "total_tickets_audited": total_audited,
            "tickets_with_discrepancies": discrepancy_count,
            "discrepancy_rate_percent": round(discrepancy_rate, 1),
            "average_confidence": round(stats.get("avg_confidence", 0), 2),
            "breakdown": {
                "fault_type_mismatches": stats.get("fault_type_mismatches", 0),
                "responsible_party_mismatches": stats.get("party_mismatches", 0),
                "priority_mismatches": stats.get("priority_mismatches", 0)
            }
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_discrepancy_statistics: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve discrepancy statistics: {e}")


async def get_tickets_by_extracted_fault_type(
    services: dict,
    fault_type: str,
    min_confidence: float = 0.8,
    limit: int = 50
) -> Any:
    """
    Get tickets where AI extracted a specific fault type from notes.

    Useful for finding tickets with specific fault patterns regardless
    of how they were originally categorized.

    Args:
        services: Service container with memgraph_client
        fault_type: Fault type to search for (HardDown, PacketLoss, Latency, etc.)
        min_confidence: Minimum confidence threshold (default 0.8)
        limit: Maximum results to return (default 50)
    """
    try:
        logging.info(f"FastMCP Tool Call: get_tickets_by_extracted_fault_type "
                    f"(fault_type={fault_type}, min_confidence={min_confidence})")

        memgraph_client = services.get("memgraph_client")
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        result = await memgraph_client.execute(
            GET_TICKETS_BY_EXTRACTED_FAULT,
            {"fault_type": fault_type, "min_confidence": min_confidence, "limit": limit}
        )

        records = [record.data() for record in result]

        if not records:
            return {"message": f"No tickets found with extracted fault type: {fault_type}"}

        return Helpers.recursive_serialize({
            "fault_type": fault_type,
            "min_confidence": min_confidence,
            "ticket_count": len(records),
            "tickets": records
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_tickets_by_extracted_fault_type: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve tickets by fault type: {e}")


async def get_ticket_audit(
    services: dict,
    ticket_id: str
) -> Any:
    """
    Get audit comparison for a ticket: original values vs AI-suggested values.

    Shows what was recorded in ServiceNow vs what the AI extracted from notes.
    Does NOT trigger LLM processing - just retrieves existing NoteInfo.

    Args:
        services: Service container with memgraph_client
        ticket_id: Ticket number (e.g., "INC0012345" or "CS0067890")
    """
    try:
        logging.info(f"FastMCP Tool Call: get_ticket_audit (ticket_id={ticket_id})")

        memgraph_client = services.get("memgraph_client")
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Query ticket, Outage_Info, Fault, Service, and NoteInfo
        query = """
        MATCH (t:Ticket {ticket_id: $ticket_id})
        OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
        OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
        OPTIONAL MATCH (t)-[:HAS_SERVICE]->(s:Service)
        OPTIONAL MATCH (t)-[:HAS_NOTES]->(n:NoteInfo)
        RETURN t.ticket_id AS ticket_id,
               t.ticket_sys_id AS ticket_sys_id,
               t.ticket_type AS ticket_type,
               t.ticket_status AS ticket_status,
               f.short_description AS short_description,
               // Original values (from ticket, outage_info, fault, service)
               t.priority AS original_priority,
               s.subcategory AS original_fault_type,
               t.responsible_party AS original_responsible_party,
               o.mttr AS original_mttr,
               t.resolution_code AS original_resolution_code,
               o.resolution AS original_resolution_notes,
               o.customer_resolution AS original_customer_resolution,
               COALESCE(o.rfo, f.rfo) AS original_rfo,
               s.service_restored_date AS original_actual_end_date,
               // Suggested values (from NoteInfo)
               n.priority AS suggested_priority,
               n.fault_type AS suggested_fault_type,
               n.responsible_party AS suggested_responsible_party,
               n.mttr_minutes AS suggested_mttr,
               n.root_cause AS suggested_root_cause,
               n.rfo AS suggested_rfo,
               n.suggested_resolution_notes AS suggested_resolution_notes,
               n.suggested_internal_notes AS suggested_internal_notes,
               n.suggested_actual_end_date AS suggested_actual_end_date,
               // Per-field evidence (why AI suggested each value)
               n.evidence_priority AS evidence_priority,
               n.evidence_fault_type AS evidence_fault_type,
               n.evidence_responsible_party AS evidence_responsible_party,
               n.evidence_mttr AS evidence_mttr,
               // Audit metadata
               n.confidence AS confidence,
               n.differs_from_ticket AS differs_from_ticket,
               n.notes_analyzed AS notes_analyzed,
               n.emails_analyzed AS emails_analyzed,
               n.field_changes_analyzed AS field_changes_analyzed,
               n.processed_at AS processed_at
        """
        result = await memgraph_client.execute(query, {"ticket_id": ticket_id})
        records = [record.data() for record in result]

        if not records:
            return {"error": f"Ticket not found: {ticket_id}"}

        record = records[0]

        # Check if NoteInfo exists
        if record.get("confidence") is None:
            return {
                "ticket_id": ticket_id,
                "status": "not_processed",
                "message": "No NoteInfo found. Ticket has not been processed by the pipeline yet."
            }

        # Build comparison response
        root_cause = record.get("suggested_root_cause") or ""

        response = {
            "ticket_id": ticket_id,
            "ticket_sys_id": record.get("ticket_sys_id"),
            "ticket_type": record.get("ticket_type"),
            "ticket_status": record.get("ticket_status"),
            "short_description": record.get("short_description"),
            "confidence": record.get("confidence"),
            "root_cause": root_cause,
            "original_values": {
                "priority": record.get("original_priority"),
                "fault_type": record.get("original_fault_type"),
                "responsible_party": record.get("original_responsible_party"),
                "mttr_minutes": record.get("original_mttr"),
                "resolution_code": record.get("original_resolution_code"),
                "rfo": record.get("original_rfo"),
                "actual_end_date": record.get("original_actual_end_date"),
                "resolution_notes": record.get("original_resolution_notes"),
            },
            "suggested_values": {
                "priority": record.get("suggested_priority"),
                "fault_type": record.get("suggested_fault_type"),
                "responsible_party": record.get("suggested_responsible_party"),
                "mttr_minutes": record.get("suggested_mttr"),
                "root_cause": record.get("suggested_root_cause"),
                "rfo": record.get("suggested_rfo"),
                "actual_end_date": record.get("suggested_actual_end_date"),
                "resolution_notes": record.get("suggested_resolution_notes"),
                "internal_notes": record.get("suggested_internal_notes"),
            },
            "audit_metadata": {
                "notes_analyzed": record.get("notes_analyzed"),
                "emails_analyzed": record.get("emails_analyzed"),
                "field_changes_analyzed": record.get("field_changes_analyzed"),
                "processed_at": record.get("processed_at"),
            }
        }

        # Build discrepancies list with per-field evidence
        discrepancies = []
        orig = response["original_values"]
        sugg = response["suggested_values"]

        if orig["priority"] != sugg["priority"] and sugg["priority"] is not None:
            discrepancies.append({
                "field": "priority",
                "original": orig["priority"],
                "suggested": sugg["priority"],
                "evidence": record.get("evidence_priority") or "No evidence available"
            })
        if orig["fault_type"] != sugg["fault_type"] and sugg["fault_type"] is not None:
            discrepancies.append({
                "field": "fault_type",
                "original": orig["fault_type"],
                "suggested": sugg["fault_type"],
                "evidence": record.get("evidence_fault_type") or "No evidence available"
            })
        if orig["responsible_party"] != sugg["responsible_party"] and sugg["responsible_party"] is not None:
            discrepancies.append({
                "field": "responsible_party",
                "original": orig["responsible_party"],
                "suggested": sugg["responsible_party"],
                "evidence": record.get("evidence_responsible_party") or "No evidence available"
            })
        if orig["mttr_minutes"] != sugg["mttr_minutes"] and sugg["mttr_minutes"] is not None:
            discrepancies.append({
                "field": "mttr_minutes",
                "original": orig["mttr_minutes"],
                "suggested": sugg["mttr_minutes"],
                "evidence": record.get("evidence_mttr") or "No evidence available"
            })

        response["discrepancies"] = discrepancies
        response["has_discrepancies"] = len(discrepancies) > 0

        # Fetch fault description summary and ticket summary in parallel
        semantic_search_service = services.get("semantic_search_service")
        milvus_notes_client = services.get("milvus_notes_client")
        ticket_sys_id = record.get("ticket_sys_id")

        async def _fetch_fault_summary():
            if semantic_search_service and semantic_search_service.milvus_client:
                try:
                    fault_data = await semantic_search_service.milvus_client.get_vector_by_id(ticket_id)
                    if fault_data:
                        return fault_data.get("fault_description_summary", "")
                except Exception as e:
                    logging.warning(f"Could not fetch fault description summary: {e}")
            return None

        async def _fetch_ticket_summary():
            if milvus_notes_client and ticket_sys_id:
                try:
                    summary_result = await milvus_notes_client.get_by_ticket_id(ticket_sys_id)
                    if summary_result:
                        return summary_result.get("summary_text")
                    else:
                        logging.warning(f"No summary found in Milvus for ticket_sys_id: {ticket_sys_id}")
                except Exception as e:
                    logging.warning(f"Could not fetch summary from Milvus: {e}")
            return None

        fault_summary, ticket_summary = await asyncio.gather(
            _fetch_fault_summary(), _fetch_ticket_summary()
        )
        response["fault_description_summary"] = fault_summary
        response["ticket_summary"] = ticket_summary

        return Helpers.recursive_serialize(response)

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_ticket_audit: {e}", exc_info=True)
        raise ToolError(f"Failed to get ticket audit: {e}")
