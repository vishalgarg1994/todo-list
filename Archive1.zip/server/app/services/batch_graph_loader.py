"""
Batch Graph Loader for Memgraph
Uses UNWIND for efficient bulk operations instead of individual queries
"""
import logging
import asyncio
from typing import Dict, Any, List, Optional
from neo4j.exceptions import TransientError
from data_access.memgraphClient import MemgraphClient


def normalize_enum_value(value: Optional[str]) -> Optional[str]:
    """Normalize enum values to lowercase for consistent querying.

    This helps the LLM generate correct Cypher queries regardless of
    how users phrase their questions (e.g., 'pending', 'Pending', 'PENDING').
    """
    if value is None:
        return None
    return value.lower()


class BatchGraphLoader:
    """Efficient batch loading using Cypher UNWIND operations"""

    def __init__(self, memgraph_client: MemgraphClient):
        self.memgraphClient = memgraph_client
        self.logger = logging.getLogger(__name__)
        self.max_retries = 5  # Increased from 3 for extra safety with higher concurrency
        self.base_delay = 0.1  # 100ms base delay

    async def _execute_with_retry(self, query: str, params: Dict[str, Any] = None):
        """Execute query with exponential backoff retry for transient errors"""
        for attempt in range(self.max_retries):
            try:
                return await self.memgraphClient.execute(query, params)
            except TransientError as e:
                if attempt == self.max_retries - 1:
                    raise  # Last attempt, re-raise
                delay = self.base_delay * (2 ** attempt)  # Exponential backoff
                self.logger.warning(f"⚠️  Transient error, retrying in {delay}s (attempt {attempt + 1}/{self.max_retries})")
                await asyncio.sleep(delay)
            except Exception as e:
                # Non-transient errors, fail immediately
                raise

    async def load_client_node(self, client_info: Dict[str, Any], noc_info: Dict[str, Any]) -> bool:
        """Load single client node (usually only one per message)"""
        cl_id = client_info.get("cl_id")
        if not cl_id:
            self.logger.error("❌ No client ID found")
            return False

        try:
            await self._execute_with_retry(
                """
                MERGE (c:Client {cl_id: $cl_id})
                SET
                    c.client_id = $client_id,
                    c.client_name = $client_name,
                    c.client_group = $client_group,
                    c.client_tier = $client_tier,
                    c.channel = $channel,
                    c.sales_division = $sales_division,
                    c.market_segment = $market_segment,
                    c.client_import_source = $client_import_source,
                    c.client_ticket = $client_ticket,
                    c.default_noc = $default_noc,
                    c.default_noc_queue = $default_noc_queue,
                    c.incident_manager = $incident_manager,
                    c.service_manager = $service_manager,
                    c.operations_specialist = $operations_specialist,
                    c.operations_specialist_sys_id = $operations_specialist_sys_id
                """,
                {
                    "cl_id": cl_id,
                    "client_id": client_info.get("client_id"),
                    "client_name": client_info.get("client_name"),
                    "client_group": client_info.get("client_group"),
                    "client_tier": client_info.get("client_tier"),
                    "channel": client_info.get("channel"),
                    "sales_division": client_info.get("sales_division"),
                    "market_segment": client_info.get("market_segment"),
                    "client_import_source": client_info.get("client_import_source"),
                    "client_ticket": client_info.get("client_ticket"),
                    "default_noc": noc_info.get("default_noc"),
                    "default_noc_queue": noc_info.get("default_noc_queue"),
                    "incident_manager": client_info.get("incident_manager"),
                    "service_manager": client_info.get("service_manager"),
                    "operations_specialist": client_info.get("operations_specialist"),
                    "operations_specialist_sys_id": client_info.get("operations_specialist_sys_id")
                }
            )
            self.logger.debug("✅ Created client node")
            return True
        except Exception as e:
            self.logger.error(f"❌ Failed to create client node: {e}")
            return False

    async def batch_load_services(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load Service nodes using UNWIND"""
        services = []
        for op_status in operational_status:
            service_entity = op_status.get("service_entity", {})
            svc_id = service_entity.get("svc_id")
            if svc_id:
                services.append({
                    "svc_id": svc_id,
                    "subcategory": service_entity.get("subcategory"),
                    "technology": service_entity.get("technology"),
                    "service_restored_date": service_entity.get("service_restored_date"),
                    "related_circuit_id": service_entity.get("related_circuit_id", 0)
                })

        if not services:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $services AS svc
                MERGE (s:Service {svc_id: svc.svc_id})
                SET
                    s.subcategory = svc.subcategory,
                    s.technology = svc.technology,
                    s.service_restored_date = svc.service_restored_date,
                    s.related_circuit_id = svc.related_circuit_id
                """,
                {"services": services}
            )
            self.logger.debug(f"✅ Batch loaded {len(services)} Service nodes")
            return len(services)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load services: {e}")
            return 0

    async def batch_load_faults(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load Fault nodes using UNWIND (renamed from Incident, uses fault_info)"""
        faults = []
        for op_status in operational_status:
            fault_info = op_status.get("fault_info", {})
            # Generate fault_id from ticket_sys_id
            ticket_sys_id = op_status.get("ticket_sys_id")
            if ticket_sys_id and fault_info:
                faults.append({
                    "fault_id": f"fault_{ticket_sys_id}",
                    "short_description": fault_info.get("short_description"),
                    "fault_occured_date": fault_info.get("fault_occured_date"),
                    "is_customer_impacting": fault_info.get("is_customer_impacting", False),
                    "rfo": fault_info.get("rfo"),
                    "ticket_rfo_group": fault_info.get("ticket_rfo_group")
                })

        if not faults:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $faults AS f
                MERGE (fault:Fault {fault_id: f.fault_id})
                SET
                    fault.short_description = f.short_description,
                    fault.fault_occured_date = f.fault_occured_date,
                    fault.is_customer_impacting = f.is_customer_impacting,
                    fault.rfo = f.rfo,
                    fault.ticket_rfo_group = f.ticket_rfo_group
                """,
                {"faults": faults}
            )
            self.logger.debug(f"✅ Batch loaded {len(faults)} Fault nodes")
            return len(faults)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load faults: {e}")
            return 0

    # Keep old method for backward compatibility
    async def batch_load_incidents(self, operational_status: List[Dict[str, Any]]) -> int:
        """DEPRECATED: Use batch_load_faults instead. Kept for backward compatibility."""
        return await self.batch_load_faults(operational_status)

    async def batch_load_tickets(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load Ticket nodes using UNWIND"""
        tickets = []
        for op_status in operational_status:
            ticket_info = op_status.get("ticket_info", {})
            # Use ticket_sys_id as primary key (TSM model), fallback to tkt_id for backward compat
            ticket_sys_id = op_status.get("ticket_sys_id")
            tkt_id = ticket_info.get("tkt_id") or ticket_sys_id
            if not tkt_id:
                continue

            # Extract service_desk_engineer and tier2_engineer from users array
            users = op_status.get("users", [])
            service_desk_engineer = None
            tier2_engineer = None
            for user in users:
                if user.get("role") == "service_desk_engineer":
                    service_desk_engineer = user.get("name")
                elif user.get("role") == "tier2_engineer":
                    tier2_engineer = user.get("name")

            # Extract entity-specific fields (CI, resolution, etc.)
            ticket_type = op_status.get("ticket_type")
            ci_sys_id = None
            ci_name = None
            circuit_id = None
            responsible_party = None
            internal_resolution_notes = None
            resolution_code = None
            resolved_at = None
            caused_by_change_sys_id = None
            # FK reference fields (for reconciliation) + classification fields
            subcategory = None
            service_type = None
            incident_number = None
            problem_number = None
            case_number = None
            parent_incident_number = None
            related_problem_number = None
            case_type = None
            major_incident_state = None

            if ticket_type == "incident":
                inc_fields = op_status.get("incident_fields", {}) or {}
                ci_sys_id = inc_fields.get("ci_sys_id")
                ci_name = inc_fields.get("ci_name")
                circuit_id = inc_fields.get("circuit_id")
                responsible_party = inc_fields.get("responsible_party")
                internal_resolution_notes = inc_fields.get("internal_resolution_notes")
                resolution_code = inc_fields.get("close_code")  # Incidents use close_code in SNOW
                resolved_at = inc_fields.get("resolved_at")
                caused_by_change_sys_id = inc_fields.get("caused_by_change_sys_id")
                subcategory = inc_fields.get("subcategory")
                major_incident_state = inc_fields.get("major_incident_state")
                parent_incident_number = inc_fields.get("parent_incident_number") or inc_fields.get("related_parent_incident_number")
                related_problem_number = inc_fields.get("related_problem_number")
            elif ticket_type == "case":
                case_fields = op_status.get("case_fields", {}) or {}
                ci_sys_id = case_fields.get("ci_sys_id")
                ci_name = case_fields.get("ci_name")
                circuit_id = case_fields.get("circuit_id")
                responsible_party = case_fields.get("responsible_party")
                internal_resolution_notes = case_fields.get("internal_resolution_notes")
                resolution_code = case_fields.get("resolution_code")  # Cases use resolution_code in SNOW
                caused_by_change_sys_id = case_fields.get("caused_by_change_sys_id")
                subcategory = case_fields.get("subcategory")
                case_type = case_fields.get("case_type")
                incident_number = case_fields.get("incident_number")
                problem_number = case_fields.get("problem_number")
            elif ticket_type == "problem":
                prob_fields = op_status.get("problem_fields", {}) or {}
                ci_sys_id = prob_fields.get("ci_sys_id")
                ci_name = prob_fields.get("ci_name")
                circuit_id = prob_fields.get("circuit_id")
                responsible_party = prob_fields.get("responsible_party")
                resolution_code = prob_fields.get("resolution_code")
                subcategory = prob_fields.get("subcategory")
                service_type = prob_fields.get("service_type")
            elif ticket_type == "request":
                req_fields = op_status.get("request_fields", {}) or {}
                case_number = req_fields.get("case_number")

            tickets.append({
                "tkt_id": tkt_id,
                # NEW: TSM fields
                "ticket_sys_id": ticket_sys_id,
                "ticket_type": normalize_enum_value(op_status.get("ticket_type")),  # incident, case, problem, request
                # Existing fields
                "ticket_source": ticket_info.get("ticket_source"),
                "ticket_id": ticket_info.get("ticket_id"),
                "ticket_category": normalize_enum_value(ticket_info.get("ticket_category")),
                "ticket_queue": ticket_info.get("ticket_queue"),
                "ticket_status": normalize_enum_value(ticket_info.get("ticket_status")),
                "ticket_substatus": normalize_enum_value(ticket_info.get("ticket_substatus")),
                "is_master_ticket": ticket_info.get("is_master_ticket", False),
                "master_ticket_id": ticket_info.get("master_ticket_id"),
                "created_by": ticket_info.get("created_by"),
                "created_on": ticket_info.get("created_on"),
                "closed_on": ticket_info.get("closed_on"),
                "source_system": ticket_info.get("source_system"),
                "priority": ticket_info.get("priority", 0),
                "type": ticket_info.get("type"),
                "linked_ticket_id": ticket_info.get("linked_ticket_id"),
                "ticket_import_source": ticket_info.get("ticket_import_source"),
                "ticket_escalation_level": ticket_info.get("ticket_escalation_level", 0),
                "next_action": ticket_info.get("next_action"),
                "next_action_date": ticket_info.get("next_action_date"),
                "next_action_date_notification_counter": ticket_info.get("next_action_date_notification_counter", 0),
                "updated_on": ticket_info.get("updated_on"),
                "closed_by": ticket_info.get("closed_by"),
                "closed_by_id": ticket_info.get("closed_by_id"),
                "assigned_to": ticket_info.get("assigned_to"),
                "assigned_to_id": ticket_info.get("assigned_to_id"),
                "first_assigned_to": ticket_info.get("first_assigned_to"),
                "first_assigned_on": ticket_info.get("first_assigned_on"),
                "first_resolved_on": ticket_info.get("first_resolved_on"),
                "oldest_resolved_date": ticket_info.get("oldest_resolved_date"),
                "first_child_ticket_created_on": ticket_info.get("first_child_ticket_created_on"),
                "service_desk_engineer": service_desk_engineer,
                "tier2_engineer": tier2_engineer,
                # Entity-specific fields (from incident_fields/case_fields)
                "ci_sys_id": ci_sys_id,
                "ci_name": ci_name,
                "circuit_id": circuit_id,
                "responsible_party": responsible_party,
                "internal_resolution_notes": internal_resolution_notes,
                "resolution_code": resolution_code,
                "resolved_at": resolved_at,
                "caused_by_change_sys_id": caused_by_change_sys_id,
                # FK reference fields (for reconciliation)
                "subcategory": subcategory,
                "service_type": service_type,
                "incident_number": incident_number,
                "problem_number": problem_number,
                "case_number": case_number,
                "parent_incident_number": parent_incident_number,
                "related_problem_number": related_problem_number,
                # Classification fields
                "case_type": case_type,
                "major_incident_state": major_incident_state,
            })

        if not tickets:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $tickets AS tkt
                MERGE (t:Ticket {tkt_id: tkt.tkt_id})
                SET
                    t.ticket_sys_id = tkt.ticket_sys_id,
                    t.ticket_type = tkt.ticket_type,
                    t.ticket_source = tkt.ticket_source,
                    t.ticket_id = tkt.ticket_id,
                    t.ticket_category = tkt.ticket_category,
                    t.ticket_queue = tkt.ticket_queue,
                    t.ticket_status = tkt.ticket_status,
                    t.ticket_substatus = tkt.ticket_substatus,
                    t.is_master_ticket = tkt.is_master_ticket,
                    t.master_ticket_id = tkt.master_ticket_id,
                    t.created_by = tkt.created_by,
                    t.created_on = tkt.created_on,
                    t.closed_on = tkt.closed_on,
                    t.source_system = tkt.source_system,
                    t.priority = tkt.priority,
                    t.type = tkt.type,
                    t.linked_ticket_id = tkt.linked_ticket_id,
                    t.ticket_import_source = tkt.ticket_import_source,
                    t.ticket_escalation_level = tkt.ticket_escalation_level,
                    t.next_action = tkt.next_action,
                    t.next_action_date = tkt.next_action_date,
                    t.next_action_date_notification_counter = tkt.next_action_date_notification_counter,
                    t.updated_on = tkt.updated_on,
                    t.closed_by = tkt.closed_by,
                    t.closed_by_id = tkt.closed_by_id,
                    t.assigned_to = tkt.assigned_to,
                    t.assigned_to_id = tkt.assigned_to_id,
                    t.first_assigned_to = tkt.first_assigned_to,
                    t.first_assigned_on = tkt.first_assigned_on,
                    t.first_resolved_on = tkt.first_resolved_on,
                    t.oldest_resolved_date = tkt.oldest_resolved_date,
                    t.first_child_ticket_created_on = tkt.first_child_ticket_created_on,
                    t.service_desk_engineer = tkt.service_desk_engineer,
                    t.tier2_engineer = tkt.tier2_engineer,
                    t.ci_sys_id = tkt.ci_sys_id,
                    t.ci_name = tkt.ci_name,
                    t.circuit_id = tkt.circuit_id,
                    t.responsible_party = tkt.responsible_party,
                    t.internal_resolution_notes = tkt.internal_resolution_notes,
                    t.resolution_code = tkt.resolution_code,
                    t.resolved_at = tkt.resolved_at,
                    t.caused_by_change_sys_id = tkt.caused_by_change_sys_id,
                    t.subcategory = tkt.subcategory,
                    t.service_type = tkt.service_type,
                    t.incident_number = tkt.incident_number,
                    t.problem_number = tkt.problem_number,
                    t.case_number = tkt.case_number,
                    t.parent_incident_number = tkt.parent_incident_number,
                    t.related_problem_number = tkt.related_problem_number,
                    t.case_type = tkt.case_type,
                    t.major_incident_state = tkt.major_incident_state
                """,
                {"tickets": tickets}
            )
            self.logger.debug(f"✅ Batch loaded {len(tickets)} Ticket nodes")
            return len(tickets)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load tickets: {e}")
            return 0

    async def batch_load_tasks(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load Task nodes using UNWIND (TSM tasks)

        Supports all task types:
        - task (TASK*): Incident tasks
        - cstask (CSTASK*): Case tasks
        - ptask (PTASK*): Problem tasks
        - ctask (CTASK*): Change tasks
        """
        tasks = []
        for op_status in operational_status:
            ticket_tasks = op_status.get("tasks", [])
            if not ticket_tasks:
                continue
            for task in ticket_tasks:
                task_sys_id = task.get("task_sys_id")
                if task_sys_id:
                    tasks.append({
                        # Common fields (all task types)
                        "task_sys_id": task_sys_id,
                        "task_number": task.get("task_number"),
                        "task_state": task.get("task_state") or task.get("state"),  # CaseTaskInfo uses 'state'
                        "task_type": task.get("task_type"),
                        "short_description": task.get("short_description"),
                        "priority": task.get("priority", 0),
                        "assigned_to": task.get("assigned_to"),
                        "assigned_to_sys_id": task.get("assigned_to_sys_id"),
                        "assignment_group": task.get("assignment_group"),
                        # Lifecycle fields
                        "created_on": task.get("created_on"),
                        "created_by": task.get("created_by"),
                        "updated_on": task.get("updated_on"),
                        "closed_on": task.get("closed_on"),
                        "closed_by": task.get("closed_by"),
                        "closed_by_sys_id": task.get("closed_by_sys_id"),
                        # Incident task fields (task_type="task")
                        "closure_code": task.get("closure_code"),
                        # Problem task fields (task_type="ptask")
                        "close_notes": task.get("close_notes"),
                        "cause_code": task.get("cause_code"),
                        "cause_notes": task.get("cause_notes"),
                        "is_pending": task.get("is_pending", False),
                        "started_on": task.get("started_on"),
                        # Case task fields (task_type="cstask")
                        "parent_case_sys_id": task.get("parent_case_sys_id"),
                        "parent_case_number": task.get("parent_case_number"),
                        "service_type": task.get("service_type"),
                        "third_party_sys_id": task.get("third_party_sys_id"),
                        "third_party_score": task.get("third_party_score"),
                        "vendor_name": task.get("vendor_name"),
                        # Shared third party fields (incident + case tasks)
                        "third_party_name": task.get("third_party_name"),
                        "third_party_ticket": task.get("third_party_ticket"),
                        "vendor_id": task.get("vendor_id"),
                        # Change task fields (task_type="ctask")
                        "change_sys_id": task.get("change_sys_id"),
                        "change_number": task.get("change_number"),
                        "change_category": task.get("change_category"),
                        "change_subcategory": task.get("change_subcategory"),
                        "fulfillment": task.get("fulfillment", False),
                        "follow_up_needed": task.get("follow_up_needed", False),
                        "implemented_in_timeframe": task.get("implemented_in_timeframe"),
                        "unexpected_consequences": task.get("unexpected_consequences", False),
                        "closure_responsibility": task.get("closure_responsibility"),
                        "responsible_team": task.get("responsible_team"),
                    })

        if not tasks:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $tasks AS t
                MERGE (task:Task {task_sys_id: t.task_sys_id})
                SET
                    // Common fields
                    task.task_number = t.task_number,
                    task.task_state = t.task_state,
                    task.task_type = t.task_type,
                    task.short_description = t.short_description,
                    task.priority = t.priority,
                    task.assigned_to = t.assigned_to,
                    task.assigned_to_sys_id = t.assigned_to_sys_id,
                    task.assignment_group = t.assignment_group,
                    // Lifecycle fields
                    task.created_on = t.created_on,
                    task.created_by = t.created_by,
                    task.updated_on = t.updated_on,
                    task.closed_on = t.closed_on,
                    task.closed_by = t.closed_by,
                    task.closed_by_sys_id = t.closed_by_sys_id,
                    // Incident task fields
                    task.closure_code = t.closure_code,
                    // Problem task fields
                    task.close_notes = t.close_notes,
                    task.cause_code = t.cause_code,
                    task.cause_notes = t.cause_notes,
                    task.is_pending = t.is_pending,
                    task.started_on = t.started_on,
                    // Case task fields
                    task.parent_case_sys_id = t.parent_case_sys_id,
                    task.parent_case_number = t.parent_case_number,
                    task.service_type = t.service_type,
                    task.third_party_sys_id = t.third_party_sys_id,
                    task.third_party_score = t.third_party_score,
                    task.vendor_name = t.vendor_name,
                    // Shared third party fields
                    task.third_party_name = t.third_party_name,
                    task.third_party_ticket = t.third_party_ticket,
                    task.vendor_id = t.vendor_id,
                    // Change task fields
                    task.change_sys_id = t.change_sys_id,
                    task.change_number = t.change_number,
                    task.change_category = t.change_category,
                    task.change_subcategory = t.change_subcategory,
                    task.fulfillment = t.fulfillment,
                    task.follow_up_needed = t.follow_up_needed,
                    task.implemented_in_timeframe = t.implemented_in_timeframe,
                    task.unexpected_consequences = t.unexpected_consequences,
                    task.closure_responsibility = t.closure_responsibility,
                    task.responsible_team = t.responsible_team
                """,
                {"tasks": tasks}
            )
            self.logger.debug(f"✅ Batch loaded {len(tasks)} Task nodes")
            return len(tasks)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load tasks: {e}")
            return 0

    async def batch_load_outage_info(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load Outage_Info nodes using UNWIND"""
        outages = []
        for op_status in operational_status:
            outage_info = op_status.get("outage_info", {})
            oi_id = outage_info.get("oi_id")
            if oi_id:
                outages.append({
                    "oi_id": oi_id,
                    "customer_resolution": outage_info.get("customer_resolution"),
                    "resolution": outage_info.get("resolution"),
                    "rfo": outage_info.get("rfo"),
                    "outage_total": outage_info.get("outage_total", 0),
                    "outage_duration": outage_info.get("outage_duration"),
                    "internal_mttr": outage_info.get("internal_mttr"),
                    "mttr": outage_info.get("mttr", 0),
                    "problem_type": outage_info.get("problem_type"),
                    "ticket_rfo_group": outage_info.get("ticket_rfo_group"),
                    "is_worked_ticket": outage_info.get("is_worked_ticket", False),
                    "closure_quality": outage_info.get("closure_quality"),
                    "first_email_from_customer_on": outage_info.get("first_email_from_customer_on"),
                    "first_customer_note_on": outage_info.get("first_customer_note_on"),
                    "first_supplier_dispatch_event_on": outage_info.get("first_supplier_dispatch_event_on"),
                    "first_tech_dispatch_event_on": outage_info.get("first_tech_dispatch_event_on")
                })

        if not outages:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $outages AS oi
                MERGE (o:Outage_Info {oi_id: oi.oi_id})
                SET
                    o.customer_resolution = oi.customer_resolution,
                    o.resolution = oi.resolution,
                    o.rfo = oi.rfo,
                    o.outage_total = oi.outage_total,
                    o.outage_duration = oi.outage_duration,
                    o.internal_mttr = oi.internal_mttr,
                    o.mttr = oi.mttr,
                    o.problem_type = oi.problem_type,
                    o.ticket_rfo_group = oi.ticket_rfo_group,
                    o.is_worked_ticket = oi.is_worked_ticket,
                    o.closure_quality = oi.closure_quality,
                    o.first_email_from_customer_on = oi.first_email_from_customer_on,
                    o.first_customer_note_on = oi.first_customer_note_on,
                    o.first_supplier_dispatch_event_on = oi.first_supplier_dispatch_event_on,
                    o.first_tech_dispatch_event_on = oi.first_tech_dispatch_event_on
                """,
                {"outages": outages}
            )
            self.logger.debug(f"✅ Batch loaded {len(outages)} Outage_Info nodes")
            return len(outages)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load outages: {e}")
            return 0

    async def batch_load_users(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load UserInfo nodes using UNWIND"""
        users_map = {}  # user_id -> name (dedup)

        for op_status in operational_status:
            # Users from users array
            users = op_status.get("users", [])
            for user in users:
                user_id = user.get("user_id")
                if user_id:
                    users_map[user_id] = user.get("name")

            # Lifecycle users
            ticket_info = op_status.get("ticket_info", {})
            if ticket_info.get("assigned_to_id"):
                users_map[ticket_info["assigned_to_id"]] = ticket_info.get("assigned_to")
            if ticket_info.get("closed_by_id"):
                users_map[ticket_info["closed_by_id"]] = ticket_info.get("closed_by")

        if not users_map:
            return 0

        users_batch = [{"user_id": uid, "name": name} for uid, name in users_map.items()]

        try:
            await self._execute_with_retry(
                """
                UNWIND $users AS u
                MERGE (user:UserInfo {user_id: u.user_id})
                SET user.name = u.name
                """,
                {"users": users_batch}
            )
            self.logger.debug(f"✅ Batch loaded {len(users_batch)} UserInfo nodes")
            return len(users_batch)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load users: {e}")
            return 0

    async def batch_load_contacts(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load ContactInfo nodes using UNWIND"""
        contacts_map = {}  # contact_id -> contact_data (dedup)

        for op_status in operational_status:
            contacts = op_status.get("contacts", [])
            for contact in contacts:
                contact_id = contact.get("contact_id")
                if contact_id:
                    contacts_map[contact_id] = {
                        "contact_id": contact_id,
                        "name": contact.get("name"),
                        "email": contact.get("email"),
                        "phone": contact.get("phone"),
                        "contact_type": contact.get("contact_type")
                    }

        if not contacts_map:
            return 0

        contacts_batch = list(contacts_map.values())

        try:
            await self._execute_with_retry(
                """
                UNWIND $contacts AS c
                MERGE (contact:ContactInfo {contact_id: c.contact_id})
                SET
                    contact.name = c.name,
                    contact.email = c.email,
                    contact.phone = c.phone,
                    contact.contact_type = c.contact_type
                """,
                {"contacts": contacts_batch}
            )
            self.logger.debug(f"✅ Batch loaded {len(contacts_batch)} ContactInfo nodes")
            return len(contacts_batch)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load contacts: {e}")
            return 0

    async def batch_load_vendors(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load VendorInfo nodes using UNWIND"""
        vendors_map = {}  # vendor_id -> vendor_data (dedup)

        for op_status in operational_status:
            vendors = op_status.get("vendors", [])
            for vendor in vendors:
                vendor_id = vendor.get("vendor_id")
                if vendor_id:
                    vendors_map[vendor_id] = {
                        "vendor_id": vendor_id,
                        "vendor": vendor.get("vendor"),
                        "vendor_downtime": vendor.get("vendor_downtime", 0.0)
                    }

        if not vendors_map:
            return 0

        vendors_batch = list(vendors_map.values())

        try:
            await self._execute_with_retry(
                """
                UNWIND $vendors AS v
                MERGE (vendor:VendorInfo {vendor_id: v.vendor_id})
                SET
                    vendor.vendor = v.vendor,
                    vendor.vendor_downtime = v.vendor_downtime
                """,
                {"vendors": vendors_batch}
            )
            self.logger.debug(f"✅ Batch loaded {len(vendors_batch)} VendorInfo nodes")
            return len(vendors_batch)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load vendors: {e}")
            return 0

    async def batch_load_maintenance_windows(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load MaintenanceWindow nodes using UNWIND"""
        mw_list = []

        for op_status in operational_status:
            tkt_id = op_status.get("ticket_info", {}).get("tkt_id")
            mw = op_status.get("maintenance_window")
            if tkt_id and mw:
                mw_list.append({
                    "mw_id": f"mw_{tkt_id}",
                    "pw_start": mw.get("pw_start"),
                    "pw_end": mw.get("pw_end"),
                    "pw_duration": mw.get("pw_duration"),
                    "pw_location": mw.get("pw_location"),
                    "pw_reason": mw.get("pw_reason")
                })

        if not mw_list:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $mws AS mw
                MERGE (m:MaintenanceWindow {mw_id: mw.mw_id})
                SET
                    m.pw_start = mw.pw_start,
                    m.pw_end = mw.pw_end,
                    m.pw_duration = mw.pw_duration,
                    m.pw_location = mw.pw_location,
                    m.pw_reason = mw.pw_reason
                """,
                {"mws": mw_list}
            )
            self.logger.debug(f"✅ Batch loaded {len(mw_list)} MaintenanceWindow nodes")
            return len(mw_list)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load maintenance windows: {e}")
            return 0

    async def batch_load_surveys(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load SurveyInfo nodes using UNWIND"""
        survey_list = []

        for op_status in operational_status:
            tkt_id = op_status.get("ticket_info", {}).get("tkt_id")
            survey = op_status.get("survey_info")
            if tkt_id and survey:
                survey_list.append({
                    "survey_id": f"survey_{tkt_id}",
                    "score_id": survey.get("score_id"),
                    "score_reason": survey.get("score_reason"),
                    "survey_score": survey.get("survey_score"),
                    "survey_ref": survey.get("survey_ref"),
                    "survey_created_on": survey.get("survey_created_on")
                })

        if not survey_list:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $surveys AS s
                MERGE (survey:SurveyInfo {survey_id: s.survey_id})
                SET
                    survey.score_id = s.score_id,
                    survey.score_reason = s.score_reason,
                    survey.survey_score = s.survey_score,
                    survey.survey_ref = s.survey_ref,
                    survey.survey_created_on = s.survey_created_on
                """,
                {"surveys": survey_list}
            )
            self.logger.debug(f"✅ Batch loaded {len(survey_list)} SurveyInfo nodes")
            return len(survey_list)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load surveys: {e}")
            return 0

    async def batch_load_core_relationships(self, operational_status: List[Dict[str, Any]], client_id: str) -> int:
        """Batch load core relationships (HAS_TICKET, HAS_SERVICE, HAS_FAULT, HAS_OUTAGE) using UNWIND"""
        relationships = []

        for op_status in operational_status:
            # Use ticket_sys_id for TSM model, fallback to tkt_id
            ticket_sys_id = op_status.get("ticket_sys_id")
            tkt_id = op_status.get("ticket_info", {}).get("tkt_id") or ticket_sys_id
            svc_id = op_status.get("service_entity", {}).get("svc_id")
            # Generate fault_id from ticket_sys_id (matching batch_load_faults)
            fault_id = f"fault_{ticket_sys_id}" if ticket_sys_id else None
            oi_id = op_status.get("outage_info", {}).get("oi_id")

            if tkt_id:
                relationships.append({
                    "client_id": client_id,
                    "tkt_id": tkt_id,
                    "svc_id": svc_id,
                    "fault_id": fault_id,
                    "oi_id": oi_id
                })

        if not relationships:
            return 0

        rel_count = 0

        # HAS_TICKET relationship (Client -> Ticket)
        try:
            await self._execute_with_retry(
                """
                UNWIND $rels AS rel
                MATCH (c:Client {cl_id: rel.client_id})
                MATCH (t:Ticket {tkt_id: rel.tkt_id})
                MERGE (c)-[:HAS_TICKET]->(t)
                """,
                {"rels": relationships}
            )
            rel_count += len(relationships)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load HAS_TICKET relationships: {e}")

        # HAS_SERVICE relationship (Ticket -> Service)
        svc_rels = [r for r in relationships if r.get("svc_id")]
        if svc_rels:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (t:Ticket {tkt_id: rel.tkt_id})
                    MATCH (s:Service {svc_id: rel.svc_id})
                    MERGE (t)-[:HAS_SERVICE]->(s)
                    """,
                    {"rels": svc_rels}
                )
                rel_count += len(svc_rels)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load HAS_SERVICE relationships: {e}")

        # HAS_FAULT relationship (Ticket -> Fault)
        fault_rels = [r for r in relationships if r.get("fault_id")]
        if fault_rels:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (t:Ticket {tkt_id: rel.tkt_id})
                    MATCH (f:Fault {fault_id: rel.fault_id})
                    MERGE (t)-[:HAS_FAULT]->(f)
                    """,
                    {"rels": fault_rels}
                )
                rel_count += len(fault_rels)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load HAS_FAULT relationships: {e}")

        # HAS_OUTAGE relationship (Ticket -> Outage)
        outage_rels = [r for r in relationships if r.get("oi_id")]
        if outage_rels:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (t:Ticket {tkt_id: rel.tkt_id})
                    MATCH (o:Outage_Info {oi_id: rel.oi_id})
                    MERGE (t)-[:HAS_OUTAGE]->(o)
                    """,
                    {"rels": outage_rels}
                )
                rel_count += len(outage_rels)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load HAS_OUTAGE relationships: {e}")

        self.logger.debug(f"✅ Batch loaded {rel_count} core relationships")
        return rel_count

    async def batch_load_user_relationships(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load user relationships (HAS_USER) using UNWIND"""
        relationships = []

        for op_status in operational_status:
            tkt_id = op_status.get("ticket_info", {}).get("tkt_id")
            if not tkt_id:
                continue

            # Users from users array (incident_manager, operations_specialist)
            users = op_status.get("users", [])
            for user in users:
                user_id = user.get("user_id")
                role = user.get("role")
                if user_id and role in ["incident_manager", "operations_specialist"]:
                    relationships.append({
                        "tkt_id": tkt_id,
                        "user_id": user_id,
                        "role": role
                    })

            # Lifecycle users
            ticket_info = op_status.get("ticket_info", {})
            if ticket_info.get("assigned_to_id"):
                relationships.append({
                    "tkt_id": tkt_id,
                    "user_id": ticket_info["assigned_to_id"],
                    "role": "assigned_to"
                })
            if ticket_info.get("closed_by_id"):
                relationships.append({
                    "tkt_id": tkt_id,
                    "user_id": ticket_info["closed_by_id"],
                    "role": "closed_by"
                })

        if not relationships:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $rels AS rel
                MATCH (t:Ticket {tkt_id: rel.tkt_id})
                MATCH (u:UserInfo {user_id: rel.user_id})
                MERGE (t)-[:HAS_USER {role: rel.role}]->(u)
                """,
                {"rels": relationships}
            )
            self.logger.debug(f"✅ Batch loaded {len(relationships)} user relationships")
            return len(relationships)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load user relationships: {e}")
            return 0

    async def batch_load_contact_relationships(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load contact relationships (HAS_CONTACT) using UNWIND"""
        relationships = []

        for op_status in operational_status:
            tkt_id = op_status.get("ticket_info", {}).get("tkt_id")
            if not tkt_id:
                continue

            contacts = op_status.get("contacts", [])
            for contact in contacts:
                contact_id = contact.get("contact_id")
                if contact_id:
                    relationships.append({
                        "tkt_id": tkt_id,
                        "contact_id": contact_id
                    })

        if not relationships:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $rels AS rel
                MATCH (t:Ticket {tkt_id: rel.tkt_id})
                MATCH (c:ContactInfo {contact_id: rel.contact_id})
                MERGE (t)-[:HAS_CONTACT]->(c)
                """,
                {"rels": relationships}
            )
            self.logger.debug(f"✅ Batch loaded {len(relationships)} contact relationships")
            return len(relationships)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load contact relationships: {e}")
            return 0

    async def batch_load_vendor_relationships(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load vendor relationships (INVOLVES_VENDOR) using UNWIND"""
        relationships = []

        for op_status in operational_status:
            tkt_id = op_status.get("ticket_info", {}).get("tkt_id")
            if not tkt_id:
                continue

            vendors = op_status.get("vendors", [])
            for vendor in vendors:
                vendor_id = vendor.get("vendor_id")
                if vendor_id:
                    relationships.append({
                        "tkt_id": tkt_id,
                        "vendor_id": vendor_id
                    })

        if not relationships:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $rels AS rel
                MATCH (t:Ticket {tkt_id: rel.tkt_id})
                MATCH (v:VendorInfo {vendor_id: rel.vendor_id})
                MERGE (t)-[:INVOLVES_VENDOR]->(v)
                """,
                {"rels": relationships}
            )
            self.logger.debug(f"✅ Batch loaded {len(relationships)} vendor relationships")
            return len(relationships)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load vendor relationships: {e}")
            return 0

    async def batch_load_ticket_hierarchy_relationships(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load ticket hierarchy (CHILD_OF, LINKED_TO) using UNWIND"""
        child_of = []
        linked_to = []

        for op_status in operational_status:
            ticket_info = op_status.get("ticket_info", {})
            tkt_id = ticket_info.get("tkt_id")
            if not tkt_id:
                continue

            if ticket_info.get("master_ticket_id"):
                child_of.append({
                    "tkt_id": tkt_id,
                    "master_id": ticket_info["master_ticket_id"]
                })

            if ticket_info.get("linked_ticket_id"):
                linked_to.append({
                    "tkt_id": tkt_id,
                    "linked_id": ticket_info["linked_ticket_id"]
                })

        count = 0

        if child_of:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (child:Ticket {tkt_id: rel.tkt_id})
                    MATCH (master:Ticket {ticket_id: rel.master_id})
                    MERGE (child)-[:CHILD_OF]->(master)
                    """,
                    {"rels": child_of}
                )
                count += len(child_of)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load CHILD_OF relationships: {e}")

        if linked_to:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (ticket1:Ticket {tkt_id: rel.tkt_id})
                    MATCH (ticket2:Ticket {ticket_id: rel.linked_id})
                    MERGE (ticket1)-[:LINKED_TO]->(ticket2)
                    """,
                    {"rels": linked_to}
                )
                count += len(linked_to)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load LINKED_TO relationships: {e}")

        if count > 0:
            self.logger.debug(f"✅ Batch loaded {count} ticket hierarchy relationships")

        return count

    async def batch_load_auxiliary_relationships(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load auxiliary relationships (DURING_MAINTENANCE, HAS_SURVEY) using UNWIND"""
        maintenance = []
        surveys = []

        for op_status in operational_status:
            tkt_id = op_status.get("ticket_info", {}).get("tkt_id")
            if not tkt_id:
                continue

            if op_status.get("maintenance_window"):
                maintenance.append({
                    "tkt_id": tkt_id,
                    "mw_id": f"mw_{tkt_id}"
                })

            if op_status.get("survey_info"):
                surveys.append({
                    "tkt_id": tkt_id,
                    "survey_id": f"survey_{tkt_id}"
                })

        count = 0

        if maintenance:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (t:Ticket {tkt_id: rel.tkt_id})
                    MATCH (m:MaintenanceWindow {mw_id: rel.mw_id})
                    MERGE (t)-[:DURING_MAINTENANCE]->(m)
                    """,
                    {"rels": maintenance}
                )
                count += len(maintenance)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load DURING_MAINTENANCE relationships: {e}")

        if surveys:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (t:Ticket {tkt_id: rel.tkt_id})
                    MATCH (s:SurveyInfo {survey_id: rel.survey_id})
                    MERGE (t)-[:HAS_SURVEY]->(s)
                    """,
                    {"rels": surveys}
                )
                count += len(surveys)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load HAS_SURVEY relationships: {e}")

        if count > 0:
            self.logger.debug(f"✅ Batch loaded {count} auxiliary relationships")

        return count

    # =========================================================================
    # NEW: TSM FK Relationships
    # =========================================================================

    async def batch_load_task_relationships(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load HAS_TASK relationships (Ticket -> Task) using UNWIND"""
        relationships = []

        for op_status in operational_status:
            ticket_sys_id = op_status.get("ticket_sys_id")
            tkt_id = op_status.get("ticket_info", {}).get("tkt_id") or ticket_sys_id
            tasks = op_status.get("tasks", [])

            if not tkt_id or not tasks:
                continue

            for task in tasks:
                task_sys_id = task.get("task_sys_id")
                if task_sys_id:
                    relationships.append({
                        "tkt_id": tkt_id,
                        "task_sys_id": task_sys_id
                    })

        if not relationships:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $rels AS rel
                MATCH (t:Ticket {tkt_id: rel.tkt_id})
                MATCH (task:Task {task_sys_id: rel.task_sys_id})
                MERGE (t)-[:HAS_TASK]->(task)
                """,
                {"rels": relationships}
            )
            self.logger.debug(f"✅ Batch loaded {len(relationships)} HAS_TASK relationships")
            return len(relationships)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load HAS_TASK relationships: {e}")
            return 0

    async def batch_load_tsm_fk_relationships(self, operational_status: List[Dict[str, Any]]) -> int:
        """
        Batch load TSM FK relationships using UNWIND:
        - RAISED_BY_INCIDENT: Case -> Incident
        - RAISED_BY_PROBLEM: Case -> Problem
        - BELONGS_TO_CASE: Request -> Case
        - CHILD_OF: Incident -> Parent Incident
        - RELATED_TO_PROBLEM: Incident -> Problem
        """
        raised_by_incident = []
        raised_by_problem = []
        belongs_to_case = []
        child_of = []
        related_to_problem = []

        for op_status in operational_status:
            ticket_sys_id = op_status.get("ticket_sys_id")
            ticket_type = op_status.get("ticket_type")
            tkt_id = op_status.get("ticket_info", {}).get("tkt_id") or ticket_sys_id

            if not tkt_id or not ticket_type:
                continue

            # Case FK relationships
            if ticket_type == "case":
                case_fields = op_status.get("case_fields", {})
                if case_fields:
                    # Case raised by Incident
                    if case_fields.get("incident_sys_id"):
                        raised_by_incident.append({
                            "case_tkt_id": tkt_id,
                            "incident_sys_id": case_fields["incident_sys_id"]
                        })
                    # Case raised by Problem
                    if case_fields.get("problem_sys_id"):
                        raised_by_problem.append({
                            "case_tkt_id": tkt_id,
                            "problem_sys_id": case_fields["problem_sys_id"]
                        })

            # Request FK relationships
            elif ticket_type == "request":
                request_fields = op_status.get("request_fields", {})
                if request_fields and request_fields.get("case_sys_id"):
                    belongs_to_case.append({
                        "request_tkt_id": tkt_id,
                        "case_sys_id": request_fields["case_sys_id"]
                    })

            # Incident FK relationships
            elif ticket_type == "incident":
                incident_fields = op_status.get("incident_fields", {})
                if incident_fields:
                    # Incident child of parent Incident
                    if incident_fields.get("related_parent_incident_sys_id"):
                        child_of.append({
                            "child_tkt_id": tkt_id,
                            "parent_sys_id": incident_fields["related_parent_incident_sys_id"]
                        })
                    # Incident related to Problem
                    if incident_fields.get("related_problem_sys_id"):
                        related_to_problem.append({
                            "incident_tkt_id": tkt_id,
                            "problem_sys_id": incident_fields["related_problem_sys_id"]
                        })

        count = 0

        # RAISED_BY_INCIDENT: Case -> Incident
        if raised_by_incident:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (case_tkt:Ticket {tkt_id: rel.case_tkt_id})
                    MATCH (inc_tkt:Ticket {ticket_sys_id: rel.incident_sys_id})
                    MERGE (case_tkt)-[:RAISED_BY_INCIDENT]->(inc_tkt)
                    """,
                    {"rels": raised_by_incident}
                )
                count += len(raised_by_incident)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load RAISED_BY_INCIDENT relationships: {e}")

        # RAISED_BY_PROBLEM: Case -> Problem
        if raised_by_problem:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (case_tkt:Ticket {tkt_id: rel.case_tkt_id})
                    MATCH (prob_tkt:Ticket {ticket_sys_id: rel.problem_sys_id})
                    MERGE (case_tkt)-[:RAISED_BY_PROBLEM]->(prob_tkt)
                    """,
                    {"rels": raised_by_problem}
                )
                count += len(raised_by_problem)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load RAISED_BY_PROBLEM relationships: {e}")

        # BELONGS_TO_CASE: Request -> Case
        if belongs_to_case:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (req_tkt:Ticket {tkt_id: rel.request_tkt_id})
                    MATCH (case_tkt:Ticket {ticket_sys_id: rel.case_sys_id})
                    MERGE (req_tkt)-[:BELONGS_TO_CASE]->(case_tkt)
                    """,
                    {"rels": belongs_to_case}
                )
                count += len(belongs_to_case)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load BELONGS_TO_CASE relationships: {e}")

        # CHILD_OF: Incident -> Parent Incident
        if child_of:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (child_tkt:Ticket {tkt_id: rel.child_tkt_id})
                    MATCH (parent_tkt:Ticket {ticket_sys_id: rel.parent_sys_id})
                    MERGE (child_tkt)-[:CHILD_OF]->(parent_tkt)
                    """,
                    {"rels": child_of}
                )
                count += len(child_of)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load CHILD_OF relationships: {e}")

        # RELATED_TO_PROBLEM: Incident -> Problem
        if related_to_problem:
            try:
                await self._execute_with_retry(
                    """
                    UNWIND $rels AS rel
                    MATCH (inc_tkt:Ticket {tkt_id: rel.incident_tkt_id})
                    MATCH (prob_tkt:Ticket {ticket_sys_id: rel.problem_sys_id})
                    MERGE (inc_tkt)-[:RELATED_TO_PROBLEM]->(prob_tkt)
                    """,
                    {"rels": related_to_problem}
                )
                count += len(related_to_problem)
            except Exception as e:
                self.logger.error(f"❌ Failed to batch load RELATED_TO_PROBLEM relationships: {e}")

        if count > 0:
            self.logger.debug(f"✅ Batch loaded {count} TSM FK relationships")

        return count

    # =========================================================================
    # NEW: Configuration Item (CI) nodes and relationships
    # =========================================================================

    async def batch_load_configuration_items(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load ConfigurationItem nodes using UNWIND"""
        ci_map = {}  # ci_sys_id -> ci_data (dedup)

        for op_status in operational_status:
            config_items = op_status.get("configuration_items", [])
            if config_items is None:
                continue
            for ci in config_items:
                ci_sys_id = ci.get("ci_sys_id")
                if ci_sys_id:
                    ci_map[ci_sys_id] = {
                        "ci_sys_id": ci_sys_id,
                        "ci_name": ci.get("ci_name"),
                        "is_manually_added": ci.get("is_manually_added", False)
                    }

        if not ci_map:
            return 0

        ci_batch = list(ci_map.values())

        try:
            await self._execute_with_retry(
                """
                UNWIND $cis AS ci
                MERGE (c:ConfigurationItem {ci_sys_id: ci.ci_sys_id})
                SET
                    c.ci_name = ci.ci_name,
                    c.is_manually_added = ci.is_manually_added
                """,
                {"cis": ci_batch}
            )
            self.logger.debug(f"✅ Batch loaded {len(ci_batch)} ConfigurationItem nodes")
            return len(ci_batch)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load configuration items: {e}")
            return 0

    async def batch_load_ci_relationships(self, operational_status: List[Dict[str, Any]]) -> int:
        """Batch load RELATES_TO_CI relationships (Ticket -> ConfigurationItem) using UNWIND"""
        relationships = []

        for op_status in operational_status:
            ticket_sys_id = op_status.get("ticket_sys_id")
            tkt_id = op_status.get("ticket_info", {}).get("tkt_id") or ticket_sys_id
            config_items = op_status.get("configuration_items", [])

            if not tkt_id or not config_items:
                continue

            for ci in config_items:
                ci_sys_id = ci.get("ci_sys_id")
                if ci_sys_id:
                    relationships.append({
                        "tkt_id": tkt_id,
                        "ci_sys_id": ci_sys_id
                    })

        if not relationships:
            return 0

        try:
            await self._execute_with_retry(
                """
                UNWIND $rels AS rel
                MATCH (t:Ticket {tkt_id: rel.tkt_id})
                MATCH (ci:ConfigurationItem {ci_sys_id: rel.ci_sys_id})
                MERGE (t)-[:RELATES_TO_CI]->(ci)
                """,
                {"rels": relationships}
            )
            self.logger.debug(f"✅ Batch loaded {len(relationships)} RELATES_TO_CI relationships")
            return len(relationships)
        except Exception as e:
            self.logger.error(f"❌ Failed to batch load RELATES_TO_CI relationships: {e}")
            return 0
