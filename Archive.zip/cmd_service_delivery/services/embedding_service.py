"""
Embedding service using OpenAI for generating text embeddings.
"""

import logging
from typing import List

from openai import AsyncOpenAI

from config import Config

logger = logging.getLogger(__name__)


MAX_CHARS = 6000


class EmbeddingService:
    def __init__(self, config: Config):
        self.client = AsyncOpenAI(api_key=config.openai_api_key)
        self.model = config.openai_embedding_model
        self.dim = config.embedding_dim

    @staticmethod
    def _truncate(text: str) -> str:
        return text[:MAX_CHARS] if len(text) > MAX_CHARS else text

    async def embed(self, text: str) -> List[float]:
        """Generate embedding for a single text."""
        resp = await self.client.embeddings.create(
            model=self.model,
            input=self._truncate(text),
        )
        return resp.data[0].embedding

    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for a batch of texts (single API call)."""
        if not texts:
            return []
        truncated = [self._truncate(t) for t in texts]
        try:
            resp = await self.client.embeddings.create(
                model=self.model,
                input=truncated,
            )
            return [item.embedding for item in sorted(resp.data, key=lambda x: x.index)]
        except Exception:
            logger.warning("Batch embed failed, falling back to individual calls")
            results = []
            for t in truncated:
                try:
                    r = await self.client.embeddings.create(model=self.model, input=t)
                    results.append(r.data[0].embedding)
                except Exception as e:
                    logger.warning("Skipping text (len=%d): %s", len(t), e)
                    results.append([0.0] * self.dim)
            return results

    async def health_check(self) -> bool:
        """Check if the OpenAI API is reachable."""
        try:
            resp = await self.client.embeddings.create(
                model=self.model,
                input="test",
            )
            return len(resp.data[0].embedding) == self.dim
        except Exception as e:
            logger.warning("OpenAI health check failed: %s", e)
            return False
