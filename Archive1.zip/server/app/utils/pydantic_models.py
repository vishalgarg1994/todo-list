# utils/models.py
from pydantic import BaseModel, HttpUrl


class LoadDataRequest(BaseModel):
    url: HttpUrl  # Validates incoming URL format


class CustomerQueryRequest(BaseModel):
    question: str


class TicketQueryRequest(BaseModel):
    question: str


class SiteQueryRequest(BaseModel):
    country_code: str = "USA"
