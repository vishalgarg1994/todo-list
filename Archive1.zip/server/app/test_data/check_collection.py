"""
Check Milvus collection schema and drop if needed
"""
import sys
sys.path.append('/app')

from data_access.milvusClient import MilvusClient
from configs.config import Config

config = Config()
client = MilvusClient(config)

try:
    client.connect()

    # Check collection stats
    stats = client.get_collection_stats()
    print(f"Collection stats: {stats}")
    print(f"Number of entities: {stats['num_entities']}")

    # Check schema
    if client.collection:
        schema = client.collection.schema
        print("\nCurrent schema:")
        for field in schema.fields:
            print(f"  Field: {field.name}")
            print(f"    Type: {field.dtype}")
            print(f"    Is Primary: {field.is_primary}")
            print(f"    Auto ID: {field.auto_id}")
            print()

        # Drop collection to force recreation
        print("\n⚠️  Dropping collection to force recreation with new schema...")
        client.drop_collection()
        print("✅ Collection dropped successfully")

    client.disconnect()

except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
