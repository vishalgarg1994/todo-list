# Messaging Infrastructure Naming Conventions

**Version**: 1.0
**Date**: 2025-09-20
**Purpose**: Stable, company-agnostic naming standards for messaging infrastructure

## Philosophy

Use **domain-based naming** that survives organizational rebranding and clearly identifies functional areas. Avoid company-specific prefixes that change over time (eva, deva, evo, etc.).

## Stream Naming Convention

### Pattern
```
MESSAGING_{DOMAIN}_{STREAM_TYPE}

Examples:
- MESSAGING_TICKETING_STREAM
- MESSAGING_ANALYTICS_STREAM
- MESSAGING_AUDIT_STREAM
- MESSAGING_NOTIFICATIONS_STREAM
```

### Benefits
- ✅ **Company-agnostic**: Survives rebranding
- ✅ **Self-documenting**: Clear domain identification
- ✅ **Consistent**: Predictable naming pattern
- ✅ **Scalable**: Easy to add new domains

## Subject Naming Convention

### Pattern
```
{domain}.{subdomain}.{action}

Examples:
- ticketing.created
- ticketing.updated
- ticketing.fault_description
- analytics.processed
- analytics.report_generated
- audit.user_action
- audit.security_event
- notifications.email_sent
- notifications.alert_triggered
```

### Benefits
- ✅ **Hierarchical**: Natural topic organization
- ✅ **Filterable**: Easy wildcard matching (`ticketing.*`)
- ✅ **Extensible**: Can add new subdomains/actions
- ✅ **Domain-focused**: Clear functional boundaries

## Implementation Examples

### Current Stream Configuration

```yaml
# Ticketing Domain
MESSAGING_TICKETING_STREAM:
  subjects: ["ticketing.*", "incidents.*", "maintenance.*"]
  description: "Ticketing System - tickets, incidents, and maintenance events"
  retention: "workqueue"
  max_age: "72h"

# Analytics Domain
MESSAGING_ANALYTICS_STREAM:
  subjects: ["analytics.*", "metrics.*", "reports.*"]
  description: "Analytics - metrics, reports, and business intelligence"
  retention: "limits"
  max_age: "30d"

# Audit Domain
MESSAGING_AUDIT_STREAM:
  subjects: ["audit.*", "security.*", "compliance.*"]
  description: "Audit - security events, compliance, and audit logs"
  retention: "limits"
  max_age: "365d"

# Notifications Domain
MESSAGING_NOTIFICATIONS_STREAM:
  subjects: ["notifications.*", "alerts.*", "emails.*"]
  description: "Notifications - alerts, emails, and user notifications"
  retention: "workqueue"
  max_age: "24h"
```

### Application Configuration Example

```bash
# Environment Variables
JETSTREAM_STREAM_NAME=MESSAGING_TICKETING_STREAM
TICKET_PUBLISH_SUBJECT=ticketing.created
FAULT_DESCRIPTION_PUBLISH_SUBJECT=ticketing.fault_description

# Usage in Code
await js.publish('ticketing.created', message, {
  stream: 'MESSAGING_TICKETING_STREAM'
});
```

## Migration Path

### From Company-Branded Names
```bash
# OLD (Company-branded)
EVA_TICKETING → MESSAGING_TICKETING_STREAM
eva.tickets.created → ticketing.created

# NEW (Domain-based)
MESSAGING_TICKETING_STREAM
ticketing.created
```

### From Legacy Names
```bash
# OLD (Legacy)
ticketing-stream → MESSAGING_TICKETING_STREAM
tickets.created → ticketing.created

# NEW (Standardized)
MESSAGING_TICKETING_STREAM
ticketing.created
```

## Subject Categories by Domain

### Ticketing Domain (`ticketing.*`)
- `ticketing.created` - New ticket created
- `ticketing.updated` - Ticket information updated
- `ticketing.assigned` - Ticket assigned to agent
- `ticketing.resolved` - Ticket marked as resolved
- `ticketing.closed` - Ticket closed
- `ticketing.fault_description` - Fault description added
- `ticketing.comment_added` - Comment added to ticket

### Incidents Domain (`incidents.*`)
- `incidents.created` - New incident reported
- `incidents.escalated` - Incident escalated
- `incidents.resolved` - Incident resolved
- `incidents.maintenance_scheduled` - Maintenance scheduled

### Analytics Domain (`analytics.*`)
- `analytics.ticket_processed` - Ticket analytics processed
- `analytics.report_generated` - Report generated
- `analytics.metric_calculated` - Metric calculated
- `analytics.dashboard_updated` - Dashboard data updated

### Audit Domain (`audit.*`)
- `audit.user_action` - User action logged
- `audit.security_event` - Security event detected
- `audit.data_access` - Data access logged
- `audit.configuration_changed` - System configuration changed

### Notifications Domain (`notifications.*`)
- `notifications.email_sent` - Email notification sent
- `notifications.alert_triggered` - Alert triggered
- `notifications.reminder_scheduled` - Reminder scheduled
- `notifications.broadcast_sent` - Broadcast message sent

## Consumer Naming Convention

### Pattern
```
{application_name}-{domain}-{purpose}

Examples:
- ticketing-app-processor
- analytics-service-consumer
- audit-collector-consumer
- messaging-ui-monitor
```

## Best Practices

### Do's ✅
- Use lowercase with underscores for streams
- Use lowercase with dots for subjects
- Keep domain names singular (`ticketing` not `tickets`)
- Use descriptive action verbs (`created`, `updated`, `processed`)
- Group related subjects under same domain

### Don'ts ❌
- Don't use company names in infrastructure naming
- Don't use abbreviations that aren't obvious
- Don't mix naming conventions within same system
- Don't create deeply nested subject hierarchies (max 3 levels)

## Governance

### Adding New Domains
1. **Propose** new domain name following conventions
2. **Document** subject patterns and use cases
3. **Review** with team for consistency
4. **Implement** with proper stream configuration
5. **Update** this documentation

### Changing Existing Names
1. **Plan** migration strategy with aliases
2. **Communicate** changes to all teams
3. **Implement** gradual migration
4. **Deprecate** old names after migration period
5. **Clean up** legacy references

## Tools and Validation

### Naming Validation Script
```bash
#!/bin/bash
# validate-naming.sh - Validates naming conventions

validate_stream_name() {
  if [[ $1 =~ ^MESSAGING_[A-Z]+_STREAM$ ]]; then
    echo "✅ Valid stream name: $1"
  else
    echo "❌ Invalid stream name: $1"
    echo "   Should match: MESSAGING_{DOMAIN}_STREAM"
  fi
}

validate_subject_name() {
  if [[ $1 =~ ^[a-z]+\.[a-z_]+$ ]]; then
    echo "✅ Valid subject name: $1"
  else
    echo "❌ Invalid subject name: $1"
    echo "   Should match: {domain}.{action}"
  fi
}
```

### Configuration Checker
```bash
# Check current configuration compliance
grep -r "JETSTREAM_STREAM_NAME" . | grep -v "MESSAGING_.*_STREAM" || echo "✅ All streams use proper naming"
grep -r "PUBLISH_SUBJECT" . | grep -v "\." || echo "✅ All subjects use domain.action format"
```

---

**Adherence to these conventions ensures long-term stability and clarity across the messaging infrastructure, regardless of organizational changes.**