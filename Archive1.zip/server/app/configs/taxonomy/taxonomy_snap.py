"""
Taxonomy Snap — loads ServiceNow category/subcategory taxonomy and provides
snap-to-grid functionality for LLM extraction.

The LLM reasons freely about a ticket's fault, then snaps its analysis
to the nearest valid category + subcategory from the official taxonomy.
"""
import os
import logging
from typing import Dict, List, Optional
import yaml

logger = logging.getLogger(__name__)

# Model type constants
CUSTOMER_INCIDENT = "customer_incident"
CUSTOMER_PROBLEM = "customer_problem"
PLATFORM_INCIDENT = "platform_incident"
PLATFORM_PROBLEM = "platform_problem"
SERVICE_REQUEST = "service_request"

MODEL_TYPES = [CUSTOMER_INCIDENT, CUSTOMER_PROBLEM, PLATFORM_INCIDENT, PLATFORM_PROBLEM, SERVICE_REQUEST]

# Singleton instance
_taxonomy: Optional["Taxonomy"] = None


def get_taxonomy() -> "Taxonomy":
    """Get or create the singleton Taxonomy instance."""
    global _taxonomy
    if _taxonomy is None:
        _taxonomy = Taxonomy()
    return _taxonomy


class Taxonomy:
    """
    Loads and provides access to the ServiceNow category/subcategory taxonomy.

    Usage:
        tax = get_taxonomy()
        model_type = tax.get_model_type("incident", "Managed Networking")
        prompt_text = tax.format_for_prompt(model_type)
        valid = tax.validate(model_type, "Managed Networking", "Line Down")
        fields = tax.lookup_fields(model_type, "Managed Networking", "Line Down")
    """

    def __init__(self, taxonomy_dir: Optional[str] = None):
        if taxonomy_dir is None:
            taxonomy_dir = os.path.dirname(os.path.abspath(__file__))
        self._data: Dict[str, Dict] = {}
        self._category_to_model: Dict[str, List[str]] = {}
        self._load(taxonomy_dir)

    def _load(self, taxonomy_dir: str):
        """Load all taxonomy YAML files."""
        files = {
            CUSTOMER_INCIDENT: "customer_incident.yaml",
            CUSTOMER_PROBLEM: "customer_problem.yaml",
            PLATFORM_INCIDENT: "platform_incident.yaml",
            PLATFORM_PROBLEM: "platform_problem.yaml",
            SERVICE_REQUEST: "service_request.yaml",
        }
        for model_type, filename in files.items():
            path = os.path.join(taxonomy_dir, filename)
            try:
                with open(path, "r") as f:
                    data = yaml.safe_load(f)
                self._data[model_type] = data.get("categories", {})
                # Build reverse index: category name -> model types
                for cat_name in self._data[model_type]:
                    self._category_to_model.setdefault(cat_name, []).append(model_type)
                logger.info(f"Loaded taxonomy {model_type}: {len(self._data[model_type])} categories")
            except FileNotFoundError:
                logger.warning(f"Taxonomy file not found: {path}")
                self._data[model_type] = {}
            except Exception as e:
                logger.error(f"Error loading taxonomy {path}: {e}")
                self._data[model_type] = {}

        total_cats = sum(len(v) for v in self._data.values())
        total_subs = sum(
            len(cat_data.get("subcategories", {}))
            for model_data in self._data.values()
            for cat_data in model_data.values()
        )
        logger.info(f"Taxonomy loaded: {total_cats} categories, {total_subs} subcategories")

    # -------------------------------------------------------------------------
    # Model type determination
    # -------------------------------------------------------------------------

    def get_model_type(self, ticket_type: str, category: Optional[str] = None) -> str:
        """
        Determine the taxonomy model type from ticket type and category.

        Args:
            ticket_type: "incident", "case", "problem", "request", etc.
            category: The ticket's existing category from ServiceNow (optional).
                      Used to distinguish customer vs platform.

        Returns:
            One of: customer_incident, customer_problem, platform_incident, platform_problem
        """
        ticket_type_lower = ticket_type.lower()
        is_request = ticket_type_lower in ("request", "service_request")
        is_problem = ticket_type_lower in ("problem",)
        is_incident = ticket_type_lower in ("incident", "case")

        if is_request:
            return SERVICE_REQUEST

        if category:
            # Check which model types contain this category
            possible = self._category_to_model.get(category, [])
            if is_problem:
                for mt in possible:
                    if "problem" in mt:
                        return mt
            elif is_incident:
                for mt in possible:
                    if "incident" in mt:
                        return mt

        # Fallback: use ticket type + category name pattern
        if is_problem:
            # Platform problem categories: Cloud Computing, Systems, IP, SD-WAN, Security
            # Customer problem categories: Managed Networking, Voice, Cloud Solutions, Secure Network
            if category and self._is_platform_category(category):
                return PLATFORM_PROBLEM
            return CUSTOMER_PROBLEM
        else:
            # Platform incident categories have dash-suffix: "Systems - CMD", "IP - Core Equipment"
            if category and " - " in category and self._is_platform_category(category):
                return PLATFORM_INCIDENT
            return CUSTOMER_INCIDENT

    def _is_platform_category(self, category: str) -> bool:
        """Check if a category belongs to platform models."""
        # Platform incident categories contain " - " (e.g., "Systems - CMD")
        if " - " in category:
            prefix = category.split(" - ")[0].strip()
            return prefix in ("Systems", "IP", "SD-WAN", "Security", "Voice", "Cloud Computing")
        # Platform problem categories (bare names)
        return category in ("Cloud Computing", "Systems", "IP", "SD-WAN", "Security")

    # -------------------------------------------------------------------------
    # Lookup and validation
    # -------------------------------------------------------------------------

    def get_valid_categories(self, model_type: str) -> List[str]:
        """Get all valid category names for a model type."""
        return list(self._data.get(model_type, {}).keys())

    def get_valid_subcategories(self, model_type: str, category: str) -> List[str]:
        """Get all valid subcategory names for a model type + category."""
        cat_data = self._data.get(model_type, {}).get(category, {})
        return list(cat_data.get("subcategories", {}).keys())

    def validate(self, model_type: str, category: str, subcategory: str) -> bool:
        """Check if a category + subcategory pair is valid for the model type."""
        cat_data = self._data.get(model_type, {}).get(category, {})
        return subcategory in cat_data.get("subcategories", {})

    def lookup_fields(self, model_type: str, category: str, subcategory: str) -> Optional[Dict]:
        """
        Look up impact/urgency/priority/SLA for a category + subcategory.

        Returns:
            Dict with keys like impact, urgency, priority, sla_hours/sla, or None if not found.
        """
        cat_data = self._data.get(model_type, {}).get(category, {})
        return cat_data.get("subcategories", {}).get(subcategory)


    # -------------------------------------------------------------------------
    # Prompt formatting
    # -------------------------------------------------------------------------

    def format_for_prompt(self, model_type: str) -> str:
        """
        Format the taxonomy for inclusion in the LLM prompt.
        Compact representation: one line per category with subcategories listed.

        Example output:
          Managed Networking: DDOS, Flaps | Instabilities, Latency, Line Down, ...
          Voice: CLI Issue, Incoming Call Failure, Outgoing Call Failure, ...
        """
        model_data = self._data.get(model_type, {})
        if not model_data:
            return "(No taxonomy available for this model type)"

        lines = []
        for cat_name, cat_data in model_data.items():
            subs = list(cat_data.get("subcategories", {}).keys())
            subs_str = ", ".join(subs)
            lines.append(f"  {cat_name}: {subs_str}")

        return "\n".join(lines)

    # -------------------------------------------------------------------------
    # Compose helpers
    # -------------------------------------------------------------------------

    @staticmethod
    def compose_fault_summary(category: str, subcategory: str) -> str:
        """Compose deterministic fault summary: '{Category} had {Subcategory}'."""
        return f"{category} had {subcategory}"

    def enrich_audit_result(
        self, result: Dict, model_type: str
    ) -> Dict:
        """
        Post-process LLM audit result: lookup taxonomy fields, compose summary.

        The LLM does ALL the snapping — it reasons freely, then picks the closest
        category + subcategory from the taxonomy. This method trusts the LLM's
        pick and just does deterministic lookups + compose.

        Modifies the result dict in-place and returns it.
        """
        suggested_cat = result.get("suggested_category", "")
        fault_type = result.get("fault_type", "")

        if not suggested_cat or not fault_type:
            return result

        # Compose fault summary (always — regardless of taxonomy match)
        result["fault_summary"] = self.compose_fault_summary(suggested_cat, fault_type)

        # Deterministic lookup from taxonomy
        fields = self.lookup_fields(model_type, suggested_cat, fault_type)
        if fields:
            result["taxonomy_priority"] = fields.get("priority")
            result["taxonomy_impact"] = fields.get("impact")
            result["taxonomy_urgency"] = fields.get("urgency")
            result["taxonomy_sla_hours"] = fields.get("sla_hours")
            result["taxonomy_sla"] = fields.get("sla")  # For problem types (business days)
            result["taxonomy_valid"] = True
        else:
            # LLM picked something not in the taxonomy — log it, keep LLM values
            logger.warning(
                f"LLM output not in taxonomy: '{suggested_cat}/{fault_type}' "
                f"(model={model_type}). Keeping LLM values, no taxonomy fields."
            )
            result["taxonomy_valid"] = False

        return result
