"""
Data Model - Pydantic models for ServiceNow ticket data

Extended to support TSM tables (incident, case, problem, request, change) with CMD enrichment.

Message Topics:
- tickets.created -> Memgraph (TicketSummary) - client-grouped tickets
- tickets.change -> Memgraph (ChangeBatch) - infrastructure changes (batched)
- tickets.fault_descriptions -> Milvus (FaultDescriptionSummary)
- tickets.notes -> Milvus (NotesSummary)
"""

from typing import List, Optional, Literal, Union, Annotated
from pydantic import BaseModel, Field, field_validator, Discriminator
from datetime import datetime
import logging
import os

logger = logging.getLogger(__name__)


# =============================================================================
# Existing Models (unchanged)
# =============================================================================

class UserInfo(BaseModel):
    """User node for knowledge graph - represents people who act on tickets"""
    name: Optional[str] = None
    role: Optional[str] = None
    user_id: Optional[str] = None


class MaintenanceWindow(BaseModel):
    """Maintenance window node for knowledge graph - represents scheduled maintenance periods"""
    pw_start: Optional[datetime] = Field(None, description="Planned work start time")
    pw_end: Optional[datetime] = Field(None, description="Planned work end time")
    pw_duration: Optional[str] = None
    pw_location: Optional[str] = None
    pw_reason: Optional[str] = None

    @field_validator("pw_start", "pw_end", mode="before")
    def parse_maintenance_datetime_fields(cls, value):
        return value if isinstance(value, datetime) else None


class ContactInfo(BaseModel):
    """Contact node for knowledge graph - represents people who can be contacted about tickets"""
    contact_id: Optional[str] = None
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    contact_type: Optional[str] = None  # customer, poc_a_end, poc_z_end, supplier, local


class NOCInfo(BaseModel):
    """NOC operations information"""
    default_noc: Optional[str] = None
    default_noc_queue: Optional[str] = None


class SurveyInfo(BaseModel):
    """Customer survey and quality feedback"""
    score_id: Optional[str] = None
    score_reason: Optional[str] = None
    survey_score: Optional[str] = None
    survey_ref: Optional[str] = None
    survey_created_on: Optional[datetime] = None

    @field_validator("survey_created_on", mode="before")
    def parse_survey_datetime(cls, value):
        return value if isinstance(value, datetime) else None


class VendorInfo(BaseModel):
    """Vendor node for knowledge graph - represents vendors/suppliers handling tickets"""
    vendor_id: Optional[str] = None
    vendor: Optional[str] = None
    vendor_downtime: Optional[float] = None


class ServiceEntity(BaseModel):
    subcategory: Optional[str] = Field("", description="Subcategory")
    technology: Optional[str] = Field("", description="Technology")
    service_restored_date: Optional[datetime] = Field(
        None, description="Date when the service was restored"
    )
    related_circuit_id: Optional[int] = None

    @field_validator("service_restored_date", mode="before")
    def parse_service_restored_date(cls, value):
        return value if isinstance(value, datetime) else None


class FaultDescription(BaseModel):
    """Individual fault description for a single ticket"""
    fault_description_id: str = Field(..., description="Unique identifier linking to ticket")
    ticket_id: str = Field(..., description="Reference to the ticket")
    fault_description: Optional[str] = None
    fault_occured_date: Optional[datetime] = Field(None, description="Date when the fault occurred")

    @field_validator("fault_occured_date", mode="before")
    def parse_fault_occured_date(cls, value):
        return value if isinstance(value, datetime) else None


class FaultDescriptionSummary(BaseModel):
    """Grouped fault descriptions by client with ticket-bounded splitting"""
    fault_description_summary_id: str = Field(..., description="Unique identifier for this summary part")
    client_id: str = Field(..., description="Client ID for all fault descriptions in this summary")
    part_number: int = Field(..., description="Part number (1-based)")
    total_parts: int = Field(..., description="Total number of parts for this client")
    fault_descriptions: List[FaultDescription] = Field(..., description="Array of fault descriptions for tickets")

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class FaultInfo(BaseModel):
    """Fault information from CMD enrichment - applies to all ticket types"""
    fault_description_ref: Optional[str] = Field(None, description="Reference to separate fault description message")
    fault_description: Optional[str] = None
    fault_occured_date: Optional[datetime] = None
    short_description: Optional[str] = None
    is_customer_impacting: Optional[bool] = None
    rfo: Optional[str] = None
    ticket_rfo_group: Optional[str] = None

    @field_validator("fault_occured_date", mode="before")
    def parse_fault_datetime(cls, value):
        return value if isinstance(value, datetime) else None


class TicketInfo(BaseModel):
    ticket_id: Optional[str] = None
    ticket_queue: Optional[str] = None
    ticket_status: Optional[str] = None
    ticket_substatus: Optional[str] = None
    ticket_category: Optional[str] = None
    ticket_source: Optional[str] = None
    source_system: Optional[str] = None
    priority: Optional[int] = None
    type: Optional[str] = None
    is_master_ticket: Optional[bool] = None
    master_ticket_id: Optional[str] = None
    linked_ticket_id: Optional[str] = None
    ticket_import_source: Optional[str] = None
    ticket_escalation_level: Optional[int] = None
    next_action: Optional[str] = None
    next_action_timestamp: Optional[datetime] = None
    next_action_date_notification_counter: Optional[int] = None
    # Lifecycle fields
    created_by: Optional[str] = None
    created_on: Optional[datetime] = Field(
        None, description="Date when the ticket was created"
    )
    updated_on: Optional[datetime] = Field(
        None, description="Date when ticket was last updated"
    )
    closed_by: Optional[str] = None
    closed_by_id: Optional[str] = None
    closed_on: Optional[datetime] = Field(
        None, description="Date when ticket was closed"
    )
    assigned_to: Optional[str] = None
    assigned_to_id: Optional[str] = None
    first_assigned_to: Optional[str] = None
    first_assigned_on: Optional[datetime] = None
    first_resolved_on: Optional[datetime] = None
    oldest_resolved_date: Optional[datetime] = None
    first_child_ticket_created_on: Optional[datetime] = None

    @field_validator("assigned_to_id", "closed_by_id", mode="before")
    def coerce_id_to_string(cls, value):
        """Coerce integer IDs to strings"""
        if value is None:
            return None
        return str(value) if isinstance(value, (int, float)) else value

    @field_validator("created_on", "closed_on", "updated_on", "next_action_timestamp",
                     "first_assigned_on", "first_resolved_on", "oldest_resolved_date",
                     "first_child_ticket_created_on", mode="before")
    def parse_datetime_fields(cls, value):
        return value if isinstance(value, datetime) else None


class OutageInfo(BaseModel):
    customer_resolution: Optional[str] = None
    resolution: Optional[str] = None
    rfo: Optional[str] = None
    problem_type: Optional[str] = None
    ticket_rfo_group: Optional[str] = None
    outage_duration: Optional[str] = None
    internal_mttr: Optional[str] = None
    mttr: Optional[int] = None
    is_worked_ticket: Optional[bool] = None
    closure_quality: Optional[str] = None
    # Communication timeline
    first_email_from_customer_on: Optional[datetime] = None
    first_customer_note_on: Optional[datetime] = None
    first_supplier_dispatch_event_on: Optional[datetime] = None
    first_tech_dispatch_event_on: Optional[datetime] = None

    @field_validator("first_email_from_customer_on", "first_customer_note_on",
                     "first_supplier_dispatch_event_on", "first_tech_dispatch_event_on",
                     mode="before")
    def parse_communication_datetime_fields(cls, value):
        return value if isinstance(value, datetime) else None


# =============================================================================
# NEW: Entity-Specific Field Models (for TSM extension)
# =============================================================================

class IncidentFields(BaseModel):
    """Incident-specific fields (only present when ticket_type='incident')"""
    category: Optional[str] = None
    subcategory: Optional[str] = None
    # Configuration Item (CI) - for tracing shared infrastructure
    ci_sys_id: Optional[str] = None
    ci_class: Optional[str] = None
    ci_name: Optional[str] = None
    circuit_id: Optional[str] = None
    major_incident_state: Optional[str] = None
    # Parent incident (CHILD_OF relationship)
    parent_incident_number: Optional[str] = None
    related_parent_incident_sys_id: Optional[str] = None
    related_parent_incident_number: Optional[str] = None
    cause: Optional[str] = None
    business_impact: Optional[str] = None
    escalation_level: Optional[int] = None
    support_area: Optional[str] = None
    is_customer_impacted: Optional[bool] = None
    is_stranded: Optional[bool] = None
    # Related problem
    related_problem_sys_id: Optional[str] = None
    related_problem_number: Optional[str] = None
    # Related change
    related_change_sys_id: Optional[str] = None
    related_change_number: Optional[str] = None
    # Caused by change
    caused_by_change_sys_id: Optional[str] = None
    caused_by_change_number: Optional[str] = None
    # Resolution
    customer_close_notes: Optional[str] = None
    internal_resolution_notes: Optional[str] = None
    close_code: Optional[str] = None
    hold_reason: Optional[str] = None
    resolved_at: Optional[datetime] = None
    responsible_party: Optional[str] = None

    @field_validator("circuit_id", mode="before")
    def coerce_circuit_id_to_string(cls, value):
        """Coerce integer circuit IDs to strings"""
        if value is None:
            return None
        return str(value) if isinstance(value, (int, float)) else value

    @field_validator("resolved_at", mode="before")
    def parse_datetime(cls, value):
        return value if isinstance(value, datetime) else None


class CaseFields(BaseModel):
    """Case-specific fields (only present when ticket_type='case')"""
    category: Optional[str] = None
    subcategory: Optional[str] = None
    # Configuration Item (CI) - for tracing shared infrastructure
    ci_sys_id: Optional[str] = None
    ci_class: Optional[str] = None
    ci_name: Optional[str] = None
    circuit_id: Optional[str] = None
    segment_id: Optional[str] = None
    related_circuit_id: Optional[str] = None
    resolution_code: Optional[str] = None
    contact_type: Optional[str] = None  # What spawned the case: Incident, Problem, Change, TSM Request
    snow_release_name: Optional[str] = None  # "Case First" or "Case Second"
    case_type: Optional[str] = None
    sub_state: Optional[str] = None
    needs_attention: Optional[bool] = None
    is_customer_updated: Optional[bool] = None
    first_response_time: Optional[datetime] = None
    reassignment_count: Optional[int] = None
    escalation_number: Optional[int] = None
    adjusted_business_elapsed_time: Optional[str] = None
    # FK for RAISED_BY relationship to Incident
    incident_sys_id: Optional[str] = None
    incident_number: Optional[str] = None
    # FK for RAISED_BY relationship to Problem
    problem_sys_id: Optional[str] = None
    problem_number: Optional[str] = None
    # FK for RAISED_BY relationship to Change
    caused_by_change_sys_id: Optional[str] = None
    caused_by_change_number: Optional[str] = None
    # FK for CHILD_OF relationship to parent Case
    parent_sys_id: Optional[str] = None
    parent_number: Optional[str] = None
    # Contact
    contact_name: Optional[str] = None
    contact_sys_id: Optional[str] = None
    # Resolution
    internal_resolution_notes: Optional[str] = None
    responsible_party: Optional[str] = None

    @field_validator("related_circuit_id", "circuit_id", mode="before")
    def coerce_circuit_id_to_string(cls, value):
        """Coerce integer circuit IDs to strings"""
        if value is None:
            return None
        return str(value) if isinstance(value, (int, float)) else value

    @field_validator("first_response_time", mode="before")
    def parse_datetime(cls, value):
        return value if isinstance(value, datetime) else None


class ProblemFields(BaseModel):
    """Problem-specific fields (only present when ticket_type='problem')"""
    category: Optional[str] = None
    subcategory: Optional[str] = None
    ci_class: Optional[str] = None
    segment_id: Optional[str] = None
    resolution_code: Optional[str] = None
    problem_source: Optional[str] = None
    problem_type: Optional[str] = None
    problem_duration: Optional[str] = None
    problem_duration_minutes: Optional[int] = None
    is_on_hold: Optional[bool] = None
    on_hold_reason: Optional[str] = None
    fix_notes: Optional[str] = None
    internal_fix_notes: Optional[str] = None
    fixed_on: Optional[datetime] = None
    is_customer_visible: Optional[bool] = None
    first_reported_by_task_sys_id: Optional[str] = None
    first_reported_by_task_number: Optional[str] = None

    @field_validator("fixed_on", mode="before")
    def parse_datetime(cls, value):
        return value if isinstance(value, datetime) else None


class RequestFields(BaseModel):
    """Request-specific fields (only present when ticket_type='request')

    SCTASK is the ticket. REQ, RITM, and Case are reference metadata.
    - ticket_sys_id → OperationalStatus.ticket_sys_id (SCTASK sys_id)
    - ticket_id → TicketInfo.ticket_id (SCTASK number)
    """
    # Reference metadata
    req_number: Optional[str] = None      # Parent REQ (REQ0026086)
    ritm_number: Optional[str] = None     # Parent RITM (RITM0028790)
    case_number: Optional[str] = None     # Parent Case if exists (CS0070665)
    # Request item details
    request_item_name: Optional[str] = None   # e.g., "Root Cause Analysis"
    request_item_form: Optional[str] = None   # e.g., "Security - Other"
    request_item_type: Optional[str] = None   # e.g., "Change Service Configuration"


# =============================================================================
# NEW: Change-Specific Models (for tickets.change stream)
# =============================================================================

class ChangeFields(BaseModel):
    """Fields specific to Change records - infrastructure-level, no client_id"""
    change_type: Optional[str] = None        # Normal, Standard, Emergency
    work_type: Optional[str] = None          # Service Affecting, Non-Service Affecting
    source: Optional[str] = None             # External, Internal

    # Planned work
    planned_start_date: Optional[datetime] = None
    planned_end_date: Optional[datetime] = None
    backup_start_date: Optional[datetime] = None
    backup_end_date: Optional[datetime] = None
    impact_duration: Optional[str] = None
    impact_duration_minutes: Optional[int] = None

    # Plans
    implementation_plan: Optional[str] = None
    backout_plan: Optional[str] = None
    test_plan: Optional[str] = None
    risk_impact_analysis: Optional[str] = None
    justification: Optional[str] = None

    # Location
    country: Optional[str] = None
    city: Optional[str] = None
    planned_work_location: Optional[str] = None

    # Risk flags
    risk: Optional[str] = None
    security_risk: Optional[bool] = None
    modification_of_access: Optional[bool] = None
    core_network: Optional[bool] = None
    critical_systems: Optional[bool] = None

    # CAB (Change Advisory Board)
    cab_date_time: Optional[datetime] = None
    is_cab_required: Optional[bool] = None
    is_postponed: Optional[bool] = None

    # Supplier
    supplier_sys_id: Optional[str] = None
    supplier_name: Optional[str] = None
    supplier_reference: Optional[str] = None
    vendor_id: Optional[str] = None

    # Implementation
    implemented_by_sys_ids: Optional[str] = None
    implemented_by_names: Optional[str] = None
    requested_by_sys_id: Optional[str] = None
    requested_by: Optional[str] = None
    requested_by_date: Optional[datetime] = None

    # Impact metrics
    impacted_services_count: Optional[int] = None
    planned_work_reason: Optional[str] = None

    # Second backup window
    second_backup_start_date: Optional[datetime] = None
    second_backup_end_date: Optional[datetime] = None

    # Additional flags
    is_inside_blackout_schedule: Optional[bool] = None
    is_suppress_client_notifications: Optional[bool] = None
    modification_of_cryptographic: Optional[bool] = None

    @field_validator("planned_start_date", "planned_end_date", "backup_start_date",
                     "backup_end_date", "cab_date_time", "requested_by_date",
                     "second_backup_start_date", "second_backup_end_date", mode="before")
    def parse_datetime(cls, value):
        return value if isinstance(value, datetime) else None


class ChangeTaskInfo(BaseModel):
    """CTASK - Change task (snow_tsm_change_task)"""
    task_sys_id: str = Field(..., description="Task sys_id - primary key")
    task_number: str = Field(..., description="Human-readable task number (CTASK*)")
    task_type: Literal["ctask"] = "ctask"
    change_sys_id: str = Field(..., description="Parent change sys_id")
    change_number: str = Field(..., description="Parent change number (CHG*)")
    short_description: Optional[str] = None
    state: Optional[str] = None
    priority: Optional[int] = None

    # Change task specific
    change_category: Optional[str] = None
    change_subcategory: Optional[str] = None
    fulfillment: Optional[bool] = None
    follow_up_needed: Optional[bool] = None
    implemented_in_timeframe: Optional[bool] = None
    unexpected_consequences: Optional[bool] = None
    closure_responsibility: Optional[str] = None
    responsible_team: Optional[str] = None

    # Assignment
    assignment_group: Optional[str] = None
    assigned_to: Optional[str] = None
    assigned_to_sys_id: Optional[str] = None

    # Lifecycle
    created_on: Optional[datetime] = None
    created_by: Optional[str] = None
    updated_on: Optional[datetime] = None
    closed_on: Optional[datetime] = None
    closed_by: Optional[str] = None
    closed_by_sys_id: Optional[str] = None

    @field_validator("created_on", "updated_on", "closed_on", mode="before")
    def parse_datetime(cls, value):
        return value if isinstance(value, datetime) else None


class CaseTaskInfo(BaseModel):
    """CSTASK - Case task (snow_tsm_case_task)"""
    task_sys_id: str = Field(..., description="Task sys_id - primary key")
    task_number: str = Field(..., description="Human-readable task number (CSTASK*)")
    task_type: Literal["cstask"] = "cstask"
    parent_case_sys_id: str = Field(..., description="Parent case sys_id")
    parent_case_number: str = Field(..., description="Parent case number (CS*)")
    short_description: Optional[str] = None
    state: Optional[str] = None
    priority: Optional[int] = None

    # Case task specific
    service_type: Optional[str] = None
    third_party_sys_id: Optional[str] = None
    third_party_name: Optional[str] = None
    third_party_ticket: Optional[str] = None
    third_party_score: Optional[str] = None

    # Assignment
    assignment_group: Optional[str] = None
    assigned_to: Optional[str] = None
    assigned_to_sys_id: Optional[str] = None

    # Vendor
    vendor_id: Optional[str] = None
    vendor_name: Optional[str] = None

    # Lifecycle
    created_on: Optional[datetime] = None
    created_by: Optional[str] = None
    updated_on: Optional[datetime] = None
    closed_on: Optional[datetime] = None
    closed_by: Optional[str] = None
    closed_by_sys_id: Optional[str] = None

    @field_validator("vendor_id", mode="before")
    def coerce_vendor_id_to_string(cls, value):
        """Coerce integer vendor IDs to strings"""
        if value is None:
            return None
        return str(value) if isinstance(value, (int, float)) else value

    @field_validator("created_on", "updated_on", "closed_on", mode="before")
    def parse_datetime(cls, value):
        return value if isinstance(value, datetime) else None


# =============================================================================
# NEW: Configuration Item Model (for CI service mapping)
# =============================================================================

class ConfigurationItem(BaseModel):
    """Configuration Item (CI) - represents circuits/services affected by tickets"""
    ci_sys_id: str = Field(..., description="CI sys_id - primary key")
    ci_name: Optional[str] = Field(None, description="CI name/circuit identifier (e.g., GTT/002605906)")
    is_manually_added: Optional[bool] = Field(None, description="Whether CI was manually added")


# =============================================================================
# NEW: Task Models (separate class per task type)
# =============================================================================

class IncidentTaskInfo(BaseModel):
    """TASK - Incident task (snow_tsm_incident_task)"""
    task_sys_id: str = Field(..., description="Task sys_id - primary key")
    task_number: str = Field(..., description="Human-readable task number (TASK*)")
    task_type: Literal["task"] = "task"
    task_state: Optional[str] = None
    short_description: Optional[str] = None
    priority: Optional[int] = None
    assigned_to: Optional[str] = None
    assigned_to_sys_id: Optional[str] = None
    assignment_group: Optional[str] = None
    created_on: Optional[datetime] = None
    closed_on: Optional[datetime] = None
    # Incident task specific
    closure_code: Optional[str] = None
    third_party_name: Optional[str] = None
    third_party_ticket: Optional[str] = None
    vendor_id: Optional[str] = None

    @field_validator("vendor_id", mode="before")
    def coerce_vendor_id_to_string(cls, value):
        """Coerce integer vendor IDs to strings"""
        if value is None:
            return None
        return str(value) if isinstance(value, (int, float)) else value

    @field_validator("created_on", "closed_on", mode="before")
    def parse_datetime(cls, value):
        return value if isinstance(value, datetime) else None


class ProblemTaskInfo(BaseModel):
    """PTASK - Problem task (snow_tsm_problem_task)"""
    task_sys_id: str = Field(..., description="Task sys_id - primary key")
    task_number: str = Field(..., description="Human-readable task number (PTASK*)")
    task_type: Literal["ptask"] = "ptask"
    task_state: Optional[str] = None
    short_description: Optional[str] = None
    priority: Optional[int] = None
    assigned_to: Optional[str] = None
    assigned_to_sys_id: Optional[str] = None
    assignment_group: Optional[str] = None
    created_on: Optional[datetime] = None
    closed_on: Optional[datetime] = None
    # Problem task specific
    cause_code: Optional[str] = None
    cause_notes: Optional[str] = None
    is_pending: Optional[bool] = None
    started_on: Optional[datetime] = None
    close_notes: Optional[str] = None

    @field_validator("created_on", "closed_on", "started_on", mode="before")
    def parse_datetime(cls, value):
        return value if isinstance(value, datetime) else None


class SCTaskInfo(BaseModel):
    """SCTASK - Service Catalog task (snow_tsm_request)"""
    task_sys_id: str = Field(..., description="Task sys_id - primary key")
    task_number: str = Field(..., description="Human-readable task number (SCTASK*)")
    task_type: Literal["sctask"] = "sctask"
    task_state: Optional[str] = None
    short_description: Optional[str] = None
    priority: Optional[int] = None
    assigned_to: Optional[str] = None
    assigned_to_sys_id: Optional[str] = None
    assignment_group: Optional[str] = None
    created_on: Optional[datetime] = None
    closed_on: Optional[datetime] = None
    # SCTASK specific
    ritm_number: Optional[str] = None
    request_item_name: Optional[str] = None
    case_number: Optional[str] = None  # reference to parent case

    @field_validator("created_on", "closed_on", mode="before")
    def parse_datetime(cls, value):
        return value if isinstance(value, datetime) else None


# Union type for all task types with discriminator
TaskType = Annotated[
    Union[IncidentTaskInfo, CaseTaskInfo, ProblemTaskInfo, ChangeTaskInfo, SCTaskInfo],
    Discriminator('task_type')
]


# =============================================================================
# OperationalStatus (extended with TSM fields)
# =============================================================================

class OperationalStatus(BaseModel):
    # Existing nested objects
    service_entity: ServiceEntity
    fault_info: FaultInfo
    ticket_info: TicketInfo
    outage_info: OutageInfo
    noc_info: NOCInfo
    # Knowledge graph nodes for this specific ticket
    users: Optional[List[UserInfo]] = None
    maintenance_window: Optional[MaintenanceWindow] = None
    contacts: Optional[List[ContactInfo]] = None
    vendors: Optional[List[VendorInfo]] = None
    survey_info: Optional[SurveyInfo] = None

    # NEW: TSM extension fields
    ticket_type: Optional[Literal["incident", "case", "problem", "request", "cmd"]] = None
    ticket_sys_id: Optional[str] = Field(None, description="Ticket sys_id - use for joins")

    # NEW: Entity-specific fields (only one populated based on ticket_type)
    incident_fields: Optional[IncidentFields] = None
    case_fields: Optional[CaseFields] = None
    problem_fields: Optional[ProblemFields] = None
    request_fields: Optional[RequestFields] = None

    # NEW: Tasks (union of all task types, discriminated by task_type)
    tasks: Optional[List[TaskType]] = None

    # NEW: Configuration Items (circuits/services affected by this ticket)
    configuration_items: Optional[List[ConfigurationItem]] = None


# =============================================================================
# ClientInfo and TicketSummary (unchanged)
# =============================================================================

class ClientInfo(BaseModel):
    client_id: Optional[int] = None
    client_name: Optional[str] = None
    client_group: Optional[str] = None
    client_tier: Optional[str] = None
    channel: Optional[str] = None
    sales_division: Optional[str] = None
    market_segment: Optional[str] = None
    client_import_source: Optional[str] = None
    client_ticket: Optional[str] = None
    # From Client API (customer endpoint) - not on individual tickets
    default_noc_queue: Optional[str] = None
    incident_manager: Optional[str] = None
    service_manager: Optional[str] = None
    # NEW from API (not in DB)
    operations_specialist: Optional[str] = None
    operations_specialist_sys_id: Optional[str] = None


class TicketSummary(BaseModel):
    client_info: ClientInfo
    operational_status: List[OperationalStatus]

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


# =============================================================================
# NEW: Notes Models (for tickets.notes topic)
# =============================================================================

class TicketNote(BaseModel):
    """Individual note for a single ticket - structure TBD based on data source"""
    ticket_sys_id: str = Field(..., description="Ticket sys_id - links to ticket")
    ticket_id: str = Field(..., description="Human-readable ticket number")
    note_sys_id: Optional[str] = None
    note_text: Optional[str] = None
    note_type: Optional[str] = None  # work_note, customer_note, etc.
    created_on: Optional[datetime] = None
    created_by: Optional[str] = None

    @field_validator("created_on", mode="before")
    def parse_datetime(cls, value):
        return value if isinstance(value, datetime) else None


class NotesSummary(BaseModel):
    """Message published to tickets.notes topic -> Milvus - structure TBD"""
    notes_summary_id: str = Field(..., description="Unique identifier for this summary")
    client_id: str = Field(..., description="Client ID")
    part_number: int = Field(1, description="Part number (for large batches)")
    total_parts: int = Field(1, description="Total parts for this client")
    notes: List[TicketNote] = Field(..., description="Notes for embedding")

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


# =============================================================================
# NEW: Change Record and Batch (for tickets.change stream - infrastructure)
# =============================================================================

# Configurable batch size (default 100, ~696KB worst case, 68% of 1MB limit)
CHANGE_BATCH_SIZE = int(os.getenv("CHANGE_BATCH_SIZE", "100"))


class ChangeRecord(BaseModel):
    """A single change record with all its details - published via ChangeBatch.

    Changes are infrastructure-level records (no client_id).
    They link to clients indirectly through incidents/cases via:
    - caused_by_change_sys_id
    - related_change_sys_id
    """
    change_sys_id: str = Field(..., description="Change sys_id - primary key")
    change_number: str = Field(..., description="Human-readable change number (CHG*)")
    short_description: Optional[str] = None
    description: Optional[str] = None

    # Status
    change_state: Optional[str] = None
    category: Optional[str] = None
    subcategory: Optional[str] = None
    reason: Optional[str] = None

    # Change-specific fields (nested)
    change_fields: Optional[ChangeFields] = None

    # Tasks (embedded)
    tasks: List[ChangeTaskInfo] = Field(default_factory=list)

    # Assignment
    assignment_group: Optional[str] = None
    assigned_to: Optional[str] = None
    assigned_to_sys_id: Optional[str] = None

    # Lifecycle
    created_on: Optional[datetime] = None
    created_by: Optional[str] = None
    updated_on: Optional[datetime] = None
    closed_on: Optional[datetime] = None
    closed_by: Optional[str] = None
    closed_by_sys_id: Optional[str] = None
    close_code: Optional[str] = None
    close_notes: Optional[str] = None

    # Work tracking
    time_worked_minutes: Optional[int] = None
    support_area: Optional[str] = None
    contact_type: Optional[str] = None

    # Configuration Items (circuits/services affected)
    configuration_items: List[ConfigurationItem] = Field(default_factory=list)

    @field_validator("created_on", "updated_on", "closed_on", mode="before")
    def parse_datetime(cls, value):
        return value if isinstance(value, datetime) else None

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class ChangeBatch(BaseModel):
    """Batch of changes - published to tickets.change topic.

    Changes are batched (default 100/batch) to stay under NATS message size limits.
    At 100 changes/batch: ~696KB worst case (68% of 1MB limit).
    """
    changes: List[ChangeRecord] = Field(..., description="Changes in this batch")
    batch_number: int = Field(..., description="Batch number (1-based)")
    total_batches: int = Field(..., description="Total number of batches")
    total_changes: int = Field(..., description="Total changes across all batches")
    extraction_time: datetime = Field(..., description="When extraction occurred")

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }
