# Standard library imports
import asyncio
import nest_asyncio
from contextlib import asynccontextmanager

# Third-party imports
import httpx

# FastMCP-specific imports
from fastmcp import FastMCP

# Local utility imports
from utils.memgraph_utils import ensure_memgraph_initialized

# from utils.baml_utils import init_baml
from utils.baml_utils import BAMLService
from configs.config import Config
from utils.utilities import Helpers

# Your project-specific imports
from data_access.memgraphClient import MemgraphClient
from services.ticket_loader import DataLoader


# Deferred import - moved to app_init() to avoid premature module loading

import logging

logging.basicConfig(level=logging.WARNING, format="%(asctime)s - %(levelname)s - %(message)s")

# Load config values
config = Config()
MEMGRAPH_URI = config.memgraph_uri
MEMGRAPH_USER = config.memgraph_user
MEMGRAPH_PASSWORD = config.memgraph_password
MEMGRAPH_DATABASE = config.memgraph_database
LLM_TEMPERATURE = config.llm_temperature
NATS_URL = config.nats_url
JETSTREAM_STREAM_NAME = config.jetstream_stream_name
TICKET_PUBLISH_SUBJECT = config.ticket_publish_subject
TICKET_SUBSCRIBE_SUBJECT = config.ticket_subscribe_subject


# --- Application Lifecycle Management ---
async def startup_services():
    logging.info("Startup: Initializing services...")

    # Ensure required directories exist
    import os
    from pathlib import Path
    # Determine logs directory: use /app/logs in Docker, otherwise use ./logs relative to current directory
    logs_dir = Path("/app/logs") if os.path.exists("/app") else Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")
    logs_dir.mkdir(parents=True, exist_ok=True)
    logging.info(f"Ensured log directory exists: {logs_dir}")

    # ============================================================================
    # Phase 1: Initialize Extensibility Hooks
    # ============================================================================

    # --- Initialize Observability Hooks ---
    if config.observability_enabled:
        logging.info("Initializing observability hooks...")
        # Note: Actual providers (Prometheus, OpenTelemetry) will be implemented in Phase 2
        # For now, hooks are in place but using NoOp implementations
        from utils.observability import set_metrics_collector, set_tracing_provider
        # Future: set_metrics_collector(PrometheusMetrics()) when Phase 2 implemented
        logging.info("Observability hooks initialized (NoOp mode)")

    # --- Initialize Security Hooks ---
    if config.auth_enabled:
        logging.info(f"Initializing authentication: provider={config.auth_provider}")
        from utils.security import set_authenticator
        # Future: set_authenticator(APIKeyAuthenticator(...)) when Phase 2 implemented
        logging.info("Authentication hooks initialized (NoOp mode - no auth required)")

    if config.audit_enabled:
        logging.info(f"Initializing audit logging: file={config.audit_log_file}")
        from utils.security import set_audit_logger, FileAuditLogger
        set_audit_logger(FileAuditLogger(config.audit_log_file))
        logging.info("Audit logging enabled")

    # --- Initialize LLM Validation Hooks ---
    if config.llm_validation_enabled:
        logging.info(f"Initializing LLM validator: type={config.llm_validator_type}")
        from utils.llm_validators import set_cypher_validator, BasicCypherValidator
        if config.llm_validator_type == "basic":
            validator = BasicCypherValidator(
                allow_writes=config.allow_write_queries,
                max_query_length=10000,
                max_clauses=20
            )
            set_cypher_validator(validator)
            logging.info("LLM validation enabled (basic validator)")
        else:
            logging.info("LLM validation hooks initialized (NoOp mode)")

    # --- Initialize LLM Observability Hooks ---
    if config.llm_observability_enabled:
        logging.info(f"Initializing LLM observability: provider={config.llm_observability_provider}")
        from utils.llm_observability import set_llm_observability_provider, ConsoleLLMObservability

        if config.llm_observability_provider == "console":
            provider = ConsoleLLMObservability(
                log_prompts=config.llm_log_prompts,
                log_responses=config.llm_log_responses
            )
            set_llm_observability_provider(provider)
            logging.info("LLM observability enabled (console logger)")

        # Phase 2: Opik/MLflow will be added here after platform decision
        # elif config.llm_observability_provider == "opik":
        #     from utils.opik_provider import OpikProvider
        #     set_llm_observability_provider(OpikProvider(api_key=...))
        #
        # elif config.llm_observability_provider == "mlflow":
        #     from utils.mlflow_provider import MLflowProvider
        #     set_llm_observability_provider(MLflowProvider(experiment_name=...))

        else:
            logging.info("LLM observability hooks initialized (NoOp mode)")

    logging.info("Phase 1 hooks initialized successfully")

    memgraph_client = MemgraphClient(
        uri=MEMGRAPH_URI,
        user=MEMGRAPH_USER,
        password=MEMGRAPH_PASSWORD,
        database=MEMGRAPH_DATABASE
    )
    await ensure_memgraph_initialized(memgraph_client)

    ticket_schema_description = Helpers.load_cypher_configs(config.schema_desc_path)

    baml_service = BAMLService()
    baml_registry = await baml_service.init_baml()
    if baml_registry:
        logging.info("BAML initialized successfully.")
    else:
        logging.error("Failed to initialize BAML. This may impact AI functionalities.")

    # Import the actual BAML client with TranslateToCypher function
    from baml_client import b as baml_client
    logging.info("BAML client imported for tool functions.")

    http_client = httpx.AsyncClient(timeout=30.0)
    logging.info("HTTP client initialized.")

    # Initialize semantic search service (Phase 3: Vector Search)
    from services.semantic_search_service import SemanticSearchService
    semantic_search_service = None
    try:
        semantic_search_service = SemanticSearchService(config)
        await semantic_search_service.connect()
        # Load collection into memory for search operations
        semantic_search_service.milvus_client.load_collection()
        logging.info("✅ Semantic search service initialized (Milvus, Memgraph, Ollama)")
        logging.info("✅ Milvus collection loaded into memory")
    except ConnectionError as e:
        # Specific connection errors (Milvus or Ollama)
        logging.error(f"❌ Connection error during semantic search initialization: {e}")
        logging.warning("⚠️  Vector search tools will NOT be available")
        logging.warning("⚠️  Check service availability and configuration:")
        logging.warning(f"   - Milvus: {config.milvus_host}:{config.milvus_port}")
        logging.warning(f"   - Ollama: {config.ollama_embedding_base_url}")
        # Don't fail startup, continue without semantic search
    except Exception as e:
        # Other unexpected errors
        logging.error(f"❌ Unexpected error initializing semantic search service: {e}", exc_info=True)
        logging.warning("⚠️  Vector search tools will NOT be available")
        # Don't fail startup, just log the error

    background_tasks = []

    # Ticketing consumer using wildcard subscription
    async def ticketing_ingestion():
        """Ticketing consumer for tickets.created, tickets.change, and tickets.fault_description"""
        try:
            # Import handlers
            from services.fault_description_loader import FaultDescriptionLoader
            from services.change_loader import ChangeLoader
            from services.notes_extraction_pipeline import NotesExtractionPipeline

            # Initialize ticket handler
            data_loader = DataLoader(
                memgraphClient=memgraph_client,
                nats_url=NATS_URL,
                stream_name=JETSTREAM_STREAM_NAME,
                subject="tickets.*",  # Wildcard subscription - handles all ticket topics
            )

            # Initialize fault description handler
            fault_desc_handler = None
            if semantic_search_service:
                fault_desc_loader = FaultDescriptionLoader(
                    milvus_client=semantic_search_service.milvus_client,
                    embedding_service=semantic_search_service.embedding_service,
                    nats_url=NATS_URL,
                    stream_name=JETSTREAM_STREAM_NAME,
                    subject="tickets.fault_description",
                )
                fault_desc_handler = fault_desc_loader.handle_fault_description_message

            # Initialize change handler (infrastructure changes → Memgraph)
            change_loader = ChangeLoader(
                memgraph_client=memgraph_client,
                config=config,
            )
            change_handler = change_loader.handle_change_message

            # Create separate semaphores (semaBouncers!) for each message type
            memgraph_semaphore = asyncio.Semaphore(config.memgraph_max_concurrent)
            milvus_semaphore = asyncio.Semaphore(config.milvus_max_concurrent)
            change_semaphore = asyncio.Semaphore(config.memgraph_max_concurrent)  # Changes also go to Memgraph
            logging.info(f"🚪 Created semaBouncers: Memgraph={config.memgraph_max_concurrent}, Milvus={config.milvus_max_concurrent}")

            # Unified message router with subject-specific concurrency control
            async def route_message(msg):
                """Route message based on subject with subject-specific concurrency control"""
                try:
                    if msg.subject == "tickets.created":
                        # Client-grouped tickets → Memgraph
                        async with memgraph_semaphore:
                            await data_loader.handle_ticket_message(msg)
                    elif msg.subject == "tickets.change":
                        # Infrastructure changes → Memgraph (batched)
                        async with change_semaphore:
                            await change_handler(msg)
                    elif msg.subject == "tickets.fault_description":
                        # Fault descriptions → Milvus (for embedding/vector search)
                        if fault_desc_handler:
                            async with milvus_semaphore:
                                await fault_desc_handler(msg)
                        else:
                            logging.warning(f"⚠️  Received fault description but handler not available, ACK'ing")
                            await msg.ack()
                    else:
                        logging.warning(f"⚠️  Unknown subject: {msg.subject}, ACK'ing")
                        await msg.ack()
                except Exception as e:
                    logging.error(f"❌ Error routing message from {msg.subject}: {e}", exc_info=True)
                    # ACK to avoid infinite retry
                    try:
                        await msg.ack()
                    except:
                        pass

            # Start ticketing consumer
            logging.info("🚀 Starting ticketing consumer (tickets.* → Memgraph & Milvus)...")
            await data_loader.ticket_consumer.connect()
            logging.info("✅ Ticketing consumer connected and listening for tickets.created, tickets.change, and tickets.fault_description")

            # Initialize notes extraction pipeline (runs after 5 min idle)
            notes_pipeline = NotesExtractionPipeline(
                memgraph_client=memgraph_client,
                config=config,
            )

            # Start background checker
            asyncio.create_task(notes_pipeline.start_background_checker())

            # Wrap route_message to track last message time
            async def route_message_with_tracking(msg):
                await route_message(msg)
                notes_pipeline.on_message_processed()

            await data_loader.ticket_consumer.subscribe(route_message_with_tracking)

        except Exception as e:
            logging.error(f"❌ Error in ticketing consumer: {e}", exc_info=True)

    # Start ticketing consumer as single background task
    ticketing_task = asyncio.create_task(ticketing_ingestion(), name="Ticketing-Consumer")
    background_tasks.append(ticketing_task)
    logging.info("✅ Ticketing consumer scheduled (tickets.* → Memgraph & Milvus)")

    # Initialize Milvus notes client for ticket summaries
    from data_access.milvus_notes_client import MilvusNotesClient
    milvus_notes_client = None
    try:
        milvus_notes_client = MilvusNotesClient(config)
        milvus_notes_client.connect()
        milvus_notes_client.load_collection()
        logging.info("✅ Milvus notes client initialized (ticket_notes collection)")
    except Exception as e:
        logging.warning(f"⚠️  Could not initialize Milvus notes client: {e}")

    return {
        "memgraph_client": memgraph_client,
        "ticket_schema_description": ticket_schema_description,
        "baml_registry": baml_registry,  # LLM configuration registry
        "baml_client": baml_client,  # Actual BAML client with functions like TranslateToCypher
        "http_client": http_client,
        "semantic_search_service": semantic_search_service,  # Phase 3: Vector search service
        "milvus_notes_client": milvus_notes_client,  # For ticket summary lookup
        "background_tasks": background_tasks,
    }


async def shutdown_services(services):
    logging.info("Shutdown: Stopping services...")

    for task in services["background_tasks"]:
        if not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                logging.info(f"Background task '{task.get_name()}' cancelled.")
            except Exception as e:
                logging.error(f"Error during background task cancellation/await: {e}", exc_info=True)

    if services.get("semantic_search_service"):
        try:
            services["semantic_search_service"].disconnect()
            logging.info("Semantic search service disconnected")
        except Exception as e:
            logging.error(f"Error disconnecting semantic search service: {e}")

    if services.get("milvus_notes_client"):
        try:
            services["milvus_notes_client"].disconnect()
            logging.info("Milvus notes client disconnected")
        except Exception as e:
            logging.error(f"Error disconnecting Milvus notes client: {e}")

    if services["memgraph_client"]:
        services["memgraph_client"].shutdown()
    if services["http_client"]:
        await services["http_client"].aclose()
    logging.info("All services shut down.")


@asynccontextmanager
async def lifespan(app):
    logging.info("🚀 Lifespan startup triggered")
    services = await startup_services()
    app.state.services = services
    yield
    logging.info("🛑 Lifespan shutdown triggered")
    await shutdown_services(services)


async def app_init():
    # Import here to avoid premature module loading at import time
    from services.register_mcp_components import RegisterMCPComponents, TOOLS_DETAILS, RESOURCES_DETAILS

    mcp = FastMCP(name="TicketServer")
    app = mcp.http_app()  # FastMCP HTTP app first

    # Register tools after app creation
    RegisterMCPComponents(mcp_app=mcp, tools_details=TOOLS_DETAILS, resources_details=RESOURCES_DETAILS).register()

    return app


def app_factory():
    nest_asyncio.apply()

    # Import and register outside asyncio context
    from services.register_mcp_components import RegisterMCPComponents, TOOLS_DETAILS, RESOURCES_DETAILS

    mcp = FastMCP(name="TicketServer")

    # Register tools FIRST, before creating HTTP app
    registrar = RegisterMCPComponents(mcp_app=mcp, http_app=None, tools_details=TOOLS_DETAILS, resources_details=RESOURCES_DETAILS)
    registrar.register()

    # Get the FastMCP HTTP app in stateless mode (no session IDs required)
    # This simplifies client implementation and improves scalability
    app = mcp.http_app(stateless_http=True)

    # NOW set the http_app reference so wrappers can access app.state.services
    registrar.http_app = app

    # DEBUG: Check registered tools
    import asyncio
    tools_dict = asyncio.run(mcp.get_tools())
    print(f"🔍 DEBUG: Total tools registered on mcp object: {len(tools_dict)}")
    semantic_tools = [name for name in tools_dict if 'search_similar' in name]
    print(f"🔍 DEBUG: Semantic search tools: {semantic_tools}")

    # Wrap the app's existing lifespan to add custom services
    original_lifespan = app.router.lifespan_context

    @asynccontextmanager
    async def combined_lifespan(app):
        services = None
        try:
            # Custom startup
            logging.info("🚀 Starting custom services...")
            services = await startup_services()
            app.state.services = services
            logging.info("✅ Custom services ready")

            # Run original FastMCP lifespan (initializes task group)
            async with original_lifespan(app):
                logging.info("✅ FastMCP task group initialized")
                yield  # App runs here

        except Exception as e:
            logging.error(f"❌ Startup failed: {e}", exc_info=True)
            raise
        finally:
            # Custom shutdown
            if services:
                logging.info("🛑 Shutting down custom services...")
                await shutdown_services(services)

    # Replace the lifespan context with our combined version
    app.router.lifespan_context = combined_lifespan

    # ============================================================================
    # Phase 1: Add Extensibility Middleware
    # ============================================================================

    # --- Add Authentication Middleware (if enabled) ---
    if config.auth_enabled:
        from utils.security import AuthMiddleware
        app.add_middleware(AuthMiddleware)
        logging.info("Authentication middleware added")

    # Note: Observability middleware will be added in Phase 2 when implementing
    # Prometheus/OpenTelemetry integrations. For now, hooks are in place.

    # ============================================================================
    # Health Check & Metrics Endpoints
    # ============================================================================

    # Add health check endpoint (Starlette syntax)
    from starlette.responses import JSONResponse
    from starlette.routing import Route

    async def health_check(request):
        """Health check endpoint for Docker and Kubernetes"""
        return JSONResponse({
            "status": "healthy",
            "service": "mcp_ticket_server",
            "memgraph_connected": app.state.services.get("memgraph_client") is not None if hasattr(app.state, "services") else False,
            "observability_enabled": config.observability_enabled,
            "auth_enabled": config.auth_enabled,
            "audit_enabled": config.audit_enabled,
            "llm_validation_enabled": config.llm_validation_enabled,
            "llm_observability_enabled": config.llm_observability_enabled
        })

    # Add route to the existing router
    app.routes.append(Route("/health", health_check, methods=["GET"]))

    # ============================================================================
    # Feedback API Endpoints (SME feedback for training data collection)
    # ============================================================================

    from data_access.feedback_db import (
        init_db as init_feedback_db,
        submit_sme_feedback,
        upsert_audit_results,
        get_feedback,
        get_all_feedback,
        get_stats as get_feedback_stats,
        export_training_data,
    )

    # Initialize feedback DB on startup
    init_feedback_db()

    async def feedback_submit(request):
        """Submit SME feedback for a ticket audit"""
        try:
            body = await request.json()
            ticket_id = body.get("ticket_id")
            if not ticket_id:
                return JSONResponse({"error": "ticket_id required"}, status_code=400)

            # If sme_fields provided, store SME feedback
            if "sme_fields" in body:
                submit_sme_feedback(ticket_id, body["sme_fields"])

            # If ai_fields/snow_fields provided, store audit results
            if "ai_fields" in body or "snow_fields" in body:
                upsert_audit_results(
                    ticket_id=ticket_id,
                    ai_summary=body.get("ai_summary", ""),
                    chronology=body.get("chronology", ""),
                    snow_fields=body.get("snow_fields", {}),
                    ai_fields=body.get("ai_fields", {}),
                )

            return JSONResponse({"status": "ok", "ticket_id": ticket_id})
        except Exception as e:
            logging.error(f"Feedback submit error: {e}", exc_info=True)
            return JSONResponse({"error": str(e)}, status_code=500)

    async def feedback_get(request):
        """Get feedback for a specific ticket or all tickets"""
        ticket_id = request.query_params.get("ticket_id")
        if ticket_id:
            record = get_feedback(ticket_id)
            if not record:
                return JSONResponse({"error": "not found"}, status_code=404)
            return JSONResponse(record)
        else:
            records = get_all_feedback()
            return JSONResponse(records)

    async def feedback_stats(request):
        """Get feedback collection statistics"""
        return JSONResponse(get_feedback_stats())

    async def feedback_export(request):
        """Export training data (records with SME feedback)"""
        data = export_training_data()
        return JSONResponse(data)

    app.routes.append(Route("/api/feedback", feedback_submit, methods=["POST"]))
    app.routes.append(Route("/api/feedback", feedback_get, methods=["GET"]))
    app.routes.append(Route("/api/feedback/stats", feedback_stats, methods=["GET"]))
    app.routes.append(Route("/api/feedback/export", feedback_export, methods=["GET"]))

    # Future: Add /metrics endpoint for Prometheus when Phase 2 implemented
    # if config.metrics_provider == "prometheus":
    #     from prometheus_client import make_asgi_app
    #     metrics_app = make_asgi_app()
    #     app.mount("/metrics", metrics_app)

    return app


if __name__ == "__main__":
    import uvicorn
    # FIXED: Direct function reference, no path manipulation
    app = app_factory()
    uvicorn.run(app, host="0.0.0.0", port=8003, reload=False)
