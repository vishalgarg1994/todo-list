import asyncio
import nats
import logging
from nats.errors import NoServersError, TimeoutError
from typing import Tuple
from configs.config import Config

# Get configuration from environment
config = Config()


async def connect_nats() -> Tuple[nats.NATS, nats.js.JetStreamContext]:
    """Connects to NATS server and sets up JetStream subscription."""
    attempt = 0
    max_attempts = 5

    while attempt < max_attempts:
        try:
            if config.nats_user and config.nats_password:
                nc = await nats.connect(config.nats_url, user=config.nats_user, password=config.nats_password)
            else:
                nc = await nats.connect(config.nats_url)
            js = nc.jetstream()
            logging.info("✅ Connected to NATS!")

            # Ensure JetStream stream exists
            try:
                await js.stream_info(config.jetstream_stream_name)
                logging.info("⚡ Stream exists, skipping creation.")
            except Exception:
                await js.add_stream(name=config.jetstream_stream_name, subjects=[config.ticket_subscribe_subject])
                logging.info("✅ JetStream stream created.")

            return nc, js  # ✅ Return both instances

        except (NoServersError, TimeoutError) as e:
            logging.warning(f"⚠️ NATS connection failed (attempt {attempt + 1}): {e}. Retrying...")
        except Exception as e:
            logging.error(f"❌ Unexpected error during NATS setup: {e}")

        attempt += 1
        await asyncio.sleep(2**attempt)  # Exponential backoff

    raise Exception("Failed to connect to NATS after multiple attempts.")


async def shutdown_nats(nc: nats.NATS):
    """Gracefully shuts down NATS connection."""
    if nc:
        await nc.close()
        logging.info("🔌 NATS connection closed.")
