#!/usr/bin/env python3
"""
Check messages in EVA_TICKETING_STREAM
"""
import asyncio
import nats
import json

async def check_messages():
    """Peek at messages in the stream"""
    try:
        nc = await nats.connect("nats://localhost:4222")
        js = nc.jetstream()
        print("✅ Connected to NATS")

        # Get stream info
        stream_info = await js.stream_info("EVA_TICKETING_STREAM")
        print(f"\n📊 Stream: EVA_TICKETING_STREAM")
        print(f"   Total messages: {stream_info.state.messages}")
        print(f"   Subjects: {stream_info.config.subjects}")

        # List consumers
        print(f"\n👥 Consumers:")
        try:
            consumers = await js.consumers_info("EVA_TICKETING_STREAM")
            if not consumers:
                print("   No consumers found")
            else:
                for consumer in consumers:
                    print(f"\n   Consumer: {consumer.name}")
                    print(f"      Stream: {consumer.stream_name}")
                    print(f"      Filter: {consumer.config.filter_subject}")
                    print(f"      Delivered: {consumer.delivered.stream_seq}")
                    print(f"      Ack Pending: {consumer.num_ack_pending}")
                    print(f"      Pending: {consumer.num_pending}")
        except Exception as e:
            print(f"   Error listing consumers: {e}")

        # Sample a few messages
        print(f"\n📨 Sample messages (first 3):")
        try:
            # Create a temporary consumer to fetch messages
            temp_consumer = await js.pull_subscribe(
                "tickets.*",
                durable="temp_viewer"
            )

            for i in range(min(3, stream_info.state.messages)):
                try:
                    msgs = await temp_consumer.fetch(1, timeout=2)
                    if msgs:
                        msg = msgs[0]
                        data = json.loads(msg.data.decode())
                        print(f"\n   Message {i+1}:")
                        print(f"      Subject: {msg.subject}")
                        print(f"      Size: {len(msg.data)} bytes")
                        # Show just the keys to understand structure
                        if isinstance(data, dict):
                            print(f"      Keys: {list(data.keys())}")
                            if 'fault_description_summary_id' in data:
                                print(f"      Type: FaultDescriptionSummary")
                                print(f"      Client: {data.get('client_id', 'N/A')}")
                                print(f"      Fault count: {len(data.get('fault_descriptions', []))}")
                            elif 'ticket_id' in data:
                                print(f"      Type: Ticket")
                                print(f"      Ticket ID: {data.get('ticket_id', 'N/A')}")
                except Exception as e:
                    print(f"   Error fetching message {i+1}: {e}")
                    break

            # Delete temporary consumer
            try:
                await js.delete_consumer("EVA_TICKETING_STREAM", "temp_viewer")
            except:
                pass

        except Exception as e:
            print(f"   Error sampling messages: {e}")

        await nc.close()

    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(check_messages())
