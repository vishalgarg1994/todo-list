import asyncio
import logging
import os
from utils.config import Config
from services.pipeline_service import DataPipelineService
from services.scheduler import Scheduler
from services.health_service import HealthService
from services.http_server import HealthHTTPServer
from utils.connection_manager import ConnectionManager
from utils.logging_config import configure_logging
from utils.correlation import CorrelationContext
from utils.stream_validator import StreamValidator

# Configure structured logging based on environment
config_temp = Config()
log_level = config_temp.get("LOG_LEVEL", "INFO")
debug_mode = config_temp.get("DEBUG_MODE", "false").lower() == "true"
configure_logging(log_level, use_structured=not debug_mode)

logger = logging.getLogger(__name__)


# Dependency checking now handled by ConnectionManager


async def log_pending_tasks():
    pending_tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
    if pending_tasks:
        logger.debug(f"Background services: {len(pending_tasks)} tasks running")
        for task in pending_tasks:
            logger.debug(f"Task: {task.get_name()} - {task._coro}")


def exception_handler(loop, context):
    """Global exception handler for asyncio to catch NATS background task exceptions"""
    exception = context.get("exception")
    if exception:
        # Check if this is a NATS-related exception
        error_msg = str(exception).lower()
        if any(
            keyword in error_msg for keyword in ["nats", "connection", "timeout", "eof"]
        ):
            logger.warning(
                f"Background NATS task exception (non-critical): {exception}"
            )
        else:
            logger.error(
                f"Unhandled exception in background task: {exception}",
                exc_info=exception,
            )
    else:
        logger.error(f"Unhandled exception context: {context}")


async def main():
    """Start the application."""
    # Set global exception handler for background tasks
    loop = asyncio.get_running_loop()
    loop.set_exception_handler(exception_handler)

    # Instantiate config and connection manager
    config = Config()
    connection_manager = ConnectionManager(config)

    try:
        # TEMPORARY: Local testing bypass - skip DB connection
        skip_db = os.environ.get("SKIP_DB_CONNECTION", "false").lower() == "true"

        if skip_db:
            logger.warning("=" * 60)
            logger.warning("SKIP_DB_CONNECTION=true - Running without database")
            logger.warning("This mode is for LOCAL HELM TESTING ONLY")
            logger.warning("=" * 60)

            # Initialize NATS only (skip database)
            await connection_manager.initialize_nats_only()

            # Validate streams
            logger.info("Validating Eva messaging infrastructure streams...")
            stream_validator = StreamValidator()
            streams_valid = await stream_validator.validate_streams(
                connection_manager.get_nats_connection()
            )

            if not streams_valid:
                logger.error("Required Eva streams not found!")
                raise Exception(
                    "Eva messaging infrastructure streams not properly initialized"
                )

            # Create minimal health service without DB-dependent components
            health_service = HealthService(
                connection_manager=connection_manager,
                scheduler=None,
                nats_publisher=connection_manager.get_nats_publisher(),
                data_pipeline_service=None,
                version=config.get("APP_VERSION", "1.0.0"),
            )

            # Start health HTTP server
            health_port = int(config.get("HEALTH_PORT", "8080"))
            health_server = HealthHTTPServer(health_service, port=health_port)
            logger.info(f"Starting health endpoints on port {health_port}...")
            await health_server.start()

            # Keep running
            logger.info("Running in DB-bypass mode. Health server active.")
            while True:
                await asyncio.sleep(60)
            return
        # END TEMPORARY BYPASS

        # Initialize all connections through connection manager
        logger.info("Initializing connection manager...")
        await connection_manager.initialize()

        # Setup JetStream attributes
        # Validate Eva messaging infrastructure streams exist
        logger.info("Validating Eva messaging infrastructure streams...")
        stream_validator = StreamValidator()
        streams_valid = await stream_validator.validate_streams(
            connection_manager.get_nats_connection()
        )

        if not streams_valid:
            logger.error("Required Eva streams not found! Please run:")
            logger.error("  cd eva/messaging-infrastructure/nats")
            logger.error("  ./scripts/init-streams.sh")
            raise Exception(
                "Eva messaging infrastructure streams not properly initialized"
            )

        # Create pipeline service
        pipeline_service = DataPipelineService(connection_manager, config)

        # Create NATS publisher for health monitoring
        nats_publisher = connection_manager.get_nats_publisher()

        # Instantiate and start the scheduler
        scheduler = Scheduler(config=config, pipeline_service=pipeline_service)

        # Create health service with publisher metrics and data quality monitoring
        health_service = HealthService(
            connection_manager=connection_manager,
            scheduler=scheduler,
            nats_publisher=nats_publisher,
            data_pipeline_service=pipeline_service,
            version=config.get("APP_VERSION", "1.0.0"),
        )

        # Create and start health HTTP server
        health_port = int(config.get("HEALTH_PORT", "8080"))
        health_server = HealthHTTPServer(health_service, port=health_port)

        logger.info(f"Starting health endpoints on port {health_port}...")
        await health_server.start()

        # Start the scheduler
        await scheduler.start()

        # Keep the main task running to prevent the program from exiting
        while True:
            try:
                # ////////////////////////////
                await log_pending_tasks()  # Log any lingering tasks
                # ////////////////////////////

                # Perform health check to clean up any stale connections
                try:
                    health_status = await connection_manager.health_check()
                    # Log health status periodically (every 10 minutes)
                    if hasattr(main, "_last_health_log"):
                        import time

                        if time.time() - main._last_health_log > 600:  # 10 minutes
                            db_status = health_status.get("database", False)
                            nats_status = health_status.get("messaging", False)
                            logger.debug(
                                f"Health status: Database={db_status}, NATS={nats_status}"
                            )
                            main._last_health_log = time.time()
                    else:
                        import time

                        main._last_health_log = time.time()
                except Exception as health_error:
                    logger.warning(f"Health check error (non-critical): {health_error}")

                await asyncio.sleep(config.get_scheduler_interval())
            except Exception as e:
                # Log but don't exit - maintain resilience during runtime
                logger.error(f"Non-fatal error in main loop: {e}", exc_info=True)
                await asyncio.sleep(5)  # Brief pause before continuing

    except KeyboardInterrupt:
        logger.info("\nShutting down gracefully...")
        if "scheduler" in locals():
            logger.info("Stopping scheduler...")
            await scheduler.stop()

        if "health_server" in locals():
            logger.info("Stopping health server...")
            await health_server.stop()

        # Close all connections through connection manager
        logger.info("Closing connection manager...")
        await connection_manager.close()

        pending_tasks = [
            t for t in asyncio.all_tasks() if t is not asyncio.current_task()
        ]
        await asyncio.gather(
            *pending_tasks, return_exceptions=True  # Prevents "Task destroyed" error
        )

    finally:
        logger.info("Cleaning up pending async tasks...")
        pending_tasks = [
            t for t in asyncio.all_tasks() if t is not asyncio.current_task()
        ]
        await asyncio.gather(
            *pending_tasks, return_exceptions=True  # Ensures graceful exit
        )

        # Ensure connection manager is closed
        if "connection_manager" in locals():
            await connection_manager.close()


if __name__ == "__main__":
    with CorrelationContext() as correlation_id:
        logger.info(
            "Starting the application...", extra={"correlation_id": correlation_id}
        )
        asyncio.run(main())
