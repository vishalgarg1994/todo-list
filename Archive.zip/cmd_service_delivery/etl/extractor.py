"""
ETL Extractor: polls the CMD server (mock or real) for newly completed tasks
via the ai_tasks GraphQL query with a min_timestamp watermark, then fetches
full order data for each discovered service_order_id.

Flow (mirrors get_data.py):
  1. Query ai_tasks(min_timestamp=watermark) → unique service_order_ids
  2. For each order:
     a. service_order   (GraphQL getSO)
     b. segment details (GraphQL getSeg per segment)
     c. vendor details  (GraphQL getV per vendor)
     d. task list       (GraphQL getTasks)
     e. order notes     (GraphQL getNotes)
  3. Return OrderPayloads + advance watermark
"""

import logging
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple

import httpx

from config import Config
from models import (
    Note, Order, OrderPayload, OrderStatus, Segment, Service,
    ServiceType, Task, Vendor,
)

logger = logging.getLogger(__name__)

# Task labels the pipeline tracks (same as get_data.py / mock server)
TRACKED_LABELS = [
    "IP Assign - Off Net", "IP Assign - On Net", "IP Assign - VPN Port",
    "IP Assign - PA Space", "IP Assign - Off Net (Exotic)", "IP Assign - MPLS Port",
    "IP Assign Management - ROW", "IP Assign Management - North America",
    "IP Assign - Linknet", "IP Assign - Lease", "IP Assign - LAN", "IP Assign - IP Port",
    "Confirm - EISD",
    "Loop - FOC", "Loop - Send ASR", "Loop - Install",
]

DISPATCH_LABELS = [
    "Requested Dispatch Date - Site Survey",
    "Requested Dispatch Date (FSM)",
    "Requested Dispatch Date - Site Survey - Outdoor",
    "Requested Dispatch Date - Vendor Meet",
    "Requested Dispatch Date - Wiring",
]


# ── GraphQL queries (matching get_data.py exactly) ───────────────────────────

Q_COMPLETED_TASKS = """
query testTasks($min_ts: String!, $limit: Int!) {
    ai_tasks(
        args: {min_timestamp: $min_ts},
        where: {
            _or: [
                {wq_task_type_id_label: {_in: $tracked_labels}},
                {wq_task_type_id_label: {_regex: "^Complete Order"}},
                {wq_task_type_id_label: {_regex: "^GTT FOC"}}
            ],
            status_label: {_eq: "Completed"}
        },
        limit: $limit
    ) {
        task_id
        service_order_id
        wq_task_type_id_label
        status_label
        completed_on
    }
}
"""

Q_SERVICE_ORDER = """
query getSO($order_id: Int!) {
    service_order(where: {id: {_eq: $order_id}}) {
        latest_status
        qj_client_id
        comments
        service {
            id
            gtt_foc_ready
            foc_status_date
            gii_foc_date
            service_type { name }
            segments(where: {a_vendor_id: {_neq: 1398}, category: {_eq: 1}}) {
                id comments category created_on last_updated_on
                foc_date service_start_date order_confirmed_date equipment_shipment_date
                a_company_name a_demarc a_vendor_id
                z_company_name z_demarc z_vendor_id
                vendor_circuit_id
            }
        }
        service_order_status { id label main }
    }
}
"""

Q_SEGMENT = """
query getSegment($id: Int!) {
    segment(where: {id: {_eq: $id}}) {
        id product_type cpe_hostname comments created_on last_updated_on
        iw_date dlr_date foc_date cancel_date asr_sent_date term_end_date
        loop_test_date provisioned_date service_start_date order_confirmed_date
        equipment_shipment_date
        a_company_name a_company_code a_address a_floor a_room a_rack
        a_city a_state a_country_id a_demarc a_site_poc a_vendor_id
        z_company_name z_company_code z_address z_floor z_room z_rack
        z_city z_state z_country_id z_demarc z_site_poc z_vendor_id
        vendor_circuit_id vendor_order_id vendor_sla vendor_quote_id
        vendor_requested_due_date vendor_gateway_ip vendor_usable_ip
        vendor_network_ip vendor_product_id vendor_subnet_mask
        vendor_circuit_gnid vendor_pin
    }
}
"""

Q_VENDOR = """
query getVendor($id: Int!) {
    vendor(where: {id: {_eq: $id}}) { id name legal_name }
}
"""

Q_TASKS_BY_ORDER = """
query getTasks($oid: Int!) {
    ai_tasks_by_service_order(args: {service_order_id: $oid}) {
        task_id status summary
    }
}
"""

Q_ORDER_NOTES = """
query getOrderNotes($order_id: Int!) {
    order_notes(args: {service_order_id: $order_id}) {
        subject body created_on created_by_name
    }
}
"""


class CMDExtractor:
    """
    Polls the CMD GraphQL API for newly completed tasks, then fetches
    full order data for each discovered service_order_id.
    Maintains a watermark to only fetch incremental changes.
    """

    def __init__(self, config: Config):
        self.config = config
        self.watermark: str = config.initial_watermark
        self.processed_order_ids: Set[int] = set()
        self._vendor_cache: Dict[int, Vendor] = {}

    async def _gql(self, client: httpx.AsyncClient, query: str, variables: dict = None) -> dict:
        """Execute a GraphQL query against the CMD server."""
        resp = await client.post(
            self.config.cmd_graphql_url,
            json={"query": query, "variables": variables or {}},
            headers={
                "Authorization": f"Bearer {self.config.cmd_token}",
                "Content-Type": "application/json",
            },
        )
        resp.raise_for_status()
        return resp.json()

    # ── Poll for new tasks ────────────────────────────────────────────────

    async def poll(self) -> Tuple[List[OrderPayload], dict]:
        """
        Single poll cycle:
          1. Query ai_tasks with min_timestamp = watermark
          2. Discover new service_order_ids
          3. Fetch full order data for each
          4. Advance watermark

        Returns (payloads, stats_dict).
        """
        async with httpx.AsyncClient(timeout=30.0) as client:
            # Step 1: fetch completed tasks since watermark
            all_labels = TRACKED_LABELS + DISPATCH_LABELS
            tasks_result = await self._gql(client, Q_COMPLETED_TASKS, {
                "min_ts": self.watermark,
                "tracked_labels": all_labels,
                "limit": self.config.poll_batch_limit,
            })

            tasks = tasks_result.get("data", {}).get("ai_tasks", [])
            if not tasks:
                logger.info("No new tasks since %s", self.watermark)
                return [], {"new_tasks": 0, "new_orders": 0, "watermark": self.watermark}

            logger.info("Discovered %d completed tasks since %s", len(tasks), self.watermark)

            # Step 2: extract unique order IDs, skip already processed
            new_order_ids: List[int] = []
            seen = set()
            latest_completed_on = self.watermark

            for t in tasks:
                oid = t.get("service_order_id")
                completed_on = t.get("completed_on", "")
                if completed_on > latest_completed_on:
                    latest_completed_on = completed_on

                if oid and oid not in self.processed_order_ids and oid not in seen:
                    seen.add(oid)
                    new_order_ids.append(oid)

            logger.info("Found %d new order IDs to ingest (skipped %d already processed)",
                        len(new_order_ids), len(seen) - len(new_order_ids) + (len(tasks) - len(seen)))

            # Step 3: fetch full data for each order
            payloads: List[OrderPayload] = []
            for oid in new_order_ids:
                try:
                    payload = await self._fetch_order(client, oid)
                    if payload:
                        payloads.append(payload)
                        self.processed_order_ids.add(oid)
                        logger.info("Fetched order %d (%d segments, %d tasks, %d notes)",
                                    oid,
                                    len(payload.segments),
                                    len(payload.order.tasks),
                                    len(payload.order.notes))
                except Exception as e:
                    logger.error("Failed to fetch order %d: %s", oid, e)

            # Step 4: advance watermark
            self.watermark = latest_completed_on
            logger.info("Watermark advanced to %s", self.watermark)

            stats = {
                "new_tasks": len(tasks),
                "new_orders": len(payloads),
                "skipped": len(new_order_ids) - len(payloads),
                "total_processed": len(self.processed_order_ids),
                "watermark": self.watermark,
            }
            return payloads, stats

    # ── Fetch a single order with all related data ────────────────────────

    async def _fetch_order(self, client: httpx.AsyncClient, oid: int) -> Optional[OrderPayload]:
        """
        Fetch full order data via GraphQL, mirroring get_data.py:
          1. service_order (with inline segments)
          2. deep segment details
          3. vendor details
          4. tasks
          5. notes
        """
        # 1. Service Order
        so_result = await self._gql(client, Q_SERVICE_ORDER, {"order_id": oid})
        so_list = so_result.get("data", {}).get("service_order", [])
        if not so_list:
            logger.warning("Order %d not found in CMD", oid)
            return None

        entry = so_list[0]
        svc_raw = entry.get("service") or {}
        service = None
        if svc_raw.get("id"):
            service = Service(
                id=svc_raw["id"],
                service_type=ServiceType(**svc_raw["service_type"]) if svc_raw.get("service_type") else None,
                gtt_foc_ready=svc_raw.get("gtt_foc_ready"),
                foc_status_date=svc_raw.get("foc_status_date"),
                gii_foc_date=svc_raw.get("gii_foc_date"),
            )

        status_raw = entry.get("service_order_status") or {}
        order = Order(
            id=oid,
            latest_status=entry.get("latest_status"),
            qj_client_id=entry.get("qj_client_id"),
            comments=entry.get("comments"),
            service=service,
            service_order_status=OrderStatus(**status_raw) if status_raw else None,
        )

        # 2. Segments — get IDs from inline, then deep-fetch each
        inline_segments = svc_raw.get("segments", [])
        seg_ids = [s["id"] for s in inline_segments if s.get("id")]

        segments: List[Segment] = []
        for sid in seg_ids:
            seg = await self._fetch_segment(client, sid)
            if seg:
                segments.append(seg)

        # fallback to inline if deep fetch returned nothing
        if not segments and inline_segments:
            for s in inline_segments:
                segments.append(Segment(**{k: v for k, v in s.items() if k in Segment.model_fields}))

        # 3. Vendors — crawl from segments
        vendors: List[Vendor] = []
        vendor_ids_seen: Set[int] = set()
        for seg in segments:
            for vid in [seg.a_vendor_id, seg.z_vendor_id]:
                if vid and vid not in vendor_ids_seen:
                    vendor_ids_seen.add(vid)
                    vendor = await self._fetch_vendor(client, vid)
                    vendors.append(vendor)

        # 4. Tasks
        tasks_result = await self._gql(client, Q_TASKS_BY_ORDER, {"oid": oid})
        for t in tasks_result.get("data", {}).get("ai_tasks_by_service_order", []):
            order.tasks.append(Task(**{k: v for k, v in t.items() if k in Task.model_fields}))

        # 5. Notes
        notes_result = await self._gql(client, Q_ORDER_NOTES, {"order_id": oid})
        for n in notes_result.get("data", {}).get("order_notes", []):
            order.notes.append(Note(**{k: v for k, v in n.items() if k in Note.model_fields}))

        return OrderPayload(order=order, segments=segments, vendors=vendors)

    async def _fetch_segment(self, client: httpx.AsyncClient, sid: int) -> Optional[Segment]:
        """Fetch deep segment details by ID."""
        try:
            result = await self._gql(client, Q_SEGMENT, {"id": sid})
            seg_list = result.get("data", {}).get("segment", [])
            if seg_list:
                return Segment(**{k: v for k, v in seg_list[0].items() if k in Segment.model_fields})
        except Exception as e:
            logger.warning("Failed to fetch segment %d: %s", sid, e)
        return None

    async def _fetch_vendor(self, client: httpx.AsyncClient, vid: int) -> Vendor:
        """Fetch vendor details by ID, with caching."""
        if vid in self._vendor_cache:
            return self._vendor_cache[vid]

        try:
            result = await self._gql(client, Q_VENDOR, {"id": vid})
            vlist = result.get("data", {}).get("vendor", [])
            if vlist:
                vendor = Vendor(id=vid, name=vlist[0].get("name"), legal_name=vlist[0].get("legal_name"))
                self._vendor_cache[vid] = vendor
                return vendor
        except Exception as e:
            logger.warning("Failed to fetch vendor %d: %s", vid, e)

        vendor = Vendor(id=vid, name="Unknown")
        self._vendor_cache[vid] = vendor
        return vendor
