"""
MCP tools for CMD task queries.
"""

from typing import Any, Dict, List


async def get_order_tasks(order_id: int, services: dict) -> List[Dict[str, Any]]:
    """
    Get all tasks for a specific order, with status labels.

    Args:
        order_id: The service order ID
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order {id: $order_id})-[:HAS_TASK]->(t:Task)
        RETURN t.task_id AS task_id,
               t.summary AS summary,
               t.status AS status,
               CASE t.status
                   WHEN 1 THEN 'Open'
                   WHEN 2 THEN 'In Progress'
                   WHEN 3 THEN 'On Hold'
                   WHEN 4 THEN 'Cancelled'
                   WHEN 5 THEN 'Completed'
                   ELSE 'Unknown'
               END AS status_label
        ORDER BY t.task_id
    """, {"order_id": order_id})

    return records


async def get_tasks_by_status(status: int, services: dict) -> List[Dict[str, Any]]:
    """
    Get all tasks with a given status across all orders.

    Args:
        status: Task status code (1=Open, 2=In Progress, 3=On Hold, 4=Cancelled, 5=Completed)
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order)-[:HAS_TASK]->(t:Task {status: $status})
        RETURN t.task_id AS task_id,
               t.summary AS summary,
               o.id AS order_id,
               o.status_label AS order_status
        ORDER BY t.task_id DESC
        LIMIT 100
    """, {"status": status})

    return records


async def get_tasks_by_type(task_type: str, services: dict) -> List[Dict[str, Any]]:
    """
    Get tasks matching a specific type/summary label (e.g. "Complete Order", "Loop - FOC").

    Args:
        task_type: Task summary/type label to match (case-insensitive partial match)
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order)-[:HAS_TASK]->(t:Task)
        WHERE toLower(t.summary) CONTAINS toLower($task_type)
        RETURN t.task_id AS task_id,
               t.summary AS summary,
               t.status AS status,
               o.id AS order_id,
               o.status_label AS order_status
        ORDER BY t.task_id DESC
        LIMIT 100
    """, {"task_type": task_type})

    return records


async def get_task_summary_stats(services: dict) -> Dict[str, Any]:
    """
    Get aggregate task statistics: breakdown by status and by task type.
    """
    mg = services["memgraph_client"]

    by_status = await mg.execute_and_fetch("""
        MATCH (t:Task)
        RETURN t.status AS status,
               CASE t.status
                   WHEN 1 THEN 'Open'
                   WHEN 2 THEN 'In Progress'
                   WHEN 3 THEN 'On Hold'
                   WHEN 4 THEN 'Cancelled'
                   WHEN 5 THEN 'Completed'
                   ELSE 'Unknown'
               END AS status_label,
               count(t) AS count
        ORDER BY count DESC
    """)

    by_type = await mg.execute_and_fetch("""
        MATCH (t:Task)
        RETURN t.summary AS task_type, count(t) AS count
        ORDER BY count DESC
        LIMIT 20
    """)

    total = await mg.execute_and_fetch("MATCH (t:Task) RETURN count(t) AS total")

    return {
        "total_tasks": total[0]["total"] if total else 0,
        "by_status": by_status,
        "by_type": by_type,
    }
