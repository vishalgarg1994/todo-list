import os
import sys

print("=" * 80)
print("Testing BAML TranslateToCypher function call")
print("=" * 80)

sys.path.insert(0, '/app')

print(f"\nEnvironment variables:")
print(f"  OLLAMA_CYPHER_BASE_URL = {os.environ.get('OLLAMA_CYPHER_BASE_URL', 'NOT SET')}")
print(f"  OLLAMA_CYPHER_MODEL = {os.environ.get('OLLAMA_CYPHER_MODEL', 'NOT SET')}")

print("\nImporting baml_client...")
from baml_client import b as baml_client

print("SUCCESS: baml_client imported")

print("\nAttempting to call TranslateToCypher...")
print("This should fail with the same 404 error we saw before")

try:
    result = baml_client.TranslateToCypher(
        question="How many tickets are there?",
        schema_description="Test schema"
    )
    print(f"\nSUCCESS! Result: {result}")
except Exception as e:
    print(f"\nERROR (as expected): {type(e).__name__}")
    print(f"Error message: {str(e)[:500]}")

    # Try to extract the actual URL being used
    error_str = str(e)
    if 'http' in error_str.lower():
        print("\nSearching for URL in error message...")
        import re
        urls = re.findall(r'https?://[^\s]+', error_str)
        if urls:
            print(f"Found URLs in error: {urls}")
        else:
            print("No URLs found in error message")

    print(f"\nFull error:\n{e}")
