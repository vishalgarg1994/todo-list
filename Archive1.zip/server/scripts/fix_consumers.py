#!/usr/bin/env python3
"""
Delete old consumer and let new ones be created
"""
import asyncio
import nats

async def fix_consumers():
    """Delete old consumer with hardcoded name"""
    try:
        nc = await nats.connect("nats://localhost:4222")
        js = nc.jetstream()
        print("✅ Connected to NATS")

        # List current consumers
        consumers = await js.consumers_info("EVA_TICKETING_STREAM")
        print(f"\n📋 Current consumers:")
        for consumer in consumers:
            print(f"   - {consumer.name} (filter: {consumer.config.filter_subject})")

        # Delete old hardcoded consumer
        print(f"\n🗑️  Deleting old hardcoded consumer 'ticket_consumer_durable'...")
        try:
            await js.delete_consumer("EVA_TICKETING_STREAM", "ticket_consumer_durable")
            print(f"   ✅ Deleted successfully")
        except Exception as e:
            print(f"   ℹ️  Could not delete (may not exist): {e}")

        # Show new state
        print(f"\n📋 Consumers after cleanup:")
        consumers = await js.consumers_info("EVA_TICKETING_STREAM")
        if not consumers:
            print("   No consumers (they will be recreated by the server)")
        for consumer in consumers:
            print(f"   - {consumer.name} (filter: {consumer.config.filter_subject})")

        await nc.close()

    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(fix_consumers())
