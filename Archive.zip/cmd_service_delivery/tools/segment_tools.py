"""
MCP tools for CMD segment queries.
"""

from typing import Any, Dict, List


async def get_segment_details(segment_id: int, services: dict) -> Dict[str, Any]:
    """
    Get full details for a network segment, including connected vendors and parent order.

    Args:
        segment_id: The segment ID to look up
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (seg:Segment {id: $segment_id})
        OPTIONAL MATCH (seg)<-[:HAS_SEGMENT]-(o:Order)
        OPTIONAL MATCH (seg)-[:HAS_A_VENDOR]->(av:Vendor)
        OPTIONAL MATCH (seg)-[:HAS_Z_VENDOR]->(zv:Vendor)
        RETURN seg, o.id AS order_id, o.status_label AS order_status,
               av, zv
    """, {"segment_id": segment_id})

    if not records:
        return {"error": f"Segment {segment_id} not found"}

    r = records[0]
    return {
        "segment": dict(r["seg"]) if r.get("seg") else None,
        "order_id": r.get("order_id"),
        "order_status": r.get("order_status"),
        "a_vendor": dict(r["av"]) if r.get("av") else None,
        "z_vendor": dict(r["zv"]) if r.get("zv") else None,
    }


async def get_segments_by_vendor(vendor_id: int, services: dict) -> List[Dict[str, Any]]:
    """
    Get all network segments associated with a given vendor (either as A-end or Z-end).

    Args:
        vendor_id: The vendor ID to search for
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (v:Vendor {id: $vendor_id})<-[:HAS_A_VENDOR|HAS_Z_VENDOR]-(seg:Segment)
        OPTIONAL MATCH (seg)<-[:HAS_SEGMENT]-(o:Order)
        RETURN seg.id AS segment_id,
               seg.a_company_name AS a_company,
               seg.z_company_name AS z_company,
               seg.vendor_circuit_id AS vendor_circuit,
               seg.foc_date AS foc_date,
               o.id AS order_id,
               o.status_label AS order_status
        ORDER BY seg.id DESC
    """, {"vendor_id": vendor_id})

    return records


async def search_segments_by_company(company_name: str, services: dict) -> List[Dict[str, Any]]:
    """
    Search segments by A-end or Z-end company name (partial match).

    Args:
        company_name: Company name to search (case-insensitive partial match)
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (seg:Segment)
        WHERE toLower(seg.a_company_name) CONTAINS toLower($name) OR toLower(seg.z_company_name) CONTAINS toLower($name)
        OPTIONAL MATCH (seg)<-[:HAS_SEGMENT]-(o:Order)
        RETURN seg.id AS segment_id,
               seg.a_company_name AS a_company,
               seg.z_company_name AS z_company,
               seg.a_city AS a_city,
               seg.z_city AS z_city,
               seg.vendor_circuit_id AS vendor_circuit,
               o.id AS order_id
        ORDER BY seg.id DESC
    """, {"name": company_name})

    return records


async def get_segments_by_location(city: str, services: dict) -> List[Dict[str, Any]]:
    """
    Find segments by A-end or Z-end city (partial match).

    Args:
        city: City name to search
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (seg:Segment)
        WHERE toLower(seg.a_city) CONTAINS toLower($city) OR toLower(seg.z_city) CONTAINS toLower($city)
        OPTIONAL MATCH (seg)<-[:HAS_SEGMENT]-(o:Order)
        RETURN seg.id AS segment_id,
               seg.a_company_name AS a_company,
               seg.a_city AS a_city,
               seg.z_company_name AS z_company,
               seg.z_city AS z_city,
               o.id AS order_id
    """, {"city": city})

    return records
