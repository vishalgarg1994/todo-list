import logging
import asyncio
from neo4j.exceptions import ServiceUnavailable, AuthError
from configs.config import Config

# Create an instance of Config (Singleton ensures it's the same everywhere)
config = Config()

# Load Memgraph connection details from config
MEMGRAPH_URI = config.memgraph_uri
MEMGRAPH_USER = config.memgraph_user
MEMGRAPH_PASSWORD = config.memgraph_password
MEMGRAPH_DATABASE = config.memgraph_database


async def connect_memgraph():
    """Initializes a Memgraph database connection and checks readiness."""
    from neo4j import GraphDatabase

    try:
        # Attempt to connect to Memgraph
        auth = (MEMGRAPH_USER, MEMGRAPH_PASSWORD) if MEMGRAPH_USER else None
        driver = GraphDatabase.driver(MEMGRAPH_URI, auth=auth)

        # Verify connection with a simple query
        with driver.session(database=MEMGRAPH_DATABASE) as session:
            result = session.run("RETURN 1 AS test")
            result.single()

            # Check if DB is populated
            result = session.run("MATCH (n:Ticket) RETURN count(n) AS count")
            record = result.single()
            count = record["count"] if record else 0
            is_ready = count > 0

            logging.info(f"Memgraph DB connected at {MEMGRAPH_URI}. "
                        f"{'Ready for queries.' if is_ready else 'Seems empty, awaiting data.'}")

            return driver if is_ready else None, is_ready

    except ServiceUnavailable as e:
        logging.error(f"Memgraph service unavailable at {MEMGRAPH_URI}: {e}")
        return None, False
    except AuthError as e:
        logging.error(f"Memgraph authentication failed: {e}")
        return None, False
    except Exception as e:
        logging.error(f"Error connecting to Memgraph: {e}")
        return None, False


async def shutdown_memgraph(driver):
    """Cleans up Memgraph driver connections before shutting down."""
    if driver:
        driver.close()
        logging.info("Memgraph driver closed.")


async def ensure_memgraph_initialized(memgraph_client):
    """
    Ensures that the Memgraph database is initialized and has a valid schema.
    If not, it will create and initialize the database schema.

    Note: Memgraph is network-based, so we just check if schema exists
    and create it if needed (no file cleanup required).
    """
    try:
        # Connect to Memgraph and assign driver to client instance
        await memgraph_client.connect()

        # Check if schema exists by looking for node labels (Memgraph-compatible query)
        result = await memgraph_client.execute("""
            MATCH (n)
            RETURN DISTINCT labels(n) AS label
            LIMIT 1
        """)
        labels = [record["label"] for record in result] if result else []

        if not labels:
            # No schema exists, create it
            logging.info("Memgraph DB has no schema. Initializing schema...")
            await asyncio.to_thread(memgraph_client.createSchema)
            logging.info("Memgraph schema created successfully.")
        else:
            logging.info(f"Memgraph DB is initialized with schema (found labels: {labels})")

    except ServiceUnavailable as e:
        logging.error(f"Memgraph service unavailable: {e}")
        logging.info("Please ensure Memgraph is running and accessible at {MEMGRAPH_URI}")
        raise
    except AuthError as e:
        logging.error(f"Memgraph authentication failed: {e}")
        raise
    except Exception as e:
        logging.error(f"Error during Memgraph initialization: {e}", exc_info=True)
        # Try to create schema anyway in case it's just missing
        try:
            logging.info("Attempting to create schema...")
            await asyncio.to_thread(memgraph_client.createSchema)
            logging.info("Schema created successfully on retry.")
        except Exception as schema_error:
            logging.error(f"Failed to create schema: {schema_error}", exc_info=True)
            raise
