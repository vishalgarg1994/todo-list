import asyncio
import json
import logging
from datetime import datetime, timezone
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import urlparse
from typing import Optional

logger = logging.getLogger(__name__)


class HealthHTTPRequestHandler(BaseHTTPRequestHandler):
    """HTTP request handler for health endpoints"""

    def __init__(self, health_service, *args, **kwargs):
        self.health_service = health_service
        super().__init__(*args, **kwargs)

    def do_GET(self):
        """Handle GET requests"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path

        try:
            if path == "/health":
                asyncio.run(self._handle_health())
            elif path == "/health/live" or path == "/healthz":
                asyncio.run(self._handle_liveness())
            elif path == "/health/ready":
                asyncio.run(self._handle_readiness())
            elif path == "/health/metrics":
                asyncio.run(self._handle_metrics())
            else:
                self._send_not_found()
        except Exception as e:
            logger.error(f"Error handling request {path}: {e}")
            self._send_error(500, f"Internal server error: {str(e)}")

    async def _handle_health(self):
        """Handle comprehensive health check"""
        try:
            health_response = await self.health_service.get_health_status()
            status_code = 200

            # Return 503 for unhealthy status
            if health_response.status.value == "unhealthy":
                status_code = 503
            elif health_response.status.value == "degraded":
                status_code = 200  # Still accepting traffic but with warnings

            self._send_json_response(health_response.to_dict(), status_code)

        except Exception as e:
            logger.error(f"Health check failed: {e}")
            self._send_error(500, f"Health check failed: {str(e)}")

    async def _handle_liveness(self):
        """Handle liveness probe (Kubernetes style)"""
        try:
            is_alive = await self.health_service.is_alive()

            if is_alive:
                response = {
                    "status": "alive",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                self._send_json_response(response, 200)
            else:
                response = {
                    "status": "dead",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                self._send_json_response(response, 503)

        except Exception as e:
            logger.error(f"Liveness check failed: {e}")
            self._send_error(500, f"Liveness check failed: {str(e)}")

    async def _handle_readiness(self):
        """Handle readiness probe (Kubernetes style)"""
        try:
            is_ready = await self.health_service.is_ready()

            if is_ready:
                response = {
                    "status": "ready",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                self._send_json_response(response, 200)
            else:
                response = {
                    "status": "not_ready",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                self._send_json_response(response, 503)

        except Exception as e:
            logger.error(f"Readiness check failed: {e}")
            self._send_error(500, f"Readiness check failed: {str(e)}")

    async def _handle_metrics(self):
        """Handle metrics endpoint for monitoring systems"""
        try:
            health_response = await self.health_service.get_health_status()

            # Convert to Prometheus-style metrics format
            metrics = []

            # Overall health status (0=unhealthy, 1=degraded, 2=healthy)
            status_value = {"unhealthy": 0, "degraded": 1, "healthy": 2}.get(
                health_response.status.value, 0
            )
            metrics.append(f"application_health_status {status_value}")
            metrics.append(
                f"application_uptime_seconds {health_response.uptime_seconds}"
            )

            # Component metrics
            for component_name, component in health_response.components.items():
                component_status = {"unhealthy": 0, "degraded": 1, "healthy": 2}.get(
                    component.status.value, 0
                )
                metrics.append(
                    f'component_health_status{{component="{component_name}"}} {component_status}'
                )

                if component.response_time_ms:
                    metrics.append(
                        f'component_response_time_ms{{component="{component_name}"}} {component.response_time_ms}'
                    )

                # Add specific component details
                if component.details:
                    for detail_key, detail_value in component.details.items():
                        if isinstance(detail_value, (int, float)):
                            metrics.append(
                                f"{component_name}_{detail_key} {detail_value}"
                            )

            # Send as plain text for Prometheus scraping
            self.send_response(200)
            self.send_header("Content-type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write("\n".join(metrics).encode("utf-8"))

        except Exception as e:
            logger.error(f"Metrics endpoint failed: {e}")
            self._send_error(500, f"Metrics generation failed: {str(e)}")

    def _send_json_response(self, data: dict, status_code: int = 200):
        """Send JSON response"""
        response_body = json.dumps(data, indent=2)

        self.send_response(status_code)
        self.send_header("Content-type", "application/json")
        self.send_header("Content-length", str(len(response_body)))
        self.end_headers()
        self.wfile.write(response_body.encode("utf-8"))

    def _send_not_found(self):
        """Send 404 response"""
        response = {
            "error": "Not Found",
            "message": "Available endpoints: /health, /health/live, /health/ready, /health/metrics",
        }
        self._send_json_response(response, 404)

    def _send_error(self, status_code: int, message: str):
        """Send error response"""
        response = {
            "error": "Internal Server Error" if status_code == 500 else "Error",
            "message": message,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self._send_json_response(response, status_code)

    def log_message(self, format, *args):
        """Override to use our logger instead of stderr"""
        logger.info(f"HTTP {self.address_string()} - {format % args}")


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    """Threading HTTP server for concurrent request handling"""

    daemon_threads = True
    allow_reuse_address = True


class HealthHTTPServer:
    """HTTP server for health endpoints"""

    def __init__(self, health_service, host: str = "0.0.0.0", port: int = 8080):
        self.health_service = health_service
        self.host = host
        self.port = port
        self.server: Optional[ThreadingHTTPServer] = None
        self.server_task: Optional[asyncio.Task] = None
        self.logger = logging.getLogger(__name__)

    def _create_handler_class(self):
        """Create a request handler class with health service bound"""
        health_service = self.health_service

        class BoundHealthHTTPRequestHandler(HealthHTTPRequestHandler):
            def __init__(self, *args, **kwargs):
                super().__init__(health_service, *args, **kwargs)

        return BoundHealthHTTPRequestHandler

    async def start(self):
        """Start the HTTP server"""
        if self.server_task:
            self.logger.warning("HTTP server is already running")
            return

        try:
            handler_class = self._create_handler_class()
            self.server = ThreadingHTTPServer((self.host, self.port), handler_class)

            self.logger.info(f"Starting health HTTP server on {self.host}:{self.port}")

            # Run server in a separate task
            loop = asyncio.get_event_loop()
            self.server_task = loop.run_in_executor(None, self.server.serve_forever)

            self.logger.info("Health endpoints available:")
            self.logger.info(
                f"  - http://{self.host}:{self.port}/health (comprehensive)"
            )
            self.logger.info(
                f"  - http://{self.host}:{self.port}/health/live (liveness)"
            )
            self.logger.info(
                f"  - http://{self.host}:{self.port}/health/ready (readiness)"
            )
            self.logger.info(
                f"  - http://{self.host}:{self.port}/health/metrics (prometheus)"
            )

        except Exception as e:
            self.logger.error(f"Failed to start HTTP server: {e}")
            raise

    async def stop(self):
        """Stop the HTTP server"""
        if self.server:
            self.logger.info("Stopping health HTTP server...")
            self.server.shutdown()
            self.server.server_close()

        if self.server_task:
            try:
                self.server_task.cancel()
                await asyncio.gather(self.server_task, return_exceptions=True)
            except Exception as e:
                self.logger.error(f"Error stopping HTTP server task: {e}")

        self.server = None
        self.server_task = None
        self.logger.info("Health HTTP server stopped")

    def is_running(self) -> bool:
        """Check if the server is running"""
        return self.server_task is not None and not self.server_task.done()
