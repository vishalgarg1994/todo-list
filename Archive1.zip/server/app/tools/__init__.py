# Minimal __init__.py to avoid import issues during module loading
