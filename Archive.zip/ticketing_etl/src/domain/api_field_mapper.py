"""
API Field Mapper - Maps ServiceNow SMDS API responses to data_model.py structure

Handles:
- Incident mapping (API → OperationalStatus with IncidentFields)
- Case mapping (API → OperationalStatus with CaseFields)
- Customer mapping (API → ClientInfo)
- MTTR parsing (business_elapsed_minutes string → int)
"""

import re
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

from classes.data_model import (
    TicketSummary,
    ClientInfo,
    OperationalStatus,
    ServiceEntity,
    FaultInfo,
    TicketInfo,
    OutageInfo,
    NOCInfo,
    IncidentFields,
    CaseFields,
    FaultDescription,
)
from utils.data_sanitizer import sanitize_text_for_json


logger = logging.getLogger(__name__)


# =============================================================================
# MTTR Parsing
# =============================================================================


def parse_business_elapsed_minutes(elapsed_str: Optional[str]) -> Optional[int]:
    """
    Parse ServiceNow business_elapsed_minutes string to integer minutes.

    Input: "51 Days 20 Hours 8 Minutes"
    Output: 74648 (51*24*60 + 20*60 + 8)

    Input: "2 Hours 30 Minutes"
    Output: 150

    Input: "45 Minutes"
    Output: 45

    Args:
        elapsed_str: ServiceNow formatted elapsed time string

    Returns:
        Total minutes as int, or None if parsing fails
    """
    if not elapsed_str:
        return None

    total_minutes = 0

    # Extract days
    days_match = re.search(r"(\d+)\s*Days?", elapsed_str, re.IGNORECASE)
    if days_match:
        total_minutes += int(days_match.group(1)) * 24 * 60

    # Extract hours
    hours_match = re.search(r"(\d+)\s*Hours?", elapsed_str, re.IGNORECASE)
    if hours_match:
        total_minutes += int(hours_match.group(1)) * 60

    # Extract minutes
    minutes_match = re.search(r"(\d+)\s*Minutes?", elapsed_str, re.IGNORECASE)
    if minutes_match:
        total_minutes += int(minutes_match.group(1))

    return total_minutes if total_minutes > 0 else None


# =============================================================================
# Type Conversion Helpers
# =============================================================================


def _to_int(value: Any) -> Optional[int]:
    """Convert value to int, handling strings and floats"""
    if value is None or value == "":
        return None
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return None


def _to_bool(value: Any) -> Optional[bool]:
    """Convert value to bool"""
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() in ("true", "1", "yes", "t")
    return bool(value)


def _to_datetime(value: Any) -> Optional[datetime]:
    """Convert value to datetime"""
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        # Try common ServiceNow formats
        for fmt in [
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%d",
        ]:
            try:
                return datetime.strptime(value, fmt)
            except ValueError:
                continue
    return None


# =============================================================================
# Incident Field Mapping
# =============================================================================


def map_incident_to_operational_status(
    inc: Dict[str, Any], customer_info: Optional[Dict[str, Any]] = None
) -> OperationalStatus:
    """
    Map API incident response to OperationalStatus with IncidentFields.

    Args:
        inc: Incident record from API
        customer_info: Optional customer data from /customers/{sys_id}

    Returns:
        OperationalStatus populated with incident data
    """
    # Parse MTTR from business_elapsed_minutes
    mttr_minutes = parse_business_elapsed_minutes(inc.get("business_elapsed_minutes"))

    return OperationalStatus(
        ticket_type="incident",
        ticket_sys_id=inc.get("sys_id"),
        service_entity=ServiceEntity(
            subcategory=inc.get("subcategory"),
            technology=None,  # Not in API
            service_restored_date=_to_datetime(
                inc.get("work_end") or inc.get("actual_end")
            ),
            related_circuit_id=_to_int(inc.get("circuit_id")),
        ),
        fault_info=FaultInfo(
            fault_description_ref=inc.get("number"),
            fault_description=sanitize_text_for_json(inc.get("description")),
            fault_occured_date=_to_datetime(inc.get("opened_at")),
            short_description=sanitize_text_for_json(inc.get("short_description")),
            is_customer_impacting=_to_bool(inc.get("customer_impacted")),
            rfo=inc.get("u_rfo"),  # Custom field
            ticket_rfo_group=inc.get("u_rfo_group"),  # Custom field
        ),
        ticket_info=TicketInfo(
            ticket_id=inc.get("number"),
            ticket_queue=inc.get("assignment_group"),
            ticket_status=inc.get("state"),
            priority=_to_int(inc.get("priority")),
            is_worked_ticket=_to_bool(inc.get("u_is_worked_ticket")),
            created_by=inc.get("sys_created_by"),
            created_on=_to_datetime(inc.get("opened_at")),
            updated_on=_to_datetime(inc.get("sys_updated_on")),
            closed_by=inc.get("closed_by"),
            closed_by_id=inc.get("closed_by_sys_id"),
            closed_on=_to_datetime(inc.get("closed_at")),
            assigned_to=inc.get("assigned_to"),
            assigned_to_id=inc.get("assigned_to_sys_id"),
        ),
        outage_info=OutageInfo(
            customer_resolution=inc.get("u_customer_resolution"),
            resolution=sanitize_text_for_json(inc.get("resolution_notes")),
            rfo=inc.get("u_rfo"),
            mttr=mttr_minutes,
            internal_mttr=inc.get("business_elapsed_minutes"),  # Store original string
        ),
        noc_info=NOCInfo(
            default_noc=None,
            default_noc_queue=inc.get("assignment_group"),
        ),
        incident_fields=IncidentFields(
            category=inc.get("category"),
            subcategory=inc.get("subcategory"),
            ci_sys_id=inc.get("cmdb_ci_sys_id"),
            ci_class=inc.get("cmdb_ci_class"),
            ci_name=inc.get("cmdb_ci"),
            circuit_id=str(inc.get("circuit_id")) if inc.get("circuit_id") else None,
            major_incident_state=inc.get("major_incident_state"),
            parent_incident_number=inc.get("parent_incident"),
            cause=inc.get("cause"),
            business_impact=inc.get("business_impact"),
            escalation_level=_to_int(inc.get("escalation")),
            support_area=inc.get("u_support_area"),
            is_customer_impacted=_to_bool(inc.get("customer_impacted")),
            customer_close_notes=sanitize_text_for_json(inc.get("close_notes")),
            internal_resolution_notes=sanitize_text_for_json(
                inc.get("internal_resolution_note")
            ),
            close_code=inc.get("close_code"),
            hold_reason=inc.get("hold_reason"),
            resolved_at=_to_datetime(inc.get("resolved_at")),
            responsible_party=inc.get("u_responsible_party"),
        ),
        # Not populated from API (would need separate calls)
        case_fields=None,
        problem_fields=None,
        request_fields=None,
        users=None,
        maintenance_window=None,
        contacts=None,
        vendors=None,
        survey_info=None,
        tasks=None,
        configuration_items=None,
    )


# =============================================================================
# Case Field Mapping
# =============================================================================


def map_case_to_operational_status(
    case: Dict[str, Any], customer_info: Optional[Dict[str, Any]] = None
) -> OperationalStatus:
    """
    Map API case response to OperationalStatus with CaseFields.

    Args:
        case: Case record from API
        customer_info: Optional customer data from /customers/{sys_id}

    Returns:
        OperationalStatus populated with case data
    """
    # Parse MTTR from business_elapsed_minutes
    mttr_minutes = parse_business_elapsed_minutes(case.get("business_elapsed_minutes"))

    return OperationalStatus(
        ticket_type="case",
        ticket_sys_id=case.get("sys_id"),
        service_entity=ServiceEntity(
            subcategory=case.get("subcategory"),
            technology=None,
            service_restored_date=_to_datetime(
                case.get("work_end") or case.get("actual_end")
            ),
            related_circuit_id=_to_int(case.get("circuit_id")),
        ),
        fault_info=FaultInfo(
            fault_description_ref=case.get("number"),
            fault_description=sanitize_text_for_json(case.get("description")),
            fault_occured_date=_to_datetime(case.get("opened_at")),
            short_description=sanitize_text_for_json(case.get("short_description")),
            is_customer_impacting=_to_bool(case.get("u_customer_impacted")),
            rfo=case.get("u_rfo"),
            ticket_rfo_group=case.get("u_rfo_group"),
        ),
        ticket_info=TicketInfo(
            ticket_id=case.get("number"),
            ticket_queue=case.get("assignment_group"),
            ticket_status=case.get("state"),
            priority=_to_int(case.get("priority")),
            is_worked_ticket=_to_bool(case.get("u_is_worked_ticket")),
            created_by=case.get("sys_created_by"),
            created_on=_to_datetime(case.get("opened_at")),
            updated_on=_to_datetime(case.get("sys_updated_on")),
            closed_by=case.get("closed_by"),
            closed_by_id=case.get("closed_by_sys_id"),
            closed_on=_to_datetime(case.get("closed_at")),
            assigned_to=case.get("assigned_to"),
            assigned_to_id=case.get("assigned_to_sys_id"),
        ),
        outage_info=OutageInfo(
            customer_resolution=case.get("u_customer_resolution"),
            resolution=sanitize_text_for_json(case.get("resolution_notes")),
            rfo=case.get("u_rfo"),
            mttr=mttr_minutes,
            internal_mttr=case.get("business_elapsed_minutes"),
        ),
        noc_info=NOCInfo(
            default_noc=None,
            default_noc_queue=case.get("assignment_group"),
        ),
        case_fields=CaseFields(
            category=case.get("category"),
            subcategory=case.get("subcategory"),
            ci_sys_id=case.get("cmdb_ci_sys_id"),
            ci_class=case.get("cmdb_ci_class"),
            ci_name=case.get("cmdb_ci"),
            circuit_id=str(case.get("circuit_id")) if case.get("circuit_id") else None,
            segment_id=case.get("segment_id"),
            related_circuit_id=str(case.get("related_circuit_id"))
            if case.get("related_circuit_id")
            else None,
            resolution_code=case.get("resolution_code"),
            contact_type=case.get("contact_type"),
            case_type=case.get("case_type"),
            sub_state=case.get("sub_state"),
            needs_attention=_to_bool(case.get("needs_attention")),
            is_customer_updated=_to_bool(case.get("u_customer_updated")),
            first_response_time=_to_datetime(case.get("first_response_time")),
            reassignment_count=_to_int(case.get("reassignment_count")),
            escalation_number=_to_int(case.get("escalation")),
            adjusted_business_elapsed_time=case.get("business_elapsed_time"),
            # FK relationships
            incident_sys_id=case.get("incident", {}).get("value")
            if isinstance(case.get("incident"), dict)
            else case.get("incident_sys_id"),
            incident_number=case.get("incident", {}).get("display_value")
            if isinstance(case.get("incident"), dict)
            else case.get("incident_number"),
            contact_name=case.get("contact_name"),
            contact_sys_id=case.get("contact_sys_id"),
            internal_resolution_notes=sanitize_text_for_json(
                case.get("internal_resolution_notes")
            ),
            responsible_party=case.get("u_responsible_party"),
        ),
        incident_fields=None,
        problem_fields=None,
        request_fields=None,
        users=None,
        maintenance_window=None,
        contacts=None,
        vendors=None,
        survey_info=None,
        tasks=None,
        configuration_items=None,
    )


# =============================================================================
# Customer Field Mapping
# =============================================================================


def map_customer_to_client_info(customer: Dict[str, Any]) -> ClientInfo:
    """
    Map API customer response to ClientInfo.

    Args:
        customer: Customer record from /customers/{sys_id}

    Returns:
        ClientInfo populated with customer data
    """
    return ClientInfo(
        client_id=_to_int(customer.get("u_client_id")),
        client_name=customer.get("name"),
        client_group=customer.get("u_customer_group"),
        market_segment=customer.get("u_segment"),
    )


# =============================================================================
# Batch Processing Helpers
# =============================================================================


def group_by_client(
    incidents: List[Dict[str, Any]],
    cases: List[Dict[str, Any]],
    customers: Dict[str, Dict[str, Any]],
) -> Dict[str, TicketSummary]:
    """
    Group incidents and cases by client_id into TicketSummary objects.

    Args:
        incidents: List of incident records from API
        cases: List of case records from API
        customers: Dict of customer records indexed by sys_id

    Returns:
        Dict of TicketSummary objects indexed by client_id
    """
    client_summaries: Dict[str, TicketSummary] = {}

    # Process incidents
    for inc in incidents:
        customer_sys_id = inc.get("customer")
        if isinstance(customer_sys_id, dict):
            customer_sys_id = customer_sys_id.get("value")

        customer_info = customers.get(customer_sys_id, {})
        client_id = customer_info.get("u_client_id") or inc.get("u_client_id")

        if not client_id:
            logger.warning(f"Incident {inc.get('number')} has no client_id, skipping")
            continue

        client_id_str = str(client_id)
        op_status = map_incident_to_operational_status(inc, customer_info)

        if client_id_str not in client_summaries:
            client_summaries[client_id_str] = TicketSummary(
                client_info=map_customer_to_client_info(customer_info)
                if customer_info
                else ClientInfo(
                    client_id=_to_int(client_id),
                    client_name=inc.get("customer_name"),
                ),
                operational_status=[op_status],
            )
        else:
            client_summaries[client_id_str].operational_status.append(op_status)

    # Process cases
    for case in cases:
        customer_sys_id = case.get("customer")
        if isinstance(customer_sys_id, dict):
            customer_sys_id = customer_sys_id.get("value")

        customer_info = customers.get(customer_sys_id, {})
        client_id = customer_info.get("u_client_id") or case.get("u_client_id")

        if not client_id:
            logger.warning(f"Case {case.get('number')} has no client_id, skipping")
            continue

        client_id_str = str(client_id)
        op_status = map_case_to_operational_status(case, customer_info)

        if client_id_str not in client_summaries:
            client_summaries[client_id_str] = TicketSummary(
                client_info=map_customer_to_client_info(customer_info)
                if customer_info
                else ClientInfo(
                    client_id=_to_int(client_id),
                    client_name=case.get("customer_name"),
                ),
                operational_status=[op_status],
            )
        else:
            client_summaries[client_id_str].operational_status.append(op_status)

    return client_summaries


def extract_fault_descriptions(
    incidents: List[Dict[str, Any]],
    cases: List[Dict[str, Any]],
    customers: Dict[str, Dict[str, Any]],
) -> Dict[str, List[FaultDescription]]:
    """
    Extract fault descriptions from incidents and cases, grouped by client_id.

    Args:
        incidents: List of incident records from API
        cases: List of case records from API
        customers: Dict of customer records indexed by sys_id

    Returns:
        Dict of FaultDescription lists indexed by client_id
    """
    fault_descriptions: Dict[str, List[FaultDescription]] = {}

    def _add_fault_desc(ticket: Dict[str, Any], customer_sys_id: Optional[str]):
        description = ticket.get("description")
        if not description or not description.strip():
            return

        customer_info = customers.get(customer_sys_id, {}) if customer_sys_id else {}
        client_id = customer_info.get("u_client_id") or ticket.get("u_client_id")

        if not client_id:
            return

        client_id_str = str(client_id)
        ticket_id = ticket.get("number")

        if client_id_str not in fault_descriptions:
            fault_descriptions[client_id_str] = []

        fault_descriptions[client_id_str].append(
            FaultDescription(
                fault_description_id=str(ticket_id),
                ticket_id=str(ticket_id),
                fault_description=sanitize_text_for_json(description),
                fault_occured_date=_to_datetime(ticket.get("opened_at")),
            )
        )

    # Process incidents
    for inc in incidents:
        customer_sys_id = inc.get("customer")
        if isinstance(customer_sys_id, dict):
            customer_sys_id = customer_sys_id.get("value")
        _add_fault_desc(inc, customer_sys_id)

    # Process cases
    for case in cases:
        customer_sys_id = case.get("customer")
        if isinstance(customer_sys_id, dict):
            customer_sys_id = customer_sys_id.get("value")
        _add_fault_desc(case, customer_sys_id)

    return fault_descriptions
