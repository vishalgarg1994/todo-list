#!/usr/bin/env python3
"""
Simple script to verify MCP tools are registered
Runs inside the Docker container
"""

import sys
sys.path.insert(0, '/app')

from services.register_mcp_components import TOOLS_DETAILS

print("\n" + "="*60)
print("MCP TOOLS VERIFICATION")
print("="*60)

# Group tools by category
categories = {
    "Natural Language Query": [],
    "Direct Lookup": [],
    "Analytical Tools": [],
    "NEW Analytical Tools (Phase 2)": [],
    "Relationship Tools": [],
    "Search Tools": []
}

# New tools from Phase 2 Task 2
# Note: get_contact_communication_stats and get_ticket_contacts disabled (no contact data in PostgreSQL)
new_tools = [
    "get_user_performance",
    "get_vendor_impact",
    "get_client_escalations",
    "get_survey_satisfaction",
    "get_maintenance_impact"
]

for tool_name, tool_detail in TOOLS_DETAILS.items():
    if tool_name == "ask_tickets_question":
        categories["Natural Language Query"].append(tool_name)
    elif tool_detail["module"] == "tools.tickets.lookup_tools":
        categories["Direct Lookup"].append(tool_name)
    elif tool_detail["module"] == "tools.tickets.analytical_tools" and tool_name in new_tools:
        categories["NEW Analytical Tools (Phase 2)"].append(tool_name)
    elif tool_detail["module"] == "tools.tickets.analytical_tools":
        categories["Analytical Tools"].append(tool_name)
    elif tool_detail["module"] == "tools.tickets.relationship_tools":
        categories["Relationship Tools"].append(tool_name)
    elif tool_detail["module"] == "tools.tickets.search_tools":
        categories["Search Tools"].append(tool_name)

# Print results
for category, tools in categories.items():
    if tools:
        print(f"\n{category}: {len(tools)}")
        for tool in tools:
            print(f"  ✓ {tool}")

print("\n" + "="*60)
print(f"TOTAL TOOLS REGISTERED: {len(TOOLS_DETAILS)}")
print("="*60)

# Verify all 5 new tools are present (2 disabled: get_contact_communication_stats, get_ticket_contacts)
print("\n" + "="*60)
print("VERIFICATION: Phase 2 Task 2 - 5 Active Analytical Tools")
print("="*60)

all_present = True
for tool in new_tools:
    if tool in TOOLS_DETAILS:
        print(f"  ✅ {tool}")
    else:
        print(f"  ❌ {tool} - MISSING!")
        all_present = False

print("\n⚠️  Disabled (no contact data):")
print("  🚫 get_ticket_contacts")
print("  🚫 get_contact_communication_stats")

if all_present:
    print("\n🎉 SUCCESS! All 5 active analytical tools are registered!")
    sys.exit(0)
else:
    print("\n❌ FAILURE! Some tools are missing!")
    sys.exit(1)
