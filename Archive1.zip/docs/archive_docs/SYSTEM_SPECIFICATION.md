# MCP Ticket System - System Specification
**Document Status:** Final
**Version:** 3.1.0
**Release Date:** October 30, 2025
**Classification:** Internal Technical Documentation

---

## Executive Summary

The **MCP Ticket System v3.1** is a production-grade, AI-augmented knowledge graph service with semantic search capabilities and high-performance async processing, designed to provide intelligent access to IT service management ticket data.

### Key Improvements in v3.1 (October 30, 2025)
- ✅ **Async Performance**: 43× faster ticket ingestion (4.224s → 0.098s per message)
- ✅ **100% Reliability**: Strategic locking eliminates transaction conflicts
- ✅ **Configurable Concurrency**: 3-10 concurrent database operations
- ✅ **612 msg/min Throughput**: At recommended concurrency=5 setting

### Key Improvements in v3.0 (October 22, 2025)
- ✅ **Semantic Search**: Milvus vector database with 505 embeddings indexed
- ✅ **3 Vector Search Tools**: Similar tickets, semantic search, recommendations
- ✅ **High Performance**: <400ms query response time (95th percentile)
- ✅ **Production-Ready**: All services healthy and operational
- ✅ **Backward Compatible**: Zero breaking changes, existing tools unchanged

### Key Improvements from Previous Versions
- ✅ **Concurrent Access**: Multiple users can query simultaneously (v2.0)
- ✅ **120x Performance**: Memgraph benchmarks show significant speed improvements (v2.0)
- ✅ **Network-Based**: Decoupled storage from application lifecycle (v2.0)
- ✅ **BAML Optimization**: 10x query generation improvement (v2.1)
- ✅ **Vector Search**: Semantic similarity matching (v3.0)
- ✅ **Async Processing**: 43× ingestion speedup with strategic locking (v3.1)

---

## System Identification

| Attribute | Value |
|-----------|-------|
| **System Name** | MCP Ticket System |
| **Version** | 3.1.0 |
| **Code Name** | "Async Performance + Vector Search" |
| **Release Type** | Minor Version (Performance Enhancement) |
| **Build Date** | October 30, 2025 |
| **License** | Internal/Proprietary |
| **Repository** | `mcp_ticket/` |
| **Primary Language** | Python 3.13 |
| **Primary Database** | Memgraph (via Async Neo4j driver) |
| **Vector Database** | Milvus 2.x |
| **Concurrency Model** | Async/await with strategic locking |

---

## Table of Contents
1. [Functional Specification](#functional-specification)
2. [Non-Functional Requirements](#non-functional-requirements)
3. [Data Model](#data-model)
4. [API Reference](#api-reference)
5. [Integration Specifications](#integration-specifications)
6. [Deployment Specifications](#deployment-specifications)
7. [Migration Guide](#migration-guide)
8. [Known Limitations](#known-limitations)

---

## Functional Specification

### F1. Natural Language Query Translation

**Requirement ID**: FR-NL-001
**Priority**: Critical
**Description**: System must translate natural language questions into Cypher queries for graph database execution.

**Specifications**:
- **Input**: Plain English question (string, max 500 characters)
- **Process**: BAML + LLM (Ollama Gemma3-Cypher-4b)
- **Output**: Valid Cypher query + execution results
- **Performance**: <500ms end-to-end latency (95th percentile)
- **Accuracy**: >80% valid query generation rate

**Example**:
```
Input:  "What tickets does client ACME have with high priority?"
Output: MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
        WHERE LOWER(c.client_name) CONTAINS LOWER('acme')
          AND t.priority >= 3
        RETURN t
```

**Error Handling**:
- Invalid query: Return error message with explanation
- LLM timeout: Fallback to direct tool invocation
- No results: Return empty list with success status

---

### F2. Ticket Lookup Operations

**Requirement ID**: FR-LOOKUP-001 to FR-LOOKUP-003
**Priority**: Critical

#### F2.1 Get Ticket Details
- **Input**: `ticket_id: str` (e.g., "Ticket_8709441")
- **Output**: Complete ticket object with relationships
- **Performance**: <100ms (95th percentile)
- **Data Returned**:
  - Ticket properties (status, priority, dates, etc.)
  - Associated client information
  - Incident details
  - Outage information
  - Service impacts
  - Team members (incident manager, engineers, etc.)
  - Contacts and vendors

#### F2.2 Get Client Tickets
- **Input**: `client_name: str` or `client_id: int`
- **Output**: List of tickets for the client
- **Pagination**: Default 100, max 1000 results
- **Sorting**: By `created_on` DESC

#### F2.3 Get Ticket Timeline
- **Input**: `ticket_id: str`
- **Output**: Chronological timeline of ticket events
- **Events**: Created, assigned, resolved, closed, reopened

---

### F3. Analytical Operations

**Requirement ID**: FR-ANALYTICS-001 to FR-ANALYTICS-003

#### F3.1 Get Client Summary
- **Aggregations**: Total tickets, open tickets, avg MTTR, survey scores
- **Grouping**: By client
- **Performance**: <200ms

#### F3.2 Get Tickets by Status
- **Input**: `status: str` (Open, Closed, Resolved, etc.)
- **Output**: List of matching tickets
- **Filters**: Optional date range, priority

#### F3.3 Get High Priority Tickets
- **Input**: `priority_threshold: int` (default: 2)
- **Output**: Tickets with priority >= threshold
- **Sorting**: By priority ASC, then by created_on ASC

---

### F4. Relationship Traversal

**Requirement ID**: FR-RELATIONSHIP-001 to FR-RELATIONSHIP-004

#### F4.1 Get Ticket Relationships
- **Traversal**: Master-child relationships, linked tickets
- **Depth**: Configurable (default: 2 hops)
- **Visualization**: Return graph structure (nodes + edges)

#### F4.2 Trace Root Cause
- **Algorithm**: Traverse TRIGGERED_BY relationships
- **Output**: Root incident(s) causing ticket
- **Include**: All intermediate incidents and services

#### F4.3 Get Vendor Tickets
- **Input**: `vendor_name: str`
- **Output**: Tickets involving specified vendor
- **Include**: Vendor downtime information

#### F4.4 Get Service Outages
- **Input**: `service_name: str` or `technology: str`
- **Output**: Outages affecting the service
- **Metrics**: Total outages, avg duration, MTTR

---

### F5. Search Operations

**Requirement ID**: FR-SEARCH-001 to FR-SEARCH-002

#### F5.1 Get Tickets by Date Range
- **Input**: `start_date: str`, `end_date: str` (ISO 8601 format)
- **Field**: Searches `created_on` field
- **Output**: Tickets within range
- **Max Range**: 365 days

#### F5.2 Get Ticket Contacts
- **Input**: `ticket_id: str`
- **Output**: List of contacts associated with ticket
- **Fields**: Name, email, phone, contact_type

---

### F6. Vector Search Operations (NEW in v3.0)

**Requirement ID**: FR-VECTOR-001 to FR-VECTOR-003
**Priority**: High

#### F6.1 Find Similar Tickets
- **Input**: `fault_description: str` or `ticket_id: str`
- **Process**: Generate embedding, search Milvus for similar vectors
- **Output**: List of similar tickets with similarity scores
- **Performance**: <400ms (95th percentile)
- **Limit**: Default 10, max 50 results

#### F6.2 Semantic Ticket Search
- **Input**: `query: str` (natural language)
- **Process**: Embed query, find semantically similar tickets
- **Output**: Ranked tickets by relevance
- **Use Case**: "Network issues in Dallas datacenter"

#### F6.3 Get Ticket Recommendations
- **Input**: `ticket_id: str`
- **Process**: Find similar past tickets, extract resolution patterns
- **Output**: Recommended troubleshooting steps based on similar incidents
- **Enhancement**: Graph + vector hybrid search

---

### F7. Data Ingestion

**Requirement ID**: FR-INGESTION-001
**Priority**: Critical
**Description**: System must consume ticket data from NATS JetStream and persist to graph database.

**Specifications**:
- **Source**: NATS Subject `tickets.created`
- **Format**: Compressed JSON (gzip + base64)
- **Processing**: Asynchronous pull-based consumption
- **Batch Size**: 10 messages per fetch
- **Throughput**: 1000+ tickets/second (batch mode)
- **Reliability**: Durable subscription with explicit ACK

**Data Pipeline**:
```
NATS Message
    ↓
Decompress (gzip + base64)
    ↓
Validate (Pydantic models)
    ↓
Normalize (null values, types)
    ↓
Generate IDs (cl_id, tkt_id, etc.)
    ↓
Transform to Graph Format
    ↓
Batch Insert (UNWIND, 1000 rows)
    ↓
Acknowledge Message
```

---

## Non-Functional Requirements

### NFR1. Performance

| Metric | Requirement | Current Status |
|--------|-------------|----------------|
| **Query Latency (P95)** | <100ms (simple), <500ms (complex) | ✅ Met |
| **Ingestion Throughput** | >500 tickets/sec | ✅ Exceeds (1000+) |
| **Concurrent Users** | 100+ simultaneous connections | ✅ Met |
| **Database Response Time** | <50ms | ✅ Met (Memgraph) |
| **LLM Query Translation** | <2 seconds | ✅ Met |
| **Health Check Response** | <10ms | ✅ Met |

### NFR2. Scalability

- **Horizontal Scaling**: MCP Server pods (2-10 replicas via HPA)
- **Database Scaling**: Single Memgraph instance (HA requires Enterprise)
- **NATS Scaling**: Clustered NATS deployment for HA
- **Resource Limits**:
  - CPU: 500m request, 2000m limit
  - Memory: 1Gi request, 4Gi limit

### NFR3. Reliability

- **Uptime**: 99.5% target (excluding planned maintenance)
- **Data Durability**: Memgraph persistent storage via PVC
- **Message Delivery**: At-least-once guarantee (NATS JetStream)
- **Health Checks**: Liveness (30s interval), Readiness (10s interval)
- **Restart Policy**: Always (Docker), OnFailure (Kubernetes)

### NFR4. Maintainability

- **Code Coverage**: 30% (target: 70%)
- **Documentation**: Architecture, API, deployment guides
- **Logging**: Structured logging (JSON format recommended for production)
- **Monitoring**: Health endpoint (Prometheus-compatible metrics recommended)

### NFR5. Security

- **Authentication**: None (internal network only)
  - **Recommendation**: Add API key or OAuth2 for production
- **Authorization**: None
  - **Recommendation**: Implement RBAC for multi-tenancy
- **Encryption**: None (plain Bolt protocol)
  - **Recommendation**: Enable TLS for Memgraph connections
- **Input Validation**: Pydantic models for data validation
- **SQL Injection Prevention**: Parameterized Cypher queries

---

## Data Model

### Graph Schema

#### Node Types

**Client Node**
```python
{
    "cl_id": "Client_96757",      # Primary key
    "client_id": 96757,            # Original ID
    "client_name": "ACME Corp"
}
```

**Ticket Node**
```python
{
    "tkt_id": "Ticket_8709441",    # Primary key
    "ticket_id": 8709441,
    "ticket_status": "Closed",
    "priority": 2,
    "ticket_category": "Outage",
    "ticket_queue": "NOC",
    "created_by": "John Doe",
    "created_on": "2025-01-15 10:30:00",
    "closed_on": "2025-01-15 12:30:00",
    "assigned_to": "Jane Smith"
}
```

**Incident Node**
```python
{
    "inc_id": "Incident_8709441",
    "fault_description": "Circuit down due to hardware failure",
    "fault_occured_date": "2025-01-15",
    "additional_info": "Router failure detected",
    "sears_incident_id": "INC-2025-001"
}
```

**Service Node**
```python
{
    "svc_id": "Service_8709441",
    "subcategory": "Internet",
    "technology": "Fiber",
    "service_restored_date": "2025-01-15 12:00:00"
}
```

**Outage_Info Node**
```python
{
    "oi_id": "Outage_8709441",
    "rfo": "Hardware Failure",  # Reason For Outage
    "resolution": "Replaced faulty router",
    "customer_resolution": "Service restored",
    "mttr": 120,                # Minutes To Repair
    "outage_total": 1,
    "outage_duration": "2 hours",
    "internal_mttr": "1 hour 45 minutes"
}
```

**UserInfo Node**
```python
{
    "user_id": "U12345",
    "name": "Jane Smith",
    "email": "jane.smith@company.com",
    "role": "Incident Manager"
}
```

**ContactInfo Node**
```python
{
    "contact_id": "C789",
    "name": "Bob Johnson",
    "email": "bob@acme.com",
    "phone": "+1-555-0100",
    "contact_type": "Primary"
}
```

**VendorInfo Node**
```python
{
    "vendor_id": "V001",
    "vendor": "AT&T",
    "vendor_downtime": "30 minutes"
}
```

#### Relationship Types

| Relationship | From | To | Cardinality |
|--------------|------|------|-------------|
| `HAS_TICKET` | Client | Ticket | 1:N |
| `TRIGGERED_BY` | Ticket | Incident | 1:1 |
| `HAS_OUTAGE_INFO` | Ticket | Outage_Info | 1:1 |
| `IMPACTS` | Incident | Service | 1:N |
| `HAS_INCIDENT_MANAGER` | Ticket | UserInfo | 1:1 |
| `HAS_OPS_SPECIALIST` | Ticket | UserInfo | 1:1 |
| `HAS_SD_ENGINEER` | Ticket | UserInfo | 1:1 |
| `HAS_TIER2_ENGINEER` | Ticket | UserInfo | 1:1 |
| `HAS_CONTACT` | Ticket | ContactInfo | 1:N |
| `INVOLVES_VENDOR` | Ticket | VendorInfo | 1:N |
| `CHILD_OF` | Ticket | Ticket | N:1 |
| `LINKED_TO` | Ticket | Ticket | N:N |

---

## API Reference

### MCP Protocol

#### Tool Discovery
```json
Request:
{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/list"
}

Response:
{
    "jsonrpc": "2.0",
    "id": 1,
    "result": {
        "tools": [
            {
                "name": "ask_tickets_question",
                "description": "Translate natural language question to Cypher query and execute",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "user_query": {"type": "string"}
                    },
                    "required": ["user_query"]
                }
            },
            // ... 11 more tools
        ]
    }
}
```

#### Tool Invocation
```json
Request:
{
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
        "name": "get_ticket_details",
        "arguments": {
            "ticket_id": "Ticket_8709441"
        }
    }
}

Response:
{
    "jsonrpc": "2.0",
    "id": 2,
    "result": {
        "content": [
            {
                "type": "text",
                "text": "{\"ticket\": {...}, \"client\": {...}, ...}"
            }
        ]
    }
}
```

### Health Check API

```
GET /health

Response 200 OK:
{
    "status": "healthy",
    "service": "mcp_ticket_server",
    "memgraph_connected": true,
    "timestamp": "2025-10-13T10:20:30.123456Z"
}

Response 503 Service Unavailable:
{
    "status": "unhealthy",
    "service": "mcp_ticket_server",
    "memgraph_connected": false,
    "error": "Connection refused to bolt://memgraph:7687"
}
```

---

## Integration Specifications

### Memgraph Integration

**Connection String**: `bolt://memgraph:7687`
**Driver**: neo4j-python-driver 5.17+
**Protocol**: Neo4j Bolt 4.x
**Authentication**: Optional (username/password)
**Connection Pool**: 50 connections (max)
**Timeout**: 60 seconds (connection acquisition)

**Schema Initialization**:
```cypher
-- Executed on first connection
CREATE INDEX ON :Client(cl_id);
CREATE INDEX ON :Ticket(tkt_id);
CREATE INDEX ON :Ticket(ticket_status);
CREATE INDEX ON :Ticket(priority);
```

---

### NATS JetStream Integration

**Connection URL**: `nats://nats-server:4222`
**Client**: nats-py 2.10.0+
**Stream**: `DATA_INJESTION_STREAM`
**Subject**: `tickets.created`
**Consumer**: `ticket_consumer_durable` (pull-based)
**Batch Size**: 10 messages
**Fetch Timeout**: 2 seconds
**ACK Policy**: Explicit
**Max Deliveries**: 5 attempts
**ACK Wait**: 30 seconds

---

### BAML + LLM Integration

**LLM Provider**: Ollama (openai-generic provider)
**Model**: llama3.1-cypher:8b
**Base URL**: `http://ollama:11434/v1`
**API**: OpenAI-compatible HTTP API
**Temperature**: 0.2 (deterministic output)
**Max Tokens**: Auto
**Timeout**: 60 seconds
**Retry Policy**: Exponential backoff (3 retries)

**Prompt Template**:
```
You are an expert Memgraph database engineer.
Your task is to translate the user's natural language question
into a valid Cypher query based on the provided schema.

Graph Schema:
<schema_description>

Constraints:
- Only generate the Cypher query (no explanations)
- Use WHERE clauses with LOWER() and CONTAINS for text matching
- Verify relationships exist before querying

User Question: <question>
Cypher Query:
```

---

## Deployment Specifications

### Docker Image

**Base Image**: python:3.13-slim
**Final Image Size**: ~800MB (with dependencies)
**Layers**:
1. Base OS + Python 3.13
2. System dependencies (curl, etc.)
3. Python dependencies (pip install)
4. Application code
5. BAML generated client

**Build Command**:
```bash
docker build -t mcp-ticket-server:v2.0 .
```

**Run Command (Development)**:
```bash
docker-compose up -d
```

---

### Kubernetes Deployment

**Namespace**: `mcp-ticket-system`
**Deployment**: `mcp-ticket-deployment`
**Replicas**: 2-10 (auto-scaled via HPA)
**Service**: `mcp-ticket-service` (ClusterIP)
**Ingress**: `/mcp/ticket/*` → `mcp-ticket-service:8000`

**Resource Allocation**:
```yaml
resources:
  requests:
    cpu: 500m
    memory: 1Gi
  limits:
    cpu: 2000m
    memory: 4Gi
```

**Environment Variables**:
```yaml
env:
- name: MEMGRAPH_URI
  value: "bolt://memgraph-service:7687"
- name: NATS_URL
  value: "nats://nats-service:4222"
- name: OLLAMA_BASE_URL
  valueFrom:
    configMapKeyRef:
      name: mcp-ticket-config
      key: OLLAMA_BASE_URL
```

---

## Migration Guide (v1.0 → v2.0)

### Breaking Changes

#### 1. Database Driver Change
```python
# v1.0 (Kuzu)
import kuzu
db = kuzu.Database("./ticket_kuzu_db")
conn = kuzu.Connection(db)
result = conn.execute("MATCH (n) RETURN n")
data = result.get_as_pl()  # Polars DataFrame

# v2.0 (Memgraph)
from neo4j import GraphDatabase
driver = GraphDatabase.driver("bolt://memgraph:7687")
with driver.session() as session:
    result = session.run("MATCH (n) RETURN n")
    data = [record.data() for record in result]  # List of dicts
```

#### 2. Configuration Changes
```yaml
# v1.0
kuzu:
  db_path: "./ticket_kuzu_db"

# v2.0
memgraph:
  uri: "bolt://localhost:7687"
  user: ""
  password: ""
  database: "memgraph"
```

#### 3. Method Renames
```python
# v1.0
client.createKuzuDb()
client.cleanKuzuDb()

# v2.0
client.connect()
client.clearDatabase()
```

### Migration Steps

1. **Backup Existing Data** (if needed)
   ```bash
   # v1.0 database located at: ./ticket_kuzu_db/
   tar -czf kuzu_db_backup_$(date +%Y%m%d).tar.gz ./ticket_kuzu_db/
   ```

2. **Update Dependencies**
   ```bash
   pip uninstall kuzu
   pip install neo4j>=5.17.0
   pip install --upgrade baml-py==0.210.0
   ```

3. **Update Configuration**
   - Update `config.yml` with Memgraph settings
   - Set environment variables: `MEMGRAPH_URI`, `MEMGRAPH_USER`, `MEMGRAPH_PASSWORD`

4. **Deploy Memgraph**
   ```bash
   docker-compose up -d memgraph
   ```

5. **Regenerate BAML Client**
   ```bash
   cd server/app
   baml-cli generate
   ```

6. **Test Connection**
   ```bash
   curl http://localhost:8000/health
   ```

7. **Re-ingest Data** (if needed)
   - Replay messages from NATS (if durable)
   - Or re-run ETL pipeline

### Data Migration (Optional)

If you need to migrate existing data from Kuzu to Memgraph:

```python
# Export from Kuzu
import kuzu
import json

kuzu_db = kuzu.Database("./ticket_kuzu_db")
kuzu_conn = kuzu.Connection(kuzu_db)
result = kuzu_conn.execute("MATCH (n) RETURN n")
data = result.get_as_pl().to_dicts()

with open("kuzu_export.json", "w") as f:
    json.dump(data, f)

# Import to Memgraph
from neo4j import GraphDatabase

driver = GraphDatabase.driver("bolt://localhost:7687")
with open("kuzu_export.json") as f:
    data = json.load(f)

with driver.session() as session:
    for record in data:
        # Transform and insert (custom logic)
        session.run("CREATE (n:Node $props)", props=record)
```

---

## Known Limitations

### L1. Single Memgraph Instance
- **Issue**: No high availability (single point of failure)
- **Workaround**: Use Memgraph Enterprise for HA clustering
- **Impact**: Downtime during Memgraph restarts

### L2. No Authentication
- **Issue**: MCP endpoints publicly accessible (if exposed)
- **Workaround**: Deploy behind VPN or add API key middleware
- **Impact**: Security risk for production

### L3. Limited Test Coverage
- **Issue**: <30% unit test coverage
- **Workaround**: Manual testing, integration tests
- **Impact**: Higher risk of regressions

### L4. No Query Validation
- **Issue**: LLM-generated Cypher not validated before execution
- **Workaround**: Use prompt engineering to improve accuracy
- **Impact**: Invalid queries may cause errors

### L5. No Distributed Tracing
- **Issue**: Difficult to debug multi-service requests
- **Workaround**: Use correlation IDs in logs
- **Impact**: Longer troubleshooting time

---

## Appendices

### Appendix A: Cypher Query Examples

**Get all tickets for a client**:
```cypher
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
WHERE LOWER(c.client_name) CONTAINS LOWER('acme')
RETURN t
```

**Find root cause of an outage**:
```cypher
MATCH path = (t:Ticket)-[:TRIGGERED_BY*]->(root:Incident)
WHERE t.tkt_id = 'Ticket_8709441' AND NOT (root)-[:TRIGGERED_BY]->()
RETURN path
```

**Get high-priority open tickets**:
```cypher
MATCH (t:Ticket)
WHERE t.ticket_status IN ['Open', 'In Progress'] AND t.priority >= 3
RETURN t
ORDER BY t.priority DESC, t.created_on ASC
LIMIT 100
```

### Appendix B: Environment Variables Reference

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `MEMGRAPH_URI` | Yes | `bolt://localhost:7687` | Memgraph connection URI |
| `MEMGRAPH_USER` | No | `""` | Database username |
| `MEMGRAPH_PASSWORD` | No | `""` | Database password |
| `MEMGRAPH_DATABASE` | No | `memgraph` | Database name |
| `NATS_URL` | Yes | `nats://localhost:4222` | NATS server URL |
| `OLLAMA_BASE_URL` | Yes | `http://localhost:11434/v1` | Ollama API endpoint |
| `OLLAMA_MODEL` | Yes | `llama3.1-cypher:8b` | LLM model name |
| `LLM_TEMPERATURE` | No | `0.2` | LLM sampling temperature |
| `JETSTREAM_STREAM_NAME` | No | `DATA_INJESTION_STREAM` | NATS stream name |
| `TICKET_PUBLISH_SUBJECT` | No | `tickets.created` | NATS publish subject |
| `TICKET_SUBSCRIBE_SUBJECT` | No | `tickets.created` | NATS subscribe subject |

### Appendix C: File Structure

```
mcp_ticket/
├── server/
│   ├── app/
│   │   ├── baml_src/          # BAML definitions
│   │   ├── configs/            # Configuration files
│   │   ├── data_access/        # Database clients
│   │   │   ├── cyphers/        # Cypher query templates
│   │   │   └── messaging/      # NATS consumer
│   │   ├── services/           # Business logic
│   │   ├── tools/              # MCP tools (12 tools)
│   │   ├── utils/              # Helper functions
│   │   ├── main.py             # Application entry point
│   │   └── requirements.txt    # Python dependencies
│   ├── k8s/                    # Kubernetes manifests
│   ├── scripts/                # Deployment scripts
│   ├── tests/                  # Unit + integration tests
│   ├── Dockerfile              # Production image
│   └── docker-compose.yml      # Local development
├── MATURITY_ASSESSMENT_V2.md   # System maturity analysis
├── LOGICAL_ARCHITECTURE.md     # Conceptual architecture
├── TECHNICAL_ARCHITECTURE.md   # Implementation details
└── SYSTEM_SPECIFICATION_V2.md  # This document
```

---

## Document Control

| Attribute | Value |
|-----------|-------|
| **Document Version** | 3.0.0 |
| **Last Updated** | October 22, 2025 |
| **Next Review Date** | January 22, 2026 (Quarterly) |
| **Approval Status** | Approved for Internal Use |
| **Distribution** | Engineering Team, Operations |
| **Classification** | Internal Technical |

### Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 3.0.0 | Oct 22, 2025 | System | Vector search integration with Milvus |
| 2.0.0 | Oct 13, 2025 | System | Memgraph migration, complete rewrite |
| 1.0.0 | Sep 26, 2025 | System | Initial specification (Kuzu-based) |

---

**End of Document**
