import uuid
from contextvars import ContextVar
from typing import Optional

# Context variable to store correlation ID
correlation_id: ContextVar[str] = ContextVar("correlation_id", default=None)


def generate_correlation_id() -> str:
    """Generate a new correlation ID"""
    return str(uuid.uuid4())


def get_correlation_id() -> Optional[str]:
    """Get the current correlation ID from context"""
    return correlation_id.get()


def set_correlation_id(cid: str = None) -> str:
    """Set correlation ID in context, generate new one if not provided"""
    if cid is None:
        cid = generate_correlation_id()
    correlation_id.set(cid)
    return cid


class CorrelationContext:
    """Context manager for correlation ID"""

    def __init__(self, cid: str = None):
        self.correlation_id = cid or generate_correlation_id()
        self.token = None

    def __enter__(self):
        self.token = correlation_id.set(self.correlation_id)
        return self.correlation_id

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.token:
            correlation_id.reset(self.token)
