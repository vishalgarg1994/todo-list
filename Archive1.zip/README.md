# Eva MCP Ticket System

> **Enterprise Knowledge Graph & Vector Search for Intelligent Ticket Management**
> Memgraph + Milvus + NATS + FastMCP + BAML

## What is This?

The Eva MCP Ticket System is an enterprise-grade [Model Context Protocol](https://modelcontextprotocol.io) server that provides intelligent ticket analysis through:

- **Knowledge Graph** (Memgraph) - Entity relationships and network topology
- **Vector Search** (Milvus) - Semantic similarity for fault descriptions
- **Message Streaming** (NATS JetStream) - Real-time ticket ingestion
- **AI Integration** (BAML + Ollama) - Natural language query interface
- **MCP Tools** (27 tools) - Graph queries, semantic search, administration

The system enables AI assistants and agents to perform sophisticated ticket analysis, relationship exploration, and semantic search through natural language queries.

---

## 🎯 Key Features

✅ **27 MCP Tools** - Graph queries, semantic search, admin tools
✅ **Knowledge Graph** - 11 node types, 19+ relationship types
✅ **Semantic Search** - Fine-tuned embeddings for telecom domain
✅ **43× Performance** - Async architecture with strategic locking
✅ **Production Ready** - Kubernetes deployment with Helm charts
✅ **Interactive Testing** - Python-based testing client

---

## 🚀 Quick Start (5 Minutes)

```bash
# Clone repository
cd /path/to/eva/mcp_ticket/server

# Start all services (Memgraph, Milvus, NATS, Ollama, MCP Server)
docker-compose up -d

# Verify system health
curl http://localhost:8003/health
python system_health_check.py

# Load test data (optional)
python load_synthetic_data.py
```

**Access Points:**
- **MCP Server:** http://localhost:8003
- **Memgraph Lab:** http://localhost:7444
- **NATS Monitor:** http://localhost:8222
- **MinIO Console:** http://localhost:9001 (minioadmin/minioadmin)

---

## 📚 Documentation

### Architecture & Design
- **[Technical Architecture](docs/TECHNICAL_ARCHITECTURE.md)** - System design and components
- **[Logical Architecture](docs/LOGICAL_ARCHITECTURE.md)** - Business logic and data flow
- **[System Specification](docs/SYSTEM_SPECIFICATION.md)** - Requirements and specifications
- **[Async Performance Architecture](docs/ASYNC_PERFORMANCE_ARCHITECTURE.md)** - 43× performance optimization
- **[Semantic Search Architecture](docs/SEMANTIC_SEARCH_ARCHITECTURE.md)** - Vector search implementation

### Operations & Deployment
- **[Deployment Guide](docs/DEPLOYMENT_GUIDE.md)** - Docker and Kubernetes deployment
- **[Testing Guide](docs/TESTING_GUIDE.md)** - Test suite and quality assurance
- **[Maturity Assessment](docs/MATURITY_ASSESSMENT.md)** - Production readiness analysis

### Specialized Topics
- **[Fine-Tuning Overview](docs/FINE_TUNING_OVERVIEW.md)** - Embedding model customization
- **[References](docs/references/)** - API docs and technical references
- **[Archive](docs/archive/)** - Historical docs and completed phases

---

## 🖥️ Components

### Server (`/server`)

**FastMCP-based MCP server with 27 tools across 3 categories:**

#### Graph Query Tools (`tools/tickets/`)
- Search tickets by client, service, timeframe
- Entity relationship exploration
- Outage and maintenance tracking
- User, contact, vendor information

#### Semantic Search Tools (`tools/vector/`)
- 8 specialized semantic search tools
- Fine-tuned telecom embeddings
- Context-aware fault description matching
- Configurable similarity thresholds

#### Administration Tools (`tools/admin/`)
- System health monitoring
- Database statistics
- Configuration management
- Performance metrics

**Technology Stack:**
- FastMCP 2.9+ (MCP interface)
- Memgraph (graph database)
- Milvus (vector search)
- NATS JetStream (messaging)
- BAML + Ollama (LLM integration)

### Client (`/client`)

**Interactive Python-based testing interface:**

```bash
cd client/app
python3 interactive_test.py
```

**Features:**
- Menu-driven tool selection
- Parameter input prompts
- Response visualization
- JSON output formatting

**Available Test Scripts:**
- `interactive_test.py` - Full interactive menu
- `ask_eva.py` - BAML natural language queries
- `test_tools.py` - Automated tool testing
- `test_direct.py` - Direct API testing

---

## 🏗️ System Architecture

```
External Systems (Ticketing ETL)
        ↓
    NATS JetStream
  (EVA_TICKETING_STREAM)
        ↓
┌───────────────────────────┐
│   MCP Ticket Server       │
│  ┌─────────────────────┐  │
│  │  FastMCP Interface  │  │ ← AI Assistants / Agents
│  │   (27 MCP Tools)    │  │
│  └──────────┬──────────┘  │
│             │              │
│  ┌──────────┴──────────┐  │
│  │  Message Handler    │  │
│  │ (Async Processing)  │  │
│  └──┬────────────────┬─┘  │
│     │                │     │
│  ┌──▼──────┐   ┌────▼───┐ │
│  │Memgraph │   │ Milvus │ │
│  │  Graph  │   │ Vector │ │
│  └─────────┘   └────────┘ │
└───────────────────────────┘
        ↓
  Testing Client (Python CLI)
```

### Knowledge Graph Schema

**11 Node Types:**
- Client, Service, Incident, Ticket
- Outage_Info, UserInfo, ContactInfo
- VendorInfo, MaintenanceWindow
- SurveyInfo, NOCInfo

**19+ Relationship Types:**
- CLIENT_HAS_SERVICE, SERVICE_HAS_INCIDENT
- ASSIGNED_TO, MANAGED_BY
- VENDOR_SUPPLIES, VENDOR_HAS_CONTACT
- SCHEDULED_FOR, MAINTENANCE_AFFECTS

### Vector Search

**Milvus Configuration:**
- Index: IVF_FLAT with COSINE metric
- Embeddings: nomic-embed-text-v1.5 (fine-tuned)
- Dimension: 768
- Storage: Fault descriptions for semantic similarity

---

## 🛠️ Development

### Local Setup

```bash
cd server

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r app/requirements.txt

# Start external services
docker-compose up -d memgraph milvus nats ollama

# Run server
python app/main.py
```

### Quality Assurance

```bash
# Tests (11/11 passing)
make test

# Linting (120-char lines)
make lint

# Formatting
black app/ tests/ --line-length 120
```

### Database Management

```bash
# View database in browser
python3 view_memgraph_db.py  # http://localhost:8080

# Or use Memgraph Lab
cd scripts && ./explore_memgraph.sh 7444

# Health check
python3 system_health_check.py
```

---

## 🐳 Deployment

### Docker Compose (Development)

```bash
cd server
docker-compose up -d
```

Includes: MCP Server, Memgraph, Milvus, NATS, Ollama, Etcd, MinIO

### Kubernetes (Production)

```bash
cd server/helm

# Deploy to development
./deploy.sh dev --install

# Deploy to production
./deploy.sh prod --upgrade
```

---

## ⚙️ Configuration

**Environment Files:**
- `.env.development` - Development settings
- `.env.staging` - Staging settings
- `.env.production` - Production settings

**Key Configuration:**
```bash
# NATS JetStream
JETSTREAM_STREAM_NAME=EVA_TICKETING_STREAM
TICKET_SUBSCRIBE_SUBJECT=tickets.created

# Databases
MEMGRAPH_URI=bolt://localhost:7687
MILVUS_HOST=localhost
MILVUS_PORT=19530

# Performance
MEMGRAPH_MAX_CONCURRENT=5  # 3-7 recommended

# MCP Server
MCP_SERVER_PORT=8003
```

---

## 📊 Performance

- **Processing Speed:** 0.098s/message (43× improvement)
- **Reliability:** 100% success rate
- **Concurrency:** 3-10 configurable concurrent tasks
- **Throughput:** ~10 messages/second sustained
- **Latency:** <100ms graph queries, <200ms semantic search

---

## 📁 Project Structure

```
mcp_ticket/
├── README.md                    # This file
├── docs/                        # Documentation
│   ├── TECHNICAL_ARCHITECTURE.md
│   ├── DEPLOYMENT_GUIDE.md
│   ├── SEMANTIC_SEARCH_ARCHITECTURE.md
│   ├── FINE_TUNING_OVERVIEW.md
│   ├── archive/                # Historical docs
│   └── references/             # API references
├── server/                      # MCP Server
│   ├── app/
│   │   ├── main.py
│   │   ├── tools/              # MCP tools
│   │   │   ├── admin/          # 6 admin tools
│   │   │   ├── tickets/        # 13 graph query tools
│   │   │   └── vector/         # 8 semantic search tools
│   │   ├── services/
│   │   ├── data_access/
│   │   └── utils/
│   ├── tests/                  # 11/11 passing
│   ├── helm/                   # Kubernetes
│   ├── fine_tuning/            # Local only
│   └── docker-compose.yml
└── client/                      # Testing client
    └── app/
        ├── interactive_test.py
        ├── ask_eva.py
        └── test_tools.py
```

---

## 🤝 Integration with Eva Ecosystem

**Upstream:** Ticketing ETL → NATS → MCP Server
**Downstream:** MCP Server → AI Assistants / Agents

---

## 📈 Status

**Completed:** ✅ Knowledge graph, Vector search, Async optimization, Semantic search, Kubernetes deployment, Testing infrastructure

**In Progress:** 🚧 Fine-tuned embeddings, Production monitoring

**Planned:** 📋 Real-time analytics, Advanced inference, Multi-tenant support

---

*Part of the Eva enterprise automation ecosystem*
