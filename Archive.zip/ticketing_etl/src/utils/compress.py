import gzip
import base64
import json
import logging

logger = logging.getLogger(__name__)

MAX_NATS_PAYLOAD = 1048576  # 1MB


def compress_and_check(message: str) -> bytes | None:
    original_size = len(message.encode("utf-8"))
    compressed = gzip.compress(message.encode("utf-8"))
    encoded = base64.b64encode(compressed).decode("utf-8")

    payload = {"compressed": True, "encoding": "gzip+base64", "data": encoded}

    final_bytes = json.dumps(payload).encode("utf-8")
    size = len(final_bytes)

    if size > MAX_NATS_PAYLOAD:
        logger.warning(
            "Message exceeds size limit and will be skipped",
            extra={
                "original_size_bytes": original_size,
                "compressed_size_bytes": size,
                "max_payload_bytes": MAX_NATS_PAYLOAD,
            },
        )
        return None

    return final_bytes
