# 🏥 Enterprise Ticketing Data Processor

This project is a **production-ready, enterprise-grade Python application** that:

- ✅ **Processes ticketing data** from PostgreSQL databases with knowledge graph extraction
- ✅ **Transforms complex data** into structured JSON with relationship mapping
- ✅ **Publishes to Eva Messaging Infrastructure** for reliable message delivery
- ✅ **Provides comprehensive health monitoring** with HTTP endpoints for APM integration
- ✅ **Runs on automated schedules** with circuit breakers and retry mechanisms
- ✅ **Supports Docker & Kubernetes** with production-ready health checks

---

## 🏗️ Architecture Overview

### **Core Components**
- **🎯 Data Pipeline Service** - Configuration-driven table processing with knowledge graph extraction
- **🧠 Knowledge Graph Engine** - Extracts User, Contact, Vendor, and Maintenance Window relationships  
- **📡 Eva Messaging Integration** - Connects to Eva NATS infrastructure for reliable message publishing
- **🏥 Health Monitoring System** - Comprehensive health checks with Prometheus metrics
- **⚙️ Enterprise Resilience** - Circuit breakers, retry handlers, and graceful degradation
- **📅 Daily Scheduling** - Configurable daily processing with precise time control

### **Health & Monitoring**
- **`/health`** - Comprehensive component health status
- **`/health/live`** - Kubernetes liveness probe  
- **`/health/ready`** - Kubernetes readiness probe
- **`/health/metrics`** - Prometheus-compatible metrics

---

## 📂 Project Structure

```plaintext
ticketing_data_processor/
├── src/                        # Application source code
│   ├── services/               # Core business services
│   │   ├── app_service.py      # Main data pipeline service
│   │   ├── health_service.py   # Health monitoring & checks
│   │   ├── http_server.py      # Health HTTP endpoints
│   │   └── scheduler.py        # Automated job scheduling
│   ├── domain/                 # Domain logic & transformations
│   │   ├── transformers.py     # Knowledge graph data transformers
│   │   └── table_config.py     # Configuration-driven table processing
│   ├── classes/                # Data models & core classes
│   │   ├── data_model.py       # Pydantic models with knowledge graph nodes
│   │   ├── jetstream_setup.py  # NATS JetStream configuration
│   │   └── queries.py          # Database query definitions
│   ├── utils/                  # Infrastructure utilities  
│   │   ├── connection_manager.py    # Database & NATS connection pooling
│   │   ├── circuit_breaker.py      # Circuit breaker implementation
│   │   ├── retry_handler.py        # Exponential backoff retry logic
│   │   ├── compress.py             # Data compression for NATS
│   │   ├── data_sanitizer.py       # Data sanitization & validation
│   │   └── config.py               # Environment configuration
│   ├── messaging/              # NATS message bus integration
│   │   ├── ticket_publisher.py # Message publishing with compression
│   │   └── ticket_subscriber.py # Message subscription handling
│   └── main.py                 # Application entry point with health server
├── tests/                      # Comprehensive test suite
│   ├── test_health_integration.py   # Health endpoint integration tests
│   ├── test_health_browser.py       # Browser compatibility tests
│   ├── test_health_manual.py        # Manual testing with live servers
│   ├── test_transformers_new.py     # Knowledge graph transformation tests
│   ├── test_data_model_new.py       # Data model validation tests
│   └── test_table_config_new.py     # Configuration management tests
├── config/                     # Configuration files
│   └── tables.yaml            # Table processing configurations
├── docs/                      # Documentation
│   ├── c-technical-architecture.md  # Technical architecture
│   ├── c-logical-architecture.md    # Logical architecture  
│   └── future-state-design.md       # Future roadmap
├── docker-compose.yml         # Docker orchestration with health checks
├── Dockerfile                 # Production-ready container image
└── requirements.txt           # Python dependencies
```

---

## 🚀 Quick Start

### 📋 Prerequisites
- Docker and Docker Compose installed
- PostgreSQL database accessible
- Eva messaging infrastructure running

### 🎯 Step-by-Step Setup

#### 1️⃣ Start Eva Messaging Infrastructure
**⚠️ CRITICAL**: Eva messaging must be running before starting the ticketing app.

```bash
# Navigate to your messaging-infrastructure project directory
cd /path/to/messaging-infrastructure

# Start Eva NATS infrastructure
docker-compose up -d

# Streams are automatically initialized on startup
# No manual init required!

# Verify NATS is healthy
curl http://localhost:8222/varz | jq '.server_id'

# Verify streams were created
docker logs eva-stream-init
```

#### 2️⃣ Configure Database Connection
Update your database connection in `docker-compose.override.yml`:

```yaml
version: '3.8'
services:
  app:
    environment:
      # Update with your PostgreSQL connection
      - DATABASE_URL=postgresql://user:password@host:port/database_name
```

#### 3️⃣ Start Ticketing Application
```bash
# From ticketing_etl project directory
docker-compose up -d

# Watch startup logs
docker-compose logs -f app
```

#### 4️⃣ Verify Everything Works
```bash
# Check application health
curl http://localhost:8080/health | jq '.status'

# Check Eva messaging connection
curl http://localhost:8080/health | jq '.components.nats.status'

# View real-time messages (optional)
open http://localhost:3001
```

### 🎛️ Access Points
- **Application Health**: http://localhost:8080/health
- **NATS Monitor**: http://localhost:8222
- **Message Viewer**: http://localhost:3001 (real-time message streaming)

### 🔧 Environment Configuration
Key environment variables (set in `docker-compose.override.yml`):

```bash
# Database (Required)
DATABASE_URL=postgresql://user:pass@host:port/db

# Eva Messaging (Pre-configured)
NATS_URL=nats://localhost:4222
NATS_PUBLISHER_USER=ticket-app
NATS_PUBLISHER_PASSWORD=ticket-app-2024

# Processing Schedule
DAILY_SCHEDULE_TIME=02:00                # UTC time for daily runs
RUN_ON_STARTUP=true                      # Process data on startup
LOOKUP_INTERVAL_MINUTES=1440             # 24 hours between runs
```

---

## 🏥 Health Monitoring & APM Integration

### **Health Endpoints**
The application provides enterprise-grade health monitoring:

| Endpoint | Purpose | Response Format |
|----------|---------|----------------|
| `/health` | Comprehensive health status | JSON with component details |
| `/health/live` | Liveness probe (Kubernetes) | Simple alive/dead status |
| `/health/ready` | Readiness probe (load balancer) | Service readiness status |
| `/health/metrics` | Prometheus metrics | Plain text metrics format |

### **Sample Health Response**
```json
{
  "status": "healthy",
  "timestamp": "2025-01-11T15:30:00Z",
  "version": "1.0.0",
  "uptime_seconds": 3600.0,
  "components": {
    "database": {
      "status": "healthy",
      "message": "Database is responsive",
      "response_time_ms": 15.2,
      "details": {"pool_size": 10}
    },
    "nats": {
      "status": "healthy", 
      "message": "NATS and JetStream are healthy",
      "response_time_ms": 8.7,
      "details": {"streams": 5, "consumers": 10}
    },
    "scheduler": {
      "status": "healthy",
      "message": "Scheduler is running",
      "details": {"active_jobs": 3}
    },
    "system": {
      "status": "healthy",
      "message": "System resources are healthy",
      "details": {
        "cpu_percent": 25.0,
        "memory_percent": 45.0,
        "disk_percent": 32.0
      }
    }
  }
}
```

### **APM Integration**
Compatible with major APM platforms:
- ✅ **Prometheus/Grafana** - Native metrics endpoint
- ✅ **DataDog** - Health check monitoring
- ✅ **New Relic** - Infrastructure & application monitoring
- ✅ **Elastic APM** - Performance monitoring & logging

---

## 🧠 Knowledge Graph Processing

### **Entity Extraction**
The application automatically extracts knowledge graph entities from ticketing data:

- **👥 User Nodes** - Incident managers, service desk engineers, technicians
- **📞 Contact Nodes** - Customer contacts, site contacts, suppliers  
- **🏢 Vendor Nodes** - Service providers with contact information
- **🔧 Maintenance Windows** - Scheduled maintenance periods with details

### **Sample Knowledge Graph Output**
```json
{
  "client_info": {"client_id": 123, "client": "Enterprise Customer"},
  "operational_status": [{
    "users": [
      {"username": "john.manager", "role": "incident_manager"},
      {"username": "jane.tech", "role": "service_desk_engineer"}
    ],
    "contacts": [
      {"name": "Bob Customer", "email": "bob@customer.com", "contact_type": "customer"}
    ],
    "vendors": [
      {"vendor_name": "NetworkCorp", "supplier_email": "support@networkcorp.com"}
    ],
    "maintenance_window": {
      "pw_start": "2025-01-15T02:00:00Z",
      "pw_reason": "Fiber upgrade maintenance"
    }
  }]
}
```

---

## 🧪 Testing Framework

### **Comprehensive Test Coverage**
- **📊 Integration Tests** - Core functionality without dependencies
- **🌐 Browser Tests** - Health endpoint format validation  
- **🔧 Manual Tests** - Interactive testing with live servers
- **⚙️ Unit Tests** - Individual component testing

### **Running Tests**
```bash
# Run all tests
pytest -v

# Run health endpoint tests
pytest -k health -v

# Run manual browser testing (30-second live server)
pytest -m manual tests/test_health_manual.py -v -s
```

### **Health Endpoint Browser Testing**
```bash
# Start interactive test server
pytest tests/test_health_manual.py::TestHealthEndpointManual::test_start_health_server_for_manual_testing -v -s

# Then visit in browser:
# - http://localhost:8085/health
# - http://localhost:8085/health/live  
# - http://localhost:8085/health/ready
# - http://localhost:8085/health/metrics
```

---

## 🛡️ Enterprise Resilience & Runtime Behavior

### **Startup Dependencies (Hard Requirements)**
The application requires these services to be available during startup:
- ✅ **Database**: PostgreSQL connection pool initialization
- ✅ **Eva NATS**: Messaging infrastructure connection and stream validation

### **Runtime Resilience (Graceful Degradation)**
During runtime, the application handles service outages gracefully:

| Service Outage | Behavior | Impact |
|----------------|----------|--------|
| **Database Down** | ✅ Logs error, skips affected table, continues with other tables | Table marked as failed, retries next cycle |
| **NATS Down** | ✅ Data extracted/transformed, publishing fails gracefully, logs error | Processing continues, messages queued in DLQ |
| **Both Down** | ✅ Tables fail individually, app continues running, health endpoints active | Failed tables retry next cycle |

### **Circuit Breaker Protection**
- **NATS Publishing**: Opens after 5 failures, 5-minute timeout
- **Dead Letter Queue**: Failed messages preserved for 6 hours (100 message limit)
- **Automatic Recovery**: Circuit closes automatically when service recovers

### **Operational Benefits**
- ✅ **No Cascade Failures**: Database issues don't crash NATS processing
- ✅ **Partial Success**: Tables process independently
- ✅ **Automatic Retry**: Failed operations retry on next scheduled run
- ✅ **Zero Downtime**: Health endpoints remain active during outages
- ✅ **Observability**: Detailed logging and metrics for all failure scenarios

---

## 🐳 Production Deployment

### **Docker Build & Run**
```bash
# Build production image
docker build -t ticketing-processor:latest .

# Run with health monitoring
docker run -d -p 8080:8080 \
  -e DATABASE_URL="your-database-url" \
  -e NATS_URL="your-nats-url" \
  ticketing-processor:latest
```

### **Kubernetes Deployment**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ticketing-processor
spec:
  replicas: 3
  template:
    spec:
      containers:
      - name: app
        image: ticketing-processor:latest
        ports:
        - containerPort: 8080
        livenessProbe:
          httpGet:
            path: /health/live
            port: 8080
          initialDelaySeconds: 60
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /health/ready  
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
```

### **Docker Compose with Health Checks**
```yaml
services:
  app:
    build: .
    ports:
      - "8080:8080"
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:8080/health/live || exit 1"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - NATS_URL=${NATS_URL}
```

---

## 📊 Enterprise Features

### **🔄 Resilience & Reliability**
- **Circuit Breakers** - Prevent cascade failures
- **Retry Mechanisms** - Exponential backoff with jitter  
- **Connection Pooling** - Efficient database connections
- **Graceful Degradation** - Continue operation with reduced functionality

### **📈 Observability & Monitoring** 
- **Structured Logging** - JSON logs with correlation IDs
- **Metrics Collection** - Response times, error rates, resource usage
- **Health Checks** - Component-level health monitoring
- **Performance Tracking** - Database query times, NATS latency

### **⚙️ Configuration Management**
- **YAML-based Configuration** - Dynamic table processing configuration
- **Environment Variables** - 12-factor app compliance
- **Hot Configuration Reload** - Update settings without restart

---

## 🎯 Key Benefits

- 🏥 **Enterprise Monitoring** - Comprehensive health checks and APM integration
- 🧠 **Knowledge Graph Processing** - Automated relationship extraction from ticketing data
- 🔄 **Production Resilience** - Circuit breakers, retry logic, graceful degradation
- 📊 **Observability** - Structured logging, metrics, and performance tracking
- 🚀 **Cloud Native** - Kubernetes-ready with health probes and auto-scaling support
- 🧪 **Test-Driven** - Comprehensive test coverage with automated and manual testing

---

## 📚 Documentation

### Getting Started
- **[Quick Start Guide](QUICK_START.md)** - 5-minute Eva platform setup
- **[Development Guide](DEVELOPMENT_GUIDE.md)** - Comprehensive development workflow

### Technical Documentation
- **[Technical Architecture](docs/c-technical-architecture.md)** - Detailed technical design
- **[Logical Architecture](docs/c-logical-architecture.md)** - Business logic overview
- **[Health Testing Guide](README_HEALTH_TESTS.md)** - Comprehensive testing documentation
- **[Future Roadmap](docs/future-state-design.md)** - Planned enhancements

### Eva Messaging Integration
- **[Eva Messaging README](../messaging-infrastructure/README.md)** - Infrastructure documentation
- **[Integration Guide](../messaging-infrastructure/INTEGRATION_GUIDE.md)** - Application integration patterns

---

## 🔧 Development Commands

| Command | Description |
|---------|-------------|
| `docker-compose up -d` | Start all services in background |
| `docker-compose logs -f app` | Follow application logs |  
| `pytest -v` | Run complete test suite |
| `pytest -k health` | Run health endpoint tests |
| `pytest -m manual -s` | Interactive browser testing |
| `docker build -t app .` | Build production image |
| `curl http://localhost:8080/health` | Check health status |

---

## 📧 Support & Contributing

**👨‍💻 Author**: Aklilu Gebreyesus  
**📧 Email**: Aklilu.Gebreyesus@gtt.net  
**🐛 Issues**: Open a GitHub issue for bug reports or feature requests

### Contributing
1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Run tests: `pytest -v`  
4. Commit changes: `git commit -m 'Add amazing feature'`
5. Push to branch: `git push origin feature/amazing-feature`
6. Open a Pull Request

---

## 🔗 References & Technologies

- **[NATS JetStream](https://docs.nats.io/jetstream)** - Message streaming platform
- **[Pydantic](https://docs.pydantic.dev/)** - Data validation and serialization  
- **[FastAPI Health Checks](https://fastapi.tiangolo.com/advanced/health-checks/)** - Health monitoring patterns
- **[Prometheus Metrics](https://prometheus.io/docs/practices/naming/)** - Metrics best practices
- **[Kubernetes Health Checks](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/)** - Container health probes
- **[12-Factor App](https://12factor.net/)** - Cloud-native application principles

---

**🎉 Ready for enterprise deployment with comprehensive monitoring and knowledge graph processing!**