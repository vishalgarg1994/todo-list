# Eva MCP Ticket - Workstreams

## Completed

### WS-A: Ticket + Change Ingestion (Memgraph)
- NATS subjects: `tickets.created`, `tickets.change`
- DataLoader: Ticket, Client, Service, CI nodes + relationships
- ChangeLoader: Change, ChangeTask, CI nodes (count-batched 100/batch, infrastructure-level)
- Status: **COMPLETE**

### WS-B: Fault Description Embeddings (Milvus)
- NATS subject: `tickets.fault_description`
- FaultDescriptionConsumer: text -> EmbeddingService (nomic) -> Milvus `fault_descriptions` collection
- Client-batched (grouped by client_id)
- Status: **COMPLETE**

### WS-C: Notes Extraction Pipeline
- NATS subject: `tickets.notes` (future), TEST_MODE (current)
- NotesConsumer: text -> ExtractionService (Gemma 12B) -> structured extraction + summary
- Outputs: Milvus `ticket_notes` (embeddings), Memgraph NoteInfo nodes, correction JSON files
- Audit + corrections only for resolved tickets
- Status: **COMPLETE** (unit tests passing, TEST_MODE functional, NATS wiring pending)

---

## Future Workstreams

### WS-D: MCP Client Tools for Notes
**Purpose:** Expose note data to the LLM agent via new MCP tools.

**Scope:**
- `search_similar_notes(query, top_k)` - Semantic search on `ticket_notes` Milvus collection
- `get_note_extractions(ticket_id)` - Query NoteInfo nodes from Memgraph for a ticket
- `get_correction_suggestions(ticket_id)` - Read pending correction file for a ticket
- `get_ticket_timeline(ticket_id)` - Reconstruct timeline from NoteInfo nodes (service_down -> restored)

**Dependencies:** WS-C complete, client directory changes

**Files to modify:**
- `client/` - New tool definitions
- `server/` - New MCP tool handlers (if server-side tool registration)

---

### WS-E: Corrections Write-Back (ServiceNow API)
**Purpose:** Push approved corrections back to ServiceNow instead of just writing JSON files.

**Scope:**
- Human review queue (UI or API) for correction approval
- ServiceNow API integration (update ticket fields: responsible_party, MTTR, closure_code, priority)
- Confidence-based auto-approve (High confidence -> auto, Medium/Low -> human review)
- Audit trail of applied corrections

**Dependencies:** WS-C complete, ServiceNow API credentials + permissions

**Files to create:**
- `app/services/servicenow_client.py` - ServiceNow REST API client
- `app/services/correction_applier.py` - Reads pending JSONs, applies via API
- Review queue mechanism (TBD: could be another MCP tool, or separate UI)

---

### WS-F: Notes NATS Integration (ticketing_etl)
**Purpose:** Wire up the ETL pipeline to publish notes to NATS for real-time consumption.

**Scope:**
- Define PostgreSQL -> NATS message format for notes/journal entries
- Primary key handling (journal sys_id vs element_id)
- Client-centric batching (grouped by client_id, like fault descriptions)
- Incremental: only new/updated notes since last poll
- Ticket status included in message metadata (for resolved-only audit gating)

**Dependencies:** ticketing_etl codebase, PostgreSQL journal table schema

**Files to modify:**
- `ticketing_etl/` - New publisher for notes subject
- `messaging-infrastructure/` - Stream config for `tickets.notes` subject
- `server/app/consumers/notes_consumer.py` - Wire `_run_nats_mode()` to real message handler
- `server/app/main.py` - Add `tickets.notes` route in `route_message()`

---

### WS-G: Analytical Queries (Graph Intelligence)
**Purpose:** Enable analytical questions across the ticket knowledge graph.

**Scope:**
- Supplier performance: "Which supplier has the highest average MTTR?"
- Misclassification detection: "Show tickets where responsible_party was corrected"
- Fault pattern analysis: "What are the most common root causes for P1 HardDown tickets?"
- Customer impact: "Which clients have the most repeat incidents on the same circuit?"
- MTTR trends: "Average time-to-resolve by fault_type over the last 90 days"

**Implementation options:**
- Cypher queries exposed as MCP tools
- Pre-computed materialized views in Memgraph
- Dashboard integration (Grafana, custom UI)

**Dependencies:** WS-C (NoteInfo nodes populated), WS-F (production data flowing)

---

### WS-H: Feedback Loop + Prompt Tuning
**Purpose:** Use human-reviewed corrections to improve extraction quality over time.

**Scope:**
- Track acceptance/rejection rate of correction suggestions
- Identify systematic extraction errors (e.g., always misclassifying supplier vs GTT)
- Adjust extraction prompts based on error patterns
- Evaluate: fine-tune extraction model vs prompt engineering vs few-shot examples
- A/B test prompt variants on historical data

**Dependencies:** WS-E (corrections applied, acceptance data available), sufficient volume

---

## Workstream Dependency Graph

```
WS-A (Memgraph) ─────────────────────────────────────────┐
WS-B (Milvus FD) ────────────────────────────────────────┤
WS-C (Notes Pipeline) ──┬── WS-D (Client Tools)          │
                         ├── WS-E (ServiceNow Write-Back) ├── WS-G (Analytics)
                         ├── WS-F (NATS Integration)      │
                         └── WS-E ── WS-H (Feedback Loop) ┘
```

## Priority Order (suggested)

1. **WS-F** (NATS integration) - Needed for production data flow
2. **WS-D** (Client tools) - Makes notes queryable by the agent
3. **WS-E** (Corrections write-back) - Closes the loop with ServiceNow
4. **WS-G** (Analytics) - Value layer on top of populated graph
5. **WS-H** (Feedback loop) - Optimization once volume is sufficient
