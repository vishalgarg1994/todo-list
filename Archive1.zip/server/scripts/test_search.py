#!/usr/bin/env python3
"""
Simple test for semantic search
"""
import asyncio
import json
import sys
from pathlib import Path

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent / "app"))

from services.semantic_search_service import SemanticSearchService
from configs.config import Config

async def test_search():
    """Test semantic search"""
    config = Config()

    try:
        # Initialize service
        print("🔌 Initializing semantic search service...")
        service = SemanticSearchService(config)
        service.connect()
        service.milvus_client.load_collection()
        print("✅ Connected to Milvus and Ollama\n")

        # Test query
        query = "fiber cut outage"
        top_k = 5

        print(f"🔍 Searching for: '{query}'")
        print(f"   Top K: {top_k}\n")

        # Search (await since it's async)
        results = await service.search_similar_faults(query, top_k=top_k, min_score=0.5)

        print(f"{'='*70}")
        print(f"📊 Results: {len(results)} matches found")
        print(f"{'='*70}\n")

        for i, result in enumerate(results, 1):
            print(f"Result {i}:")
            print(f"   ID: {result.get('fault_description_id', 'N/A')}")
            print(f"   Score: {result.get('similarity_score', 0.0):.4f}")
            print(f"   Text: {result.get('fault_description', 'N/A')[:100]}...")
            print()

        # Disconnect
        service.disconnect()
        print("✅ Test complete!")

    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_search())
