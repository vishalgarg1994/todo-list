"""
Search and filtering tools for ticket system
Provides time-based filtering and contact lookup
"""
import asyncio
import logging
import polars as pl
from typing import Any, Optional
from fastmcp.exceptions import ToolError
from utils.utilities import Helpers


async def get_tickets_by_date_range(
    start_date: str,
    end_date: str,
    services: dict,
    client_name: Optional[str] = None,
    limit: Optional[int] = 100
) -> Any:
    """
    Get tickets created within a specific date range.

    Dates should be in ISO format (YYYY-MM-DD or YYYY-MM-DD HH:MM:SS).
    Optionally filter by client.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_tickets_by_date_range from {start_date} to {end_date}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Build query based on whether client_name is provided
        if client_name:
            cypher_query = """
                MATCH (c:Client {client_name: $client_name})-[:HAS_TICKET]->(t:Ticket)
                WHERE t.created_on >= $start_date AND t.created_on <= $end_date
                OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
                RETURN t.ticket_id as ticket_id,
                       t.ticket_status as status,
                       t.ticket_category as category,
                       t.priority as priority,
                       t.created_on as created_on,
                       t.closed_on as closed_on,
                       t.assigned_to as assigned_to,
                       o.rfo as rfo,
                       o.mttr as mttr
                ORDER BY t.created_on DESC
            """
            params = {"start_date": start_date, "end_date": end_date, "client_name": client_name}
        else:
            cypher_query = """
                MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
                WHERE t.created_on >= $start_date AND t.created_on <= $end_date
                OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
                RETURN c.client_name as client_name,
                       t.ticket_id as ticket_id,
                       t.ticket_status as status,
                       t.ticket_category as category,
                       t.priority as priority,
                       t.created_on as created_on,
                       t.closed_on as closed_on,
                       t.assigned_to as assigned_to,
                       o.rfo as rfo,
                       o.mttr as mttr
                ORDER BY t.created_on DESC
            """
            params = {"start_date": start_date, "end_date": end_date}

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute( cypher_query, params)
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No tickets found between {start_date} and {end_date}"}

        return Helpers.recursive_serialize({
            "start_date": start_date,
            "end_date": end_date,
            "client_name": client_name,
            "ticket_count": len(response_data),
            "tickets": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_tickets_by_date_range: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve tickets by date range: {e}")


# DISABLED - No contact data in PostgreSQL schema
# async def get_ticket_contacts(ticket_id: str, services: dict) -> Any:
#     """
#     Get all contacts associated with a ticket.
#
#     Returns customer contacts, POC contacts (A-end, Z-end), supplier contacts,
#     and local contacts with their contact details.
#     """
#     try:
#         logging.info(f"FastMCP Tool Call: get_ticket_contacts for ticket: '{ticket_id}'")
#
#         memgraph_client = services["memgraph_client"]
#         if not memgraph_client:
#             raise ToolError("Memgraph client not initialized.")
#
#         cypher_query = """
#             MATCH (t:Ticket {ticket_id: $ticket_id})
#             OPTIONAL MATCH (t)-[:TICKET_CONTACT]->(contact:ContactInfo)
#             OPTIONAL MATCH (c:Client)-[:HAS_TICKET]->(t)
#             OPTIONAL MATCH (c)-[:HAS_CONTACT]->(client_contact:ContactInfo)
#             RETURN t.ticket_id as ticket_id,
#                    collect(distinct {
#                        contact_id: contact.contact_id,
#                        name: contact.name,
#                        email: contact.email,
#                        phone: contact.phone,
#                        contact_type: contact.contact_type,
#                        source: 'ticket'
#                    }) as ticket_contacts,
#                    collect(distinct {
#                        contact_id: client_contact.contact_id,
#                        name: client_contact.name,
#                        email: client_contact.email,
#                        phone: client_contact.phone,
#                        contact_type: client_contact.contact_type,
#                        source: 'client'
#                    }) as client_contacts
#         """
#
#         result = await memgraph_client.execute( cypher_query, {"ticket_id": ticket_id})
#         records = [record.data() for record in result]
#         df = pl.DataFrame(records) if records else pl.DataFrame()
#         response_data = df.to_dicts()
#
#         if not response_data:
#             return {"message": f"No ticket found with ticket_id: {ticket_id}"}
#
#         data = response_data[0]
#
#         # Filter out null contacts and combine
#         ticket_contacts = [c for c in data.get('ticket_contacts', []) if c.get('contact_id')]
#         client_contacts = [c for c in data.get('client_contacts', []) if c.get('contact_id')]
#
#         # Group by contact type
#         contacts_by_type = {}
#         for contact in ticket_contacts + client_contacts:
#             contact_type = contact.get('contact_type', 'unknown')
#             if contact_type not in contacts_by_type:
#                 contacts_by_type[contact_type] = []
#             contacts_by_type[contact_type].append(contact)
#
#         return Helpers.recursive_serialize({
#             "ticket_id": ticket_id,
#             "total_contacts": len(ticket_contacts) + len(client_contacts),
#             "contacts_by_type": contacts_by_type,
#             "all_contacts": {
#                 "ticket_contacts": ticket_contacts,
#                 "client_contacts": client_contacts
#             }
#         })
#
#     except ToolError:
#         raise
#     except Exception as e:
#         logging.error(f"Error in get_ticket_contacts: {e}", exc_info=True)
#         raise ToolError(f"Failed to retrieve ticket contacts: {e}")
