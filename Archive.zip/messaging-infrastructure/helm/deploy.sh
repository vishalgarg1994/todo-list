#!/bin/bash
set -e

# Eva Messaging Infrastructure Helm Deployment Script

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CHART_DIR="$SCRIPT_DIR"
RELEASE_NAME="eva-messaging"

# Default values
ENVIRONMENT="dev"
NAMESPACE=""
DRY_RUN=false
UPGRADE=false

# Help function
show_help() {
    echo "Usage: $0 [ENVIRONMENT] [OPTIONS]"
    echo ""
    echo "Deploy Eva Messaging Infrastructure to Kubernetes"
    echo ""
    echo "ENVIRONMENTS:"
    echo "  dev      Deploy to development environment (default)"
    echo "  test  Deploy to test environment"
    echo "  prod     Deploy to production environment"
    echo ""
    echo "OPTIONS:"
    echo "  --upgrade    Upgrade existing deployment"
    echo "  --dry-run    Show what would be deployed without applying"
    echo "  --namespace  Override namespace (default: eva-messaging-[env])"
    echo "  --help       Show this help message"
    echo ""
    echo "EXAMPLES:"
    echo "  $0 dev                    # Deploy to dev"
    echo "  $0 prod --upgrade         # Upgrade production"
    echo "  $0 test --dry-run      # Preview test deployment"
    echo ""
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        dev|test|prod)
            ENVIRONMENT="$1"
            shift
            ;;
        --upgrade)
            UPGRADE=true
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        --help)
            show_help
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Set namespace if not provided
if [[ -z "$NAMESPACE" ]]; then
    NAMESPACE="eva-messaging-$ENVIRONMENT"
fi

# Values file based on environment
VALUES_FILE="$CHART_DIR/values-$ENVIRONMENT.yaml"
if [[ ! -f "$VALUES_FILE" ]]; then
    echo "❌ Values file not found: $VALUES_FILE"
    exit 1
fi

echo "🚀 Eva Messaging Infrastructure Deployment"
echo "=========================================="
echo "Environment: $ENVIRONMENT"
echo "Namespace: $NAMESPACE"
echo "Values file: $VALUES_FILE"
echo "Release name: $RELEASE_NAME"
echo ""

# Check if Helm is installed
if ! command -v helm &> /dev/null; then
    echo "❌ Helm is not installed. Please install Helm first."
    exit 1
fi

# Check if kubectl is available and configured
if ! kubectl cluster-info &> /dev/null; then
    echo "❌ kubectl is not configured or cluster is not accessible"
    exit 1
fi

# Validate Helm chart
echo "🔍 Validating Helm chart..."
if ! helm lint "$CHART_DIR" -f "$VALUES_FILE"; then
    echo "❌ Helm chart validation failed"
    exit 1
fi

# Create namespace if it doesn't exist
echo "📋 Creating namespace if needed..."
kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

# Determine Helm command
HELM_CMD="helm"
if [[ "$DRY_RUN" == "true" ]]; then
    HELM_CMD="$HELM_CMD --dry-run --debug"
    echo "🧪 Dry run mode - no changes will be made"
fi

if [[ "$UPGRADE" == "true" ]] || helm status "$RELEASE_NAME" -n "$NAMESPACE" &> /dev/null; then
    echo "⬆️  Upgrading release..."
    $HELM_CMD upgrade "$RELEASE_NAME" "$CHART_DIR" \
        --namespace "$NAMESPACE" \
        --values "$VALUES_FILE" \
        --atomic \
        --timeout 10m \
        --wait
else
    echo "📦 Installing release..."
    $HELM_CMD install "$RELEASE_NAME" "$CHART_DIR" \
        --namespace "$NAMESPACE" \
        --values "$VALUES_FILE" \
        --atomic \
        --timeout 10m \
        --wait \
        --create-namespace
fi

if [[ "$DRY_RUN" == "false" ]]; then
    echo ""
    echo "✅ Deployment completed successfully!"
    echo ""
    echo "📊 Deployment Status:"
    helm status "$RELEASE_NAME" -n "$NAMESPACE"
    echo ""
    echo "🔍 Pod Status:"
    kubectl get pods -n "$NAMESPACE" -l "app.kubernetes.io/instance=$RELEASE_NAME"
    echo ""
    echo "🌐 Services:"
    kubectl get services -n "$NAMESPACE" -l "app.kubernetes.io/instance=$RELEASE_NAME"
    echo ""

    # Environment-specific instructions
    case $ENVIRONMENT in
        dev)
            echo "🧪 Development Environment Ready!"
            echo "Port forwarding examples:"
            echo "  kubectl port-forward -n $NAMESPACE svc/$RELEASE_NAME-nats-monitor 8222:8222"
            echo "  kubectl port-forward -n $NAMESPACE svc/$RELEASE_NAME-message-ui 3001:3001"
            ;;
        test)
            echo "🎭 Test Environment Ready!"
            echo "Ingress should be available at configured domain"
            ;;
        prod)
            echo "🚀 Production Environment Ready!"
            echo "⚠️  Remember to:"
            echo "  - Monitor application logs"
            echo "  - Verify persistent volumes"
            echo "  - Check ingress certificates"
            ;;
    esac
fi