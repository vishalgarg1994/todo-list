"""
Unit tests for Milvus Client
"""
import pytest
from unittest.mock import Mock, patch
from data_access.milvusClient import MilvusClient


class TestMilvusClient:
    """Test suite for MilvusClient"""

    @pytest.fixture
    def client(self, mock_config):
        """Create MilvusClient instance with complete mock config"""
        return MilvusClient(mock_config)

    def test_initialization(self, client, mock_config):
        """Test client initialization"""
        assert client.config == mock_config
        assert client.collection_name == mock_config.milvus_collection_name
        assert client.collection is None

    @patch('data_access.milvusClient.connections')
    @patch('data_access.milvusClient.utility')
    @patch('data_access.milvusClient.Collection')
    def test_connect_existing_collection(self, mock_collection_class, mock_utility, mock_connections, client):
        """Test connection to existing collection"""
        # Setup mocks
        mock_utility.has_collection.return_value = True
        mock_collection = Mock()
        mock_collection_class.return_value = mock_collection

        # Test
        client.connect()

        # Verify
        mock_connections.connect.assert_called_once_with(
            alias="default",
            host=client.config.milvus_host,
            port=client.config.milvus_port
        )
        mock_utility.has_collection.assert_called_once_with(client.collection_name, using=client._alias)
        mock_collection_class.assert_called_once_with(client.collection_name, using=client._alias)
        assert client.collection == mock_collection

    @patch('data_access.milvusClient.connections')
    @patch('data_access.milvusClient.utility')
    @patch('data_access.milvusClient.Collection')
    def test_connect_with_auth(self, mock_collection_class, mock_utility, mock_connections, mock_config):
        """Test connection passes credentials when milvus_user and milvus_password are set"""
        # Setup config with auth
        mock_config.milvus_user = "admin"
        mock_config.milvus_password = "secret"
        client = MilvusClient(mock_config)

        mock_utility.has_collection.return_value = True
        mock_collection_class.return_value = Mock()

        # Test
        client.connect()

        # Verify credentials are passed
        mock_connections.connect.assert_called_once_with(
            alias="default",
            host=mock_config.milvus_host,
            port=mock_config.milvus_port,
            user="admin",
            password="secret"
        )

    @patch('data_access.milvusClient.connections')
    @patch('data_access.milvusClient.utility')
    @patch('data_access.milvusClient.Collection')
    @patch.object(MilvusClient, '_create_collection')
    def test_connect_creates_collection_if_not_exists(
        self, mock_create, mock_collection_class, mock_utility, mock_connections, client
    ):
        """Test connection creates collection if it doesn't exist"""
        # Setup mocks
        mock_utility.has_collection.return_value = False
        mock_collection = Mock()
        mock_create.return_value = mock_collection

        # Test
        client.connect()

        # Verify
        mock_connections.connect.assert_called_once()
        mock_create.assert_called_once()

    @patch('data_access.milvusClient.CollectionSchema')
    @patch('data_access.milvusClient.FieldSchema')
    @patch('data_access.milvusClient.Collection')
    @patch('data_access.milvusClient.DataType')
    def test_create_collection(
        self, mock_datatype, mock_collection_class, mock_field_schema, mock_schema, client
    ):
        """Test collection creation with correct schema"""
        # Setup mocks
        mock_schema_instance = Mock()
        mock_schema.return_value = mock_schema_instance
        mock_collection = Mock()
        mock_collection_class.return_value = mock_collection

        # Test
        client._create_collection()

        # Verify schema creation
        assert mock_field_schema.call_count == 4  # fault_description_id, embedding, text, summary
        mock_schema.assert_called_once()
        mock_collection_class.assert_called_once_with(
            name=client.collection_name,
            schema=mock_schema_instance,
            using=client._alias
        )
        # Verify collection was set
        assert client.collection == mock_collection

    def test_collection_is_connected_true(self, client):
        """Test is_connected when collection exists"""
        client.collection = Mock()
        client.is_connected = True
        assert client.is_connected is True

    def test_collection_is_connected_false(self, client):
        """Test is_connected when not connected"""
        client.collection = None
        client.is_connected = False
        assert client.is_connected is False

    def test_create_index(self, client):
        """Test index creation"""
        # Setup
        mock_collection = Mock()
        client.collection = mock_collection

        # Test
        client.create_index()

        # Verify
        mock_collection.create_index.assert_called_once()
        call_args = mock_collection.create_index.call_args
        assert call_args[1]["field_name"] == "embedding"
        assert call_args[1]["index_params"]["index_type"] == client.config.milvus_index_type
        assert call_args[1]["index_params"]["metric_type"] == client.config.milvus_metric_type

    @pytest.mark.asyncio
    async def test_insert_success(self, client):
        """Test successful insertion"""
        # Setup
        mock_collection = Mock()
        mock_upsert_result = Mock()
        mock_upsert_result.upsert_count = 3
        mock_collection.upsert.return_value = mock_upsert_result
        client.collection = mock_collection

        # Test data
        fault_description_ids = ["TEST001", "TEST002", "TEST003"]
        embeddings = [[0.1] * 768, [0.2] * 768, [0.3] * 768]
        fault_texts = ["Fiber cut at Main St", "BGP session down", "High latency"]

        # Test
        count = await client.insert(fault_description_ids, embeddings, fault_texts)

        # Verify
        assert count == 3

    @pytest.mark.asyncio
    async def test_insert_mismatched_lengths(self, client):
        """Test insertion with mismatched ID and embedding counts raises ValueError"""
        # Setup
        mock_collection = Mock()
        client.collection = mock_collection

        # Test data with mismatched lengths
        fault_description_ids = ["TEST001", "TEST002"]
        embeddings = [[0.1] * 768]  # Only one embedding
        fault_texts = ["Text1"]  # Only one text

        # Validation correctly rejects mismatched lengths
        with pytest.raises(ValueError, match="must have same length"):
            await client.insert(fault_description_ids, embeddings, fault_texts)

    @pytest.mark.asyncio
    async def test_insert_no_collection(self, client):
        """Test insertion when not connected"""
        # Setup - no collection
        client.collection = None

        # Test
        with pytest.raises(ValueError, match="not initialized"):
            await client.insert(["TEST001"], [[0.1] * 768], ["Text1"])

    @pytest.mark.asyncio
    async def test_search_success(self, client):
        """Test successful search"""
        # Setup
        mock_collection = Mock()

        # Mock search results
        mock_hit1 = Mock()
        mock_hit1.entity.get.return_value = "INC001"
        mock_hit1.distance = 0.1
        mock_hit1.score = 0.9

        mock_hit2 = Mock()
        mock_hit2.entity.get.return_value = "INC002"
        mock_hit2.distance = 0.2
        mock_hit2.score = 0.8

        mock_collection.search.return_value = [[mock_hit1, mock_hit2]]
        client.collection = mock_collection

        # Test
        query_embedding = [0.1] * 768
        results = await client.search(query_embedding, top_k=2)

        # Verify
        assert len(results) == 2
        assert results[0]["fault_description_id"] == "INC001"
        assert results[0]["distance"] == 0.1
        assert results[0]["score"] == 0.9
        assert results[1]["fault_description_id"] == "INC002"

    @pytest.mark.asyncio
    async def test_search_with_custom_nprobe(self, client):
        """Test search with custom nprobe parameter"""
        # Setup
        mock_collection = Mock()
        mock_collection.search.return_value = [[]]
        client.collection = mock_collection

        # Test
        query_embedding = [0.1] * 768
        await client.search(query_embedding, top_k=5, nprobe=64)

        # Verify - just check that search completed without error
        # (The actual search_params validation would require inspecting asyncio.to_thread calls)

    @pytest.mark.asyncio
    async def test_search_no_collection(self, client):
        """Test search when not connected"""
        # Setup - no collection
        client.collection = None

        # Test
        with pytest.raises(ValueError, match="not initialized"):
            await client.search([0.1] * 768)

    def test_get_collection_stats(self, client):
        """Test getting collection stats"""
        # Setup
        mock_collection = Mock()
        mock_collection.num_entities = 1500
        client.collection = mock_collection

        # Test
        stats = client.get_collection_stats()

        # Verify
        assert stats["num_entities"] == 1500
        assert stats["collection_name"] == client.collection_name

    def test_get_collection_stats_no_collection(self, client):
        """Test getting stats when not connected"""
        # Setup - no collection
        client.collection = None

        # Test
        with pytest.raises(ValueError, match="not initialized"):
            client.get_collection_stats()

    @patch('data_access.milvusClient.connections')
    def test_disconnect(self, mock_connections, client):
        """Test disconnection"""
        # Setup
        client.is_connected = True

        # Test
        client.disconnect()

        # Verify
        mock_connections.disconnect.assert_called_once_with("default")
        assert client.is_connected is False

    @patch('data_access.milvusClient.connections')
    def test_disconnect_no_collection(self, mock_connections, client):
        """Test disconnection when not connected"""
        # Setup - not connected
        client.collection = None
        client.is_connected = False

        # Test - should not raise error
        client.disconnect()

        # Verify - disconnect should not be called
        mock_connections.disconnect.assert_not_called()
        assert client.is_connected is False
