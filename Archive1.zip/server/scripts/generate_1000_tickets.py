#!/usr/bin/env python3
"""
Generate realistic dummy test data for async performance testing.
Creates 200 clients with varying numbers of tickets (2-12), totaling 1000 tickets.

Correct TicketSummary structure:
{
  "client_info": {...},
  "operational_status": [
    {...ticket1 with incident, outage_info, service, users, contacts, vendors...},
    {...ticket2 with incident, outage_info, service, users, contacts, vendors...},
    ...
  ]
}
"""

import json
from datetime import datetime, timedelta
import random

# Base date: 30 days ago
BASE_DATE = datetime.now() - timedelta(days=30)

def generate_timestamp(days_offset=0, hours_offset=0):
    """Generate realistic timestamp"""
    dt = BASE_DATE + timedelta(days=days_offset, hours=hours_offset)
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def create_operational_status(
    ticket_num, client_id,
    is_master=False, master_ticket_id=None,
    days_ago=0, status="Open", priority=3,
    has_survey=False, has_maintenance=False, has_vendor=False
):
    """Create a single operational_status entry (ticket + incident + outage_info + relationships)"""

    ticket_id = f"INC-{ticket_num:06d}"
    tkt_id = f"tkt_{ticket_id}"

    # User data
    users = []
    if random.random() > 0.3:  # 70% have incident manager
        users.append({
            "user_id": f"user_{random.randint(100, 199)}",
            "name": random.choice(["John Smith", "Jane Doe", "Mike Johnson", "Sarah Williams"]),
            "role": "incident_manager"
        })

    if random.random() > 0.4:  # 60% have ops specialist
        users.append({
            "user_id": f"user_{random.randint(200, 299)}",
            "name": random.choice(["Bob Anderson", "Alice Brown", "Tom Davis", "Emma Wilson"]),
            "role": "operations_specialist"
        })

    # Service desk engineer (no user_id)
    users.append({
        "name": random.choice(["Tech Support Team", "Service Desk L1", "Help Desk"]),
        "role": "service_desk_engineer"
    })

    # Contacts
    contacts = [
        {
            "contact_id": f"contact_{ticket_num}_1",
            "name": f"Customer Contact {ticket_num}",
            "email": f"customer{ticket_num}@example.com",
            "phone": f"+1-555-{random.randint(1000, 9999)}",
            "contact_type": "customer_contact"
        }
    ]

    # Vendors (only some tickets)
    vendors = []
    if has_vendor:
        vendors.append({
            "vendor_id": f"vendor_{random.randint(1, 5)}",
            "vendor": random.choice(["AT&T", "Verizon", "Lumen", "Zayo", "Cogent"]),
            "vendor_downtime": round(random.uniform(0, 240), 2)
        })

    # Maintenance window (only some tickets)
    maintenance_window = None
    if has_maintenance:
        mw_start = generate_timestamp(days_ago + 1, 2)
        mw_end = generate_timestamp(days_ago + 1, 6)
        maintenance_window = {
            "pw_start": mw_start,
            "pw_end": mw_end,
            "pw_duration": "4 hours",
            "pw_location": random.choice(["DC1-Main", "DC2-Backup", "Edge-NY", "Core-LA"]),
            "pw_reason": random.choice([
                "Planned router upgrade",
                "Fiber maintenance",
                "Software patch deployment",
                "Hardware replacement"
            ])
        }

    # Survey (only some tickets)
    survey_info = None
    if has_survey and status == "Closed":
        survey_score = random.randint(1, 5)
        survey_info = {
            "score_id": f"survey_{ticket_id}",
            "score_reason": "Good service" if survey_score >= 4 else "Slow response",
            "survey_score": survey_score,
            "survey_ref": f"SRV-{ticket_num:06d}",
            "survey_created_on": generate_timestamp(days_ago + 2)
        }

    # Assigned to
    assigned_to_id = f"user_{random.randint(300, 399)}"
    assigned_to = random.choice(["Chris Martinez", "Pat Garcia", "Alex Rodriguez", "Morgan Lee"])

    # Closed by (only if closed)
    closed_by = None
    closed_by_id = None
    closed_on = None
    if status == "Closed":
        closed_by_id = f"user_{random.randint(400, 499)}"
        closed_by = random.choice(["Resolver A", "Resolver B", "Resolver C"])
        closed_on = generate_timestamp(days_ago + 1, 8)

    created_on = generate_timestamp(days_ago, 0)

    return {
        "service_entity": {
            "svc_id": f"svc_{ticket_num:06d}",
            "subcategory": random.choice(["MPLS", "Internet", "Voice", "SD-WAN", "Private Line"]),
            "technology": random.choice(["Fiber", "Ethernet", "IP-VPN", "MPLS-VPN", "DWDM"]),
            "service_restored_date": closed_on if status == "Closed" else None,
            "related_circuit_id": random.randint(10000, 99999)
        },
        "incident_info": {
            "inc_id": f"inc_{ticket_id}",
            "fault_description_ref": f"FD-{ticket_num:06d}",
            "short_description": random.choice([
                "Network connectivity issue",
                "Service degradation",
                "Complete service outage",
                "Intermittent packet loss",
                "High latency detected",
                "Circuit down"
            ]),
            "is_customer_impacting": random.choice([True, False])
        },
        "ticket_info": {
            "tkt_id": tkt_id,
            "ticket_source": "Email",
            "ticket_id": ticket_id,
            "ticket_category": "Incident",
            "ticket_queue": "NOC-L2",
            "ticket_status": status,
            "ticket_substatus": "Assigned" if status == "Open" else "Resolved",
            "is_master_ticket": is_master,
            "master_ticket_id": master_ticket_id,
            "created_by": "System Auto",
            "created_on": created_on,
            "closed_on": closed_on,
            "source_system": "ServiceNow",
            "priority": priority,
            "type": "Reactive",
            "linked_ticket_id": None,
            "ticket_import_source": "ticketing_etl",
            "ticket_escalation_level": random.randint(0, 2),
            "next_action": "Monitor" if status != "Closed" else None,
            "next_action_date": generate_timestamp(days_ago - 1) if status != "Closed" else None,
            "next_action_date_notification_counter": 0,
            "updated_on": generate_timestamp(days_ago, 12),
            "closed_by": closed_by,
            "closed_by_id": closed_by_id,
            "assigned_to": assigned_to,
            "assigned_to_id": assigned_to_id,
            "first_assigned_to": assigned_to,
            "first_assigned_on": generate_timestamp(days_ago, 1),
            "first_resolved_on": closed_on,
            "oldest_resolved_date": closed_on,
            "first_child_ticket_created_on": None
        },
        "outage_info": {
            "oi_id": f"oi_{ticket_id}",
            "customer_resolution": "Service restored" if status == "Closed" else None,
            "resolution": random.choice([
                "Rebooted device",
                "Replaced failed component",
                "Configuration change",
                "Vendor resolved issue"
            ]) if status == "Closed" else None,
            "rfo": random.choice([
                "Hardware Failure",
                "Software Bug",
                "Configuration Error",
                "Fiber Cut",
                "Power Outage"
            ]),
            "outage_total": random.randint(0, 10),
            "outage_duration": f"{random.randint(1, 8)} hours" if status == "Closed" else None,
            "internal_mttr": f"{random.randint(30, 480)} minutes",
            "mttr": random.randint(30, 480),
            "problem_type": "Service Outage",
            "ticket_rfo_group": "Infrastructure",
            "is_worked_ticket": True,
            "closure_quality": "Good" if status == "Closed" else None,
            "first_email_from_customer_on": created_on,
            "first_customer_note_on": generate_timestamp(days_ago, 1),
            "first_supplier_dispatch_event_on": None,
            "first_tech_dispatch_event_on": None
        },
        "users": users,
        "contacts": contacts,
        "vendors": vendors,
        "maintenance_window": maintenance_window,
        "survey_info": survey_info,
        "noc_info": {
            "default_noc": random.choice(["NOC_AMER", "NOC_EMEA", "NOC_APAC"]),
            "default_noc_queue": "L2-Network"
        }
    }

def generate_ticket_summaries():
    """Generate 200 clients with varying numbers of operational_status (2-12), totaling 1000 tickets"""

    # Distribution: 200 clients, 1000 tickets
    # Average: 5 tickets per client
    # Range: 2-12 tickets per client

    # Create distribution that totals 1000
    # Weights: more clients with 4-6 tickets, fewer with extremes
    ticket_counts = []
    remaining = 1000

    # Weighted random distribution
    weights = {
        2: 0.10,   # 10% have 2 tickets
        3: 0.15,   # 15% have 3 tickets
        4: 0.20,   # 20% have 4 tickets
        5: 0.20,   # 20% have 5 tickets
        6: 0.15,   # 15% have 6 tickets
        7: 0.10,   # 10% have 7 tickets
        8: 0.05,   # 5% have 8 tickets
        10: 0.03,  # 3% have 10 tickets
        12: 0.02   # 2% have 12 tickets
    }

    for i in range(200):
        if i == 199:  # Last client gets whatever remains
            ticket_counts.append(remaining)
        else:
            # Choose from distribution
            count = random.choices(
                list(weights.keys()),
                weights=list(weights.values())
            )[0]

            # Ensure we don't exceed remaining
            if count > remaining:
                count = max(2, remaining // (200 - i))

            ticket_counts.append(count)
            remaining -= count

    print(f"📊 Ticket distribution: min={min(ticket_counts)}, max={max(ticket_counts)}, avg={sum(ticket_counts)/len(ticket_counts):.1f}")
    print(f"📊 Total tickets: {sum(ticket_counts)}")

    # Company names pool
    company_types = ["Tech", "Global", "Enterprise", "Digital", "Cloud", "Network", "Data", "Cyber", "Smart", "Quantum"]
    company_suffixes = ["Corp", "Industries", "Solutions", "Services", "Systems", "Group", "Networks", "Technologies", "Communications", "Ltd"]

    ticket_summaries = []
    ticket_counter = 1

    for client_idx, num_tickets in enumerate(ticket_counts):
        client_id = f"C{96757 + client_idx:05d}"  # C96757 to C96956
        client_name = f"{random.choice(company_types)} {random.choice(company_suffixes)}"

        # Determine client tier based on number of tickets (more tickets = higher tier)
        if num_tickets >= 8:
            client_tier = "Platinum"
            client_group = "Enterprise"
        elif num_tickets >= 5:
            client_tier = "Gold"
            client_group = "Enterprise"
        else:
            client_tier = "Silver"
            client_group = "SMB"

        # Build operational_status list for this client
        operational_status = []

        for ticket_idx in range(num_tickets):
            days_ago = random.randint(1, 30)
            status = random.choice(["Open", "Open", "Closed", "Closed", "Closed", "In Progress", "Resolved"])
            priority = random.randint(2, 5)

            # Some tickets are master/child
            is_master = (ticket_idx == 0 and num_tickets >= 4 and random.random() > 0.9)
            master_ticket_id = None
            if not is_master and ticket_idx > 0 and random.random() > 0.95:
                master_ticket_id = f"INC-{ticket_counter - ticket_idx:06d}"  # Reference earlier ticket

            op_status = create_operational_status(
                ticket_counter, client_id,
                is_master=is_master,
                master_ticket_id=master_ticket_id,
                days_ago=days_ago,
                status=status,
                priority=priority,
                has_survey=(ticket_idx % 3 == 0 and status == "Closed"),
                has_maintenance=(ticket_idx % 4 == 0),
                has_vendor=(ticket_idx % 5 == 0)
            )

            operational_status.append(op_status)
            ticket_counter += 1

        # Create the TicketSummary message (ONE per client)
        ticket_summary = {
            "client_info": {
                "cl_id": f"cl_{client_id}",
                "client_id": client_id,
                "client_name": client_name,
                "client_group": client_group,
                "client_tier": client_tier,
                "channel": random.choice(["Direct", "Partner", "Reseller"]),
                "sales_division": random.choice(["North America", "EMEA", "APAC", "Latin America"]),
                "market_segment": random.choice(["Technology", "Finance", "Healthcare", "Manufacturing", "Retail"]),
                "client_import_source": "ServiceNow",
                "client_ticket": operational_status[0]["ticket_info"]["ticket_id"]  # First ticket as reference
            },
            "operational_status": operational_status
        }

        ticket_summaries.append(ticket_summary)

    return ticket_summaries

# Generate data
print("🚀 Generating 200 clients with 1000 tickets total...")
ticket_summaries = generate_ticket_summaries()

# Write to file
output_file = "/Users/aklilugebreyesus/projects/eva/mcp_ticket/server/test_data/dummy_tickets_1000.json"
with open(output_file, 'w') as f:
    json.dump(ticket_summaries, f, indent=2)

print(f"✅ Generated {len(ticket_summaries)} client messages")
print(f"📁 Saved to: {output_file}")
print(f"📊 Summary:")
print(f"   - Clients: {len(ticket_summaries)}")
print(f"   - Total tickets: {sum(len(ts['operational_status']) for ts in ticket_summaries)}")
print(f"   - Ticket range per client: {min(len(ts['operational_status']) for ts in ticket_summaries)} - {max(len(ts['operational_status']) for ts in ticket_summaries)}")
print(f"   - Date range: Last 30 days")
print(f"   - Structure: TicketSummary with client_info + List[OperationalStatus]")
