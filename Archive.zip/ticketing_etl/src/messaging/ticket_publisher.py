import json
import logging
from datetime import datetime, timedelta
from typing import Dict, Any
from utils.config import Config
from utils.correlation import get_correlation_id


class NatsConnectionError(Exception):
    """Exception raised for NATS connection issues."""

    pass


class NatsPublisher:
    def __init__(self, connection_manager):
        """
        Initialize the NATS publisher using connection manager for fresh context access.
        """
        self.connection_manager = connection_manager
        self.config = Config()
        self.stream_name = self.config.get_jetstream_stream_name()
        self.logger = logging.getLogger(__name__)

        # Dead Letter Queue configuration
        self.max_dlq_size = 100
        self.dlq_ttl = timedelta(hours=6)
        self.dlq_subject_suffix = ".dlq"

        # Circuit breaker configuration
        self.failure_count = 0
        self.failure_threshold = 5
        self.circuit_open_time = None
        self.circuit_timeout = timedelta(minutes=5)

        # Metrics tracking
        self.published_count = 0
        self.failed_count = 0
        self.dlq_count = 0
        self.dropped_count = 0

    async def is_connected(self):
        """Check if the NATS connection is active."""
        try:
            conn = self.connection_manager.get_nats_connection()
            return conn and conn.is_connected
        except Exception as e:
            self.logger.error(f"NATS connection check failed: {e}", exc_info=True)
            return False

    async def publish(self, subject: str, message: dict):  # Msg as a dict
        """Publish a message with DLQ and circuit breaker support."""
        correlation_id = get_correlation_id()

        # Check circuit breaker
        if self._is_circuit_open():
            self.logger.warning(
                f"Circuit breaker open - dropping message to {subject}",
                extra={"correlation_id": correlation_id},
            )
            self.dropped_count += 1
            return False

        # Check connection
        if not await self.is_connected():
            await self._handle_publish_failure(
                subject, message, "NATS connection not available"
            )
            return False

        # Get fresh connection and JetStream context
        conn = self.connection_manager.get_nats_connection()
        js = self.connection_manager.get_jetstream_context()

        if conn and conn.is_connected and js:
            try:
                # Serialize message
                logging.debug(
                    f"🔍 Type of message before serialization: {type(message)}"
                )

                # Handle different message types
                if isinstance(message, bytes):
                    # Message is already compressed bytes - use directly
                    message_bytes = message
                elif isinstance(message, str):
                    # Parse JSON string first
                    parsed_message = json.loads(message)
                    # Add correlation ID and timestamp
                    enriched_message = {
                        **parsed_message,
                        "correlation_id": correlation_id,
                        "published_at": datetime.utcnow().isoformat(),
                    }
                    message_json = json.dumps(enriched_message, default=str)
                    message_bytes = message_json.encode()
                else:
                    # Dictionary message
                    enriched_message = {
                        **message,
                        "correlation_id": correlation_id,
                        "published_at": datetime.utcnow().isoformat(),
                    }
                    message_json = json.dumps(enriched_message, default=str)
                    message_bytes = message_json.encode()

                original_size = len(message_bytes)
                self.logger.debug(
                    f"Publishing message: {original_size}B to {subject}",
                    extra={"correlation_id": correlation_id},
                )

                ack = await js.publish(
                    subject=subject, payload=message_bytes, stream=self.stream_name
                )

                # Success - reset circuit breaker
                self._record_success()
                self.published_count += 1

                self.logger.debug(
                    f"Published message to subject: {subject}, stream: {self.stream_name}, ack: {ack}",
                    extra={"correlation_id": correlation_id},
                )
                return True

            except Exception as e:
                await self._handle_publish_failure(subject, message, str(e))
                return False
        else:
            await self._handle_publish_failure(
                subject, message, "NATS connection or JetStream context not established"
            )
            return False

    def _is_circuit_open(self) -> bool:
        """Check if circuit breaker is open."""
        if self.circuit_open_time is None:
            return False

        # Check if timeout has passed
        if datetime.utcnow() - self.circuit_open_time > self.circuit_timeout:
            self.logger.info("Circuit breaker timeout - attempting to close")
            self.circuit_open_time = None
            self.failure_count = 0
            return False

        return True

    def _record_success(self):
        """Record successful publish and reset circuit breaker."""
        self.failure_count = 0
        self.circuit_open_time = None

    def _record_failure(self):
        """Record failure and potentially open circuit breaker."""
        self.failure_count += 1
        self.failed_count += 1

        if self.failure_count >= self.failure_threshold:
            self.circuit_open_time = datetime.utcnow()
            self.logger.error(
                f"Circuit breaker opened after {self.failure_count} failures"
            )

    async def _handle_publish_failure(self, subject: str, message: dict, error: str):
        """Handle failed publish by attempting DLQ or dropping."""
        correlation_id = get_correlation_id()
        self._record_failure()

        # Check if this is a connection-related error
        error_lower = error.lower()
        is_connection_error = any(
            keyword in error_lower
            for keyword in [
                "connection",
                "nats",
                "timeout",
                "unavailable",
                "refused",
                "eof",
            ]
        )

        if is_connection_error:
            self.logger.warning(
                f"NATS connection issue - message will be retried on next run: {error}",
                extra={"correlation_id": correlation_id, "subject": subject},
            )
            # Don't try DLQ when NATS is down - just track as dropped for retry
            self.dropped_count += 1
            return
        else:
            self.logger.error(
                f"Failed to publish to {subject}: {error}",
                extra={"correlation_id": correlation_id},
            )

        # Only try DLQ for non-connection errors when NATS is available
        if await self.is_connected():
            dlq_subject = f"{subject}{self.dlq_subject_suffix}"
            dlq_size = await self._get_dlq_size(dlq_subject)

            if dlq_size < self.max_dlq_size:
                try:
                    dlq_message = {
                        "original_subject": subject,
                        "original_message": message,
                        "error": error,
                        "failed_at": datetime.utcnow().isoformat(),
                        "correlation_id": correlation_id,
                        "ttl_expires_at": (
                            datetime.utcnow() + self.dlq_ttl
                        ).isoformat(),
                    }

                    message_json = json.dumps(dlq_message, default=str)
                    message_bytes = message_json.encode()

                    await self.js.publish(
                        subject=dlq_subject,
                        payload=message_bytes,
                        stream=self.stream_name,
                    )

                    self.dlq_count += 1
                    self.logger.info(
                        f"Message sent to DLQ: {dlq_subject}",
                        extra={"correlation_id": correlation_id},
                    )

                except Exception as dlq_error:
                    self.logger.error(
                        f"Failed to send to DLQ: {dlq_error} - dropping message",
                        extra={"correlation_id": correlation_id},
                    )
                    self.dropped_count += 1
            else:
                self.logger.error(
                    f"DLQ full ({dlq_size}/{self.max_dlq_size}) - dropping message",
                    extra={"correlation_id": correlation_id},
                )
                self.dropped_count += 1
        else:
            # NATS is down, can't use DLQ
            self.logger.warning(
                "NATS unavailable - dropping message for retry on reconnection",
                extra={"correlation_id": correlation_id},
            )
            self.dropped_count += 1

    async def _get_dlq_size(self, dlq_subject: str) -> int:
        """Get current size of DLQ (simplified - returns 0 for now)."""
        # In a real implementation, this would query the stream for message count
        # For now, we'll return 0 to allow DLQ usage
        return 0

    def get_metrics(self) -> Dict[str, Any]:
        """Get publisher metrics for monitoring."""
        return {
            "published_count": self.published_count,
            "failed_count": self.failed_count,
            "dlq_count": self.dlq_count,
            "dropped_count": self.dropped_count,
            "circuit_breaker_open": self._is_circuit_open(),
            "failure_count": self.failure_count,
        }

    # Connection lifecycle managed by ConnectionManager - no close/context methods needed
