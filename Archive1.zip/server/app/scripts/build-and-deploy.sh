#!/bin/bash
# Enhanced MCP Ticket System - Build and Deploy Script

set -e

# Configuration
DOCKER_REGISTRY=${DOCKER_REGISTRY:-"localhost:5000"}
IMAGE_NAME="mcp-ticket-server"
IMAGE_TAG=${IMAGE_TAG:-"latest"}
NAMESPACE="mcp-ticket-system"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Docker is running
check_docker() {
    if ! docker info > /dev/null 2>&1; then
        log_error "Docker is not running or not accessible"
        exit 1
    fi
    log_success "Docker is running"
}

# Check if kubectl is available and connected
check_kubectl() {
    if ! kubectl version --client > /dev/null 2>&1; then
        log_error "kubectl is not installed or not in PATH"
        exit 1
    fi

    if ! kubectl cluster-info > /dev/null 2>&1; then
        log_error "kubectl is not connected to a cluster"
        exit 1
    fi
    log_success "kubectl is connected to cluster"
}

# Build Docker image
build_image() {
    log_info "Building Docker image..."

    docker build -t ${IMAGE_NAME}:${IMAGE_TAG} .

    if [ $? -eq 0 ]; then
        log_success "Docker image built successfully: ${IMAGE_NAME}:${IMAGE_TAG}"
    else
        log_error "Failed to build Docker image"
        exit 1
    fi
}

# Tag and push image (if registry is specified)
push_image() {
    if [ "$DOCKER_REGISTRY" != "localhost:5000" ] && [ "$DOCKER_REGISTRY" != "" ]; then
        log_info "Tagging and pushing image to registry..."

        docker tag ${IMAGE_NAME}:${IMAGE_TAG} ${DOCKER_REGISTRY}/${IMAGE_NAME}:${IMAGE_TAG}
        docker push ${DOCKER_REGISTRY}/${IMAGE_NAME}:${IMAGE_TAG}

        if [ $? -eq 0 ]; then
            log_success "Image pushed to registry: ${DOCKER_REGISTRY}/${IMAGE_NAME}:${IMAGE_TAG}"
        else
            log_error "Failed to push image to registry"
            exit 1
        fi
    else
        log_warning "Using local registry or no registry specified, skipping push"
    fi
}

# Deploy to Kubernetes
deploy_k8s() {
    log_info "Deploying to Kubernetes..."

    # Apply Kubernetes manifests
    cd k8s

    # Update image in deployment if using registry
    if [ "$DOCKER_REGISTRY" != "localhost:5000" ] && [ "$DOCKER_REGISTRY" != "" ]; then
        sed -i.bak "s|image: mcp-ticket-server:latest|image: ${DOCKER_REGISTRY}/${IMAGE_NAME}:${IMAGE_TAG}|g" mcp-ticket-deployment.yaml
    fi

    # Apply manifests in order
    kubectl apply -f namespace.yaml
    kubectl apply -f configmap.yaml
    kubectl apply -f secret.yaml
    kubectl apply -f pvc.yaml
    kubectl apply -f rbac.yaml
    kubectl apply -f nats-deployment.yaml

    # Wait for NATS to be ready
    log_info "Waiting for NATS to be ready..."
    kubectl wait --for=condition=available --timeout=300s deployment/nats-deployment -n ${NAMESPACE}

    # Deploy application
    kubectl apply -f mcp-ticket-deployment.yaml
    kubectl apply -f hpa.yaml
    kubectl apply -f ingress.yaml

    # Wait for deployment to be ready
    log_info "Waiting for MCP Ticket Server to be ready..."
    kubectl wait --for=condition=available --timeout=600s deployment/mcp-ticket-deployment -n ${NAMESPACE}

    # Restore original deployment file if modified
    if [ -f mcp-ticket-deployment.yaml.bak ]; then
        mv mcp-ticket-deployment.yaml.bak mcp-ticket-deployment.yaml
    fi

    cd ..

    log_success "Deployment completed successfully"
}

# Check deployment status
check_status() {
    log_info "Checking deployment status..."

    echo
    log_info "Pods:"
    kubectl get pods -n ${NAMESPACE}

    echo
    log_info "Services:"
    kubectl get services -n ${NAMESPACE}

    echo
    log_info "Ingress:"
    kubectl get ingress -n ${NAMESPACE}

    echo
    log_info "PVCs:"
    kubectl get pvc -n ${NAMESPACE}
}

# Main execution
main() {
    log_info "Starting Enhanced MCP Ticket System deployment..."

    # Parse command line arguments
    OPERATION=${1:-"all"}

    case $OPERATION in
        "build")
            check_docker
            build_image
            ;;
        "push")
            check_docker
            push_image
            ;;
        "deploy")
            check_kubectl
            deploy_k8s
            ;;
        "status")
            check_kubectl
            check_status
            ;;
        "all")
            check_docker
            check_kubectl
            build_image
            push_image
            deploy_k8s
            check_status
            ;;
        *)
            echo "Usage: $0 {build|push|deploy|status|all}"
            echo "  build  - Build Docker image"
            echo "  push   - Push image to registry"
            echo "  deploy - Deploy to Kubernetes"
            echo "  status - Check deployment status"
            echo "  all    - Do everything (default)"
            exit 1
            ;;
    esac

    log_success "Operation '${OPERATION}' completed successfully!"
}

# Run main function with all arguments
main "$@"