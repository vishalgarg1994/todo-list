"""
MCP tools for CMD order note queries.
"""

from typing import Any, Dict, List


async def get_order_notes(order_id: int, services: dict) -> List[Dict[str, Any]]:
    """
    Get all notes for a specific order, ordered by creation time.

    Args:
        order_id: The service order ID
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order {id: $order_id})-[:HAS_NOTE]->(n:Note)
        RETURN n.note_id AS note_id,
               n.subject AS subject,
               n.body AS body,
               n.created_on AS created_on,
               n.created_by_name AS created_by
        ORDER BY n.note_id
    """, {"order_id": order_id})

    return records


async def search_notes_by_subject(subject: str, services: dict) -> List[Dict[str, Any]]:
    """
    Search notes by subject line across all orders (partial match).

    Args:
        subject: Subject text to search for (case-insensitive)
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order)-[:HAS_NOTE]->(n:Note)
        WHERE toLower(n.subject) CONTAINS toLower($subject)
        RETURN n.note_id AS note_id,
               n.subject AS subject,
               n.body AS body,
               o.id AS order_id
        LIMIT 50
    """, {"subject": subject})

    return records


async def search_notes_by_content(keyword: str, services: dict) -> List[Dict[str, Any]]:
    """
    Search note body text by keyword across all orders.

    Args:
        keyword: Keyword to search in note body (case-insensitive)
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order)-[:HAS_NOTE]->(n:Note)
        WHERE toLower(n.body) CONTAINS toLower($keyword)
        RETURN n.note_id AS note_id,
               n.subject AS subject,
               n.body AS body,
               o.id AS order_id
        LIMIT 50
    """, {"keyword": keyword})

    return records


async def get_note_count_by_order(services: dict) -> List[Dict[str, Any]]:
    """
    Get the number of notes per order, sorted by most notes first.
    Useful for finding orders with the most activity.
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order)-[:HAS_NOTE]->(n:Note)
        RETURN o.id AS order_id,
               o.status_label AS status,
               count(n) AS note_count
        ORDER BY note_count DESC
        LIMIT 50
    """)

    return records
