#!/usr/bin/env python3
"""
TEMPORARY TEST SCRIPT - DO NOT UPLOAD TO REMOTE
Publishes synthetic fault descriptions to NATS for local testing only
"""
import asyncio
import json
import nats
import sys
import os
from pathlib import Path

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent / "app"))

from configs.config import Config


async def publish_test_data():
    """Publish synthetic fault descriptions to NATS"""
    config = Config()

    # Load synthetic data
    test_data_file = Path(__file__).parent / "synthetic_fault_descriptions.json"

    if not test_data_file.exists():
        print(f"❌ Synthetic data file not found: {test_data_file}")
        print("   Run: python3 test_data/synthetic_fault_descriptions.py")
        return

    with open(test_data_file, 'r') as f:
        summaries = json.load(f)

    print(f"📊 Loaded {len(summaries)} FaultDescriptionSummary messages")

    # Connect to NATS
    try:
        nc = await nats.connect(config.nats_url)
        js = nc.jetstream()
        print(f"✅ Connected to NATS: {config.nats_url}")
    except Exception as e:
        print(f"❌ Failed to connect to NATS: {e}")
        print("   Make sure NATS is running (docker-compose up -d)")
        return

    # Publish each summary
    total_published = 0
    total_faults = 0
    for summary in summaries:
        try:
            # Publish to tickets.fault_description subject
            await js.publish(
                "tickets.fault_description",
                json.dumps(summary).encode()
            )
            total_published += 1
            client_id = summary.get('client_id', 'Unknown')
            fault_count = len(summary.get('fault_descriptions', []))
            total_faults += fault_count
            print(f"✅ Published summary for {client_id} ({fault_count} fault descriptions)")
        except Exception as e:
            print(f"❌ Failed to publish summary: {e}")

    await nc.close()

    print(f"\n{'=' * 70}")
    print(f"🎉 Published {total_published}/{len(summaries)} fault description summaries")
    print(f"   Total fault descriptions: {total_faults}")
    print(f"{'=' * 70}")
    print(f"\n💡 Now the MCP server should automatically consume these messages!")


if __name__ == "__main__":
    asyncio.run(publish_test_data())
