# Eva Messaging Infrastructure Integration Guide

**Version**: 1.0
**Date**: 2025-09-20
**Purpose**: Guide for integrating applications with Eva messaging infrastructure

## Overview

Eva messaging infrastructure provides enterprise-grade NATS JetStream messaging as a shared service. Applications connect to Eva infrastructure as clients, similar to how they connect to a database.

## Architecture

```
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│   Ticketing      │  │   Analytics      │  │   Future Apps    │
│      App         │  │      App         │  │                  │
│                  │  │                  │  │                  │
│ ┌──────────────┐ │  │ ┌──────────────┐ │  │ ┌──────────────┐ │
│ │NATS Client   │ │  │ │NATS Client   │ │  │ │NATS Client   │ │
│ │(Connect Only)│ │  │ │(Connect Only)│ │  │ │(Connect Only)│ │
│ └──────┬───────┘ │  │ └──────┬───────┘ │  │ └──────┬───────┘ │
└────────┼─────────┘  └────────┼─────────┘  └────────┼─────────┘
         │                     │                     │
         └─────────────────────┼─────────────────────┘
                               │
                    ┌──────────▼──────────┐
                    │   Eva Messaging     │
                    │   Infrastructure    │
                    │                     │
                    │ ┌─────────────────┐ │
                    │ │  NATS Cluster   │ │
                    │ │   (HA Setup)    │ │
                    │ └─────────────────┘ │
                    │                     │
                    │ ┌─────────────────┐ │
                    │ │   JetStream     │ │
                    │ │ Stream Manager  │ │
                    │ └─────────────────┘ │
                    │                     │
                    │ ┌─────────────────┐ │
                    │ │   Monitoring    │ │
                    │ │   & Metrics     │ │
                    │ └─────────────────┘ │
                    └─────────────────────┘
```

## Pre-configured Streams

Eva infrastructure provides these enterprise streams:

### EVA_TICKETING
- **Subjects**: `eva.tickets.*`, `eva.incidents.*`, `eva.maintenance.*`
- **Purpose**: Ticketing system events and incident management
- **Retention**: 72 hours workqueue
- **Usage**: Primary stream for ticketing applications

### EVA_ANALYTICS
- **Subjects**: `eva.analytics.*`, `eva.metrics.*`, `eva.reports.*`
- **Purpose**: Business intelligence and reporting
- **Retention**: 30 days limits
- **Usage**: Analytics and reporting applications


## Application Integration

### 1. Connection Configuration

Applications should connect to Eva infrastructure with these settings:

```bash
# Environment Variables
NATS_URL=nats://eva_nats:4222         # Eva NATS URL
# Publisher (ticketing_etl, stream-manager)
NATS_PUBLISHER_USER=ticket-app
NATS_PUBLISHER_PASSWORD=ticket-app-2024
# Consumer (mcp_ticket)
NATS_CONSUMER_USER=mcp-consumer
NATS_CONSUMER_PASSWORD=changeme-consumer
JETSTREAM_STREAM_NAME=EVA_TICKETING   # Target stream
```

### 2. TLS Configuration (Production)

Eva infrastructure supports TLS for production deployments:

```bash
# TLS Settings
TLS_ENABLED=true                      # Master TLS switch
NATS_TLS_ENABLED=true                # Enable NATS TLS
NATS_TLS_VERIFY=true                 # Verify certificates
NATS_TLS_CERT=/path/to/client.crt    # Client certificate
NATS_TLS_KEY=/path/to/client.key     # Client private key
NATS_TLS_CA=/path/to/eva-ca.crt      # Eva CA certificate
```

### 3. Subject Naming Conventions

Follow Eva naming conventions for interoperability:

```
Pattern: eva.{domain}.{subdomain}.{action}

Examples:
- eva.tickets.created
- eva.tickets.updated
- eva.tickets.fault_description
- eva.incidents.created
- eva.analytics.processed
- eva.audit.user_action
```

### 4. Network Configuration

Applications must join the Eva messaging network:

```yaml
# docker-compose.yml
networks:
  eva-messaging:
    external: true
    name: eva-messaging
```

## Application Connection Pattern

### Code Example (Node.js)

```javascript
const nats = require('nats');

async function connectToEva() {
  const nc = await nats.connect({
    servers: process.env.NATS_URL,
    // Use NATS_PUBLISHER_USER/PASSWORD for publishers, NATS_CONSUMER_USER/PASSWORD for consumers
    user: process.env.NATS_PUBLISHER_USER,
    password: process.env.NATS_PUBLISHER_PASSWORD,
    name: 'my-application'
  });

  const js = nc.jetstream();

  // Publish to Eva stream
  await js.publish('eva.tickets.created', JSON.stringify({
    ticket_id: 'T123',
    status: 'open',
    timestamp: new Date().toISOString()
  }), { stream: 'EVA_TICKETING' });

  return { nc, js };
}
```

### Code Example (Python)

```python
import asyncio
import nats
from nats.js import JetStreamContext

async def connect_to_eva():
    nc = await nats.connect(
        servers=os.getenv('NATS_URL'),
        # Use NATS_PUBLISHER_USER/PASSWORD for publishers, NATS_CONSUMER_USER/PASSWORD for consumers
        user=os.getenv('NATS_PUBLISHER_USER'),
        password=os.getenv('NATS_PUBLISHER_PASSWORD'),
        name='my-application'
    )

    js = nc.jetstream()

    # Publish to Eva stream
    await js.publish('eva.tickets.created',
                    json.dumps({
                        'ticket_id': 'T123',
                        'status': 'open',
                        'timestamp': datetime.utcnow().isoformat()
                    }).encode(),
                    stream='EVA_TICKETING')

    return nc, js
```

## Deployment Steps

### 1. Start Eva Infrastructure

```bash
cd eva/messaging-infrastructure/nats
docker-compose up -d
./scripts/init-streams.sh
```

### 2. Configure Your Application

Update your application's environment:

```bash
# Development
NATS_URL=nats://localhost:4222

# Production (update to your Eva cluster)
NATS_URL=nats://eva-cluster-1:4222,eva-cluster-2:4222,eva-cluster-3:4222
```

### 3. Update Connection Code

Remove any NATS infrastructure management code from your application:
- No stream creation
- No JetStream setup
- No server configuration
- Simple client connection only

### 4. Test Integration

```bash
# Start your application
docker-compose up -d

# Monitor messages via Eva UI
http://localhost:3001

# Verify with NATS CLI
nats stream info EVA_TICKETING
```

## Monitoring and Operations

### Eva Message Viewer UI

Access the simple UI for real-time message monitoring:
- **URL**: http://localhost:3001
- **Features**: Live message streaming, filtering, search
- **Purpose**: Development and debugging

### NATS Native Monitoring

Access NATS server monitoring:
- **URL**: http://localhost:8222
- **Features**: Server stats, connection info, JetStream details
- **Purpose**: Infrastructure monitoring

### CLI Operations

```bash
# List streams
nats stream list

# View stream info
nats stream info EVA_TICKETING

# Monitor messages
nats stream view EVA_TICKETING

# Publish test message
nats pub eva.tickets.test '{"test": true}'
```

## Security Considerations

### Development Mode
- Uses `no_auth_user` for simplicity
- TLS disabled by default
- Single-tenant configuration

### Production Mode
- Multi-tenant account system
- TLS encryption required
- Certificate-based authentication
- Network segmentation

## Troubleshooting

### Connection Issues

1. **Verify Eva infrastructure is running**:
   ```bash
   docker ps | grep eva_nats
   ```

2. **Check network connectivity**:
   ```bash
   docker network inspect eva-messaging
   ```

3. **Test NATS connection**:
   ```bash
   nats server ping --server=nats://localhost:4222
   ```

### Message Publishing Issues

1. **Verify stream exists**:
   ```bash
   nats stream info EVA_TICKETING
   ```

2. **Check subject patterns**:
   ```bash
   nats stream info EVA_TICKETING --json | jq '.config.subjects'
   ```

3. **Monitor for errors**:
   ```bash
   docker logs eva_nats
   ```

### Performance Issues

1. **Check message rates**:
   ```bash
   nats stream report
   ```

2. **Monitor memory usage**:
   ```bash
   nats server info
   ```

3. **Review consumer lag**:
   ```bash
   nats consumer report EVA_TICKETING
   ```

## Support and Migration

### From Embedded NATS

If migrating from embedded NATS:

1. **Remove NATS service** from application's docker-compose
2. **Update environment variables** to point to Eva infrastructure
3. **Remove stream management code** from application
4. **Add eva-messaging network** to application
5. **Test message flow** with Eva UI

### Best Practices

- **Fail fast**: Application should fail if can't connect to Eva
- **Circuit breaker**: Implement connection resilience patterns
- **Dead letter queue**: Handle failed message processing
- **Monitoring**: Use Eva UI and native NATS monitoring
- **Testing**: Validate integration with test messages

---

For detailed implementation examples, see the `examples/` directory.
For operational procedures, see the `docs/` directory.