# Technical Architecture - Ticketing Data Processor

## Overview

This document provides a comprehensive technical analysis of the Ticketing Data Processor, including its implementation architecture, Domain Driven Design (DDD) patterns, and technical implementation details.

## System Architecture

### **Deployment Architecture**

```
┌─────────────────────────────────────────────────────────────────┐
│                    Docker Compose Environment                   │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐ │
│  │   Python App    │  │  NATS JetStream │  │   PostgreSQL    │ │
│  │  (ticket_app)   │  │  (nats_server)  │  │   (External)    │ │
│  │                 │  │                 │  │                 │ │
│  │ • Port: 8080    │  │ • Port: 4222    │  │ • External DB   │ │
│  │   (Health API)  │  │ • Port: 8222    │  │ • Connection    │ │
│  │ • Networks:     │  │ • Networks:     │  │   Pool          │ │
│  │   - backend     │  │   - backend     │  │                 │ │
│  │   - app_network │  │                 │  │                 │ │
│  │   - tdp_network │  │                 │  │                 │ │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### **Application Layer Structure**

```
src/
├── main.py                          # Application Entry Point
├── classes/                         # Domain Models & Setup
│   ├── data_model.py               # Pydantic Domain Models  
│   ├── queries.py                  # Query Definitions
│   └── jetstream_setup.py          # NATS JetStream Configuration
├── services/                        # Application Services Layer
│   ├── app_service.py              # Core Pipeline Orchestration
│   ├── transformation_service.py   # Data Transformation Logic
│   ├── scheduler.py                # Scheduling Coordination
│   ├── health_service.py           # Health Monitoring & Checks
│   └── http_server.py              # Health HTTP Endpoints
├── messaging/                       # Infrastructure - Messaging
│   ├── ticket_publisher.py         # NATS Publisher Implementation
│   └── ticket_subscriber.py        # NATS Subscriber Implementation
├── domain/                          # Domain Logic & Transformations
│   ├── transformers.py             # Knowledge Graph Data Transformers
│   └── table_config.py             # Configuration-driven Table Processing
└── utils/                          # Infrastructure - Enterprise Utility Library
    ├── __init__.py                 # Package initialization
    ├── circuit_breaker.py          # Circuit Breaker Implementation
    ├── compress.py                 # Message Compression (GZIP + Base64)
    ├── config.py                   # Environment-based Configuration Management
    ├── connection_manager.py       # Database & NATS Connection Lifecycle (Enhanced)
    ├── correlation.py              # Request correlation ID tracking
    ├── data_sanitizer.py           # HTML/SQL injection prevention
    ├── db.py                       # Database utilities and helpers
    ├── dead_letter_queue.py        # Dead letter queue implementation
    ├── degradation_manager.py      # Graceful degradation during outages
    ├── logging_config.py           # Structured logging (JSON/text)
    ├── metrics.py                  # Prometheus-compatible metrics
    ├── retry_handler.py            # Exponential backoff retry logic
    ├── serializers.py              # Data serialization utilities
    ├── state_manager.py            # 🆕 Persistent processing state management
    └── stream_validator.py         # NATS JetStream stream validation
```

## Domain Driven Design (DDD) Analysis

### **Domain Identification**

#### **Primary Domain: Ticket Management**
- **Core Focus**: Processing and distributing ticket lifecycle data
- **Business Value**: Real-time ticket status updates for operational visibility
- **Domain Experts**: NOC teams, customer support, operations managers

#### **Bounded Context: Ticket Data Processing**
```
┌─────────────────────────────────────────────────────────────────┐
│                    TICKET DATA PROCESSING                       │
├─────────────────────────────────────────────────────────────────┤
│ Domain Models:                                                  │
│ • TicketSummary (Aggregate Root)                                │
│ • ClientInfo (Entity)                                           │
│ • OperationalStatus (Entity)                                    │
│ • ServiceEntity, IncidentInfo, TroubleTicketInfo (Value Objects)│
│ • User, ContactInfo, VendorInfo, MaintenanceWindow (Knowledge   │
│   Graph Entities)                                               │
│                                                                 │
│ Services:                                                       │
│ • DataPipelineService (Domain Service)                          │
│ • TransformationService (Domain Service)                        │
│ • HealthService (Infrastructure Service)                        │
│                                                                 │
│ Infrastructure:                                                 │
│ • TicketDatabase (Repository Pattern)                           │
│ • NatsPublisher (Infrastructure Service)                        │
│ • HealthHTTPServer (Infrastructure Service)                     │
└─────────────────────────────────────────────────────────────────┘
```

### **DDD Patterns Implementation**

#### **1. Aggregate Pattern**
**File**: `src/classes/data_model.py:84-87`

```python
class TicketSummary(BaseModel):  # Aggregate Root
    client_info: ClientInfo      # Entity
    operational_status: List[OperationalStatus]  # Collection of Entities
```

**Analysis**:
- `TicketSummary` serves as the **Aggregate Root**
- Encapsulates `ClientInfo` and multiple `OperationalStatus` entities
- Maintains consistency boundary around client-related ticket data
- Controls access to internal entities

#### **2. Entity Pattern**
**Files**: `src/classes/data_model.py:79-82, 72-77`

```python
class ClientInfo(BaseModel):  # Entity - has identity
    client_id: Optional[int]  # Unique identifier
    client: Optional[str] = None

class OperationalStatus(BaseModel):  # Entity - complex structure
    service_entity: ServiceEntity
    incident_info: IncidentInfo
    trouble_ticket_info: TroubleTicketInfo
    outage_info: OutageInfo
```

**Analysis**:
- `ClientInfo` is an **Entity** with `client_id` as unique identifier
- `OperationalStatus` represents complex operational state with identity
- Entities maintain identity across system boundaries

#### **3. Value Objects Pattern**
**Files**: `src/classes/data_model.py:10-20, 22-35, 37-60, 62-70`

```python
class ServiceEntity(BaseModel):     # Value Object
class IncidentInfo(BaseModel):      # Value Object  
class TroubleTicketInfo(BaseModel): # Value Object
class OutageInfo(BaseModel):        # Value Object
```

**Analysis**:
- **Immutable structures** representing business concepts
- No identity - equality based on attribute values
- Encapsulate related attributes (subcategory + technology, fault info, etc.)
- Provide type safety and validation

#### **4. Domain Services Pattern**
**Files**: `src/services/app_service.py:20-100, src/services/transformation_service.py:16-113`

```python
class DataPipelineService:     # Domain Service
    async def fetch_and_publish_data(self):  # Business Operation

class TransformationService:   # Domain Service  
    async def transform_ticket(self, raw_data):  # Business Logic
```

**Analysis**:
- `DataPipelineService` orchestrates **core business process**
- `TransformationService` handles **domain-specific transformation logic**
- Services contain business logic that doesn't naturally fit in entities
- Stateless operations operating on domain objects

#### **5. Repository Pattern**
**File**: `src/utils/db.py:8-96`

```python
class TicketDatabase:  # Repository Implementation
    async def fetch_data(self, table_name, columns, filters) -> List[Dict]
    async def execute_query(self, query, *args)
```

**Analysis**:
- **Abstracts database access** from domain logic
- Provides **collection-like interface** for ticket data
- Handles connection pooling and query execution
- Separates persistence concerns from business logic

### **DDD Architecture Layers**

#### **1. Domain Layer** (`classes/`)
- **Domain Models**: Pydantic models representing business entities
- **Business Rules**: Validation logic embedded in models
- **Domain Services**: Core business logic services

#### **2. Application Layer** (`services/`)
- **Application Services**: Orchestrate domain operations
- **Use Cases**: `fetch_and_publish_data()` represents primary use case
- **Workflow Coordination**: Scheduler manages application workflows

#### **3. Infrastructure Layer** (`utils/`, `messaging/`)
- **Persistence**: Database connection and query handling
- **Messaging**: NATS JetStream integration
- **Configuration**: Environment-based configuration management
- **Utilities**: Data sanitization, compression, serialization

## Technical Implementation Details

### **Asynchronous Architecture**

#### **AsyncIO Event Loop Management**
**File**: `src/main.py:88-184`

```python
async def main():
    # Dependency initialization with retry logic
    await wait_for_dependencies(config, nc, db, db_url, nats_url)
    
    # Service composition and startup
    app = DataPipelineService(config, db, ticket_publisher, transformation_service)
    scheduler = Scheduler(config, pipeline=app)
    
    # Event loop management
    while True:
        await asyncio.sleep(config.get_scheduler_interval())
```

**Key Features**:
- **Non-blocking I/O** for all external dependencies
- **Graceful shutdown** handling with task cleanup
- **Dependency health monitoring** with retry mechanisms

#### **Connection Pool Management**
**File**: `src/utils/db.py:16-29`

```python
async def connect(self):
    self.pool = await asyncpg.create_pool(
        self.db_url,
        min_size=5,    # Minimum connection pool size
        max_size=20,   # Maximum connection pool size
    )
```

**Benefits**:
- **Connection reuse** reduces overhead
- **Concurrent query execution** without blocking
- **Resource management** prevents connection leaks

### **Persistent State Management Implementation**

#### **State Manager Architecture**
**File**: `src/utils/state_manager.py:13-120`

```python
class ProcessingStateManager:
    def __init__(self, state_file_path: str = None):
        # Environment-configurable state file location
        if state_file_path is None:
            state_file_path = os.getenv("STATE_FILE_PATH", "/app/data/processing_state.json")

    def is_initial_load_complete(self, table_name: str) -> bool:
        # Check processing status from persistent storage

    def start_initial_load(self, table_name: str, start_timestamp: datetime):
        # Mark initial load in progress

    def complete_initial_load(self, table_name: str, completion_timestamp: datetime):
        # Transition to incremental mode

    def update_incremental_timestamp(self, table_name: str, timestamp: datetime):
        # Update last processed timestamp (incremental mode)
```

**Key Features**:
- **JSON file-based persistence** with Docker volume integration
- **Initial vs incremental load tracking** with state transitions
- **Environment-configurable location** (`STATE_FILE_PATH`)
- **Atomic state updates** with proper error handling

#### **State-Driven Processing Logic**
**File**: `src/services/app_service.py:216-280`

```python
def _build_time_filter(self, table_config: TableConfig) -> Dict[str, Any]:
    table_name = table_config.name

    if state_manager.is_initial_load_complete(table_name):
        # INCREMENTAL: Use last processed timestamp
        last_processed = state_manager.get_last_processed_timestamp(table_name)
        start_time = last_processed

    elif state_manager.is_initial_load_in_progress(table_name):
        # RETRY INITIAL: Previous attempt failed
        start_time = self._calculate_initial_load_time()

    else:
        # FIRST INITIAL: Brand new table
        start_time = self._calculate_initial_load_time()
        state_manager.start_initial_load(table_name, start_time)
```

**Processing State Transitions**:
```
[FIRST RUN] → initial_load_in_progress → [SUCCESS] → initial_load_complete
                      ↓                                       ↓
               [FAILURE] → (retry full load)          [INCREMENTAL MODE]
```

#### **Conditional State Updates**
**File**: `src/services/app_service.py:116-126`

```python
# Only update state on successful publishing
if published_count > 0:
    self._update_processing_state(table_name)
else:
    self.logger.warning(
        f"No messages published for {table_name} - state not updated (will retry next run)"
    )
```

**Gap Prevention Logic**:
- **State updates conditional** on successful message publishing
- **Failed runs preserve** previous successful timestamp
- **Automatic retry** of failed time ranges on next run
- **Zero data loss** during NATS outages

### **Data Processing Pipeline**

#### **Time-based Data Extraction**
**File**: `src/services/app_service.py:37-91`

```python
# First run uses default start time
if self.is_first_run:
    query_time = datetime.strptime(DEFAULT_START_TIME, "%Y-%m-%d %H:%M:%S")
else:
    # Subsequent runs use incremental approach
    query_time = datetime.now(timezone.utc) - self.lookup_interval

filters = {TIME_FILTER_COLUMN: formatted_time}
```

**Strategy**:
- **Incremental processing** prevents duplicate data processing
- **Time window approach** ensures no data loss
- **Configurable intervals** balance freshness vs. performance

#### **Data Transformation Pipeline**
**File**: `src/services/transformation_service.py:36-112`

```python
# Group by client ID to create aggregates
client_summaries = {}
for record in raw_data:
    client_id = record.get("client_id")
    # Create domain objects for each record
    operational_status_data = OperationalStatus(...)
    
    # Aggregate by client
    if client_id not in client_summaries:
        client_summaries[client_id] = TicketSummary(...)
    else:
        client_summaries[client_id].operational_status.append(...)
```

**Pattern**:
- **Raw data → Domain models → Aggregation → Serialization**
- **Client-centric grouping** creates logical message boundaries
- **Pydantic validation** ensures data integrity

### **Message Publishing Architecture**

#### **NATS JetStream Integration**
**File**: `src/messaging/ticket_publisher.py:14-124`

```python
class NatsPublisher:
    async def publish(self, subject: str, message: dict):
        # Serialize and compress message
        message_json = json.dumps(message, default=str)
        message_bytes = message_json.encode()
        
        # Publish with JetStream persistence
        ack = await self.js.publish(
            subject=subject,
            payload=message_bytes,
            stream=self.stream_name
        )
```

**Features**:
- **JetStream persistence** ensures message durability
- **Acknowledgment-based delivery** confirms successful publishing
- **Subject-based routing** enables message categorization
- **Connection resilience** with automatic reconnection

#### **Message Compression Strategy**
**File**: `src/utils/compress.py:7-25`

```python
def compress_and_check(message: str) -> bytes | None:
    # GZIP compression
    compressed = gzip.compress(message.encode('utf-8'))
    # Base64 encoding for safe transport
    encoded = base64.b64encode(compressed).decode('utf-8')
    
    # Size validation (1MB limit)
    if size > MAX_NATS_PAYLOAD:
        return None
```

**Benefits**:
- **Bandwidth optimization** through compression
- **Size validation** prevents message rejection
- **Safe encoding** ensures transport compatibility

### **Configuration Management Strategy**

#### **Hierarchical Configuration**
**File**: `src/utils/config.py:16-52`

```python
class Config:
    def get(self, key, default=None):
        # Priority: os.environ > .env > default
        return os.environ.get(key) or dotenv_config.get(key) or default
```

**Environment Variables**:
```bash
# Database Configuration
DATABASE_URL=postgresql://user:pass@host:port/db

# NATS Configuration  
NATS_URL=nats://host:port
JETSTREAM_STREAM_NAME=EVA_TICKETING_STREAM

# Application Configuration
SCHEDULER_INTERVAL=300  # 5 minutes
LOOKUP_INTERVAL_MINUTES=5
```

### **NATS Resilience Implementation**

#### **Connection Event Callbacks**
**File**: `src/utils/connection_manager.py:123-129`

```python
# NATS connection options with resilience callbacks
connection_options = {
    "name": "ticketing_data_processor",
    "max_reconnect_attempts": -1,  # Infinite reconnection attempts
    "reconnect_time_wait": 2,
    "error_cb": self._nats_error_callback,
    "disconnected_cb": self._nats_disconnected_callback,
    "reconnected_cb": self._nats_reconnected_callback
}
```

#### **Resilience Callback Implementation**
**File**: `src/utils/connection_manager.py:175-208`

```python
async def _nats_error_callback(self, e):
    """Handle NATS connection errors gracefully"""
    self.logger.warning(f"NATS connection error (non-critical): {e}")

async def _nats_disconnected_callback(self):
    """Handle NATS disconnection events"""
    self.logger.warning("NATS connection lost - will attempt automatic reconnection")
    self.js_context = None  # Clear stale references

async def _nats_reconnected_callback(self):
    """Handle NATS reconnection events"""
    self.logger.info("NATS connection restored successfully")
    if self.nats_connection:
        self.js_context = self.nats_connection.jetstream()
```

#### **Global Exception Handler**
**File**: `src/main.py:33-44`

```python
def exception_handler(loop, context):
    """Global exception handler for asyncio to catch NATS background task exceptions"""
    exception = context.get('exception')
    if exception:
        error_msg = str(exception).lower()
        if any(keyword in error_msg for keyword in ['nats', 'connection', 'timeout', 'eof']):
            logger.warning(f"Background NATS task exception (non-critical): {exception}")
        else:
            logger.error(f"Unhandled exception in background task: {exception}")
```

#### **Publishing Resilience**
**File**: `src/services/app_service.py:330-342`

```python
# Connection health check before publishing
nats_connection = self.connection_manager.get_nats_connection()
if not nats_connection or not nats_connection.is_connected:
    self.logger.warning(
        "NATS connection not available - skipping publishing for this run"
    )
    return 0
```

**Resilience Patterns**:
- **Proactive connection checking** before publishing operations
- **Graceful degradation** when NATS is unavailable
- **Event-driven state cleanup** on disconnection
- **Automatic context restoration** on reconnection
- **Background task exception isolation** prevents app crashes

### **Error Handling & Resilience**

#### **Retry Mechanisms**
**File**: `src/services/app_service.py:36-37`

```python
@retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
async def fetch_and_publish_data(self):
```

**File**: `src/main.py:23-52`

```python
async def wait_for_dependencies(config, nc, db, db_url, nats_url):
    retries = 5
    while retries > 0 and (not db_ready or not nats_ready):
        # Dependency health checks with retry logic
```

**Patterns**:
- **Exponential backoff** for external service failures
- **Circuit breaker** pattern for dependency management
- **Graceful degradation** maintains partial functionality

### **Performance Characteristics**

#### **Scalability Features**:
- **Stateless design** enables horizontal scaling
- **Connection pooling** optimizes database access
- **Async I/O** maximizes concurrency
- **Message compression** reduces network overhead

#### **Resource Management**:
- **Memory-efficient streaming** processing
- **Connection pool limits** prevent resource exhaustion
- **Graceful shutdown** ensures clean resource cleanup

### **Health Monitoring & Observability Architecture**

#### **Health Service Design**
**File**: `src/services/health_service.py:20-80`

```python
class HealthService:
    def __init__(self, connection_manager=None, scheduler=None, version="1.0.0"):
        self.connection_manager = connection_manager
        self.scheduler = scheduler
        self.version = version
        self.start_time = time.time()
    
    async def get_health_status(self) -> HealthResponse:
        # Component-level health checks
        db_health = await self._check_database_health()
        nats_health = await self._check_nats_health()
        scheduler_health = await self._check_scheduler_health()
        system_health = await self._check_system_health()
```

**Architecture Patterns**:
- **Component-based health checking** - Individual system component monitoring
- **Graceful degradation** - Service continues with partial functionality
- **Health status aggregation** - Overall system health based on component states
- **Response time tracking** - Performance metrics for each component

#### **Health HTTP Server Implementation**
**File**: `src/services/http_server.py:35-120`

```python
class HealthHTTPServer:
    def __init__(self, health_service, host: str = "0.0.0.0", port: int = 8080):
        self.health_service = health_service
        
    async def start(self):
        # Threading-based HTTP server for async compatibility
        handler_class = self._create_handler_class()
        self.server = ThreadingHTTPServer((self.host, self.port), handler_class)
        
        # Health endpoints
        # GET /health - Comprehensive health status
        # GET /health/live - Liveness probe (Kubernetes)
        # GET /health/ready - Readiness probe (Load balancer)  
        # GET /health/metrics - Prometheus metrics
```

**Endpoint Design**:
- **RESTful health endpoints** following industry standards
- **Kubernetes probe compatibility** (liveness/readiness)
- **Prometheus metrics integration** for APM platforms
- **Structured JSON responses** with detailed component information

#### **Knowledge Graph Health Integration**
**File**: `src/domain/transformers.py:85-150`

```python
# Health checks include knowledge graph processing status
class KnowledgeGraphTransformer:
    async def health_check(self) -> ComponentHealth:
        # Check entity extraction capabilities
        # Validate relationship mapping functionality
        # Monitor transformation performance
```

**Knowledge Graph Monitoring**:
- **Entity extraction health** - User, Contact, Vendor, Maintenance Window processing
- **Relationship mapping status** - Knowledge graph link validation
- **Transformation performance** - Processing time and success rates
- **Data quality metrics** - Completeness and accuracy of extracted entities

#### **Circuit Breaker & Resilience**
**File**: `src/utils/circuit_breaker.py:20-85`

```python
class CircuitBreaker:
    def __init__(self, failure_threshold=5, recovery_timeout=60):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.state = CircuitBreakerState.CLOSED
    
    async def call(self, func, *args, **kwargs):
        # Monitor component failures
        # Implement circuit breaking for external dependencies
        # Provide fallback responses during outages
```

**Resilience Patterns**:
- **Circuit breaker protection** - Prevent cascade failures
- **Exponential backoff retry** - Smart retry logic with jitter
- **Graceful degradation** - Partial functionality during outages
- **Health-aware routing** - Direct traffic based on component health

#### **APM Integration Architecture**

**Prometheus Metrics Format**:
```plaintext
# Application-level metrics
application_health_status 1                    # 1=healthy, 0=unhealthy
application_uptime_seconds 3600.0

# Component-level metrics  
component_health_status{component="database"} 1
component_health_status{component="nats"} 1
component_health_status{component="scheduler"} 1
component_health_status{component="system"} 1

# Performance metrics
component_response_time_ms{component="database"} 15.2
component_response_time_ms{component="nats"} 8.7
```

**APM Platform Compatibility**:
- ✅ **Prometheus/Grafana** - Native metrics endpoint at `/health/metrics`
- ✅ **DataDog** - Health check monitoring via HTTP endpoints
- ✅ **New Relic** - Infrastructure & application monitoring integration
- ✅ **Elastic APM** - Structured logging and performance monitoring

#### **Health Monitoring Data Flow**

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Health        │    │   Component     │    │   APM Platform  │
│   HTTP Server   │    │   Checks        │    │   Integration   │
│   (Port 8080)   │    │                 │    │                 │
├─────────────────┤    ├─────────────────┤    ├─────────────────┤
│ GET /health     │───▶│ • Database      │───▶│ • Prometheus    │
│ GET /health/live│    │ • NATS          │    │ • DataDog       │
│ GET /health/ready│    │ • Scheduler     │    │ • New Relic     │
│ GET /health/metrics│  │ • System        │    │ • Elastic APM   │
└─────────────────┘    │ • Knowledge     │    └─────────────────┘
                       │   Graph         │
                       └─────────────────┘
```

### **Security Implementation**

#### **Data Sanitization**
**File**: `src/utils/data_sanitizer.py:37-51`

```python
def sanitize_text_for_json(raw_text: str) -> str:
    # HTML entity unescaping
    unescaped = unescape_html_entities(raw_text)
    # HTML tag removal  
    text_only = remove_html_tags(unescaped)
    # JSON escape handling
    json_safe = sanitize_for_json(processed_escapes)
```

#### **Security Measures**:
- **Input sanitization** prevents injection attacks
- **Environment-based secrets** management
- **Network segmentation** through Docker networks
- **Connection encryption** for external services
- **Health endpoint security** - No sensitive data exposure in health responses