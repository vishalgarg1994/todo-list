"""
Milvus Vector Database Client for Ticket Notes
Handles the ticket_notes collection for note summary embeddings.
"""
import logging
import asyncio
from typing import List, Dict, Any, Optional
from pymilvus import (
    connections,
    Collection,
    CollectionSchema,
    FieldSchema,
    DataType,
    utility
)
from configs.config import Config


class MilvusNotesClient:
    """Client for the ticket_notes Milvus collection"""

    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.collection_name = self.config.milvus_notes_collection
        self.collection: Optional[Collection] = None
        self.is_connected = False

        logging.info(f"Initialized MilvusNotesClient for collection: {self.collection_name}")

    def connect(self):
        """Establish connection to Milvus and load/create ticket_notes collection"""
        try:
            # Reuse existing connection if available, otherwise create one
            try:
                connections.get_connection_addr("default")
            except Exception:
                connect_kwargs = {
                    "alias": "default",
                    "host": self.config.milvus_host,
                    "port": self.config.milvus_port,
                }
                if self.config.milvus_user and self.config.milvus_password:
                    connect_kwargs["user"] = self.config.milvus_user
                    connect_kwargs["password"] = self.config.milvus_password
                connections.connect(**connect_kwargs)

            self.is_connected = True
            logging.info(f"Connected to Milvus at {self.config.milvus_host}:{self.config.milvus_port}")

            if utility.has_collection(self.collection_name):
                self.collection = Collection(self.collection_name)
                logging.info(f"Loaded existing collection: {self.collection_name}")
            else:
                self._create_collection()
                logging.info(f"Created new collection: {self.collection_name}")

        except Exception as e:
            logging.error(f"Failed to connect to Milvus for notes: {e}")
            self.is_connected = False
            raise

    def disconnect(self):
        """Disconnect from Milvus"""
        try:
            if self.is_connected:
                self.is_connected = False
                logging.info("MilvusNotesClient disconnected")
        except Exception as e:
            logging.error(f"Error disconnecting MilvusNotesClient: {e}")

    def _create_collection(self):
        """Create ticket_notes collection with schema and index"""
        fields = [
            FieldSchema(
                name="note_id",
                dtype=DataType.VARCHAR,
                max_length=100,
                is_primary=True,
                auto_id=False,
                description="Note sys_id (primary key)"
            ),
            FieldSchema(
                name="embedding",
                dtype=DataType.FLOAT_VECTOR,
                dim=768,
                description="768-dim note summary embedding"
            ),
            FieldSchema(
                name="summary_text",
                dtype=DataType.VARCHAR,
                max_length=65535,
                description="Cleaned/summarized note text"
            ),
            FieldSchema(
                name="ticket_id",
                dtype=DataType.VARCHAR,
                max_length=50,
                description="Parent ticket sys_id"
            ),
        ]

        schema = CollectionSchema(
            fields=fields,
            description="Ticket note summary embeddings for semantic search"
        )

        self.collection = Collection(
            name=self.collection_name,
            schema=schema
        )

        logging.info(f"Created collection schema: {self.collection_name}")

        # Create index immediately
        self._create_index_internal()

    def _create_index_internal(self):
        """Create IVF_FLAT index on embedding field"""
        index_params = {
            "index_type": self.config.milvus_index_type,
            "metric_type": self.config.milvus_metric_type,
            "params": {"nlist": self.config.milvus_nlist}
        }

        try:
            self.collection.create_index(
                field_name="embedding",
                index_params=index_params
            )
            logging.info(f"Created {self.config.milvus_index_type} index on ticket_notes")
        except Exception as e:
            if "index already exist" in str(e).lower():
                logging.info(f"Index already exists for '{self.collection_name}'")
            else:
                logging.error(f"Failed to create index: {e}")
                raise

    async def insert(
        self,
        note_ids: List[str],
        embeddings: List[List[float]],
        summary_texts: List[str],
        ticket_ids: List[str]
    ) -> int:
        """
        Upsert note summary embeddings into Milvus.

        Args:
            note_ids: List of note sys_ids (primary keys)
            embeddings: List of 768-dim embedding vectors
            summary_texts: List of cleaned/summarized note texts
            ticket_ids: List of parent ticket sys_ids

        Returns:
            Number of entities upserted
        """
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")

        try:
            entities = [
                note_ids,
                embeddings,
                summary_texts,
                ticket_ids,
            ]

            upsert_result = await asyncio.to_thread(self.collection.upsert, entities)
            num_upserted = upsert_result.upsert_count

            logging.info(f"Upserted {num_upserted} note embeddings into Milvus")
            return num_upserted

        except Exception as e:
            logging.error(f"Failed to upsert note embeddings: {e}")
            raise

    async def search(
        self,
        query_embedding: List[float],
        top_k: int = 10,
        nprobe: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Search for similar note summaries.

        Args:
            query_embedding: 768-dim query embedding
            top_k: Number of results to return
            nprobe: Number of clusters to search

        Returns:
            List of search results with note_id, summary_text, ticket_id, score
        """
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")

        if nprobe is None:
            nprobe = self.config.milvus_nprobe

        search_params = {
            "metric_type": self.config.milvus_metric_type,
            "params": {"nprobe": nprobe}
        }

        try:
            results = await asyncio.to_thread(
                self.collection.search,
                data=[query_embedding],
                anns_field="embedding",
                param=search_params,
                limit=top_k,
                output_fields=["note_id", "summary_text", "ticket_id"]
            )

            search_results = []
            for hits in results:
                for hit in hits:
                    search_results.append({
                        "note_id": hit.entity.get("note_id"),
                        "summary_text": hit.entity.get("summary_text"),
                        "ticket_id": hit.entity.get("ticket_id"),
                        "distance": hit.distance,
                        "score": hit.score
                    })

            logging.debug(f"Notes search returned {len(search_results)} results")
            return search_results

        except Exception as e:
            logging.error(f"Notes search failed: {e}")
            raise

    def load_collection(self):
        """Load collection into memory for search"""
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")
        self.collection.load()
        logging.info(f"Loaded collection '{self.collection_name}' into memory")

    def flush(self):
        """Flush collection data to disk"""
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")
        self.collection.flush()
        logging.info(f"Flushed collection '{self.collection_name}'")

    def get_collection_stats(self) -> Dict[str, Any]:
        """Get collection statistics"""
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")
        return {
            "collection_name": self.collection_name,
            "num_entities": self.collection.num_entities,
            "index_type": self.config.milvus_index_type,
            "metric_type": self.config.milvus_metric_type
        }

    async def get_by_ticket_id(self, ticket_sys_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the summary text for a specific ticket.

        Args:
            ticket_sys_id: The ticket sys_id to look up

        Returns:
            Dict with note_id, summary_text, ticket_id or None if not found
        """
        if not self.collection:
            raise ValueError("Collection not initialized. Call connect() first.")

        try:
            # Query by ticket_id field
            results = await asyncio.to_thread(
                self.collection.query,
                expr=f'ticket_id == "{ticket_sys_id}"',
                output_fields=["note_id", "summary_text", "ticket_id"]
            )

            if results and len(results) > 0:
                return {
                    "note_id": results[0].get("note_id"),
                    "summary_text": results[0].get("summary_text"),
                    "ticket_id": results[0].get("ticket_id")
                }

            return None

        except Exception as e:
            logging.error(f"Failed to get summary by ticket_id: {e}")
            return None
