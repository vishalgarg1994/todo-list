import logging
from typing import List, Dict, Optional


class TicketDatabase:
    def __init__(self, connection_manager):
        """Initialize database access using shared connection manager."""
        self.connection_manager = connection_manager
        self.logger = logging.getLogger(__name__)

    @property
    def pool(self):
        """Get the shared database connection pool"""
        return self.connection_manager.get_database_pool()

    async def execute_query(self, query, *args):
        """Execute a SQL query asynchronously using a connection from the pool."""
        if not self.pool:
            raise Exception("Database connection pool is not initialized")

        try:
            async with self.pool.acquire() as conn:
                self.logger.debug(f"Executing query: {query} with args: {args}")
                rows = await conn.fetch(query, *args)
                return rows
        except Exception as e:
            self.logger.error(f"Query execution failed: {e}", exc_info=True)
            raise

    async def fetch_data(
        self,
        table_name: str,
        columns: List[str],
        filters: Optional[Dict[str, str]] = None,
    ) -> List[Dict]:
        """
        Fetches data from the specified table using only a time-based filter.

        Args:
            table_name: The name of the table.
            columns: A list of column names to select.
                 filters: A dictionary of filters.  Each key is a column name,
                     and each value is a string representing the filter condition
                     (e.g., "='value'", ">= '2024-01-01'", "IN ('A', 'B')").
        """

        self.logger.debug(f"The columns: {columns}")
        self.logger.debug(f"The filters: {filters}")

        columns_str = ", ".join(columns) if columns else "*"
        query = f"SELECT {columns_str} FROM {table_name}"

        params = []
        if filters and "updated_on" in filters:
            time_value = filters["updated_on"]
            query += " WHERE updated_on >= $1"
            params.append(time_value)

        query += ";"
        self.logger.debug(f"Executing query: {query} with params: {params}")

        rows = await self.execute_query(query, *params)
        return [dict(row) for row in rows]

    # Connection lifecycle managed by ConnectionManager - no close() method needed
