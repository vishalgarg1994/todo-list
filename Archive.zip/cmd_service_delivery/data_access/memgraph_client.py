"""
Async Memgraph client using Neo4j Bolt protocol.
"""

import logging
import time
from typing import Any, Dict, List, Optional

from neo4j import AsyncGraphDatabase

logger = logging.getLogger(__name__)


class MemgraphClient:
    def __init__(self, uri: str, user: str = "", password: str = "", database: str = "memgraph"):
        self.uri = uri
        self.user = user
        self.password = password
        self.database = database
        self.driver = None

    async def connect(self):
        auth = (self.user, self.password) if self.user else None
        self.driver = AsyncGraphDatabase.driver(self.uri, auth=auth)
        async with self.driver.session(database=self.database) as session:
            result = await session.run("RETURN 1 AS test")
            await result.single()
        logger.info("Memgraph connection established at %s", self.uri)

    async def execute(self, query: str, params: Dict[str, Any] = None) -> List:
        """Execute a Cypher query and return list of records."""
        async with self.driver.session(database=self.database) as session:
            result = await session.run(query, params or {})
            return [record async for record in result]

    async def execute_and_fetch(self, query: str, params: Dict[str, Any] = None) -> List[Dict]:
        """Execute a Cypher query and return results as list of dicts."""
        records = await self.execute(query, params)
        return [dict(record) for record in records]

    async def execute_write(self, query: str, params: Dict[str, Any] = None) -> bool:
        """Execute a write query, return True on success."""
        try:
            q = query.strip()
            if not q.endswith(";"):
                q += ";"
            async with self.driver.session(database=self.database) as session:
                await session.run(q, params or {})
            return True
        except Exception as e:
            logger.error("Write query failed: %s | Error: %s", query[:100], e)
            return False

    async def clear_database(self):
        """Delete all nodes and relationships."""
        await self.execute("MATCH (n) DETACH DELETE n")
        logger.info("Database cleared")

    async def shutdown(self):
        if self.driver:
            await self.driver.close()
            self.driver = None
            logger.info("Memgraph client shut down")
