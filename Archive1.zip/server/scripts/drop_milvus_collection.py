#!/usr/bin/env python3
"""
Drop the Milvus collection to allow recreation with new schema
Run this before restarting the MCP server
"""
from pymilvus import connections, utility

# Connect to Milvus
connections.connect(
    alias="default",
    host="localhost",
    port=19530
)

collection_name = "fault_descriptions"

# Check if collection exists
if utility.has_collection(collection_name):
    print(f"🗑️  Dropping collection: {collection_name}")
    utility.drop_collection(collection_name)
    print(f"✅ Collection '{collection_name}' dropped successfully")
    print(f"")
    print(f"Next steps:")
    print(f"1. Restart the MCP server - it will create the new schema")
    print(f"2. Send fault description messages to repopulate with text")
else:
    print(f"⚠️  Collection '{collection_name}' does not exist")

# Disconnect
connections.disconnect("default")
print(f"✅ Disconnected from Milvus")
