"""
NATS Stream Manager - Core stream management functionality
"""

import logging
from typing import List, Dict, Any, Optional
import nats
from nats.errors import TimeoutError, NoServersError
from nats.js import api

logger = logging.getLogger(__name__)


class NatsStreamManager:
    """Manages NATS JetStream streams for Eva messaging infrastructure"""

    def __init__(self, config):
        self.config = config
        self.nc = None
        self.js = None

    async def connect(self):
        """Connect to NATS server"""
        try:
            connection_options = {
                "name": "eva-stream-manager",
                "max_reconnect_attempts": 5,
                "reconnect_time_wait": 2
            }

            # Add authentication if provided
            nats_user = self.config.get_nats_user()
            nats_password = self.config.get_nats_password()
            if nats_user and nats_password:
                connection_options["user"] = nats_user
                connection_options["password"] = nats_password

            self.nc = await nats.connect(
                self.config.get_nats_url(),
                **connection_options
            )

            self.js = self.nc.jetstream()
            logger.info(f"✅ Connected to NATS at {self.config.get_nats_url()}")

        except (NoServersError, TimeoutError, Exception) as e:
            logger.error(f"❌ Failed to connect to NATS: {e}")
            raise

    async def disconnect(self):
        """Disconnect from NATS server"""
        if self.nc:
            await self.nc.close()
            logger.info("🔌 Disconnected from NATS")

    async def create_eva_streams(self) -> List[Dict[str, Any]]:
        """Create all Eva messaging infrastructure streams"""
        stream_definitions = [
            {
                "name": "EVA_TICKETING_STREAM",
                "subjects": ["tickets.*", "incidents.*", "maintenance.*", "fault_descriptions.*"],
                "description": "Eva Group Ticketing - tickets, incidents, maintenance events, and fault descriptions",
                "retention": api.RetentionPolicy.WORK_QUEUE,
                "max_age": 72 * 60 * 60,  # 72 hours
                "max_msgs": 100000,
                "max_bytes": 104857600,  # 100MB
            },
        ]

        results = []
        for stream_def in stream_definitions:
            result = await self.create_stream(stream_def)
            results.append(result)

        return results

    async def create_stream(self, stream_def: Dict[str, Any]) -> Dict[str, Any]:
        """Create a single stream"""
        try:
            # Check if stream already exists
            try:
                await self.js.stream_info(stream_def["name"])
                return {
                    "stream_name": stream_def["name"],
                    "success": True,
                    "message": "Stream already exists"
                }
            except Exception:
                # Stream doesn't exist, create it
                pass

            # Create stream configuration
            config = api.StreamConfig(
                name=stream_def["name"],
                subjects=stream_def["subjects"],
                description=stream_def.get("description", ""),
                retention=stream_def.get("retention", api.RetentionPolicy.LIMITS),
                storage=api.StorageType.FILE,
                max_age=stream_def.get("max_age", 0),
                max_msgs=stream_def.get("max_msgs", -1),
                max_bytes=stream_def.get("max_bytes", -1)
            )

            # Create the stream
            await self.js.add_stream(config)

            return {
                "stream_name": stream_def["name"],
                "success": True,
                "message": "Stream created successfully"
            }

        except Exception as e:
            logger.error(f"❌ Failed to create stream {stream_def['name']}: {e}")
            return {
                "stream_name": stream_def["name"],
                "success": False,
                "message": f"Failed to create: {str(e)}"
            }

    async def list_streams(self) -> List[Dict[str, Any]]:
        """List all streams"""
        try:
            streams_info = await self.js.streams_info()

            streams = []
            for stream_info in streams_info:
                config = stream_info.config
                state = stream_info.state

                streams.append({
                    "name": config.name,
                    "description": config.description,
                    "subjects": config.subjects,
                    "retention": config.retention.value,
                    "storage": config.storage.value,
                    "messages": state.messages,
                    "bytes": state.bytes,
                    "first_seq": state.first_seq,
                    "last_seq": state.last_seq,
                    "consumer_count": state.consumer_count,
                    "created": stream_info.created.isoformat() if stream_info.created else None
                })

            return streams

        except Exception as e:
            logger.error(f"❌ Failed to list streams: {e}")
            raise

    async def validate_required_streams(self) -> Dict[str, Any]:
        """Validate that all required Eva streams exist"""
        required_streams = [
            "EVA_TICKETING_STREAM",
            "EVA_ANALYTICS_STREAM"
        ]

        try:
            existing_streams = await self.list_streams()
            existing_names = {stream["name"] for stream in existing_streams}

            found_streams = []
            missing_streams = []

            for required_stream in required_streams:
                if required_stream in existing_names:
                    found_streams.append(required_stream)
                else:
                    missing_streams.append(required_stream)

            return {
                "all_valid": len(missing_streams) == 0,
                "found_streams": found_streams,
                "missing_streams": missing_streams,
                "total_required": len(required_streams),
                "total_found": len(found_streams)
            }

        except Exception as e:
            logger.error(f"❌ Stream validation failed: {e}")
            raise

    async def get_stream_info(self, stream_name: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific stream"""
        try:
            stream_info = await self.js.stream_info(stream_name)
            config = stream_info.config
            state = stream_info.state

            return {
                "name": config.name,
                "description": config.description,
                "subjects": config.subjects,
                "retention": config.retention.value,
                "storage": config.storage.value,
                "max_age": config.max_age,
                "max_msgs": config.max_msgs,
                "max_bytes": config.max_bytes,
                "max_msg_size": config.max_msg_size,
                "max_consumers": config.max_consumers,
                "replicas": config.replicas,
                "messages": state.messages,
                "bytes": state.bytes,
                "first_seq": state.first_seq,
                "last_seq": state.last_seq,
                "consumer_count": state.consumer_count,
                "created": stream_info.created.isoformat() if stream_info.created else None
            }

        except Exception as e:
            logger.error(f"❌ Failed to get stream info for {stream_name}: {e}")
            return None

    async def delete_stream(self, stream_name: str) -> bool:
        """Delete a stream"""
        try:
            await self.js.delete_stream(stream_name)
            logger.info(f"✅ Deleted stream: {stream_name}")
            return True

        except Exception as e:
            logger.error(f"❌ Failed to delete stream {stream_name}: {e}")
            return False
