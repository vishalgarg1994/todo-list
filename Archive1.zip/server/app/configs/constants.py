DEFAULT_CONFIG_PATH = "configs/config.yml"
DEFAULT_BAML_PATH = "configs/baml.yml"
