#!/usr/bin/env python3
"""
Simple integration test for semantic search MCP tools
Uses only standard library (urllib) - no external dependencies
Tests all three tools end-to-end with real services
"""
import json
import urllib.request
import urllib.error


def call_mcp_tool(tool_name: str, arguments: dict) -> dict:
    """Call an MCP tool via HTTP"""
    url = "http://localhost:8003/mcp/v1/tools/call"

    payload = {
        "name": tool_name,
        "arguments": arguments
    }

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream"
    }

    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url, data=data, headers=headers)

    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        print(f"HTTP Error {e.code}: {error_body}")
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None


def test_search_similar_faults():
    """Test search_similar_faults tool - Fast vector-only search"""
    print("\n" + "=" * 80)
    print("TEST 1: search_similar_faults - Fast vector-only search")
    print("=" * 80)

    result = call_mcp_tool(
        "search_similar_faults",
        {
            "query": "fiber cable cut",
            "top_k": 5,
            "min_score": 0.3
        }
    )

    if result:
        print("✅ SUCCESS")
        print("Query: fiber cable cut")
        print(f"Results found: {result.get('total_results', 0)}")
        if result.get('results'):
            print("\nTop 3 matches:")
            for i, match in enumerate(result['results'][:3], 1):
                score = match.get('similarity_score', 0)
                fault_id = match.get('fault_description_id', 'N/A')
                print(f"  {i}. ID: {fault_id}, Score: {score:.3f}")
        return True
    else:
        print("❌ FAILED")
        return False


def test_search_similar_tickets():
    """Test search_similar_tickets tool - Vector + ticket metadata"""
    print("\n" + "=" * 80)
    print("TEST 2: search_similar_tickets - Vector + ticket metadata")
    print("=" * 80)

    result = call_mcp_tool(
        "search_similar_tickets",
        {
            "query": "BGP routing problem",
            "top_k": 5,
            "min_score": 0.3
        }
    )

    if result:
        print("✅ SUCCESS")
        print("Query: BGP routing problem")
        print(f"Results found: {result.get('total_results', 0)}")
        if result.get('results'):
            print("\nTop 3 matches with ticket details:")
            for i, match in enumerate(result['results'][:3], 1):
                score = match.get('similarity_score', 0)
                ticket_details = match.get('ticket_details', {})

                ticket_id = ticket_details.get('ticket_id', 'N/A')
                status = ticket_details.get('status', 'N/A')
                priority = ticket_details.get('priority', 'N/A')
                client = ticket_details.get('client_id', 'N/A')

                print(f"  {i}. Ticket: {ticket_id}, Score: {score:.3f}")
                print(f"     Status: {status}, Priority: {priority}, Client: {client}")
        return True
    else:
        print("❌ FAILED")
        return False


def test_search_similar_resolutions():
    """Test search_similar_resolutions tool - Full enrichment with OutageInfo"""
    print("\n" + "=" * 80)
    print("TEST 3: search_similar_resolutions - Full enrichment with OutageInfo")
    print("=" * 80)

    result = call_mcp_tool(
        "search_similar_resolutions",
        {
            "query": "power outage at datacenter",
            "top_k": 5,
            "min_score": 0.3
        }
    )

    if result:
        print("✅ SUCCESS")
        print("Query: power outage at datacenter")

        summary = result.get('summary', {})
        print("\nSummary:")
        print(f"  Total results: {summary.get('total_results', 0)}")
        print(f"  Tickets with resolution: {summary.get('tickets_with_resolution', 0)}")
        print(f"  Average MTTR: {summary.get('average_mttr_hours', 'N/A')} hours")

        if result.get('results'):
            print("\nTop 3 matches with resolution details:")
            for i, match in enumerate(result['results'][:3], 1):
                score = match.get('similarity_score', 0)
                ticket_details = match.get('ticket_details', {})
                resolution_details = match.get('resolution_details', {})

                ticket_id = ticket_details.get('ticket_id', 'N/A')
                mttr = resolution_details.get('mttr', 'N/A')
                rfo = resolution_details.get('rfo', 'N/A')
                resolution = resolution_details.get('resolution', 'N/A')

                print(f"  {i}. Ticket: {ticket_id}, Score: {score:.3f}")
                print(f"     MTTR: {mttr}h, RFO: {rfo}")
                if resolution and resolution != 'N/A':
                    print(f"     Resolution: {resolution[:100]}...")
        return True
    else:
        print("❌ FAILED")
        return False


def test_health():
    """Test server health endpoint"""
    print("\n" + "=" * 80)
    print("SETUP: Testing server health")
    print("=" * 80)

    url = "http://localhost:8003/health"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=10) as response:
            health = json.loads(response.read().decode('utf-8'))
            print(f"✅ Server Status: {health.get('status')}")
            print(f"   Service: {health.get('service')}")
            print(f"   Memgraph Connected: {health.get('memgraph_connected')}")
            return health.get('status') == 'healthy'
    except Exception as e:
        print(f"❌ Health check failed: {e}")
        return False


def main():
    """Run all tests"""
    print("\n" + "=" * 80)
    print("MCP TICKET - SEMANTIC SEARCH INTEGRATION TESTS")
    print("=" * 80)
    print("Testing Phase 3: Vector Search Implementation")
    print("Using synthetic data (505 fault descriptions in Milvus)")

    # Test health first
    if not test_health():
        print("\n❌ Server not healthy. Exiting.")
        return

    # Run all semantic search tests
    results = []
    results.append(("search_similar_faults", test_search_similar_faults()))
    results.append(("search_similar_tickets", test_search_similar_tickets()))
    results.append(("search_similar_resolutions", test_search_similar_resolutions()))

    # Summary
    print("\n" + "=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {test_name}")

    print(f"\nTotal: {passed}/{total} tests passed")

    if passed == total:
        print("\n🎉 All tests passed! Semantic search is fully functional.")
        return 0
    else:
        print(f"\n⚠️  {total - passed} test(s) failed.")
        return 1


if __name__ == "__main__":
    exit(main())
