"""
Fault Description NATS Consumer
Dedicated consumer for tickets.fault_description → Milvus embeddings
"""
import asyncio
import nats
import logging
import time
from typing import Callable, Any
from nats.errors import NoServersError, TimeoutError


class FaultDescriptionConsumer:
    """NATS consumer specifically for fault description messages"""

    def __init__(self, nats_url: str, stream_name: str, subject: str, max_concurrent: int = 20, nats_user: str = "", nats_password: str = ""):
        """
        Initialize the fault description consumer

        Args:
            nats_url: NATS server URL
            stream_name: JetStream stream name
            subject: Subject to subscribe to (tickets.fault_description)
            max_concurrent: Maximum number of concurrent message processing operations (default: 20)
            nats_user: NATS username for authentication
            nats_password: NATS password for authentication
        """
        self.nats_url = nats_url
        self.nats_user = nats_user
        self.nats_password = nats_password
        self.stream_name = stream_name
        self.subject = subject
        self.conn = None
        self.js = None
        self.sub = None
        self.logger = logging.getLogger(__name__)
        # Semaphore to limit concurrent operations
        self.semaphore = asyncio.Semaphore(max_concurrent)
        self.logger.info(f"Initialized FaultDescriptionConsumer with max_concurrent={max_concurrent}")

    async def connect(self):
        """Establish connection to NATS with JetStream"""
        if self.conn is not None and self.js is not None:
            self.logger.info("Already connected.")
            return

        for attempt in range(5):
            try:
                if self.nats_user and self.nats_password:
                    self.conn = await nats.connect(self.nats_url, user=self.nats_user, password=self.nats_password)
                else:
                    self.conn = await nats.connect(self.nats_url)
                self.js = self.conn.jetstream()
                self.logger.info(f"✅ Connected to NATS server: {self.nats_url}")
                await self.ensure_stream()
                return
            except (NoServersError, TimeoutError) as e:
                self.logger.error(f"NATS connection error (attempt {attempt + 1}): {e}")
                await asyncio.sleep(2**attempt)
            except Exception as e:
                self.logger.error(f"Failed to connect to NATS (attempt {attempt + 1}): {e}")

        self.logger.error("❌ Max connection attempts reached. Unable to connect.")
        raise Exception("Failed to connect to NATS after multiple attempts.")

    async def ensure_stream(self):
        """Verify JetStream stream exists"""
        try:
            await self.js.stream_info(self.stream_name)
            self.logger.info(f"⚡ Stream '{self.stream_name}' exists and is ready.")
        except Exception as e:
            self.logger.error(f"❌ Required stream '{self.stream_name}' not found: {e}")
            raise RuntimeError(f"Stream '{self.stream_name}' does not exist.")

    async def subscribe(self, message_handler: Callable[[Any], None]):
        """
        Pull-based subscription loop with robust error handling

        Philosophy: Log anomalies and move on. ACK bad messages to avoid infinite loops.
        Better to finish with 99% success than get stuck on 1% bad data.

        Args:
            message_handler: Async callback to process each message
        """
        self.logger.info("🚀 Starting fault description consumer")

        if self.conn is None or self.js is None:
            await self.connect()

        try:
            # Create durable consumer
            durable_name = self.subject.replace(".", "_").replace("*", "all") + "_consumer"
            self.sub = await self.js.pull_subscribe(subject=self.subject, durable=durable_name)
            self.logger.info(f"✅ Pull-based subscription active for: {self.subject} (consumer: {durable_name})")

            consecutive_errors = 0
            max_consecutive_errors = 5

            while True:
                try:
                    fetch_start = time.time()
                    msgs = await self.sub.fetch(batch=100, timeout=2.0)
                    fetch_time = time.time() - fetch_start
                    consecutive_errors = 0  # Reset on successful fetch

                    # Only log when messages are actually fetched
                    if len(msgs) > 0:
                        self.logger.info(f"⏱️  Fetched {len(msgs)} messages in {fetch_time:.3f}s")

                        # Process messages in parallel with semaphore limiting concurrency
                        batch_start = time.time()

                        async def process_with_semaphore(msg):
                            """Process message with semaphore to limit concurrent operations"""
                            async with self.semaphore:
                                try:
                                    await message_handler(msg)
                                    # Message handler is responsible for ACK/NAK
                                except Exception as callback_error:
                                    self.logger.error(f"❌ Message processing failed: {callback_error}")
                                    # Philosophy: Log and move on. ACK to avoid infinite retry.
                                    try:
                                        await msg.ack()
                                        self.logger.warning("⚠️  ACK'd failed message to continue processing")
                                    except Exception as ack_error:
                                        self.logger.error(f"❌ Failed to ACK message: {ack_error}")

                        # Create tasks for all messages and run them concurrently
                        tasks = [process_with_semaphore(msg) for msg in msgs]
                        await asyncio.gather(*tasks, return_exceptions=True)

                        batch_time = time.time() - batch_start
                        avg_msg_time = batch_time / len(msgs) if len(msgs) > 0 else 0
                        self.logger.info(f"⏱️  Processed {len(msgs)} messages in {batch_time:.3f}s (avg: {avg_msg_time:.3f}s/msg)")

                except TimeoutError:
                    # Normal timeout, no messages available
                    continue
                except Exception as e:
                    consecutive_errors += 1
                    self.logger.error(f"❌ Fetch error ({consecutive_errors}/{max_consecutive_errors}): {e}")

                    if consecutive_errors >= max_consecutive_errors:
                        self.logger.error("❌ Too many consecutive errors, stopping subscription")
                        break

                    await asyncio.sleep(min(consecutive_errors * 2, 10))

        except Exception as e:
            self.logger.error(f"❌ Subscription setup failed: {e}", exc_info=True)
            raise
        finally:
            self.logger.info("🛑 Fault description consumer stopped")

    async def unsubscribe(self):
        """Unsubscribe from JetStream"""
        if self.sub:
            try:
                await self.sub.unsubscribe()
                self.logger.info(f"✅ Unsubscribed from '{self.subject}'")
            except Exception as e:
                self.logger.error(f"❌ Error during unsubscribe: {e}")
            finally:
                self.sub = None

    async def close(self):
        """Close NATS connection"""
        if self.conn:
            try:
                await self.conn.close()
                self.logger.info("✅ Disconnected from NATS server.")
            except Exception as e:
                self.logger.error(f"❌ Error closing NATS connection: {e}")
            finally:
                self.conn = None
                self.js = None
                self.sub = None

    async def __aenter__(self):
        """Async context manager entry"""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.unsubscribe()
        await self.close()
