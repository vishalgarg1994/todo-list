#!/usr/bin/env python3
import httpx
import json

# Test direct HTTP call to see raw response
url = "http://localhost:8003/mcp/tools/ask_tickets_question"

headers = {"Accept": "application/json, text/event-stream"}

jsonrpc_request = {
    "jsonrpc": "2.0",
    "method": "tools/call",
    "params": {
        "name": "ask_tickets_question",
        "arguments": {
            "user_query": "How many open tickets are there?"
        }
    },
    "id": 1
}

print("Sending request...")
print(json.dumps(jsonrpc_request, indent=2))

response = httpx.post(url, json=jsonrpc_request, headers=headers, timeout=120.0)

print(f"\nStatus: {response.status_code}")
print(f"Headers: {dict(response.headers)}")
print(f"\nRaw Response Text:")
print(response.text)
print(f"\n\nResponse Length: {len(response.text)}")

try:
    parsed = response.json()
    print(f"\nParsed JSON:")
    print(json.dumps(parsed, indent=2))
except Exception as e:
    print(f"\nJSON Parse Error: {e}")
