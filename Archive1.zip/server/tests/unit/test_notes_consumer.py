"""
Unit tests for Notes Consumer (WS-C)
Tests the full pipeline with mocked LLM, Milvus, and Memgraph.

Mocks pymilvus at the module level so tests run without it installed.
"""
import sys
import pytest
import json
from pathlib import Path
from unittest.mock import Mock, AsyncMock, patch, MagicMock

# Mock heavy external deps before any app imports (not installed locally, only in docker)
sys.modules.setdefault("pymilvus", MagicMock())
sys.modules.setdefault("neo4j", MagicMock())

# Mock requests with a real exception class so raise/except patterns work
if "requests" not in sys.modules:
    _requests_mock = MagicMock()

    class _ConnectionError(Exception):
        pass

    class _Timeout(Exception):
        pass

    class _RequestException(Exception):
        pass

    _exceptions = MagicMock()
    _exceptions.ConnectionError = _ConnectionError
    _exceptions.Timeout = _Timeout
    _exceptions.RequestException = _RequestException
    _requests_mock.exceptions = _exceptions
    sys.modules["requests"] = _requests_mock
    sys.modules["requests.exceptions"] = _exceptions

from consumers.notes_consumer import NotesConsumer  # noqa: E402


# Test data path (relative to project root)
TEST_DATA_PATH = Path(__file__).parent.parent.parent / "test_data" / "notes_journal_incident.json"


def _mock_extraction_result(note_text, is_boilerplate=False):
    """Generate a realistic mock extraction result based on note content"""
    if is_boilerplate or "ServiceNow Email Sent Check Job" in note_text:
        return {
            "note_source": "System",
            "is_boilerplate": True,
            "fault_type": None,
            "fault_evidence": None,
            "responsible_party": None,
            "resolution_action": None,
            "root_cause": None,
            "equipment_rebooted": False,
            "supplier_name": None,
            "customer_confirmed": False,
            "cleaned_text": "",
            "extraction_confidence": 0.95,
            "timeline_events": [],
        }

    result = {
        "note_source": "Engineer",
        "is_boilerplate": False,
        "fault_type": None,
        "fault_evidence": None,
        "responsible_party": None,
        "resolution_action": None,
        "root_cause": None,
        "equipment_rebooted": False,
        "supplier_name": None,
        "customer_confirmed": False,
        "cleaned_text": note_text[:500],
        "extraction_confidence": 0.85,
        "timeline_events": [],
    }

    # ME3 alarm
    if "ME3 alarm" in note_text or "first_notify" in note_text:
        result["note_source"] = "Diagnostic"
        result["fault_type"] = "HardDown"
        result["fault_evidence"] = "The device is not reachable"
        result["timeline_events"] = [
            {"event_type": "ServiceDown", "timestamp": "2025-12-20T09:45:05Z", "description": "Device unreachable"}
        ]

    # Supplier fix
    elif "fiber break" in note_text.lower() or "fiber splice" in note_text.lower():
        result["responsible_party"] = "Supplier"
        result["root_cause"] = "Fiber break in local access network"

    # Supplier name
    if "NetConnect" in note_text:
        result["supplier_name"] = "NetConnect Ltd"

    # GEARS service restored
    if "GEARS" in note_text and "restored" in note_text:
        result["note_source"] = "Gears"
        result["timeline_events"] = [
            {"event_type": "ServiceRestored", "timestamp": None, "description": "GEARS detected restoration"}
        ]

    # Customer communication
    if "customer" in note_text.lower() and ("comments" in note_text.lower() or "Hi support" in note_text):
        result["note_source"] = "Customer"

    # Equipment reboot
    if "reboot" in note_text.lower():
        result["equipment_rebooted"] = True

    # Customer confirmed
    if "customer confirms" in note_text.lower() or "customer happy" in note_text.lower():
        result["customer_confirmed"] = True

    # Packet loss
    if "packet loss" in note_text.lower() or "CRC errors" in note_text.lower():
        result["fault_type"] = "PacketLoss"

    # Resolution action
    if "port migration" in note_text.lower():
        result["resolution_action"] = "Port migration to new interface"
        result["responsible_party"] = "GTT"
        result["root_cause"] = "Faulty port with CRC errors"

    # Power outage = customer responsible
    if "power outage" in note_text.lower():
        result["responsible_party"] = "Customer"
        result["root_cause"] = "Customer power outage during building maintenance"

    return result


def _mock_audit_result(ticket_id):
    """Generate a mock audit result with new schema (extracted vs original values)"""
    return {
        "ticket_id": ticket_id,
        # Extracted values (from notes analysis)
        "fault_type": "HardDown",
        "responsible_party": "Supplier",
        "priority": 2,
        "mttr_minutes": 275,
        "root_cause": "Fiber break in local access network",
        # Original ticket values (for comparison)
        "ticket_fault_type": "Network",
        "ticket_responsible_party": "GTT",
        "ticket_priority": 3,
        "ticket_mttr_minutes": 240,
        # Discrepancy tracking
        "differs_from_ticket": True,
        "extraction_evidence": "- Priority: Should have been P2 based on customer impact, was logged as P3\n- Responsible Party: Supplier caused it, but GTT was blamed",
        "confidence": 0.92,
        "notes_analyzed": 6,
    }


@pytest.fixture
def mock_config(mock_config):
    """Override mock_config for this test module"""
    mock_config.test_mode = True
    return mock_config


@pytest.fixture
def mock_extraction_service():
    """Mock ExtractionService that returns realistic results"""
    service = AsyncMock()

    async def extract_side_effect(note_text, metadata=""):
        return _mock_extraction_result(note_text)

    async def summary_side_effect(note_text):
        # Strip boilerplate signatures
        lines = note_text.split("\n")
        cleaned = []
        for line in lines:
            if line.strip().startswith("NOTICE:") or line.strip().startswith("---"):
                break
            if line.strip():
                cleaned.append(line.strip())
        return " ".join(cleaned) if cleaned else None

    async def audit_side_effect(ticket_id, ticket_data, all_notes_text):
        return _mock_audit_result(ticket_id)

    service.extract_from_note_async = AsyncMock(side_effect=extract_side_effect)
    service.generate_summary_async = AsyncMock(side_effect=summary_side_effect)
    service.audit_ticket_async = AsyncMock(side_effect=audit_side_effect)
    service.test_connection = Mock(return_value=True)

    return service


@pytest.fixture
def mock_embedding_service():
    """Mock EmbeddingService that returns 768-dim vectors"""
    service = Mock()
    service.generate_embedding = Mock(return_value=[0.1] * 768)
    service.test_connection = Mock(return_value=True)
    return service


@pytest.fixture
def mock_milvus_client():
    """Mock MilvusNotesClient that captures inserts"""
    client = Mock()
    client.connect = Mock()
    client.disconnect = Mock()
    client.flush = Mock()
    client.insert = AsyncMock(return_value=1)
    client.get_collection_stats = Mock(return_value={"num_entities": 0})
    return client


@pytest.fixture
def mock_memgraph_client():
    """Mock MemgraphClient that captures queries"""
    client = AsyncMock()
    client.connect = AsyncMock()
    client.closeConnection = AsyncMock()
    client.executeQuery = AsyncMock(return_value=True)
    return client


class TestNotesConsumerPipeline:
    """End-to-end pipeline tests with mocked services"""

    @pytest.fixture
    def consumer(self, mock_config, mock_extraction_service, mock_embedding_service,
                 mock_milvus_client, mock_memgraph_client):
        """Create NotesConsumer with all services mocked"""
        consumer = NotesConsumer.__new__(NotesConsumer)
        consumer.config = mock_config
        consumer.extraction_service = mock_extraction_service
        consumer.embedding_service = mock_embedding_service
        consumer.milvus_client = mock_milvus_client
        consumer.memgraph_client = mock_memgraph_client
        consumer.running = True

        return consumer

    @pytest.mark.asyncio
    async def test_process_resolved_ticket_stores_audit(self, consumer):
        """Resolved tickets should get audit stored in Memgraph"""
        with open(TEST_DATA_PATH) as f:
            data = json.load(f)

        # Get notes for ticket_aaa (resolved, fiber break)
        ticket_id = "ticket_aaa111bbb222ccc333ddd444"
        notes = [r for r in data["records"] if r["element_id"] == ticket_id]
        ticket_metadata = data["tickets"].get(ticket_id, {})

        result = await consumer._process_ticket_notes(
            ticket_id, notes, ticket_status="resolved", ticket_metadata=ticket_metadata
        )

        # Should have processed all 6 notes
        assert result["notes_processed"] == 6
        # Should have extracted from all 6
        assert result["notes_extracted"] == 6
        # Should have embedded non-boilerplate notes
        assert result["notes_embedded"] > 0
        # Should have stored audit in Memgraph (resolved ticket)
        assert result["audit_stored"] == 1

        # Verify Memgraph received NoteInfo with audit data
        query_calls = consumer.memgraph_client.executeQuery.call_args_list
        assert len(query_calls) > 0

        # Find the audit call (last one should have differs_from_ticket)
        audit_call_found = False
        for call in query_calls:
            params = call.kwargs.get("params", {})
            if "differs_from_ticket" in params:
                audit_call_found = True
                assert params["ticket_sys_id"] == ticket_id
                assert "extraction_evidence" in params
                assert "confidence" in params
                break
        assert audit_call_found, "Audit NoteInfo should have been stored in Memgraph"

    @pytest.mark.asyncio
    async def test_open_ticket_skips_audit(self, consumer):
        """Open tickets should NOT get audit stored"""
        with open(TEST_DATA_PATH) as f:
            data = json.load(f)

        # Get notes for ticket_mmm (open, power outage)
        ticket_id = "ticket_mmm333nnn444ooo555ppp666"
        notes = [r for r in data["records"] if r["element_id"] == ticket_id]

        result = await consumer._process_ticket_notes(ticket_id, notes, ticket_status="open")

        # Notes still get extracted and embedded
        assert result["notes_processed"] == 5
        assert result["notes_extracted"] > 0
        assert result["notes_embedded"] > 0
        # But NO audit stored for open ticket
        assert result["audit_stored"] == 0

        # Verify audit was NOT called
        consumer.extraction_service.audit_ticket_async.assert_not_called()

    @pytest.mark.asyncio
    async def test_boilerplate_notes_skipped_for_embedding(self, consumer):
        """Boilerplate notes should be extracted but NOT embedded"""
        with open(TEST_DATA_PATH) as f:
            data = json.load(f)

        # Get notes for ticket_eee (all boilerplate system messages)
        ticket_id = "ticket_eee555fff666ggg777hhh888"
        notes = [r for r in data["records"] if r["element_id"] == ticket_id]

        result = await consumer._process_ticket_notes(ticket_id, notes, ticket_status="open")

        # All 3 notes processed
        assert result["notes_processed"] == 3
        # All extracted (extraction still runs to classify as boilerplate)
        assert result["notes_extracted"] == 3
        # NONE embedded (all boilerplate)
        assert result["notes_embedded"] == 0

        # Verify Milvus insert was NOT called
        consumer.milvus_client.insert.assert_not_called()
        # Verify embedding was NOT called
        consumer.embedding_service.generate_embedding.assert_not_called()

    @pytest.mark.asyncio
    async def test_resolved_packet_loss_ticket(self, consumer):
        """Resolved packet loss ticket should get full processing"""
        with open(TEST_DATA_PATH) as f:
            data = json.load(f)

        # Get notes for ticket_iii (resolved, packet loss, port migration)
        ticket_id = "ticket_iii999jjj000kkk111lll222"
        notes = [r for r in data["records"] if r["element_id"] == ticket_id]
        ticket_metadata = data["tickets"].get(ticket_id, {})

        result = await consumer._process_ticket_notes(
            ticket_id, notes, ticket_status="resolved", ticket_metadata=ticket_metadata
        )

        assert result["notes_processed"] == 5
        assert result["notes_extracted"] == 5
        assert result["notes_embedded"] > 0
        # Resolved → audit stored in Memgraph
        assert result["audit_stored"] == 1

        # Verify audit WAS called
        consumer.extraction_service.audit_ticket_async.assert_called_once()

    @pytest.mark.asyncio
    async def test_milvus_receives_correct_data(self, consumer):
        """Verify Milvus inserts have correct structure"""
        with open(TEST_DATA_PATH) as f:
            data = json.load(f)

        ticket_id = "ticket_aaa111bbb222ccc333ddd444"
        notes = [r for r in data["records"] if r["element_id"] == ticket_id]

        await consumer._process_ticket_notes(ticket_id, notes, ticket_status="resolved")

        # Check Milvus insert calls
        insert_calls = consumer.milvus_client.insert.call_args_list
        assert len(insert_calls) > 0

        for call in insert_calls:
            kwargs = call.kwargs if call.kwargs else {}
            # insert(note_ids, embeddings, summary_texts, ticket_ids)
            if kwargs:
                assert len(kwargs["note_ids"]) == 1
                assert len(kwargs["embeddings"][0]) == 768
                assert len(kwargs["ticket_ids"]) == 1
                assert kwargs["ticket_ids"][0] == ticket_id

    @pytest.mark.asyncio
    async def test_memgraph_receives_audit_note_info(self, consumer):
        """Verify Memgraph gets NoteInfo with audit data (extracted vs original)"""
        with open(TEST_DATA_PATH) as f:
            data = json.load(f)

        ticket_id = "ticket_aaa111bbb222ccc333ddd444"
        notes = [r for r in data["records"] if r["element_id"] == ticket_id]
        ticket_metadata = data["tickets"].get(ticket_id, {})

        await consumer._process_ticket_notes(
            ticket_id, notes, ticket_status="resolved", ticket_metadata=ticket_metadata
        )

        # Check Memgraph executeQuery calls
        query_calls = consumer.memgraph_client.executeQuery.call_args_list
        assert len(query_calls) > 0

        # Find the audit NoteInfo call (has differs_from_ticket field)
        audit_params = None
        for call in query_calls:
            params = call.kwargs.get("params", call.args[1] if len(call.args) > 1 else {})
            if "differs_from_ticket" in params:
                audit_params = params
                break

        assert audit_params is not None, "Should have stored audit NoteInfo"
        assert audit_params["ticket_sys_id"] == ticket_id
        # Extracted values
        assert "fault_type" in audit_params
        assert "responsible_party" in audit_params
        assert "priority" in audit_params
        assert "mttr_minutes" in audit_params
        # Original ticket values
        assert "ticket_fault_type" in audit_params
        assert "ticket_responsible_party" in audit_params
        assert "ticket_priority" in audit_params
        # Discrepancy tracking
        assert "differs_from_ticket" in audit_params
        assert "extraction_evidence" in audit_params
        assert "confidence" in audit_params

    @pytest.mark.asyncio
    async def test_full_test_mode_run(self, consumer):
        """Test all 4 tickets: only resolved ones get audit stored"""
        with open(TEST_DATA_PATH) as f:
            test_data = json.load(f)

        records = test_data["records"]
        ticket_metadata = test_data["tickets"]

        from collections import defaultdict
        tickets = defaultdict(list)
        for record in records:
            tid = record.get("element_id", "")
            if tid and record.get("value", "").strip():
                tickets[tid].append(record)

        total_audits = 0
        for ticket_sys_id, notes in tickets.items():
            meta = ticket_metadata.get(ticket_sys_id, {})
            ticket_status = meta.get("ticket_status", "unknown")

            result = await consumer._process_ticket_notes(
                ticket_sys_id, notes, ticket_status=ticket_status, ticket_metadata=meta
            )
            total_audits += result["audit_stored"]

        # Only 2 resolved tickets should have audits stored
        assert total_audits == 2

        # Verify audit_ticket was called only for resolved tickets
        resolved_count = sum(1 for m in ticket_metadata.values() if m.get("ticket_status") == "resolved")
        assert consumer.extraction_service.audit_ticket_async.call_count == resolved_count


class TestExtractionService:
    """Unit tests for ExtractionService in isolation"""

    @pytest.fixture
    def service(self, mock_config):
        from services.extraction_service import ExtractionService
        return ExtractionService(mock_config)

    @patch('services.extraction_service.requests.post')
    def test_extract_from_note_success(self, mock_post, service):
        """Test successful extraction"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "response": json.dumps({
                "note_source": "Engineer",
                "is_boilerplate": False,
                "fault_type": "HardDown",
                "cleaned_text": "Device unreachable",
                "extraction_confidence": 0.9,
                "equipment_rebooted": False,
                "customer_confirmed": False,
                "timeline_events": []
            })
        }
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response

        result = service.extract_from_note("CPE unreachable since 09:44 UTC")

        assert result is not None
        assert result["note_source"] == "Engineer"
        assert result["fault_type"] == "HardDown"
        assert result["is_boilerplate"] is False

    @patch('services.extraction_service.requests.post')
    def test_extract_from_note_empty_text(self, mock_post, service):
        """Empty text should return None without calling Ollama"""
        result = service.extract_from_note("")
        assert result is None
        mock_post.assert_not_called()

    @patch('services.extraction_service.requests.post')
    def test_generate_summary_success(self, mock_post, service):
        """Test successful summary generation"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "response": json.dumps({"summary": "CPE unreachable, fiber break identified"})
        }
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response

        result = service.generate_summary("Long note text with boilerplate...")

        assert result == "CPE unreachable, fiber break identified"

    @patch('services.extraction_service.requests.post')
    def test_audit_ticket_success(self, mock_post, service):
        """Test successful ticket audit with new schema"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "response": json.dumps({
                "ticket_id": "INC001",
                "fault_type": "HardDown",
                "responsible_party": "Supplier",
                "priority": 2,
                "mttr_minutes": 127,
                "root_cause": "Fiber break",
                "ticket_fault_type": "Network",
                "ticket_responsible_party": "GTT",
                "ticket_priority": 3,
                "ticket_mttr_minutes": 240,
                "differs_from_ticket": True,
                "extraction_evidence": "- Priority: Should have been P2, was logged as P3",
                "confidence": 0.92,
                "notes_analyzed": 5
            })
        }
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response

        result = service.audit_ticket("INC001", "ticket data", "all notes")

        assert result is not None
        assert result["ticket_id"] == "INC001"
        assert result["differs_from_ticket"] is True
        assert result["confidence"] == 0.92
        assert "extraction_evidence" in result

    @patch('services.extraction_service.requests.post')
    def test_test_connection_success(self, mock_post, service):
        """Test connection check"""
        mock_response = Mock()
        mock_response.json.return_value = {"response": '{"status": "ok"}'}
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response

        assert service.test_connection() is True

    @patch('services.extraction_service.requests.post')
    def test_test_connection_failure(self, mock_post, service):
        """Test connection failure"""
        import requests
        mock_post.side_effect = requests.exceptions.ConnectionError("refused")

        assert service.test_connection() is False


class TestMilvusNotesClient:
    """Unit tests for MilvusNotesClient"""

    @pytest.fixture
    def client(self, mock_config):
        from data_access.milvus_notes_client import MilvusNotesClient
        return MilvusNotesClient(mock_config)

    def test_initialization(self, client, mock_config):
        """Test client initialization"""
        assert client.collection_name == mock_config.milvus_notes_collection
        assert client.collection is None
        assert client.is_connected is False

    @patch('data_access.milvus_notes_client.connections')
    @patch('data_access.milvus_notes_client.utility')
    @patch('data_access.milvus_notes_client.Collection')
    def test_connect_existing_collection(self, mock_collection_class, mock_utility, mock_connections, client):
        """Test connection to existing collection"""
        mock_utility.has_collection.return_value = True
        mock_collection = Mock()
        mock_collection_class.return_value = mock_collection

        client.connect()

        assert client.is_connected is True
        assert client.collection == mock_collection

    @patch('data_access.milvus_notes_client.connections')
    @patch('data_access.milvus_notes_client.utility')
    @patch('data_access.milvus_notes_client.Collection')
    def test_connect_creates_collection(self, mock_collection_class, mock_utility, mock_connections, client):
        """Test collection creation when it doesn't exist"""
        mock_utility.has_collection.return_value = False
        mock_collection = Mock()
        mock_collection_class.return_value = mock_collection

        client.connect()

        assert client.is_connected is True
        # Collection class called with schema
        mock_collection_class.assert_called()
