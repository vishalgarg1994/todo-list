import asyncio
import random
import logging
from typing import Callable, Any, Type, List, Optional
from functools import wraps


class RetryError(Exception):
    """Exception raised when all retry attempts are exhausted"""

    def __init__(self, message: str, original_exception: Exception, attempts: int):
        super().__init__(message)
        self.original_exception = original_exception
        self.attempts = attempts


class RetryHandler:
    """Enhanced retry handler with exponential backoff and jitter"""

    def __init__(
        self,
        max_attempts: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        backoff_multiplier: float = 2.0,
        jitter: bool = True,
        retryable_exceptions: Optional[List[Type[Exception]]] = None,
    ):
        self.max_attempts = max_attempts
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.backoff_multiplier = backoff_multiplier
        self.jitter = jitter
        self.retryable_exceptions = retryable_exceptions or [Exception]
        self.logger = logging.getLogger(__name__)

    def _is_retryable_exception(self, exception: Exception) -> bool:
        """Check if exception is retryable"""
        return any(
            isinstance(exception, exc_type) for exc_type in self.retryable_exceptions
        )

    def _calculate_delay(self, attempt: int) -> float:
        """Calculate delay for the given attempt with exponential backoff and jitter"""
        # Exponential backoff: base_delay * (backoff_multiplier ^ attempt)
        delay = self.base_delay * (self.backoff_multiplier**attempt)

        # Apply maximum delay limit
        delay = min(delay, self.max_delay)

        # Add jitter to prevent thundering herd
        if self.jitter:
            jitter_range = delay * 0.1  # 10% jitter
            delay += random.uniform(-jitter_range, jitter_range)

        return max(0, delay)  # Ensure non-negative delay

    async def execute_with_retry(
        self, func: Callable, *args, context: Optional[str] = None, **kwargs
    ) -> Any:
        """
        Execute function with retry logic

        Args:
            func: Function to execute
            *args: Positional arguments for the function
            context: Optional context description for logging
            **kwargs: Keyword arguments for the function

        Returns:
            Result of successful function execution

        Raises:
            RetryError: When all retry attempts are exhausted
        """
        last_exception = None
        context_str = f" ({context})" if context else ""

        for attempt in range(self.max_attempts):
            try:
                self.logger.debug(
                    f"Executing function{context_str} - attempt {attempt + 1}/{self.max_attempts}",
                    extra={
                        "function": func.__name__
                        if hasattr(func, "__name__")
                        else str(func),
                        "attempt": attempt + 1,
                        "max_attempts": self.max_attempts,
                        "context": context,
                    },
                )

                # Execute the function
                if asyncio.iscoroutinefunction(func):
                    result = await func(*args, **kwargs)
                else:
                    result = func(*args, **kwargs)

                # Success - log if it wasn't the first attempt
                if attempt > 0:
                    self.logger.info(
                        f"Function{context_str} succeeded after {attempt + 1} attempts",
                        extra={
                            "function": func.__name__
                            if hasattr(func, "__name__")
                            else str(func),
                            "successful_attempt": attempt + 1,
                            "context": context,
                        },
                    )

                return result

            except Exception as e:
                last_exception = e

                # Check if exception is retryable
                if not self._is_retryable_exception(e):
                    self.logger.error(
                        f"Non-retryable exception in function{context_str}",
                        extra={
                            "function": func.__name__
                            if hasattr(func, "__name__")
                            else str(func),
                            "exception_type": type(e).__name__,
                            "exception_message": str(e),
                            "context": context,
                        },
                        exc_info=True,
                    )
                    raise

                # Check if we have more attempts
                if attempt == self.max_attempts - 1:
                    # This was the last attempt
                    break

                # Calculate delay for next attempt
                delay = self._calculate_delay(attempt)

                self.logger.warning(
                    f"Function{context_str} failed on attempt {attempt + 1}, retrying in {delay:.2f}s",
                    extra={
                        "function": func.__name__
                        if hasattr(func, "__name__")
                        else str(func),
                        "attempt": attempt + 1,
                        "max_attempts": self.max_attempts,
                        "retry_delay": delay,
                        "exception_type": type(e).__name__,
                        "exception_message": str(e),
                        "context": context,
                    },
                )

                # Wait before retry
                await asyncio.sleep(delay)

        # All attempts exhausted
        error_message = (
            f"Function{context_str} failed after {self.max_attempts} attempts"
        )
        self.logger.error(
            error_message,
            extra={
                "function": func.__name__ if hasattr(func, "__name__") else str(func),
                "max_attempts": self.max_attempts,
                "final_exception_type": type(last_exception).__name__,
                "final_exception_message": str(last_exception),
                "context": context,
            },
            exc_info=True,
        )

        raise RetryError(error_message, last_exception, self.max_attempts)


def retry_with_backoff(
    max_attempts: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    backoff_multiplier: float = 2.0,
    jitter: bool = True,
    retryable_exceptions: Optional[List[Type[Exception]]] = None,
    context: Optional[str] = None,
):
    """
    Decorator for applying retry logic with exponential backoff to functions

    Args:
        max_attempts: Maximum number of retry attempts
        base_delay: Base delay in seconds
        max_delay: Maximum delay in seconds
        backoff_multiplier: Multiplier for exponential backoff
        jitter: Whether to add jitter to delays
        retryable_exceptions: List of exception types that should trigger retries
        context: Optional context description for logging
    """

    def decorator(func: Callable) -> Callable:
        retry_handler = RetryHandler(
            max_attempts=max_attempts,
            base_delay=base_delay,
            max_delay=max_delay,
            backoff_multiplier=backoff_multiplier,
            jitter=jitter,
            retryable_exceptions=retryable_exceptions,
        )

        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            return await retry_handler.execute_with_retry(
                func, *args, context=context or func.__name__, **kwargs
            )

        @wraps(func)
        async def sync_wrapper(*args, **kwargs):
            return await retry_handler.execute_with_retry(
                func, *args, context=context or func.__name__, **kwargs
            )

        # Return appropriate wrapper based on function type
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper

    return decorator


# Predefined retry configurations for common scenarios
DATABASE_RETRY = RetryHandler(
    max_attempts=3,
    base_delay=2.0,
    max_delay=30.0,
    backoff_multiplier=2.0,
    retryable_exceptions=[ConnectionError, TimeoutError, OSError],
)

NATS_RETRY = RetryHandler(
    max_attempts=5,
    base_delay=1.0,
    max_delay=15.0,
    backoff_multiplier=1.5,
    retryable_exceptions=[ConnectionError, TimeoutError],
)

HTTP_RETRY = RetryHandler(
    max_attempts=3,
    base_delay=1.0,
    max_delay=10.0,
    backoff_multiplier=2.0,
    retryable_exceptions=[ConnectionError, TimeoutError],
)
