"""
MCP tools for CMD vendor queries.
"""

from typing import Any, Dict, List


async def get_vendor_details(vendor_id: int, services: dict) -> Dict[str, Any]:
    """
    Get vendor details and a summary of their involvement across orders.

    Args:
        vendor_id: The vendor ID to look up
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (v:Vendor {id: $vendor_id})
        OPTIONAL MATCH (v)<-[:HAS_A_VENDOR|HAS_Z_VENDOR]-(seg:Segment)<-[:HAS_SEGMENT]-(o:Order)
        RETURN v.id AS vendor_id,
               v.name AS name,
               v.legal_name AS legal_name,
               count(DISTINCT seg) AS segment_count,
               count(DISTINCT o) AS order_count,
               collect(DISTINCT o.id) AS order_ids
    """, {"vendor_id": vendor_id})

    if not records:
        return {"error": f"Vendor {vendor_id} not found"}

    return records[0]


async def list_vendors(services: dict) -> List[Dict[str, Any]]:
    """
    List all vendors with their segment and order counts.
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (v:Vendor)
        OPTIONAL MATCH (v)<-[:HAS_A_VENDOR|HAS_Z_VENDOR]-(seg:Segment)
        OPTIONAL MATCH (seg)<-[:HAS_SEGMENT]-(o:Order)
        RETURN v.id AS vendor_id,
               v.name AS name,
               count(DISTINCT seg) AS segment_count,
               count(DISTINCT o) AS order_count
        ORDER BY order_count DESC
    """)

    return records


async def get_vendor_orders(vendor_id: int, services: dict) -> List[Dict[str, Any]]:
    """
    Get all orders that involve a specific vendor (through their segments).

    Args:
        vendor_id: The vendor ID
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (v:Vendor {id: $vendor_id})<-[:HAS_A_VENDOR|HAS_Z_VENDOR]-(seg:Segment)<-[:HAS_SEGMENT]-(o:Order)
        OPTIONAL MATCH (o)-[:HAS_SERVICE]->(s:Service)
        RETURN o.id AS order_id,
               o.status_label AS status,
               o.latest_status AS latest_update,
               s.service_type AS service_type,
               collect(DISTINCT seg.id) AS segment_ids
        ORDER BY order_id DESC
    """, {"vendor_id": vendor_id})

    return records


async def search_vendor_by_name(name: str, services: dict) -> List[Dict[str, Any]]:
    """
    Search vendors by name (partial, case-insensitive match).

    Args:
        name: Vendor name to search for
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (v:Vendor)
        WHERE toLower(v.name) CONTAINS toLower($name) OR toLower(v.legal_name) CONTAINS toLower($name)
        OPTIONAL MATCH (v)<-[:HAS_A_VENDOR|HAS_Z_VENDOR]-(seg:Segment)
        RETURN v.id AS vendor_id,
               v.name AS name,
               v.legal_name AS legal_name,
               count(DISTINCT seg) AS segment_count
        ORDER BY segment_count DESC
    """, {"name": name})

    return records
