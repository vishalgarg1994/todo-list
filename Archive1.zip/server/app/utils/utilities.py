import gzip
import base64
import json
import os
from typing import Any, Optional
from datetime import datetime, date, time, timedelta
from pathlib import Path

import dataclasses
from decimal import Decimal

from fastapi import Request
import yaml
import logging


class Helpers:

    @staticmethod
    def format_timestamp(timestamp: Optional[Any]) -> Optional[str]:
        """Normalize timestamp format to ISO 8601 for consistency."""
        if isinstance(timestamp, datetime):
            return timestamp.isoformat()
        elif isinstance(timestamp, str):
            try:
                return datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S").isoformat()
            except ValueError:
                print(f"Warning: Invalid timestamp format '{timestamp}'")
                return None
        return None

    @staticmethod
    def get_description_from_file(file_name: str, base_path: str) -> str:
        """Load description from file. Used by MCP component registration."""
        try:
            file_path = Path(__file__).parent.parent / base_path / file_name
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Error: The file at path '{file_path}' was not found.")

            # Check if the path points to a file and not a directory
            if not os.path.isfile(file_path):
                raise IOError(f"Error: The path '{file_path}' is a directory, not a file.")

            with open(file_path, "r", encoding="utf-8") as file:
                content = file.read()
                return str(content)
        except FileNotFoundError as fnf_error:
            print(fnf_error)
            return ""  # Or re-raise, depending on desired error handling
        except IOError as io_error:
            print(f"Error reading file '{file_path}': {io_error}")
            return ""  # Or re-raise
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
            return ""

    @staticmethod
    async def get_app_state(request: Request):
        """Dependency to get the FastAPI application state."""
        return request.app.state

    @staticmethod
    def load_cypher_configs(file_path: str) -> dict:
        """Load YAML data and handle errors gracefully."""
        try:
            with open(file_path, "r") as file:
                yaml_dict = yaml.safe_load(file) or {}

            if not yaml_dict:
                logging.warning("⚠️ YAML file is empty or improperly formatted.")
                return {}

            logging.debug("✅ Successfully loaded Cypher configurations.")

            return yaml_dict

        except FileNotFoundError:
            logging.error(f"❌ File not found: {file_path}")
            return {}
        except yaml.YAMLError as e:
            logging.error(f"❌ Error loading YAML file: {e}")
            return {}

    def graph_json_adapter(ticket_summary):
        """Adds unique IDs to ticket data while preserving original field names from ticketing_etl."""
        """TSM model: service_entity, fault_info (renamed from incident_info), ticket_info, outage_info."""

        # ✅ Generate `cl_id` using `client_id`
        ticket_summary["client_info"] = {
            "cl_id": f"Client_{ticket_summary['client_info']['client_id']}",
            **ticket_summary["client_info"],
        }

        # ✅ Generate IDs for each operational status entry WITHOUT renaming fields
        for entry in ticket_summary["operational_status"]:
            # Extract ticket_id for ID generation (using correct field name)
            ticket_id = entry["ticket_info"]["ticket_id"]

            # ✅ Add IDs to EXISTING fields (don't rename them!)
            if entry.get("service_entity"):
                entry["service_entity"] = {
                    "svc_id": f"Service_{ticket_id}",
                    **entry["service_entity"]
                }
            else:
                entry["service_entity"] = {"svc_id": f"Service_{ticket_id}"}

            # TSM model uses fault_info (renamed from incident_info)
            if entry.get("fault_info"):
                entry["fault_info"] = {
                    "fault_id": f"Fault_{ticket_id}",
                    **entry["fault_info"]
                }
            else:
                entry["fault_info"] = {"fault_id": f"Fault_{ticket_id}"}

            entry["ticket_info"] = {
                "tkt_id": f"Ticket_{ticket_id}",
                **entry["ticket_info"]
            }

            if entry.get("outage_info"):
                entry["outage_info"] = {
                    "oi_id": f"Outage_{ticket_id}",
                    **entry["outage_info"]
                }
            else:
                entry["outage_info"] = {"oi_id": f"Outage_{ticket_id}"}

            # ✅ Knowledge graph fields remain unchanged:
            #    - users[] (already has user_id)
            #    - contacts[] (already has contact_id)
            #    - vendors[] (already has vendor_id)
            #    - maintenance_window (ID generated in Cypher as 'mw_' + tkt_id)
            #    - survey_info (ID generated in Cypher as 'survey_' + tkt_id)
            #    - noc_info (ID generated in Cypher as 'noc_' + tkt_id)
            #    - tasks[] (already has task_sys_id)

        return ticket_summary

    @staticmethod
    def normalise_None(obj):
        """
        Recursively replaces common null-like string values with Python None.
        Handles nested dictionaries and lists.
        Converts: "null", "None", "", and whitespace-only strings to None.
        Also sets non-numeric 'outage_total' values to 0.
        """
        null_like_values = {"null", "None", "", "Null", " ", "NULL"}

        if isinstance(obj, dict):
            new_obj = {}
            for k, v in obj.items():
                # Special handling for 'outage_total'
                if k in {"outage_total", "master_ticket_id"}:
                    try:
                        new_obj[k] = int(v)
                    except (ValueError, TypeError):
                        new_obj[k] = 0
                else:
                    new_obj[k] = Helpers.normalise_None(v)
            return new_obj
        elif isinstance(obj, list):
            return [Helpers.normalise_None(item) for item in obj]
        elif isinstance(obj, str) and obj.strip() in null_like_values:
            return None
        else:
            return obj

    def decompress_message(message_bytes: bytes) -> dict:
        """
        Decompresses NATS message data supporting both compressed and uncompressed formats.
        Handles the gzip+base64 compression format used by ticket_etl.
        """
        try:
            if not message_bytes:
                raise ValueError("Empty message received.")

            decoded_str = message_bytes.decode("utf-8", errors="ignore").strip()
            logging.debug(f"🧪 Decoded string length: {len(decoded_str)}")

            # First parse attempt
            try:
                payload = json.loads(decoded_str)
            except json.JSONDecodeError as e:
                raise ValueError(f"Decoded string is not valid JSON: {e}")

            # Handle b'...' wrapper (edge case)
            if isinstance(payload, str) and payload.startswith("b'"):
                logging.debug("⚠️ Stripping b'...' wrapper from payload string.")
                payload = payload[2:-1]  # Remove b' and trailing '
                payload = json.loads(payload)

            # Handle compressed payload
            if isinstance(payload, dict) and payload.get("compressed") and payload.get("encoding") == "gzip+base64":
                logging.debug("🧪 Processing compressed payload.")
                try:
                    compressed_data = base64.b64decode(payload["data"])
                    decompressed_str = gzip.decompress(compressed_data).decode("utf-8")
                    parsed = json.loads(decompressed_str)
                    logging.debug(f"✅ Successfully decompressed payload with {len(parsed)} top-level keys")
                    return parsed
                except Exception as decomp_error:
                    raise ValueError(f"Failed to decompress payload: {decomp_error}")

            # Handle uncompressed payload
            logging.debug("🧪 Processing uncompressed payload.")
            return payload.get("data", payload)

        except Exception as e:
            preview = message_bytes[:200].decode("utf-8", errors="ignore")
            logging.error(f"❌ Message decompression failed: {e}")
            raise ValueError(f"Failed to decompress message: {e}\nRaw preview: {preview}")

    @staticmethod
    def recursive_serialize(obj):
        if dataclasses.is_dataclass(obj):
            return {k: Helpers.recursive_serialize(v) for k, v in dataclasses.asdict(obj).items()}
        elif isinstance(obj, list):
            # Keep lists as lists (don't stringify)
            return [Helpers.recursive_serialize(i) for i in obj]
        elif isinstance(obj, dict):
            return {k: Helpers.recursive_serialize(v) for k, v in obj.items()}
        elif isinstance(obj, datetime):
            # Must check datetime before date (datetime is subclass of date)
            return obj.strftime("%Y-%m-%d %H:%M:%S")
        elif isinstance(obj, date):
            return obj.isoformat()  # YYYY-MM-DD
        elif isinstance(obj, time):
            return obj.isoformat()  # HH:MM:SS.ffffff
        elif isinstance(obj, timedelta):
            return obj.total_seconds()  # Convert to float seconds
        elif isinstance(obj, bytes):
            return base64.b64encode(obj).decode('utf-8')  # Base64 encoded string
        elif isinstance(obj, Decimal):
            return float(obj)
        elif obj is None:
            # Explicitly preserve None values
            return None
        else:
            return obj
