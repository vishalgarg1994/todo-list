# Ticketing Agent Architecture

## Overview

The Ticketing Agent ingests ServiceNow ticket data, stores it in a knowledge graph, and provides intelligent access via natural language queries.

---

## System Components

```
┌─────────────────────────────────────────────────────────────────────┐
│                         DATA SOURCES                                 │
│  ┌─────────────┐    ┌─────────────┐                                 │
│  │ ServiceNow  │    │ ServiceNow  │                                 │
│  │  Database   │    │    API      │                                 │
│  └──────┬──────┘    └──────┬──────┘                                 │
└─────────┼──────────────────┼────────────────────────────────────────┘
          │                  │
          ▼                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                       TICKETING ETL                                  │
│                                                                      │
│  • Extracts tickets (Incident, Case, Problem, Change, Request)      │
│  • Transforms to Eva data model                                      │
│  • Publishes to NATS JetStream                                       │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      NATS JETSTREAM                                  │
│                                                                      │
│  • Message queue for reliable delivery                               │
│  • Decouples ETL from consumers                                      │
│  • Subject: tickets.created                                          │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      MCP TICKET SERVER                               │
│                                                                      │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                 │
│  │   Message   │  │    MCP      │  │   Health    │                 │
│  │   Handler   │  │   Tools     │  │   Checks    │                 │
│  └──────┬──────┘  └──────┬──────┘  └─────────────┘                 │
│         │                │                                           │
│         ▼                ▼                                           │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    BAML + LLM                                │   │
│  │         Natural Language → Cypher Translation                │   │
│  └─────────────────────────────────────────────────────────────┘   │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
          ┌────────────────┴────────────────┐
          ▼                                 ▼
┌─────────────────────┐          ┌─────────────────────┐
│     MEMGRAPH        │          │      MILVUS         │
│                     │          │                     │
│  • Knowledge Graph  │          │  • Vector Database  │
│  • Ticket nodes     │          │  • Embeddings       │
│  • Relationships    │          │  • Semantic Search  │
│  • Cypher queries   │          │                     │
└─────────────────────┘          └─────────────────────┘
```

---

## Data Flow

### 1. Ticket Ingestion

```
ServiceNow → ETL → NATS → MCP Server → Memgraph + Milvus
```

### 2. Query Flow

```
User Question → MCP Tool → BAML/LLM → Cypher → Memgraph → Response
```

### 3. Semantic Search

```
User Question → Embedding → Milvus → Similar Tickets → Response
```

---

## Key Technologies

| Component | Technology | Purpose |
|-----------|------------|---------|
| ETL | Python + asyncio | Data extraction & transformation |
| Messaging | NATS JetStream | Reliable event delivery |
| Graph DB | Memgraph | Ticket relationships & queries |
| Vector DB | Milvus | Semantic similarity search |
| LLM | Ollama (local) | Natural language to Cypher |
| Protocol | MCP (FastMCP) | AI assistant integration |

---

## Graph Data Model

```
(Client)──[:HAS_TICKET]──>(Ticket)
                              │
              ┌───────────────┼───────────────┐
              ▼               ▼               ▼
        (Outage_Info)   (Service_Entity)  (UserInfo)
              │
              ▼
        (NoteInfo)
```

**Node Types**: Client, Ticket, Outage_Info, Service_Entity, UserInfo, VendorInfo, NoteInfo

---

## Deployment

```
┌─────────────────────────────────────────┐
│            Kubernetes (K3s)             │
│                                         │
│  ┌───────────┐  ┌───────────┐          │
│  │  ETL Pod  │  │ MCP Pod   │          │
│  └───────────┘  └───────────┘          │
│                                         │
│  ┌───────────┐  ┌───────────┐          │
│  │ Memgraph  │  │  Milvus   │          │
│  └───────────┘  └───────────┘          │
│                                         │
│  ┌───────────┐                         │
│  │   NATS    │                         │
│  └───────────┘                         │
└─────────────────────────────────────────┘
```

---

## MCP Tools

| Tool | Purpose |
|------|---------|
| ask_question | Natural language queries |
| get_ticket | Lookup by ticket ID |
| get_client_tickets | All tickets for a client |
| search_tickets | Filter by status/priority |
| find_similar_tickets | Semantic similarity |
| get_ticket_relationships | Related tickets/incidents |

---

## Performance

- **Ingestion**: 612 msg/min (async with concurrency=5)
- **Query Response**: <500ms (95th percentile)
- **Concurrent Users**: Multiple simultaneous queries supported
