"""
Notes Consumer (WS-C)
Consumes ticket notes, extracts structured data, generates summary embeddings,
and stores audit results in Memgraph.

Flow per note:
  1. ExtractionService.extract_from_note() → structured attributes
  2. ExtractionService.generate_summary() → cleaned text for embedding
  3. EmbeddingService.generate_embedding(summary) → 768-dim vector
  4. MilvusNotesClient.insert(note_id, embedding, summary_text, ticket_id)

After all notes for a ticket:
  5. ExtractionService.audit_ticket() → extracted vs original values + evidence
  6. MemgraphClient: create NoteInfo node with extracted + original values, link to Ticket
"""
import logging
import json
import asyncio
import uuid
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional
from collections import defaultdict

from configs.config import Config
from data_access.milvus_notes_client import MilvusNotesClient
from data_access.memgraphClient import MemgraphClient
from data_access.cyphers.notes_queries import UPSERT_NOTE_INFO
from services.embedding_service import EmbeddingService
from services.extraction_service import ExtractionService


class NotesConsumer:
    """Consumer for processing ticket notes: extract, summarize, embed, store"""

    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.extraction_service = ExtractionService(self.config)
        self.embedding_service = EmbeddingService(self.config)
        self.milvus_client = MilvusNotesClient(self.config)
        self.memgraph_client: Optional[MemgraphClient] = None
        self.running = False

        logging.info(f"Initialized NotesConsumer (TEST_MODE={self.config.test_mode})")

    async def start(self):
        """Start the consumer (TEST_MODE or NATS)"""
        self.running = True

        # Connect to Milvus
        logging.info("Connecting to Milvus (ticket_notes)...")
        self.milvus_client.connect()
        logging.info("Connected to Milvus")

        # Connect to Memgraph
        logging.info("Connecting to Memgraph...")
        self.memgraph_client = MemgraphClient(
            uri=self.config.memgraph_uri,
            user=self.config.memgraph_user,
            password=self.config.memgraph_password,
            database=self.config.memgraph_database
        )
        await self.memgraph_client.connect()
        logging.info("Connected to Memgraph")

        # Test Ollama extraction model connection (fine-tuned)
        logging.info("Testing Ollama extraction model connection...")
        if not self.extraction_service.test_connection():
            logging.error("Ollama extraction model connection failed - is Ollama running with the model?")
            raise RuntimeError(f"Ollama extraction model not available (model={self.config.ollama_extraction_model})")
        logging.info(f"Ollama extraction model available (model={self.config.ollama_extraction_model})")

        # Test Ollama embedding connection
        logging.info("Testing Ollama embedding connection...")
        if not self.embedding_service.test_connection():
            logging.error("Ollama embedding connection failed")
            raise RuntimeError("Ollama embedding service not available")
        logging.info("Ollama embedding available")

        # Start appropriate mode
        if self.config.test_mode:
            await self._run_test_mode()
        else:
            await self._run_nats_mode()

    async def _run_test_mode(self):
        """Run in TEST_MODE using journal JSON files from test_data/"""
        logging.info("Running in TEST_MODE - loading journal data...")

        test_data_file = Path("/app/test_data/notes_journal_incident.json")

        if not test_data_file.exists():
            # Try relative path for local development
            test_data_file = Path(__file__).parent.parent.parent / "test_data" / "notes_journal_incident.json"

        if not test_data_file.exists():
            logging.error(f"Test data file not found: {test_data_file}")
            return

        with open(test_data_file, 'r') as f:
            data = json.load(f)

        records = data.get("records", data if isinstance(data, list) else [])
        ticket_metadata = data.get("tickets", {})
        logging.info(f"Loaded {len(records)} journal records, {len(ticket_metadata)} ticket metadata entries")

        # Group notes by ticket (element_id = parent ticket sys_id)
        tickets = defaultdict(list)
        for record in records:
            ticket_sys_id = record.get("element_id", "")
            if ticket_sys_id and record.get("value", "").strip():
                tickets[ticket_sys_id].append(record)

        logging.info(f"Found {len(tickets)} tickets with notes")

        # Process each ticket
        total_notes = 0
        total_embedded = 0
        total_extracted = 0
        total_audits = 0

        for ticket_sys_id, notes in tickets.items():
            meta = ticket_metadata.get(ticket_sys_id, {})
            ticket_status = meta.get("ticket_status", "unknown")
            ticket_id = meta.get("ticket_id", ticket_sys_id)

            logging.info(f"\n{'=' * 70}")
            logging.info(f"Processing ticket: {ticket_id} ({ticket_sys_id}) - status={ticket_status} ({len(notes)} notes)")
            logging.info(f"{'=' * 70}")

            result = await self._process_ticket_notes(
                ticket_sys_id,
                notes,
                ticket_status=ticket_status,
                ticket_metadata=meta
            )
            total_notes += result["notes_processed"]
            total_embedded += result["notes_embedded"]
            total_extracted += result["notes_extracted"]
            total_audits += result["audit_stored"]

        # Final summary
        logging.info(f"\n{'=' * 70}")
        logging.info(f"TEST_MODE Processing Complete!")
        logging.info(f"{'=' * 70}")
        logging.info(f"   Tickets processed: {len(tickets)}")
        logging.info(f"   Total notes: {total_notes}")
        logging.info(f"   Notes extracted: {total_extracted}")
        logging.info(f"   Notes embedded: {total_embedded}")
        logging.info(f"   Audits stored in Memgraph: {total_audits}")

        # Collection stats
        stats = self.milvus_client.get_collection_stats()
        logging.info(f"\n   Milvus ticket_notes: {stats.get('num_entities', 0)} embeddings")

    async def _run_nats_mode(self):
        """Run in production mode consuming from NATS (placeholder)"""
        logging.info("Running in NATS mode - subscribing to notes...")
        logging.warning("NATS mode not yet implemented for notes consumer")
        logging.info("Waiting for implementation of NATS message format...")

        # Keep running until stopped
        while self.running:
            await asyncio.sleep(1)

    async def _process_ticket_notes(
        self,
        ticket_sys_id: str,
        notes: List[Dict[str, Any]],
        ticket_status: str = "unknown",
        ticket_metadata: Dict[str, Any] = None
    ) -> Dict[str, int]:
        """
        Process all notes for a single ticket.

        Extraction + summarization + embedding runs for ALL tickets (notes become searchable).
        Audit runs for RESOLVED tickets - stores extracted vs original values in Memgraph NoteInfo.

        Args:
            ticket_sys_id: Ticket sys_id (element_id from journal)
            notes: List of journal records for this ticket
            ticket_status: Ticket status (only "resolved" triggers audit)
            ticket_metadata: Original ticket data for comparison

        Returns:
            Dict with processing counts
        """
        result = {
            "notes_processed": len(notes),
            "notes_extracted": 0,
            "notes_embedded": 0,
            "audit_stored": 0,
        }

        all_notes_text_parts = []
        ticket_metadata = ticket_metadata or {}

        for note_record in notes:
            note_sys_id = note_record.get("sys_id", "")
            note_text = note_record.get("value", "")
            note_created = note_record.get("sys_created_on", "")
            note_created_by = note_record.get("sys_created_by", "")
            note_element = note_record.get("element", "work_notes")

            if not note_text.strip():
                continue

            # Build metadata string for extraction prompt
            metadata = (
                f"note_id: {note_sys_id}\n"
                f"created_on: {note_created}\n"
                f"created_by: {note_created_by}\n"
                f"type: {note_element}\n"
                f"ticket_sys_id: {ticket_sys_id}"
            )

            # Step 1: Extract structured data
            extraction = await self.extraction_service.extract_from_note_async(note_text, metadata)

            if not extraction:
                logging.warning(f"  Extraction failed for note {note_sys_id}")
                continue

            result["notes_extracted"] += 1

            # Skip boilerplate notes for embedding (but still count as extracted)
            if extraction.get("is_boilerplate", False):
                logging.debug(f"  Note {note_sys_id} is boilerplate, skipping embedding")
                continue

            # Step 2: Generate summary for embedding
            summary = await self.extraction_service.generate_summary_async(note_text)
            if not summary:
                # Fallback to cleaned_text from extraction
                summary = extraction.get("cleaned_text", note_text)

            # Collect for ticket-level audit
            all_notes_text_parts.append(f"[{note_created}] ({note_created_by}): {summary}")

            # Step 3: Generate embedding from summary
            embedding = self.embedding_service.generate_embedding(summary)
            if not embedding:
                logging.warning(f"  Embedding failed for note {note_sys_id}")
                continue

            # Step 4: Store in Milvus (note_id, embedding, summary_text, ticket_id)
            try:
                await self.milvus_client.insert(
                    note_ids=[note_sys_id],
                    embeddings=[embedding],
                    summary_texts=[summary[:65535]],  # Milvus VARCHAR limit
                    ticket_ids=[ticket_sys_id]
                )
                result["notes_embedded"] += 1
            except Exception as e:
                logging.error(f"  Milvus insert failed for note {note_sys_id}: {e}")
                continue

        # Step 5: Ticket-level audit (only for RESOLVED tickets)
        if all_notes_text_parts and ticket_status == "resolved":
            all_notes_text = "\n\n".join(all_notes_text_parts)

            # Build ticket data string for audit prompt (original values for comparison)
            ticket_data = self._build_ticket_data_string(ticket_sys_id, ticket_metadata)

            audit_result = await self.extraction_service.audit_ticket_async(
                ticket_id=ticket_sys_id,
                ticket_data=ticket_data,
                all_notes_text=all_notes_text
            )

            # Step 6: Store NoteInfo with extracted + original values in Memgraph
            if audit_result:
                note_info_id = f"ni_{ticket_sys_id}_{uuid.uuid4().hex[:8]}"
                params = {
                    "note_info_id": note_info_id,
                    "note_id": note_info_id,  # Reference for Milvus lookup
                    "ticket_sys_id": ticket_sys_id,
                    # Extracted values (from notes analysis)
                    "fault_type": audit_result.get("fault_type"),
                    "responsible_party": audit_result.get("responsible_party"),
                    "priority": audit_result.get("priority"),
                    "mttr_minutes": audit_result.get("mttr_minutes"),
                    "root_cause": audit_result.get("root_cause"),
                    # Original ticket values (for comparison)
                    "ticket_fault_type": audit_result.get("ticket_fault_type"),
                    "ticket_responsible_party": audit_result.get("ticket_responsible_party"),
                    "ticket_priority": audit_result.get("ticket_priority"),
                    "ticket_mttr_minutes": audit_result.get("ticket_mttr_minutes"),
                    # Discrepancy tracking
                    "differs_from_ticket": audit_result.get("differs_from_ticket", False),
                    "extraction_evidence": audit_result.get("extraction_evidence", ""),
                    "confidence": audit_result.get("confidence", 0.0),
                    "notes_analyzed": audit_result.get("notes_analyzed", len(notes)),
                    "created_on": datetime.utcnow().isoformat(),
                }

                success = await self.memgraph_client.executeQuery(
                    UPSERT_NOTE_INFO,
                    params=params,
                    message=f"NoteInfo audit {note_info_id}"
                )
                if success:
                    result["audit_stored"] = 1
                    logging.info(f"  Audit stored: differs={audit_result.get('differs_from_ticket')}, "
                                f"confidence={audit_result.get('confidence')}")
                else:
                    logging.warning(f"  Memgraph NoteInfo insert failed for {note_info_id}")
        elif ticket_status != "resolved":
            logging.info(f"  Skipping audit for {ticket_sys_id} (status={ticket_status}, not resolved)")

        # Flush Milvus after each ticket
        if result["notes_embedded"] > 0:
            try:
                self.milvus_client.flush()
            except Exception as e:
                logging.warning(f"  Milvus flush failed: {e}")

        logging.info(f"  Ticket {ticket_sys_id}: extracted={result['notes_extracted']}, "
                    f"embedded={result['notes_embedded']}, audit_stored={result['audit_stored']}")

        return result

    def _build_ticket_data_string(self, ticket_sys_id: str, metadata: Dict[str, Any]) -> str:
        """Build ticket data string for audit prompt with original values"""
        lines = [f"ticket_sys_id: {ticket_sys_id}"]

        if metadata:
            if metadata.get("ticket_id"):
                lines.append(f"ticket_number: {metadata.get('ticket_id')}")
            if metadata.get("priority"):
                lines.append(f"priority: {metadata.get('priority')}")
            if metadata.get("fault_type"):
                lines.append(f"fault_type: {metadata.get('fault_type')}")
            if metadata.get("responsible_party"):
                lines.append(f"responsible_party: {metadata.get('responsible_party')}")
            if metadata.get("mttr_minutes"):
                lines.append(f"mttr_minutes: {metadata.get('mttr_minutes')}")
            if metadata.get("resolution_code"):
                lines.append(f"resolution_code: {metadata.get('resolution_code')}")
            if metadata.get("resolution_notes"):
                lines.append(f"resolution_notes: {metadata.get('resolution_notes')}")

        return "\n".join(lines)

    async def stop(self):
        """Stop the consumer and cleanup connections"""
        logging.info("Stopping NotesConsumer...")
        self.running = False

        self.milvus_client.disconnect()

        if self.memgraph_client:
            await self.memgraph_client.closeConnection()

        logging.info("NotesConsumer stopped")


async def main():
    """Main entry point for standalone execution"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    config = Config()
    consumer = NotesConsumer(config)

    try:
        await consumer.start()
    except KeyboardInterrupt:
        logging.info("\nReceived interrupt signal")
    except Exception as e:
        logging.error(f"Consumer error: {e}")
        raise
    finally:
        await consumer.stop()


if __name__ == "__main__":
    asyncio.run(main())
