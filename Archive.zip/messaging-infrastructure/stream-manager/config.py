"""
Configuration management for Eva NATS Stream Manager
"""

import os
from typing import Optional


class Config:
    """Configuration management for NATS stream manager"""

    def __init__(self):
        self.load_config()

    def load_config(self):
        """Load configuration from environment variables"""
        pass

    def get_nats_url(self) -> str:
        """Get NATS server URL"""
        return os.getenv("NATS_URL", "nats://localhost:4222")

    def get_nats_user(self) -> Optional[str]:
        """Get NATS publisher username for authentication"""
        return os.getenv("NATS_PUBLISHER_USER")

    def get_nats_password(self) -> Optional[str]:
        """Get NATS publisher password for authentication"""
        return os.getenv("NATS_PUBLISHER_PASSWORD")

    def get_nats_tls_enabled(self) -> bool:
        """Check if TLS is enabled for NATS connection"""
        return os.getenv("NATS_TLS_ENABLED", "false").lower() == "true"

    def get_nats_tls_cert(self) -> Optional[str]:
        """Get NATS TLS client certificate path"""
        return os.getenv("NATS_TLS_CERT")

    def get_nats_tls_key(self) -> Optional[str]:
        """Get NATS TLS client key path"""
        return os.getenv("NATS_TLS_KEY")

    def get_nats_tls_ca(self) -> Optional[str]:
        """Get NATS TLS CA certificate path"""
        return os.getenv("NATS_TLS_CA")

    def get_nats_tls_verify(self) -> bool:
        """Check if TLS certificate verification is enabled"""
        return os.getenv("NATS_TLS_VERIFY", "true").lower() == "true"

    def get_tls_enabled(self) -> bool:
        """Global TLS setting"""
        return os.getenv("TLS_ENABLED", "true").lower() == "true"

    def get_api_host(self) -> str:
        """Get API server host"""
        return os.getenv("API_HOST", "0.0.0.0")

    def get_api_port(self) -> int:
        """Get API server port"""
        return int(os.getenv("API_PORT", "8080"))
