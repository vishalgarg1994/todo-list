"""
MCP tools for semantic (vector) search across CMD order data.
"""

from typing import Any, Dict, List


async def search_similar_notes(
    query: str,
    top_k: int = 10,
    services: dict = None,
) -> List[Dict[str, Any]]:
    """
    Semantic search across all order notes. Uses vector similarity to find
    notes related to a natural language query - e.g. "vendor delay",
    "address change", "fiber installation issue".

    Args:
        query: Natural language search query
        top_k: Number of results to return (default 10)
    """
    semantic = services.get("semantic_search_service")
    if not semantic:
        return [{"error": "Semantic search service not available (Milvus/Ollama not connected)"}]

    mg = services.get("memgraph_client")
    results = await semantic.search_notes(query, top_k=top_k, memgraph_client=mg)
    return results


async def find_similar_orders(
    order_id: int,
    top_k: int = 5,
    services: dict = None,
) -> List[Dict[str, Any]]:
    """
    Find orders similar to a given order based on the semantic content of their notes.
    Uses the notes of the specified order as the query to find other orders with
    similar operational patterns.

    Args:
        order_id: The reference order ID
        top_k: Number of similar orders to return (default 5)
    """
    mg = services.get("memgraph_client")
    semantic = services.get("semantic_search_service")
    if not semantic:
        return [{"error": "Semantic search service not available"}]

    # Get notes for the reference order
    notes = await mg.execute_and_fetch("""
        MATCH (o:Order {id: $order_id})-[:HAS_NOTE]->(n:Note)
        RETURN n.body AS body
        LIMIT 5
    """, {"order_id": order_id})

    if not notes:
        return [{"error": f"No notes found for order {order_id}"}]

    combined_text = " ".join(n["body"] for n in notes if n.get("body"))
    if len(combined_text) > 2000:
        combined_text = combined_text[:2000]

    results = await semantic.search_notes(combined_text, top_k=top_k * 3, memgraph_client=mg)

    # Deduplicate by order_id, exclude the source order
    seen_orders = set()
    similar_orders = []
    for r in results:
        oid = r.get("order_id")
        if oid and oid != order_id and oid not in seen_orders:
            seen_orders.add(oid)
            similar_orders.append({
                "order_id": oid,
                "status": r.get("order_status"),
                "service_type": r.get("service_type"),
                "matching_note_subject": r.get("note_subject"),
                "similarity_score": r.get("score"),
            })
            if len(similar_orders) >= top_k:
                break

    return similar_orders
