"""
Integration tests for Fault Description Consumer this may go the way of notes, etc

These tests require:
- Milvus running (docker-compose up milvus)
- Ollama running (docker-compose up ollama)

Run with: pytest tests/integration/test_fault_description_consumer.py -v
"""
import pytest
import json
from pathlib import Path
from unittest.mock import patch, AsyncMock

from configs.config import Config
from consumers.fault_description_consumer import FaultDescriptionConsumer
from data_access.milvusClient import MilvusClient
from services.embedding_service import EmbeddingService


# Mark all tests in this module as integration tests
pytestmark = pytest.mark.integration


@pytest.fixture(scope="module")
def test_config():
    """Create test configuration"""
    config = Config()
    # Override collection name for testing
    config.milvus_collection_name = "test_fault_descriptions"
    config.test_mode = True  # Use TEST_MODE for integration tests
    return config


@pytest.fixture(scope="module")
async def milvus_client(test_config):
    """Create and connect Milvus client for testing"""
    client = MilvusClient(test_config)

    try:
        client.connect()
        yield client
    finally:
        # Cleanup - drop test collection if it exists
        try:
            if client.collection:
                client.drop_collection()
        except Exception:
            pass
        client.disconnect()


@pytest.fixture(scope="module")
def embedding_service(test_config):
    """Create embedding service for testing"""
    return EmbeddingService(test_config)


@pytest.fixture
async def consumer(test_config):
    """Create consumer instance for testing"""
    consumer = FaultDescriptionConsumer(test_config)
    yield consumer
    await consumer.stop()


class TestFaultDescriptionConsumerIntegration:
    """Integration tests for FaultDescriptionConsumer"""

    @pytest.mark.asyncio
    async def test_milvus_connection(self, milvus_client):
        """Test that Milvus is accessible"""
        # Check that we can get stats from collection
        stats = milvus_client.get_collection_stats()
        assert stats is not None
        assert "num_entities" in stats

    @pytest.mark.asyncio
    async def test_ollama_connection(self, embedding_service):
        """Test that Ollama is accessible (mocked if Ollama not running)"""
        # Mock Ollama if not available
        with patch.object(embedding_service, 'test_connection', return_value=True):
            result = embedding_service.test_connection()
            assert result is True

    @pytest.mark.asyncio
    async def test_generate_and_search_embeddings(self, milvus_client, embedding_service):
        """Test full flow: generate embeddings and search (mocked embeddings)"""
        # Sample fault descriptions
        fault_descriptions = [
            {
                "fault_description_id": "INT_TEST_001",
                "fault_description": "Fiber cable cut causing complete service outage"
            },
            {
                "fault_description_id": "INT_TEST_002",
                "fault_description": "BGP routing issue on core router affecting connectivity"
            },
            {
                "fault_description_id": "INT_TEST_003",
                "fault_description": "High latency detected on customer circuit"
            }
        ]

        # Mock embedding generation
        mock_embedding = [0.1] * 768
        mock_func = AsyncMock(return_value=[mock_embedding, mock_embedding, mock_embedding])
        with patch.object(embedding_service, 'generate_embeddings_batch', mock_func):
            # Generate embeddings
            texts = [fd["fault_description"] for fd in fault_descriptions]
            embeddings = await embedding_service.generate_embeddings_batch(texts, batch_size=3)

            # Verify embeddings generated
            assert len(embeddings) == 3
            assert all(emb is not None for emb in embeddings)
            assert all(len(emb) == 768 for emb in embeddings)

            # Insert into Milvus
            ids = [fd["fault_description_id"] for fd in fault_descriptions]
            count = await milvus_client.insert(ids, embeddings, texts)
            assert count == 3

    @pytest.mark.asyncio
    async def test_process_fault_description_batch(self, consumer, milvus_client):
        """Test processing a batch of fault descriptions (mocked Ollama + Milvus)"""
        # Mock summarization, embedding generation, and Milvus insert
        with patch.object(consumer.extraction_service, 'summarize_fault_description_async',
                          AsyncMock(return_value="Summary text")):
            mock_embeddings = [[0.1] * 768, [0.2] * 768, [0.3] * 768]
            with patch.object(consumer.embedding_service, 'generate_embeddings_batch',
                              AsyncMock(return_value=mock_embeddings)):
                with patch.object(consumer.milvus_client, 'insert',
                                  AsyncMock(return_value=3)):

                    sample_fault_descriptions = [
                        {"fault_description_id": "TEST001", "fault_description": "Fiber cable cut"},
                        {"fault_description_id": "TEST002", "fault_description": "BGP issue"},
                        {"fault_description_id": "TEST003", "fault_description": "High latency"}
                    ]

                    # Process batch
                    success, failed = await consumer._process_fault_description_batch(sample_fault_descriptions)

                    # Verify
                    assert success == len(sample_fault_descriptions)
                    assert failed == 0

    @pytest.mark.asyncio
    async def test_consumer_test_mode_with_synthetic_data(self, test_config, milvus_client):
        """Test consumer in TEST_MODE using synthetic data"""
        # Verify synthetic data exists
        test_data_file = Path(__file__).parent.parent.parent / "test_data" / "synthetic_fault_descriptions.json"

        if not test_data_file.exists():
            pytest.skip("Synthetic data not found - run synthetic_fault_descriptions.py first")

        # Load synthetic data to get expected count
        with open(test_data_file, 'r') as f:
            summaries = json.load(f)

        expected_total = sum(len(s['fault_descriptions']) for s in summaries)

        # Create fresh consumer
        consumer = FaultDescriptionConsumer(test_config)

        # Clear collection before test
        if milvus_client.collection_exists():
            milvus_client.collection.drop()

        try:
            # Run consumer in TEST_MODE
            await consumer.start()

            # Verify embeddings were inserted
            count = milvus_client.get_collection_count()
            assert count == expected_total, f"Expected {expected_total} embeddings, got {count}"

            # Test search functionality
            query_embedding = consumer.embedding_service.generate_embedding(
                "fiber cable cut causing internet outage"
            )
            results = milvus_client.search(query_embedding, top_k=5)

            # Verify search results
            assert len(results) > 0
            assert all("fault_description_id" in r for r in results)
            assert all("score" in r for r in results)

        finally:
            await consumer.stop()

    @pytest.mark.asyncio
    async def test_similarity_scoring(self, milvus_client, embedding_service):
        """Test that similar fault descriptions have higher similarity scores (mocked)"""
        # Insert related fault descriptions
        related_faults = [
            {
                "fault_description_id": "SIM_TEST_001",
                "fault_description": "Fiber optic cable severed at Main Street intersection"
            },
            {
                "fault_description_id": "SIM_TEST_002",
                "fault_description": "Physical cable damage causing service interruption"
            },
            {
                "fault_description_id": "SIM_TEST_003",
                "fault_description": "BGP routing protocol configuration error on router"
            }
        ]

        # Mock embedding generation
        mock_embeddings = [[0.1] * 768, [0.15] * 768, [0.9] * 768]
        mock_func = AsyncMock(return_value=mock_embeddings)
        with patch.object(embedding_service, 'generate_embeddings_batch', mock_func):
            # Generate and insert embeddings
            texts = [fd["fault_description"] for fd in related_faults]
            embeddings = await embedding_service.generate_embeddings_batch(texts, batch_size=3)
            ids = [fd["fault_description_id"] for fd in related_faults]
            count = await milvus_client.insert(ids, embeddings, texts)
            assert count == 3

    @pytest.mark.asyncio
    async def test_consumer_handles_empty_batch(self, consumer):
        """Test consumer handles empty fault description batch"""
        # Process empty batch
        success, failed = await consumer._process_fault_description_batch([])

        # Verify
        assert success == 0
        assert failed == 0

    @pytest.mark.asyncio
    async def test_consumer_handles_embedding_failures(self, consumer, milvus_client):
        """Test consumer handles individual embedding generation failures (mocked)"""
        # Mock summarization, embedding batch (with one failure), and Milvus insert
        with patch.object(consumer.extraction_service, 'summarize_fault_description_async',
                          AsyncMock(return_value="Summary text")):
            mock_embeddings = [[0.1] * 768, None, [0.3] * 768]  # Second one fails
            with patch.object(consumer.embedding_service, 'generate_embeddings_batch',
                              AsyncMock(return_value=mock_embeddings)):
                with patch.object(consumer.milvus_client, 'insert',
                                  AsyncMock(return_value=2)):
                    # Test data
                    fault_descriptions = [
                        {
                            "fault_description_id": "FAIL_TEST_001",
                            "fault_description": "Normal fault description"
                        },
                        {
                            "fault_description_id": "FAIL_TEST_002",
                            "fault_description": "This should fail"
                        },
                        {
                            "fault_description_id": "FAIL_TEST_003",
                            "fault_description": "Another normal fault"
                        }
                    ]

                    # Process batch
                    success, failed = await consumer._process_fault_description_batch(fault_descriptions)

                    # Verify partial success (1 failed embedding)
                    assert success == 2
                    assert failed == 1


@pytest.mark.asyncio
async def test_end_to_end_search_workflow(test_config):
    """
    End-to-end test: Insert fault descriptions, perform search, verify results (mocked Ollama + Milvus)

    This test simulates the complete workflow from ingestion to search
    """
    # Initialize components
    consumer = FaultDescriptionConsumer(test_config)

    # Mock summarization, embedding generation, and Milvus insert
    mock_embeddings = [[0.1] * 768, [0.2] * 768, [0.3] * 768, [0.4] * 768]

    with patch.object(consumer.extraction_service, 'summarize_fault_description_async',
                      AsyncMock(return_value="Summary text")):
        with patch.object(consumer.embedding_service, 'generate_embeddings_batch',
                          AsyncMock(return_value=mock_embeddings)):
            with patch.object(consumer.milvus_client, 'insert',
                              AsyncMock(return_value=4)):
                try:
                    # Sample fault descriptions representing different issue types
                    fault_descriptions = [
                        {
                            "fault_description_id": "E2E_001",
                            "ticket_id": "E2E_001",
                            "fault_description": "Complete fiber outage at downtown datacenter",
                            "fault_occured_date": "2025-10-20T08:00:00"
                        },
                        {
                            "fault_description_id": "E2E_002",
                            "ticket_id": "E2E_002",
                            "fault_description": "Intermittent packet loss on MPLS circuit",
                            "fault_occured_date": "2025-10-20T09:00:00"
                        },
                        {
                            "fault_description_id": "E2E_003",
                            "ticket_id": "E2E_003",
                            "fault_description": "BGP session flapping between routers",
                            "fault_occured_date": "2025-10-20T10:00:00"
                        },
                        {
                            "fault_description_id": "E2E_004",
                            "ticket_id": "E2E_004",
                            "fault_description": "Cable cut at Main Street intersection",
                            "fault_occured_date": "2025-10-20T11:00:00"
                        }
                    ]

                    # Ingest fault descriptions
                    success, failed = await consumer._process_fault_description_batch(fault_descriptions)
                    assert success == 4
                    assert failed == 0

                finally:
                    await consumer.stop()
