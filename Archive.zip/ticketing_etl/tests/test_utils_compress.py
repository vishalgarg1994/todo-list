import pytest
import gzip
import json
import base64
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from utils.compress import compress_and_check, MAX_NATS_PAYLOAD


class TestCompressAndCheck:
    def test_compress_small_message(self):
        """Test compression of small message"""
        small_message = "Hello, World!"

        result = compress_and_check(small_message)

        # Should always return compressed bytes
        assert isinstance(result, bytes)

        # Should be valid JSON
        payload = json.loads(result.decode("utf-8"))
        assert payload["compressed"] is True
        assert payload["encoding"] == "gzip+base64"
        assert "data" in payload

        # Should be able to decompress back to original
        compressed_data = base64.b64decode(payload["data"])
        decompressed = gzip.decompress(compressed_data).decode("utf-8")
        assert decompressed == small_message

    def test_compress_medium_message(self):
        """Test compression of medium-sized message"""
        medium_message = "x" * 1100

        result = compress_and_check(medium_message)

        # Should return compressed bytes
        assert isinstance(result, bytes)

        # Verify it's valid JSON with compression metadata
        payload = json.loads(result.decode("utf-8"))
        assert payload["compressed"] is True
        assert payload["encoding"] == "gzip+base64"

        # Verify it can be decompressed back to original
        compressed_data = base64.b64decode(payload["data"])
        decompressed = gzip.decompress(compressed_data).decode("utf-8")
        assert decompressed == medium_message

    def test_compress_large_message(self):
        """Test compression of large message"""
        # Create message that's large but still compressible
        large_message = (
            "This is a test message that will be repeated many times. " * 1000
        )

        result = compress_and_check(large_message)

        if result is not None:
            # If not None, should be valid compressed data
            assert isinstance(result, bytes)
            payload = json.loads(result.decode("utf-8"))
            assert payload["compressed"] is True

            # Verify decompression
            compressed_data = base64.b64decode(payload["data"])
            decompressed = gzip.decompress(compressed_data).decode("utf-8")
            assert decompressed == large_message
        else:
            # If None, message was too large even after compression
            assert len(large_message.encode("utf-8")) > MAX_NATS_PAYLOAD

    def test_compress_string_input(self):
        """Test compression accepts string input"""
        test_message = "Test string input"

        result = compress_and_check(test_message)

        assert isinstance(result, bytes)
        payload = json.loads(result.decode("utf-8"))

        # Verify roundtrip
        compressed_data = base64.b64decode(payload["data"])
        decompressed = gzip.decompress(compressed_data).decode("utf-8")
        assert decompressed == test_message

    def test_compress_empty_string(self):
        """Test compression of empty string"""
        empty_message = ""

        result = compress_and_check(empty_message)

        assert isinstance(result, bytes)
        payload = json.loads(result.decode("utf-8"))
        assert payload["compressed"] is True

        # Verify decompression
        compressed_data = base64.b64decode(payload["data"])
        decompressed = gzip.decompress(compressed_data).decode("utf-8")
        assert decompressed == empty_message

    def test_compress_max_size_limit(self):
        """Test compression with message that exceeds size limit"""
        # Create a message that when compressed and encoded will exceed MAX_NATS_PAYLOAD
        # Use random-like data that doesn't compress well
        import string
        import secrets

        # Generate large random string that won't compress well
        large_message = "".join(
            secrets.choice(string.ascii_letters + string.digits)
            for _ in range(MAX_NATS_PAYLOAD)
        )

        result = compress_and_check(large_message)

        # Should return None if too large
        if result is None:
            # Message was too large even after compression
            assert True  # Expected behavior
        else:
            # If not None, should be under the limit
            assert len(result) <= MAX_NATS_PAYLOAD

    def test_compress_highly_compressible_content(self):
        """Test compression with highly compressible content"""
        # Repeated content should compress very well
        repeated_message = "A" * 10000

        result = compress_and_check(repeated_message)

        assert isinstance(result, bytes)
        assert len(result) < len(repeated_message.encode("utf-8"))

        # Verify decompression
        payload = json.loads(result.decode("utf-8"))
        compressed_data = base64.b64decode(payload["data"])
        decompressed = gzip.decompress(compressed_data).decode("utf-8")
        assert decompressed == repeated_message

    def test_compress_poorly_compressible_content(self):
        """Test compression with poorly compressible content"""
        import secrets
        import string

        # Random content doesn't compress well
        random_message = "".join(
            secrets.choice(string.ascii_letters + string.digits) for _ in range(1000)
        )

        result = compress_and_check(random_message)

        assert isinstance(result, bytes)
        # Even if it doesn't compress well, should still work

        # Verify decompression
        payload = json.loads(result.decode("utf-8"))
        compressed_data = base64.b64decode(payload["data"])
        decompressed = gzip.decompress(compressed_data).decode("utf-8")
        assert decompressed == random_message

    def test_compress_unicode_content(self):
        """Test compression with Unicode content"""
        unicode_message = "Hello 世界! 🌍 Testing üñíçødé çhäräctërs"

        result = compress_and_check(unicode_message)

        assert isinstance(result, bytes)

        # Verify decompression preserves Unicode
        payload = json.loads(result.decode("utf-8"))
        compressed_data = base64.b64decode(payload["data"])
        decompressed = gzip.decompress(compressed_data).decode("utf-8")
        assert decompressed == unicode_message

    def test_compress_json_like_content(self):
        """Test compression with JSON-like content"""
        json_message = '{"key": "value", "number": 42, "array": [1, 2, 3], "nested": {"inner": "data"}}'

        result = compress_and_check(json_message)

        assert isinstance(result, bytes)

        # Verify decompression
        payload = json.loads(result.decode("utf-8"))
        compressed_data = base64.b64decode(payload["data"])
        decompressed = gzip.decompress(compressed_data).decode("utf-8")
        assert decompressed == json_message

    def test_compress_output_format(self):
        """Test that compression output has expected format"""
        test_message = "Test format validation"

        result = compress_and_check(test_message)

        assert isinstance(result, bytes)

        # Should be valid JSON
        payload = json.loads(result.decode("utf-8"))

        # Should have required fields
        assert "compressed" in payload
        assert "encoding" in payload
        assert "data" in payload

        # Should have expected values
        assert payload["compressed"] is True
        assert payload["encoding"] == "gzip+base64"
        assert isinstance(payload["data"], str)

        # Data should be valid base64
        try:
            base64.b64decode(payload["data"])
        except Exception:
            pytest.fail("Data is not valid base64")

    def test_compress_consistency(self):
        """Test that compression is consistent"""
        test_content = "Consistency test content"

        result1 = compress_and_check(test_content)
        result2 = compress_and_check(test_content)

        # Results should be identical (same compression)
        assert result1 == result2

        # Both should decompress to same content
        payload1 = json.loads(result1.decode("utf-8"))
        payload2 = json.loads(result2.decode("utf-8"))

        compressed_data1 = base64.b64decode(payload1["data"])
        compressed_data2 = base64.b64decode(payload2["data"])

        decompressed1 = gzip.decompress(compressed_data1).decode("utf-8")
        decompressed2 = gzip.decompress(compressed_data2).decode("utf-8")

        assert decompressed1 == test_content
        assert decompressed2 == test_content
        assert decompressed1 == decompressed2

    def test_compress_with_compression_metadata(self):
        """Test that compression includes proper metadata"""
        content = "Content with metadata consideration. " * 100

        result = compress_and_check(content)

        assert isinstance(result, bytes)

        # Verify metadata structure
        payload = json.loads(result.decode("utf-8"))

        assert payload["compressed"] is True
        assert payload["encoding"] == "gzip+base64"
        assert isinstance(payload["data"], str)

        # Verify the compressed data can be decoded
        compressed_data = base64.b64decode(payload["data"])
        decompressed = gzip.decompress(compressed_data).decode("utf-8")
        assert decompressed == content

    def test_compress_special_characters(self):
        """Test compression with special characters"""
        special_message = "Special chars: !@#$%^&*()_+-=[]{}|;':\",./<>?\\`~"

        result = compress_and_check(special_message)

        assert isinstance(result, bytes)

        # Verify decompression preserves special characters
        payload = json.loads(result.decode("utf-8"))
        compressed_data = base64.b64decode(payload["data"])
        decompressed = gzip.decompress(compressed_data).decode("utf-8")
        assert decompressed == special_message

    def test_compress_newlines_and_whitespace(self):
        """Test compression with newlines and whitespace"""
        whitespace_message = "Line 1\nLine 2\n\tTabbed line\n  Spaced line  \n\n"

        result = compress_and_check(whitespace_message)

        assert isinstance(result, bytes)

        # Verify decompression preserves whitespace
        payload = json.loads(result.decode("utf-8"))
        compressed_data = base64.b64decode(payload["data"])
        decompressed = gzip.decompress(compressed_data).decode("utf-8")
        assert decompressed == whitespace_message

    def test_compress_performance_large_input(self):
        """Test compression performance with large input"""
        import time

        large_content = "Performance test content. " * 10000  # ~260KB

        start_time = time.time()
        result = compress_and_check(large_content)
        end_time = time.time()

        # Should complete in reasonable time (less than 1 second)
        assert (end_time - start_time) < 1.0

        if result is not None:
            assert isinstance(result, bytes)
            # Verify it's still valid
            payload = json.loads(result.decode("utf-8"))
            assert payload["compressed"] is True

    def test_compress_size_calculation(self):
        """Test that size limits are properly calculated"""
        # Test with known small content
        small_content = "small"
        result = compress_and_check(small_content)

        assert isinstance(result, bytes)
        assert len(result) < MAX_NATS_PAYLOAD

        # Verify the result size includes the JSON overhead
        payload = json.loads(result.decode("utf-8"))
        assert "compressed" in payload
        assert "encoding" in payload
        assert "data" in payload
