# TLS Configuration Guide - Ticketing Data Processor

## 🔒 **One-Switch TLS Control**

The entire TLS system can be controlled with **one environment variable**:

```bash
# Disable ALL TLS (development, testing)
TLS_ENABLED=false

# Enable ALL TLS (production)
TLS_ENABLED=true
```

## 🚀 **Quick Setup**

### **Development/Testing (No TLS)**
```bash
# .env.development
TLS_ENABLED=false

# Result: Plain HTTP connections everywhere
# - Database: postgresql://user:pass@host/db (no SSL)
# - NATS: nats://host:4222 (no TLS)
# - No certificates needed
```

### **Production (Full TLS)**
```bash
# .env.production
TLS_ENABLED=true

# Additional settings for production:
DATABASE_SSL_MODE=require
NATS_TLS_ENABLED=true
DATABASE_SSL_CERT=/path/to/db-client.pem
NATS_TLS_CERT=/path/to/nats-client.pem
```

## 📋 **Configuration Matrix**

| Environment | TLS_ENABLED | Database | NATS | Certificates |
|-------------|-------------|----------|------|--------------|
| **Development** | `false` | Plain | Plain | ❌ Not needed |
| **Staging** | `true` | SSL | TLS | ✅ Required |
| **Production** | `true` | SSL | TLS | ✅ Required |

---

## 🔒 **Advanced TLS Configuration**

### **Database TLS Settings**

```bash
# SSL Mode (required for TLS)
DATABASE_SSL_MODE=require  # disable|allow|prefer|require|verify-ca|verify-full

# Client Certificate Authentication (optional)
DATABASE_SSL_CERT=/path/to/client-cert.pem
DATABASE_SSL_KEY=/path/to/client-key.pem

# Certificate Authority (optional)
DATABASE_SSL_CA=/path/to/ca-cert.pem
```

### **NATS TLS Settings**

```bash
# Enable TLS
NATS_TLS_ENABLED=true
NATS_URL=tls://nats.production.com:4222  # Use tls:// protocol

# Certificate Verification
NATS_TLS_VERIFY=true  # Set to false for self-signed certificates

# Client Certificate Authentication (optional)
NATS_TLS_CERT=/path/to/nats-client-cert.pem
NATS_TLS_KEY=/path/to/nats-client-key.pem

# Certificate Authority (optional)
NATS_TLS_CA=/path/to/nats-ca-cert.pem
```

## 🔧 **SSL Mode Reference**

| Mode | Description | Security Level |
|------|-------------|----------------|
| `disable` | No SSL/TLS | ❌ **Not Secure** |
| `allow` | SSL if available | ⚠️ **Opportunistic** |
| `prefer` | Prefer SSL, fallback to plain | ⚠️ **Recommended for Dev** |
| `require` | SSL required, no certificate verification | ✅ **Good** |
| `verify-ca` | SSL required, verify CA certificate | ✅ **Better** |
| `verify-full` | SSL required, verify CA and hostname | ✅ **Best** |

## 📝 **Example Configurations**

### **High Security Production**

```bash
# Maximum security configuration
DATABASE_SSL_MODE=verify-full
DATABASE_SSL_CERT=/etc/ssl/certs/app-client.pem
DATABASE_SSL_KEY=/etc/ssl/private/app-client.key
DATABASE_SSL_CA=/etc/ssl/certs/ca-bundle.pem

NATS_TLS_ENABLED=true
NATS_TLS_VERIFY=true
NATS_TLS_CERT=/etc/ssl/certs/nats-client.pem
NATS_TLS_KEY=/etc/ssl/private/nats-client.key
NATS_TLS_CA=/etc/ssl/certs/nats-ca.pem
```

### **Cloud Provider Integration**

```bash
# AWS RDS with SSL
DATABASE_URL=postgresql://user:pass@rds.amazonaws.com:5432/db?sslmode=require
DATABASE_SSL_CA=/opt/app/rds-ca-2019-root.pem

# NATS Cloud with TLS
NATS_URL=tls://connect.ngs.global:4222
NATS_TLS_ENABLED=true
NATS_TLS_VERIFY=true
```

## 🔍 **Troubleshooting**

### **Common Issues**

1. **Certificate Permission Errors**
   ```bash
   chmod 600 /path/to/private-key.pem
   chown app:app /path/to/certificates/*
   ```

2. **Self-Signed Certificate Errors**
   ```bash
   NATS_TLS_VERIFY=false  # Disable verification for self-signed
   DATABASE_SSL_MODE=require  # Use require instead of verify-full
   ```

3. **Connection Timeouts**
   ```bash
   # Check firewall rules for TLS ports
   # Verify certificate expiration dates
   openssl x509 -in cert.pem -dates -noout
   ```

### **If TLS fails to connect:**
```bash
# Temporarily disable for testing
TLS_ENABLED=false

# Logs will clearly show why:
# "Database SSL disabled - TLS_ENABLED=false (development mode)"
```

### **Testing TLS Connections**

```bash
# Test database TLS
openssl s_client -connect database-host:5432 -starttls postgres

# Test NATS TLS
openssl s_client -connect nats-host:4222

# Verify application startup
docker-compose logs app | grep -i tls
```

## 📊 **Monitoring TLS**

The application logs TLS status on startup:

```log
INFO - Database SSL enabled with mode: require
INFO - NATS TLS enabled with certificate verification
INFO - Database connection pool established with TLS enforcement
INFO - NATS connection established with JetStream with TLS
```

## ⚠️ **Security Best Practices**

1. **Certificate Management**
   - Use proper certificate authorities in production
   - Rotate certificates regularly (every 12-24 months)
   - Monitor certificate expiration dates
   - Use strong private key encryption

2. **Network Security**
   - Use `verify-full` SSL mode in production
   - Enable certificate verification for NATS
   - Restrict network access to database and NATS ports
   - Use VPNs or private networks when possible

3. **Credential Management**
   - Never commit certificates to version control
   - Use proper file permissions (600 for private keys)
   - Store certificates in secure, backed-up locations
   - Use environment-specific certificate management

## 🎯 **Migration Path**

### **Phase 1: Development (Current)**
```bash
TLS_ENABLED=false
# Work with existing database and NATS without certificates
# Perfect for testing and development
```

### **Phase 2: Production Preparation**
```bash
TLS_ENABLED=true
# Get certificates from your infrastructure team
# Configure certificate paths
# Test in staging environment
```

### **Phase 3: Production Deployment**
```bash
TLS_ENABLED=true
DATABASE_SSL_MODE=verify-full  # Maximum security
NATS_TLS_VERIFY=true           # Certificate verification
# Deploy with full security
```

## 🎯 **Compliance**

This TLS implementation supports:
- **SOC 2 Type II**: Encryption in transit requirements
- **PCI DSS**: Secure transmission of cardholder data
- **HIPAA**: Protected health information encryption
- **GDPR**: Data protection in transit requirements
- **ISO 27001**: Information security management standards

## 💡 **Best Practices Summary**

1. **Development**: Keep `TLS_ENABLED=false` for simplicity
2. **Staging**: Use `TLS_ENABLED=true` to test certificate setup
3. **Production**: Always use `TLS_ENABLED=true` with proper certificates
4. **Documentation**: Always document which environment uses which setting

Perfect for your workflow: test without TLS, deploy with TLS! 🚀