import logging

from data_access.memgraphClient import MemgraphClient
from configs.config import Config
from data_access.messaging.ticket_consumer import TicketConsumer
from services.message_handler import TicketMessageHandler

# Create an instance of Config (Singleton ensures it's the same everywhere)
config = Config()


class DataLoader:
    def __init__(self, memgraphClient: MemgraphClient, nats_url: str, stream_name: str, subject: str):
        self.memgraphClient = memgraphClient
        self.config = Config()
        self.handler = TicketMessageHandler(memgraph_client=self.memgraphClient, config=self.config)
        self.ticket_consumer = TicketConsumer(
            nats_url,
            stream_name,
            subject,
            max_concurrent=self.config.memgraph_max_concurrent,
            nats_user=self.config.nats_user,
            nats_password=self.config.nats_password
        )
        self.ticket_callback = self.handle_ticket_message
        self.logger = logging.getLogger(__name__)

    async def load_tickets(self, clean: bool):
        """Subscribe to NATS and ingest ticket messages into Memgraph."""
        status = True

        try:
            await self.ticket_consumer.connect()
            logging.info("✅ Ticket ingestion is active and listening for events.")

            # ✅ Subscribe using the handler's method
            logging.info(f"🚀 Debug: ticket_callback reference = {self.ticket_callback}")
            await self.ticket_consumer.subscribe(self.handle_ticket_message)

        except Exception as e:
            logging.error(f"❌ Error in ticket ingestion: {e}", exc_info=True)
            status = False

        return status

    async def handle_ticket_message(self, msg):
        """
        Delegates message handling to the external TicketMessageHandler

        Philosophy: Log anomalies and move on. ACK bad messages to avoid infinite loops.
        Better to finish with 99% success than get stuck on 1% bad data.
        """
        try:
            await self.handler.handle_ticket_message(msg)
        except Exception as e:
            self.logger.error(f"❌ Ticket processing failed: {e}", exc_info=True)
            # Log and move on - ACK to avoid infinite retry loops
            try:
                await msg.ack()
                self.logger.warning("⚠️  ACK'd failed ticket message to continue processing")
            except Exception as ack_error:
                self.logger.error(f"❌ Failed to ACK message: {ack_error}")
