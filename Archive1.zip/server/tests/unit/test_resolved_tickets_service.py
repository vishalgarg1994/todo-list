"""
Tests for ResolvedTicketsService (WS-C Step 1)
"""
import pytest
from unittest.mock import AsyncMock, MagicMock
from services.resolved_tickets_service import ResolvedTicketsService, ResolvedTicket


class TestResolvedTicketsService:
    """Test suite for ResolvedTicketsService"""

    @pytest.fixture
    def mock_memgraph_client(self):
        """Create a mock Memgraph client"""
        client = MagicMock()
        client.execute = AsyncMock()
        return client

    @pytest.fixture
    def service(self, mock_memgraph_client):
        """Create service with mock client"""
        return ResolvedTicketsService(mock_memgraph_client)

    @pytest.mark.asyncio
    async def test_get_resolved_tickets_returns_list(self, service, mock_memgraph_client):
        """Test that get_resolved_tickets returns a list of ResolvedTicket objects"""
        # Mock response from Memgraph
        mock_memgraph_client.execute.return_value = [
            {
                "ticket_sys_id": "abc123",
                "ticket_id": "INC0012345",
                "ticket_type": "incident",
                "client_name": "Acme Corp",
                "client_id": "Client_123"
            },
            {
                "ticket_sys_id": "def456",
                "ticket_id": "CS0067890",
                "ticket_type": "case",
                "client_name": "Beta Inc",
                "client_id": "Client_456"
            }
        ]

        tickets = await service.get_resolved_tickets()

        assert len(tickets) == 2
        assert isinstance(tickets[0], ResolvedTicket)
        assert tickets[0].ticket_sys_id == "abc123"
        assert tickets[0].ticket_id == "INC0012345"
        assert tickets[0].ticket_type == "incident"
        assert tickets[0].client_name == "Acme Corp"

    @pytest.mark.asyncio
    async def test_get_resolved_tickets_empty_result(self, service, mock_memgraph_client):
        """Test handling of empty result set"""
        mock_memgraph_client.execute.return_value = []

        tickets = await service.get_resolved_tickets()

        assert tickets == []

    @pytest.mark.asyncio
    async def test_get_resolved_tickets_handles_error(self, service, mock_memgraph_client):
        """Test error handling when query fails"""
        mock_memgraph_client.execute.side_effect = Exception("Connection failed")

        tickets = await service.get_resolved_tickets()

        assert tickets == []

    @pytest.mark.asyncio
    async def test_get_resolved_tickets_by_type(self, service, mock_memgraph_client):
        """Test filtering by ticket type"""
        mock_memgraph_client.execute.return_value = [
            {
                "ticket_sys_id": "case123",
                "ticket_id": "CS0012345",
                "ticket_type": "case",
                "client_name": "Test Client",
                "client_id": "Client_789"
            }
        ]

        tickets = await service.get_resolved_tickets_by_type("case")

        assert len(tickets) == 1
        assert tickets[0].ticket_type == "case"

        # Verify the query was called with correct parameter
        call_args = mock_memgraph_client.execute.call_args
        assert call_args[0][1]["ticket_type"] == "case"

    @pytest.mark.asyncio
    async def test_has_notes_processed_true(self, service, mock_memgraph_client):
        """Test checking if notes already processed - true case"""
        mock_memgraph_client.execute.return_value = [{"has_notes": True}]

        result = await service.has_notes_processed("abc123")

        assert result is True

    @pytest.mark.asyncio
    async def test_has_notes_processed_false(self, service, mock_memgraph_client):
        """Test checking if notes already processed - false case"""
        mock_memgraph_client.execute.return_value = [{"has_notes": False}]

        result = await service.has_notes_processed("abc123")

        assert result is False

    @pytest.mark.asyncio
    async def test_get_ticket_count_by_status(self, service, mock_memgraph_client):
        """Test getting ticket counts by status"""
        mock_memgraph_client.execute.return_value = [
            {"status": "resolved", "count": 300},
            {"status": "open", "count": 150},
            {"status": "closed", "count": 2000}
        ]

        counts = await service.get_ticket_count_by_status()

        assert counts["resolved"] == 300
        assert counts["open"] == 150
        assert counts["closed"] == 2000

    @pytest.mark.asyncio
    async def test_get_notes_processing_stats(self, service, mock_memgraph_client):
        """Test getting notes processing statistics"""
        mock_memgraph_client.execute.return_value = [
            {"resolved_total": 300, "resolved_with_notes": 50}
        ]

        stats = await service.get_notes_processing_stats()

        assert stats["resolved_total"] == 300
        assert stats["resolved_with_notes"] == 50
        assert stats["resolved_pending"] == 250


class TestResolvedTicketDataclass:
    """Test the ResolvedTicket dataclass"""

    def test_resolved_ticket_creation(self):
        """Test creating a ResolvedTicket object"""
        ticket = ResolvedTicket(
            ticket_sys_id="abc123",
            ticket_id="INC0012345",
            ticket_type="incident",
            client_name="Test Corp"
        )

        assert ticket.ticket_sys_id == "abc123"
        assert ticket.ticket_id == "INC0012345"
        assert ticket.ticket_type == "incident"
        assert ticket.client_name == "Test Corp"
        assert ticket.client_id is None  # Optional, default None

    def test_resolved_ticket_with_client_id(self):
        """Test creating a ResolvedTicket with client_id"""
        ticket = ResolvedTicket(
            ticket_sys_id="def456",
            ticket_id="CS0067890",
            ticket_type="case",
            client_name="Beta Inc",
            client_id="Client_456"
        )

        assert ticket.client_id == "Client_456"
