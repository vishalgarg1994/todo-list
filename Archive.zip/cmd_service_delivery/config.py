"""
Configuration for CMD Service Delivery MCP Server.
All values are sourced from environment variables with sensible defaults.
"""

import os


class Config:
    # CMD Source (mock or real)
    cmd_graphql_url: str = os.getenv("CMD_GRAPHQL_URL", "http://localhost:8000/graphql/")
    cmd_rest_url: str = os.getenv("CMD_REST_URL", "http://localhost:8000/api/v2/")
    cmd_token: str = os.getenv("CMD_TOKEN", "mock-token")

    # Memgraph
    memgraph_uri: str = os.getenv("MEMGRAPH_URI", "bolt://localhost:7687")
    memgraph_user: str = os.getenv("MEMGRAPH_USER", "")
    memgraph_password: str = os.getenv("MEMGRAPH_PASSWORD", "")
    memgraph_database: str = os.getenv("MEMGRAPH_DATABASE", "memgraph")

    # Milvus
    milvus_host: str = os.getenv("MILVUS_HOST", "localhost")
    milvus_port: int = int(os.getenv("MILVUS_PORT", "19530"))
    milvus_user: str = os.getenv("MILVUS_USER", "")
    milvus_password: str = os.getenv("MILVUS_PASSWORD", "")
    milvus_collection_name: str = os.getenv("MILVUS_COLLECTION_NAME", "cmd_notes")
    milvus_index_type: str = os.getenv("MILVUS_INDEX_TYPE", "IVF_FLAT")
    milvus_metric_type: str = os.getenv("MILVUS_METRIC_TYPE", "COSINE")
    milvus_nlist: int = int(os.getenv("MILVUS_NLIST", "128"))
    milvus_nprobe: int = int(os.getenv("MILVUS_NPROBE", "16"))

    # OpenAI
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_embedding_model: str = os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")
    openai_chat_model: str = os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini")
    embedding_dim: int = int(os.getenv("EMBEDDING_DIM", "1536"))

    # ETL polling
    poll_interval_seconds: int = int(os.getenv("POLL_INTERVAL_SECONDS", "60"))
    initial_watermark: str = os.getenv("INITIAL_WATERMARK", "2020-01-01T00:00:00")
    poll_batch_limit: int = int(os.getenv("POLL_BATCH_LIMIT", "500"))
    auto_poll: bool = os.getenv("AUTO_POLL", "false").lower() in ("true", "1", "yes")

    # Server
    server_host: str = os.getenv("SERVER_HOST", "0.0.0.0")
    server_port: int = int(os.getenv("SERVER_PORT", "8003"))

    # Schema
    schema_path: str = os.getenv("SCHEMA_PATH", os.path.join(
        os.path.dirname(__file__), "schema", "cmd_schema.yaml"
    ))
