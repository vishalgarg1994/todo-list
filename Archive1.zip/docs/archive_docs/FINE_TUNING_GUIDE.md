# Fine-Tuning Guide: Telecom Embedding Model

**Last Updated:** November 6, 2025
**Model:** nomic-embed-text-v1.5 → telecom-nomic-embed-v1
**Approach:** Privacy-safe (NO client names)

---

## Overview

Fine-tune the nomic-embed-text embedding model for telecom domain using **telecom patterns only** (no sensitive client data).

### Why Fine-Tune?

Improve semantic search for telecom-specific terminology:
- Acronyms: MPLS ↔ Multiprotocol Label Switching
- Fault patterns: "circuit down" ↔ "link failure"
- Equipment: "Cisco router" ↔ "router from Cisco"

### Privacy-First Approach

**NO client names in training data** - Client filtering happens at application level:
```
User Query: "Blue Wireless MPLS down"
  ↓
1. Extract client: "Blue Wireless" (regex/NER)
2. Search Milvus: "MPLS down" (generic query)
3. Filter in Memgraph: WHERE client_name = "Blue Wireless"
  ↓
Results: Blue Wireless MPLS tickets
```

---

## Quick Start (5 Steps)

### Prerequisites

**Hardware:**
- GPU with 8GB+ VRAM (RTX 3070 or better)
- 16GB RAM

**Software:**
```bash
pip install sentence-transformers torch pandas numpy
```

### Step 1: Anonymize Fault Descriptions (Required)

**⚠️ REQUIRED FOR SECURITY** - Anonymization removes PII before training.

Anonymize your fault descriptions:

```bash
cd fine_tuning/

# Test anonymization
python3 anonymize_fault_descriptions.py --test

# Anonymize your data
python3 anonymize_fault_descriptions.py \
  --input data/fault_descriptions.txt \
  --output data/fault_descriptions_anonymized.txt
```

**What gets anonymized:**
- Client names → CLIENT_NAME
- IP addresses → IP_ADDRESS
- Emails → EMAIL_ADDRESS
- Phone numbers → PHONE_NUMBER
- URLs, MAC addresses, hostnames, ticket IDs

**What's preserved:**
- Technical terms (MPLS, BGP, router, etc.)
- Fault patterns (down, failure, timeout, etc.)

### Step 2: Generate Training Pairs

```bash
python3 prepare_training_data.py
```

**Output:**
- `training_pairs/training_pairs.jsonl` (~1200-1500 pairs)
- `training_pairs/training_stats.json`

**Training data includes:**
- Technology + Equipment combinations (MPLS on router)
- Vendor + Equipment (Cisco router ↔ router from Cisco)
- Acronyms (MPLS ↔ Multiprotocol Label Switching)
- Fault patterns (circuit down ↔ link failure)
- Negative pairs (MPLS service vs cooking recipes)

**NO client names included - privacy-safe!**

### Step 3: Train Model

```bash
python3 train_model.py
```

**Training time:** 30-60 minutes on GPU

**Output:** `models/telecom-nomic-embed-v1/` (~500MB)

### Step 4: Evaluate Model

```bash
python3 evaluate_model.py
```

**Tests:** Acronym understanding, technology matching, fault description similarity

**Target:** ≥80% accuracy on telecom-specific test cases

### Step 5: Deploy to Ollama

#### Option A: Automated Deployment (Recommended)

Use the end-to-end pipeline script that handles everything:

```bash
cd fine_tuning/
./run_fine_tuning.sh
```

The pipeline will:
1. Anonymize fault descriptions (required)
2. Generate training pairs
3. Train model on GPU
4. Evaluate model
5. Convert to GGUF format (for Ollama)
6. Deploy to Ollama as `telecom-nomic-embed:latest`
7. Test the deployed model

#### Option B: Manual Deployment

If you need to deploy manually or troubleshoot:

**Step 5a: Convert Model to GGUF Format**

```bash
cd fine_tuning/

# Clone llama.cpp if not already present
git clone https://github.com/ggerganov/llama.cpp.git
cd llama.cpp
pip install -r requirements.txt
cd ..

# Convert the trained model to GGUF format
python llama.cpp/convert_hf_to_gguf.py \
  models/telecom-nomic-embed \
  --outfile models/telecom-nomic-embed.gguf \
  --outtype q8_0
```

This creates a GGUF file (~146MB) optimized for Ollama.

**Step 5b: Import to Ollama**

```bash
# Create Modelfile
cat > Modelfile << EOF
FROM ./models/telecom-nomic-embed.gguf
EOF

# Import to Ollama
ollama create telecom-nomic-embed -f ./Modelfile

# Verify it's loaded
ollama list
```

Expected output:
```
NAME                          ID              SIZE      MODIFIED
telecom-nomic-embed:latest    18a0c64784ae    146 MB    4 minutes ago
nomic-embed-text:v15          f2eecf71b577    94 MB     10 days ago
```

**Step 5c: Test the Deployed Model**

```bash
curl http://localhost:11434/api/embeddings -d '{
  "model": "telecom-nomic-embed:latest",
  "prompt": "MPLS circuit down"
}'
```

You should see a JSON response with an `embedding` array of 768 floats.

#### Update Configuration Files

Update these **8 files** to use the fine-tuned model:

1. **`server/app/configs/config.py:105`**
```python
self.ollama_embedding_model = os.environ.get("OLLAMA_EMBEDDING_MODEL", "telecom-nomic-embed:latest")
```

2-5. **Environment files** - Change `OLLAMA_EMBEDDING_MODEL` value:
   - `server/.env.example:27`
   - `server/.env.development:32`
   - `server/.env.staging:32`
   - `server/.env.production:33`

```bash
OLLAMA_EMBEDDING_MODEL=telecom-nomic-embed:latest
```

6-7. **`server/docker-compose.yml`**
   - Line 77: Update environment variable
   - Line 172: Update pull command

```yaml
# Line 77
- OLLAMA_EMBEDDING_MODEL=telecom-nomic-embed:latest

# Line 172
/bin/ollama pull telecom-nomic-embed:latest
```

8. **`server/docker-compose.override.yml:14`**
```yaml
- OLLAMA_EMBEDDING_MODEL=telecom-nomic-embed:latest
```

**Restart MCP server:**
```bash
cd server/
docker-compose restart mcp_ticket_server
```

---

## Data Preparation Details

### Vocabulary Files

Located in `fine_tuning/data/`:

| File | Purpose | Example Entries | Privacy |
|------|---------|-----------------|---------|
| `acronyms.txt` | Telecom acronyms | MPLS - Multiprotocol Label Switching | ✅ Safe |
| `vendors.txt` | Equipment vendors | Cisco, Juniper, Arista | ✅ Safe |
| `equipment.txt` | Equipment types | router, switch, firewall | ✅ Safe |
| `technologies.txt` | Network tech | SDWAN, MPLS, BGP, Ethernet | ✅ Safe |
| `fault_descriptions_anonymized.txt` | Anonymized faults | MPLS circuit down at IP_ADDRESS | ✅ Safe |

**NOT USED:** `clients.txt` - Client names excluded for privacy

### Training Pair Generation

**Positive Pairs** (should match, label=1):
```json
{"text1": "MPLS circuit down", "text2": "MPLS circuit failure", "label": 1}
{"text1": "link down", "text2": "link failure", "label": 1}
{"text1": "BGP", "text2": "Border Gateway Protocol", "label": 1}
{"text1": "Cisco router", "text2": "router from Cisco", "label": 1}
```

**Negative Pairs** (should NOT match, label=0):
```json
{"text1": "MPLS service", "text2": "cooking recipes", "label": 0}
{"text1": "BGP outage", "text2": "OSPF service", "label": 0}
{"text1": "Cisco router", "text2": "Juniper switch", "label": 0}
```

**Expected:** ~1200-1500 total pairs

---

## Training Parameters

```python
Base Model: nomic-ai/nomic-embed-text-v1.5
Method: Contrastive learning
Epochs: 10
Batch Size: 16
Learning Rate: 2e-5
Loss Function: ContrastiveLoss
Training Time: 30-60 minutes (GPU)
Model Size: ~500MB
```

---

## Deployment Strategy

### Full Reindexing (Recommended)

When deploying fine-tuned model, reindex ALL embeddings:

```bash
# 1. Drop old Milvus collection
python scripts/drop_milvus_collection.py

# 2. Deploy fine-tuned model (update milvusClient.py)

# 3. Restart MCP server
docker-compose restart mcp_ticket_server

# 4. Reprocess all tickets through fault_description_consumer
# (Happens automatically as NATS messages flow)
```

**Why:** Old embeddings (base model) and new embeddings (fine-tuned) aren't comparable

### Client Filtering (Application Level)

Since NO client names in training, filter by client in Memgraph:

```python
# In semantic_search_service.py
async def search_similar_tickets(query: str, client_name: str = None, ...):
    # 1. Extract generic fault pattern (no client name)
    query_clean = remove_client_names(query)  # "Blue Wireless MPLS down" → "MPLS down"

    # 2. Generate embedding (fine-tuned model)
    embedding = self.embedding_service.generate_embedding(query_clean)

    # 3. Search Milvus (vector similarity)
    fault_ids = await self.milvus_client.search(embedding, top_k=50)

    # 4. Join with Memgraph (client filter)
    if client_name:
        query = """
        MATCH (fd:FaultDescription)-[:DESCRIBES]->(ticket:Ticket)
              -[:BELONGS_TO]->(client:Client {client_name: $client_name})
        WHERE fd.fault_description_id IN $fault_ids
        RETURN ticket
        """
        results = memgraph.execute(query, {"client_name": client_name, "fault_ids": fault_ids})

    return results
```

**Benefits:**
- ✅ No client data in model (privacy-safe)
- ✅ Filtering in Memgraph (exact match, fast)
- ✅ Model learns telecom patterns only

---

## Retraining Strategy

### When to Retrain

**Don't need monthly retraining** since NO client names in model!

Retrain only when:
- New telecom technologies emerge (e.g., Wi-Fi 7, 5G SA)
- New equipment vendors added
- New acronyms standardized
- Fault description patterns change

**Frequency:** Annually or as-needed (not monthly)

### How to Retrain

```bash
# 1. Update vocabulary files
nano data/technologies.txt  # Add new tech
nano data/vendors.txt       # Add new vendors

# 2. Regenerate training pairs
python3 prepare_training_data.py

# 3. Train new version
python3 train_model.py  # Output: models/telecom-nomic-embed-v2/

# 4. Evaluate
python3 evaluate_model.py

# 5. Deploy if better (or keep v1)
```

### Version Management

Keep last 2-3 versions for rollback:

```
models/
├── telecom-nomic-embed-v1/  # October 2025
├── telecom-nomic-embed-v2/  # October 2026
└── telecom-nomic-embed-v3/  # October 2027
```

---

## Troubleshooting

### GPU Out of Memory

**Error:** `RuntimeError: CUDA out of memory`

**Solution:**
```python
# Edit train_model.py, reduce batch size:
batch_size = 8  # Instead of 16
```

### Model Not Improving

**Check:**
1. Training loss decreased? (should be <0.1 after 10 epochs)
2. Training pairs look correct? (`head training_pairs/training_pairs.jsonl`)
3. Vocabulary files loaded? (check console output)

**Fix:**
- Increase epochs: 10 → 20
- Check fault descriptions are telecom-related (not generic text)

### Slow Inference

**Use GPU for embeddings:**
```python
self.encoder = SentenceTransformer(
    "/app/models/telecom-nomic-embed-v1",
    device='cuda'  # Force GPU
)
```

---

## Validation Checklist

### Pre-Deployment

- [ ] Training completed successfully (10 epochs)
- [ ] Final loss < 0.1
- [ ] Evaluation score ≥75% on test cases
- [ ] Model file size ~400-500MB
- [ ] No client names in training data (privacy verified)
- [ ] Backup of base model exists

### Post-Deployment

- [ ] MCP server restarts successfully
- [ ] Health check passes: `curl http://localhost:8003/health`
- [ ] Semantic search returns results
- [ ] Acronym queries work (MPLS matches Multiprotocol Label Switching)
- [ ] Client filtering works in Memgraph
- [ ] No errors in logs

---

## Privacy & Security

### What's Safe

✅ **No sensitive data in model:**
- No client names
- No IP addresses
- No emails, phone numbers
- No URLs or hostnames

✅ **Anonymized fault descriptions:**
- Client names → CLIENT_NAME
- IPs → IP_ADDRESS
- All PII removed

### What to Protect

🔒 **Training scripts** (contains business logic)
🔒 **Vocabulary files** (telecom domain knowledge)
🔒 **Fine-tuned model** (competitive advantage)

### Security Practices

```bash
# 1. Delete training data after training
rm -rf training_pairs/  # After training complete

# 2. Encrypt model at rest
gpg --encrypt models/telecom-nomic-embed-v1.tar.gz

# 3. Restrict file access
chmod 600 models/telecom-nomic-embed-v1/*

# 4. Add authentication to MCP server
# (See deployment docs)
```

---

## Performance Expectations

### Accuracy

| Test Case | Base Model | Fine-Tuned | Improvement |
|-----------|------------|------------|-------------|
| Acronym matching | 42% | 85% | +43% |
| Technology terms | 65% | 90% | +25% |
| Fault patterns | 58% | 83% | +25% |
| Vendor equipment | 55% | 88% | +33% |
| **Overall** | **53%** | **~80%** | **+27%** |

### Speed

- Embedding generation: ~50ms per query (GPU)
- Search latency: <2 seconds (including Memgraph join)
- Throughput: 10-20 queries/second

---

## File Structure

```
fine_tuning/
├── data/                              # Vocabulary (NO client names)
│   ├── acronyms.txt                  # 204 telecom acronyms
│   ├── vendors.txt                   # 46 vendors
│   ├── equipment.txt                 # 46 equipment types
│   ├── technologies.txt              # 40 technologies
│   └── fault_descriptions_anonymized.txt  # Anonymized faults
├── training_pairs/                    # Generated (output)
│   ├── training_pairs.jsonl
│   └── training_stats.json
├── models/                            # Fine-tuned models (output)
│   └── telecom-nomic-embed-v1/
├── anonymize_fault_descriptions.py   # Step 1: Anonymize data
├── prepare_training_data.py          # Step 2: Generate pairs
├── train_model.py                    # Step 3: Train model
└── evaluate_model.py                 # Step 4: Evaluate
```

---

## FAQ

**Q: Why not use client names?**
A: Privacy risk + client filtering better handled in Memgraph.

**Q: How often to retrain?**
A: Annually or when new telecom technologies emerge (not monthly).

**Q: What if accuracy is low?**
A: Check fault descriptions are telecom-related, increase epochs, verify vocabulary loaded correctly.

**Q: Can I add client names later?**
A: Yes, but consider privacy risks. Current approach is privacy-safe and effective.

**Q: How to rollback?**
A: Keep old model version, update model path, restart server.

---

## Support

**Documentation:**
- Semantic Search Architecture: `/docs/SEMANTIC_SEARCH_ARCHITECTURE.md`
- MCP Ticket README: `/README.md`

**External:**
- Sentence Transformers: https://www.sbert.net/
- nomic-embed-text: https://huggingface.co/nomic-ai/nomic-embed-text-v1.5

---

**Document Version:** 2.0 (Privacy-Safe Edition)
**Last Reviewed:** November 4, 2025
