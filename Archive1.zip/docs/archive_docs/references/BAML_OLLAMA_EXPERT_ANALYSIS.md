# BAML + Ollama Configuration - Expert Analysis

**Created:** October 9, 2025
**Based on:** Official BAML Documentation (boundaryml.com)

---

## Executive Summary: What We Were Doing Wrong

### ❌ Critical Mistake #1: Non-Existent Provider
**What we tried:** `provider ollama`
**Reality:** There is NO native "ollama" provider in BAML!
**Correct:** `provider "openai-generic"`

The Ollama documentation page is slightly misleading in its title - it actually documents how to use Ollama WITH the `openai-generic` provider.

### ❌ Critical Mistake #2: Missing `/v1` Endpoint
**What we had:** `base_url "http://10.250.99.61:11434"`
**Correct:** `base_url "http://10.250.99.61:11434/v1"`

The BAML docs explicitly state: "Note the `/v1` at the end of the URL" - Ollama's OpenAI-compatible endpoint requires this path.

---

## 1. BAML Provider Architecture

### How BAML Works with Different LLM Providers

BAML uses **provider adapters** that translate BAML's internal format to provider-specific APIs:

```
BAML Function → Provider Adapter → LLM API
```

**Available Provider Types:**
1. **Native Providers:** `openai`, `anthropic`, `google-ai`, `azure-openai`, `aws-bedrock`
2. **Generic Provider:** `openai-generic` (for OpenAI-compatible APIs)
3. **Strategy Providers:** `fallback`, `round-robin` (for multi-provider logic)

**Ollama Support:**
- Ollama does NOT have a native provider
- Ollama implements OpenAI's API format (OpenAI compatibility layer)
- Therefore: Use `openai-generic` provider with Ollama's endpoint

---

## 2. OpenAI-Generic Provider Deep Dive

### Purpose
Supports any API that implements OpenAI's request/response format, including:
- Groq
- HuggingFace Inference API
- **Ollama** ← Our use case
- OpenRouter
- Together AI
- Azure AI Foundry
- Cerebras
- LM Studio
- Llama API

### Configuration Syntax

```baml
client<llm> MyClient {
  provider "openai-generic"
  options {
    // Required
    base_url "https://api.provider.com/v1"  // Full endpoint with /v1
    model "model-name"

    // Optional - Authentication
    api_key env.API_KEY  // Becomes: Authorization: Bearer $api_key

    // Optional - Custom Headers
    headers {
      "X-Custom-Header" "value"
      "X-Another-Header" env.ANOTHER_VALUE
    }

    // Optional - Role Configuration
    default_role "user"
    allowed_roles ["system", "user", "assistant"]

    // Optional - Streaming
    supports_streaming true  // Default: true
  }
}
```

### Configuration Options Explained

#### `base_url` (Required)
- Full URL to the provider's OpenAI-compatible endpoint
- **Must include the full path** (e.g., `/v1` for Ollama)
- BAML does NOT automatically append paths
- Default: `https://api.openai.com/v1`

**Examples:**
```baml
// Ollama
base_url "http://10.250.99.61:11434/v1"

// Groq
base_url "https://api.groq.com/openai/v1"

// Together AI
base_url "https://api.together.xyz/v1"
```

#### `model` (Required)
- Provider-specific model identifier
- Format varies by provider
- Can include version tags (e.g., `"mixtral:8x22b"`)

**Ollama Model Examples:**
```baml
model "llama3"           // Latest llama3
model "gemma"            // Latest gemma
model "mixtral:8x22b"    // Specific mixtral version
```

#### `api_key` (Optional)
- Used for authentication
- Automatically builds header: `Authorization: Bearer $api_key`
- If empty or not set, Authorization header is NOT sent
- **For Ollama:** Usually not needed (Ollama doesn't require auth by default)

```baml
// With API key
api_key env.OPENAI_API_KEY

// Without API key (Ollama)
// Just omit the api_key line entirely
```

#### `headers` (Optional)
- Add custom HTTP headers to every request
- Useful for:
  - Custom authentication schemes
  - Provider-specific metadata
  - Organization IDs
  - Request tagging

```baml
headers {
  "X-Organization-ID" env.ORG_ID
  "X-Request-Source" "mcp-ticket-system"
}
```

#### `default_role` (Optional)
- Role to use when message role is not specified
- Default: `"user"`
- Usually don't need to change this

#### `allowed_roles` (Optional)
- List of permitted message roles
- Default: `["system", "user", "assistant"]`
- Some providers support additional roles like `"function"` or `"tool"`

#### `supports_streaming` (Optional)
- Enable/disable streaming responses
- Default: `true`
- If `false`, BAML still returns responses in stream format (single event)

---

## 3. Ollama-Specific Configuration

### Official Ollama Configuration for BAML

```baml
client<llm> OllamaClient {
  provider "openai-generic"
  options {
    base_url "http://localhost:11434/v1"  // ← Must include /v1
    model "llama3"
  }
}
```

### Supported Ollama Models (as of BAML docs)
- `llama4`
- `llama3.3`
- `llama3`
- `qwen2`
- `phi3`
- `aya`
- `mistral`
- `gemma`
- `mixtral`

**Using Specific Versions:**
```baml
model "mixtral:8x22b"  // Specific version tag
model "llama3:70b"     // Specific parameter size
```

Check Ollama's Model Library for full list: https://ollama.com/library

### Ollama Endpoint Details

**OpenAI-Compatible Endpoint:** `/v1`
- Ollama serves an OpenAI-compatible API at `/v1`
- This endpoint mimics OpenAI's API structure
- **Critical:** You MUST include `/v1` in the base_url

**Why `/v1` is Required:**
1. Ollama has multiple API endpoints:
   - `/api/generate` - Native Ollama API
   - `/api/chat` - Native Ollama chat API
   - `/v1/chat/completions` - OpenAI-compatible API
2. BAML's `openai-generic` provider expects OpenAI's URL structure
3. It will append `/chat/completions` to your `base_url`
4. Result: `base_url` + `/chat/completions` = `http://localhost:11434/v1/chat/completions` ✅

**Without `/v1`:**
```
base_url: http://localhost:11434
Provider appends: /chat/completions
Final URL: http://localhost:11434/chat/completions  ← 404! Wrong endpoint
```

**With `/v1`:**
```
base_url: http://localhost:11434/v1
Provider appends: /chat/completions
Final URL: http://localhost:11434/v1/chat/completions  ← ✅ Correct!
```

### CORS Configuration for Ollama
If using Ollama from a browser environment (e.g., promptfiddle.com):
```bash
OLLAMA_ORIGINS='*' ollama serve
```

This allows Ollama to accept requests from any origin.

### Authentication
Ollama doesn't require authentication by default. **Do NOT include `api_key` in your configuration** unless you've configured Ollama with authentication middleware.

---

## 4. Environment Variables in BAML

### How BAML Loads Environment Variables

**Critical Understanding:** BAML captures environment variables **at runtime initialization time**, not when functions are called.

**Loading Process:**
1. Your program starts
2. Environment variables are loaded into `process.env` / `os.environ`
3. BAML runtime initializes and captures `env` snapshot
4. BAML client instances created with those env values
5. Client instances persist with those values

**Implication:** If you change environment variables after BAML runtime initialization, clients won't see the new values unless you recreate the runtime.

### Referencing Environment Variables in BAML

```baml
client<llm> MyClient {
  provider "openai-generic"
  options {
    base_url env.OLLAMA_BASE_URL  // References $OLLAMA_BASE_URL
    model env.OLLAMA_MODEL        // References $OLLAMA_MODEL
    api_key env.API_KEY           // References $API_KEY
  }
}
```

**Syntax:** `env.VARIABLE_NAME`

### Loading Strategies

#### 1. Shell Environment Variables
```bash
export OLLAMA_BASE_URL="http://10.250.99.61:11434/v1"
export OLLAMA_MODEL="llama3.1-cypher:8b"
python main.py
```

#### 2. Docker Environment Variables
```yaml
# docker-compose.yml
environment:
  - OLLAMA_BASE_URL=http://10.250.99.61:11434/v1
  - OLLAMA_MODEL=llama3.1-cypher:8b
```

#### 3. .env Files (Python)
```python
from dotenv import load_dotenv
load_dotenv()  # Load .env before importing BAML

from baml_client import b  # Now BAML captures loaded env vars
```

#### 4. .env Files (Node.js)
```typescript
import dotenv from 'dotenv'
dotenv.config()  // Load .env before importing BAML

import { b } from './baml_client'  // Now BAML captures loaded env vars
```

### Common Gotcha: Import Order Matters!

**❌ Wrong:**
```python
from baml_client import b  # BAML initializes with empty env vars
from dotenv import load_dotenv
load_dotenv()  # Too late! BAML already initialized
```

**✅ Correct:**
```python
from dotenv import load_dotenv
load_dotenv()  # Load env vars FIRST
from baml_client import b  # BAML captures loaded env vars
```

**Our Docker Setup:**
Since we use `docker-compose` with `environment:` declarations, env vars are available from process start, so import order doesn't matter as much. But it's still good practice to be aware of this!

---

## 5. Retry Policies

BAML supports configurable retry policies for LLM calls.

### Retry Policy Types

#### 1. Constant Delay
```baml
retry_policy Constant {
  max_retries 3
  strategy {
    type constant_delay
    delay_ms 200
  }
}
```

Retries with fixed delay between attempts:
- Attempt 1 fails → wait 200ms → Attempt 2
- Attempt 2 fails → wait 200ms → Attempt 3
- And so on...

#### 2. Exponential Backoff
```baml
retry_policy Exponential {
  max_retries 2
  strategy {
    type exponential_backoff
    delay_ms 300
    multiplier 1.5
    max_delay_ms 10000
  }
}
```

Retries with increasing delay:
- Attempt 1 fails → wait 300ms → Attempt 2
- Attempt 2 fails → wait 450ms (300 × 1.5) → Attempt 3
- Attempt 3 fails → wait 675ms (450 × 1.5) → Attempt 4
- Max delay capped at 10000ms

### Applying Retry Policies to Clients

```baml
client<llm> MyClient {
  provider "openai-generic"
  retry_policy Exponential  // ← Apply retry policy
  options {
    base_url env.OLLAMA_BASE_URL
    model env.OLLAMA_MODEL
  }
}
```

### When Retries Trigger
- Network errors (connection timeout, DNS failure)
- HTTP 5xx errors (server errors)
- Rate limiting (429 Too Many Requests)

### When Retries DON'T Trigger
- HTTP 4xx errors (except 429)
- Successful responses (even if content is unexpected)
- Parsing errors (after successful response)

---

## 6. Our Specific Configuration Analysis

### What We Had (Incorrect)

**clients.baml:**
```baml
client<llm> OllamaGemma {
  provider ollama  // ❌ This provider doesn't exist!
  options {
    model env.OLLAMA_MODEL
    base_url env.OLLAMA_BASE_URL
  }
}
```

**docker-compose.yml:**
```yaml
environment:
  - OLLAMA_BASE_URL=http://10.250.99.61:11434  # ❌ Missing /v1
  - OLLAMA_MODEL=llama3.1-cypher:8b
```

### What We Should Have (Correct)

**clients.baml:**
```baml
client<llm> OllamaGemma {
  provider "openai-generic"  // ✅ Correct provider
  options {
    model env.OLLAMA_MODEL
    base_url env.OLLAMA_BASE_URL
  }
}
```

**docker-compose.yml:**
```yaml
environment:
  - OLLAMA_BASE_URL=http://10.250.99.61:11434/v1  # ✅ Includes /v1
  - OLLAMA_MODEL=llama3.1-cypher:8b
```

### Why It Failed

**Attempt #1 (Original - openai-generic without /v1):**
```
BAML tried to call: http://10.250.99.61:11434/chat/completions
Ollama expected: http://10.250.99.61:11434/v1/chat/completions
Result: 404 Not Found
```

**Attempt #2 (Approach #1 - non-existent "ollama" provider):**
```
BAML looked for: provider adapter named "ollama"
Reality: No such provider exists
Result: Unknown provider error or 404 (BAML may have fallen back to some default)
```

**Attempt #3 (Correct - openai-generic with /v1):**
```
BAML will call: http://10.250.99.61:11434/v1/chat/completions
Ollama serves: http://10.250.99.61:11434/v1/chat/completions
Result: Should work! ✅
```

---

## 7. Complete Working Configuration

### File: `app/baml_src/clients.baml`

```baml
// Ollama client using OpenAI-compatible endpoint
client<llm> OllamaGemma {
  provider "openai-generic"
  retry_policy Exponential
  options {
    // Base URL must include /v1 for OpenAI compatibility
    base_url env.OLLAMA_BASE_URL

    // Model name as configured in Ollama
    model env.OLLAMA_MODEL

    // No api_key needed - Ollama doesn't require auth by default
  }
}

// Retry policy for resilience
retry_policy Exponential {
  max_retries 2
  strategy {
    type exponential_backoff
    delay_ms 300
    multiplier 1.5
    max_delay_ms 10000
  }
}

retry_policy Constant {
  max_retries 3
  strategy {
    type constant_delay
    delay_ms 200
  }
}
```

### File: `docker-compose.yml`

```yaml
services:
  mcp_ticket_server:
    environment:
      # Ollama configuration - OpenAI-compatible endpoint
      - OLLAMA_BASE_URL=http://10.250.99.61:11434/v1
      - OLLAMA_MODEL=llama3.1-cypher:8b

      # BAML debugging
      - BAML_LOG=debug
```

### File: `docker-compose.override.yml`

```yaml
services:
  mcp_ticket_server:
    environment:
      # Same Ollama configuration with /v1
      - OLLAMA_BASE_URL=http://10.250.99.61:11434/v1
      - OLLAMA_MODEL=llama3.1-cypher:8b
      - BAML_LOG=debug
```

---

## 8. Testing and Verification

### Step 1: Verify Ollama is Running

```bash
# From inside the container or from the host
curl http://10.250.99.61:11434/v1/models

# Should return list of available models
```

### Step 2: Test OpenAI-Compatible Endpoint

```bash
curl -X POST http://10.250.99.61:11434/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "llama3.1-cypher:8b",
    "messages": [
      {"role": "user", "content": "Say hello"}
    ]
  }'

# Should return a completion response
```

### Step 3: Check BAML Environment Variables in Container

```bash
docker exec mcp_ticket_server printenv | grep OLLAMA
# Should show:
# OLLAMA_BASE_URL=http://10.250.99.61:11434/v1
# OLLAMA_MODEL=llama3.1-cypher:8b
```

### Step 4: Test BAML Client

Run your MCP tool that uses BAML:
```python
# From client
python interactive_test.py

# Try the ask_tickets_question tool
```

### Step 5: Check BAML Debug Logs

With `BAML_LOG=debug`, you should see:
```
[BAML] Request to http://10.250.99.61:11434/v1/chat/completions
[BAML] Model: llama3.1-cypher:8b
[BAML] Response: ...
```

---

## 9. Common Issues and Troubleshooting

### Issue: "Failed to parse JSON: trailing characters at line 1 column 5"

**Cause:** Usually a 404 error HTML page being returned instead of JSON

**Solutions:**
1. ✅ Verify base_url includes `/v1`
2. ✅ Verify Ollama is running: `curl http://10.250.99.61:11434/v1/models`
3. ✅ Check model name matches exactly (case-sensitive)
4. ✅ Test endpoint directly with curl (see Step 2 above)

### Issue: "RelativeUrlWithoutBase"

**Cause:** base_url not set or environment variable not loaded

**Solutions:**
1. ✅ Check environment variable is set: `docker exec container printenv`
2. ✅ Verify BAML runtime initialized after env vars loaded
3. ✅ Check for typos in env var names

### Issue: "Unknown provider: ollama"

**Cause:** Trying to use non-existent `provider ollama`

**Solution:**
✅ Use `provider "openai-generic"` instead

### Issue: Connection timeout

**Cause:** Network connectivity or Ollama not accessible

**Solutions:**
1. ✅ Verify network connectivity: `ping 10.250.99.61`
2. ✅ Check firewall rules
3. ✅ Verify Ollama is listening on correct port: `netstat -an | grep 11434`
4. ✅ If using Docker, check network mode (`network_mode: "host"` in our case)

### Issue: Model not found

**Cause:** Model name doesn't match Ollama's model name

**Solutions:**
1. ✅ List available models: `curl http://10.250.99.61:11434/v1/models`
2. ✅ Use exact model name from list (case-sensitive)
3. ✅ If using custom model, verify it's pulled: `ollama list`

---

## 10. Best Practices

### ✅ DO:
1. **Always include `/v1` in Ollama base_url**
2. **Use environment variables for configuration**
3. **Add retry policies for production resilience**
4. **Enable BAML_LOG=debug during troubleshooting**
5. **Test Ollama endpoint directly before testing through BAML**
6. **Use exact model names (case-sensitive)**
7. **Load environment variables before importing BAML client**

### ❌ DON'T:
1. **Don't use `provider ollama`** - it doesn't exist
2. **Don't forget `/v1` in base_url**
3. **Don't add api_key for Ollama (unless you've configured auth)**
4. **Don't change env vars after BAML runtime initialization** (won't take effect)
5. **Don't assume BAML adds URL paths automatically** (specify full base_url)

---

## 11. Additional Resources

- **BAML Documentation:** https://docs.boundaryml.com
- **Ollama Provider Docs:** https://docs.boundaryml.com/ref/llm-client-providers/ollama
- **OpenAI-Generic Provider:** https://docs.boundaryml.com/ref/llm-client-providers/openai-generic
- **BAML Environment Variables:** https://docs.boundaryml.com/guide/development/environment-variables
- **Ollama API Docs:** https://github.com/ollama/ollama/blob/main/docs/api.md
- **Ollama OpenAI Compatibility:** https://github.com/ollama/ollama/blob/main/docs/openai.md

---

## Conclusion

The root cause of our 404 errors was a **two-part configuration mistake**:

1. **Wrong provider:** Tried using `provider ollama` which doesn't exist
2. **Missing path:** Omitted `/v1` from base_url

Both mistakes led to BAML making requests to incorrect endpoints, resulting in 404 errors.

The correct configuration uses `provider "openai-generic"` with `base_url "http://10.250.99.61:11434/v1"`.

With these fixes in place, BAML should successfully connect to Ollama and translate natural language queries to Cypher.
