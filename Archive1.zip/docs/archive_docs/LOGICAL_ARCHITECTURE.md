# MCP Ticket System - Logical Architecture
**Version:** 2.0 (Post-Memgraph Migration)
**Date:** October 13, 2025
**Document Type:** Architectural Design

---

## Table of Contents
1. [System Overview](#system-overview)
2. [Architectural Principles](#architectural-principles)
3. [Component Model](#component-model)
4. [Data Flow](#data-flow)
5. [Integration Patterns](#integration-patterns)
6. [Deployment Views](#deployment-views)

---

## System Overview

### Purpose
The MCP Ticket System is an **AI-augmented knowledge graph service** that provides intelligent access to IT service ticket data through natural language interfaces. It enables:

- **Natural Language Queries**: Users ask questions in plain English
- **Graph Traversal**: System explores ticket relationships, vendors, incidents, outages
- **Context-Aware Responses**: LLM translates questions to Cypher queries for graph database
- **Real-time Ingestion**: Continuous ticket data ingestion via message queue

### Key Capabilities
- 🗣️ Natural language to Cypher query translation (via BAML + LLM)
- 🔍 12 specialized tools for ticket analysis and lookup
- 📊 Graph-based relationship analysis (clients, tickets, incidents, services, vendors)
- 🚀 Concurrent multi-user access
- 📬 Event-driven data ingestion (NATS JetStream)
- 🔌 MCP (Model Context Protocol) compliance for LLM integration

---

## Architectural Principles

### 1. Separation of Concerns
```
┌─────────────────────────────────────────────┐
│             Presentation Layer              │
│         (MCP Tools / FastMCP)               │
├─────────────────────────────────────────────┤
│            Application Layer                │
│     (Services, Message Handlers, BAML)      │
├─────────────────────────────────────────────┤
│            Data Access Layer                │
│        (MemgraphClient, Cypher Queries)     │
├─────────────────────────────────────────────┤
│           Persistence Layer                 │
│     (Memgraph Database, NATS JetStream)     │
└─────────────────────────────────────────────┘
```

### 2. Event-Driven Architecture
- **Asynchronous Processing**: Ticket ingestion decoupled from query serving
- **Message Queue**: NATS JetStream for reliable event delivery
- **Eventual Consistency**: Graph updates propagate asynchronously

### 3. AI-First Design
- **LLM as Query Interface**: Natural language replaces structured queries
- **Schema-Aware Prompts**: System injects graph schema into LLM context
- **Graceful Degradation**: Falls back to direct tools if LLM fails

### 4. Microservices Ready
- **Stateless Application**: No local state, all data in Memgraph
- **Horizontal Scaling**: Multiple instances can run concurrently
- **Health Checks**: Liveness and readiness probes

---

## Component Model

### High-Level Components

```
┌─────────────────────────────────────────────────────────────────┐
│                         External Systems                         │
│                                                                   │
│  ┌───────────────┐      ┌──────────────┐    ┌───────────────┐  │
│  │  Ticket ETL   │      │ AI Assistant │    │ MCP Clients   │  │
│  │   Pipeline    │      │   (via MCP)  │    │  (Any MCP)    │  │
│  └───────┬───────┘      └───────┬──────┘    └───────┬───────┘  │
└──────────┼────────────────────

──┼────────────────────┼──────────┘
           │                       │                    │
           │ JSON/NATS             │ MCP Protocol       │ MCP Protocol
           ▼                       ▼                    ▼
┌──────────────────────────────────────────────────────────────────┐
│                        MCP Ticket Server                          │
│                                                                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │                   API Gateway Layer                        │ │
│  │  ┌─────────────────┐        ┌─────────────────┐           │ │
│  │  │  FastMCP Server │        │  Health Check   │           │ │
│  │  │  (MCP Protocol) │        │    Endpoint     │           │ │
│  │  └─────────────────┘        └─────────────────┘           │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │              Tool Orchestration Layer                      │ │
│  │                                                             │ │
│  │  ┌──────────────┐  ┌───────────────┐  ┌──────────────┐   │ │
│  │  │ Lookup Tools │  │ Analytics     │  │ Relationship │   │ │
│  │  │ (3 tools)    │  │ Tools (3)     │  │ Tools (4)    │   │ │
│  │  └──────────────┘  └───────────────┘  └──────────────┘   │ │
│  │  ┌──────────────┐  ┌───────────────┐                     │ │
│  │  │ Search Tools │  │ Ask Question  │                     │ │
│  │  │ (2 tools)    │  │ (NL to Cypher)│                     │ │
│  │  └──────────────┘  └───────┬───────┘                     │ │
│  └────────────────────────────┼────────────────────────────┘ │
│                                │                               │
│  ┌────────────────────────────┼────────────────────────────┐ │
│  │          AI/LLM Layer      │                            │ │
│  │                            ▼                            │ │
│  │  ┌─────────────────────────────────────────┐           │ │
│  │  │       BAML Client                       │           │ │
│  │  │  ┌──────────────────────────────────┐   │           │ │
│  │  │  │ TranslateToCypher Function       │   │           │ │
│  │  │  │ - Schema Injection               │   │           │ │
│  │  │  │ - Prompt Templates               │   │           │ │
│  │  │  │ - LLM Retry Logic                │   │           │ │
│  │  │  └──────────────────────────────────┘   │           │ │
│  │  └──────────────────┬──────────────────────┘           │ │
│  └─────────────────────┼──────────────────────────────────┘ │
│                        │ Cypher Query                        │
│  ┌─────────────────────┼──────────────────────────────────┐ │
│  │      Service Layer  │                                  │ │
│  │                     ▼                                  │ │
│  │  ┌──────────────────────────────────┐                 │ │
│  │  │    Message Handler Service       │                 │ │
│  │  │  - Ticket Ingestion              │                 │ │
│  │  │  - Data Transformation           │                 │ │
│  │  │  - Batch Processing              │                 │ │
│  │  └──────────────────────────────────┘                 │ │
│  │  ┌──────────────────────────────────┐                 │ │
│  │  │    Component Registry Service    │                 │ │
│  │  │  - Dynamic Tool Registration     │                 │ │
│  │  │  - Dependency Injection          │                 │ │
│  │  └──────────────────────────────────┘                 │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                               │
│  ┌────────────────────────────────────────────────────────┐ │
│  │            Data Access Layer                           │ │
│  │  ┌──────────────────────────────────────────────┐     │ │
│  │  │         MemgraphClient                       │     │ │
│  │  │  - Connection Management                     │     │ │
│  │  │  - Query Execution                           │     │ │
│  │  │  - Schema Management                         │     │ │
│  │  │  - Batch Insert (UNWIND)                     │     │ │
│  │  └──────────────────┬───────────────────────────┘     │ │
│  │                     │ Neo4j Bolt Protocol              │ │
│  │  ┌──────────────────┼───────────────────────────┐     │ │
│  │  │    NATS Consumer │                           │     │ │
│  │  │  - JetStream Pull Subscription              │     │ │
│  │  │  - Message Decompression                    │     │ │
│  │  │  - Error Recovery                           │     │ │
│  │  └─────────────────────────────────────────────┘     │ │
│  └────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────┘
                         │                    │
                         ▼                    ▼
           ┌─────────────────────┐  ┌──────────────────┐
           │  Memgraph Database  │  │  NATS JetStream  │
           │  (Graph Storage)    │  │  (Message Queue) │
           └─────────────────────┘  └──────────────────┘
```

---

## Component Descriptions

### 1. API Gateway Layer

#### FastMCP Server
- **Purpose**: Exposes MCP (Model Context Protocol) interface for LLM clients
- **Technology**: FastMCP (Python framework)
- **Responsibilities**:
  - MCP protocol handling
  - Tool discovery and invocation
  - Request/response serialization
  - Connection management

#### Health Check Endpoint
- **Purpose**: System health monitoring
- **Endpoint**: `/health`
- **Response**: `{"status": "healthy", "memgraph_connected": true}`

---

### 2. Tool Orchestration Layer

#### Lookup Tools
1. **get_ticket_details** - Retrieve detailed information for a specific ticket
2. **get_client_tickets** - List all tickets for a client
3. **get_ticket_timeline** - Show ticket lifecycle events

#### Analytical Tools
1. **get_client_summary** - Aggregate metrics per client
2. **get_tickets_by_status** - Group tickets by status
3. **get_high_priority_tickets** - Filter by priority threshold

#### Relationship Tools
1. **get_ticket_relationships** - Traverse ticket dependencies
2. **trace_ticket_root_cause** - Find root cause via incident graph
3. **get_vendor_tickets** - Show vendor involvement
4. **get_service_outages** - Service-level outage analysis

#### Search Tools
1. **get_tickets_by_date_range** - Time-based filtering
2. **get_ticket_contacts** - Extract contact information

#### Natural Language Tool
- **ask_tickets_question** - Translate user question to Cypher via LLM

---

### 3. AI/LLM Layer

#### BAML Client
- **Purpose**: Abstracts LLM interaction for query generation
- **Key Function**: `TranslateToCypher(question, schema_description)`
- **Features**:
  - Dynamic schema injection
  - Prompt templates with examples
  - Retry policies (constant/exponential backoff)
  - Provider abstraction (Ollama, OpenAI compatible)

**Query Generation Flow**:
```
User Question
     │
     ▼
"What tickets does client ACME have?"
     │
     ▼
BAML TranslateToCypher()
     │
     ├─ Inject Graph Schema
     ├─ Apply Prompt Template
     ├─ Call LLM (Ollama/GPT)
     │
     ▼
MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
WHERE LOWER(c.client_name) CONTAINS LOWER('acme')
RETURN t.*
     │
     ▼
Execute on Memgraph
```

---

### 4. Service Layer

#### Message Handler Service
- **Purpose**: Process incoming ticket data from NATS
- **Input**: Compressed JSON messages (gzip + base64)
- **Output**: Ingested nodes/relationships in Memgraph
- **Operations**:
  1. Message decompression
  2. Data validation (Pydantic models)
  3. Null value normalization
  4. ID generation for graph nodes
  5. Batch insert via Cypher UNWIND

#### Component Registry Service
- **Purpose**: Dynamic tool registration at runtime
- **Features**:
  - Load tool functions via reflection
  - Inject dependencies (database client, config, BAML)
  - Generate tool descriptions from external files
  - Preserve function signatures for FastMCP

---

### 5. Data Access Layer

#### MemgraphClient
- **Purpose**: Abstract Memgraph database operations
- **Protocol**: Neo4j Bolt (port 7687)
- **Methods**:
  - `connect()` - Establish driver connection
  - `execute(query, params)` - Run Cypher query
  - `execute_with_dataframe(df, query)` - Batch insert
  - `createSchema()` - Initialize graph schema
  - `clearDatabase()` - Remove all nodes/relationships

#### NATS Consumer
- **Purpose**: Subscribe to ticket events
- **Pattern**: Pull-based JetStream consumer
- **Configuration**:
  - Durable subscription: `ticket_consumer_durable`
  - Batch size: 10 messages
  - Fetch timeout: 2 seconds
- **Error Handling**: Exponential backoff with max 5 retries

---

### 6. External Systems

#### Ticket ETL Pipeline
- **Role**: Upstream data producer
- **Output**: Compressed JSON messages to NATS
- **Format**: `{"compressed": true, "encoding": "gzip+base64", "data": "..."}`

#### LLM Providers (via MCP)
- **Ollama**: Local LLM (default: gemma3-cypher-4b)
- **Cloud LLMs**: Any OpenAI-compatible API provider (configurable)

#### MCP Clients
- **AI Assistants**: Any MCP-compliant AI assistant application
- **Desktop Applications**: MCP-enabled desktop applications
- **Custom Integrations**: Any MCP-compliant application or service

---

## Data Flow

### Query Flow (User Question → Response)

```
┌──────────────┐
│ AI Assistant │
│  MCP Client  │
└──────┬───────┘
       │ 1. MCP Request: ask_tickets_question()
       ▼
┌─────────────────────────────────────────┐
│      MCP Ticket Server (FastMCP)        │
│                                         │
│  2. Route to ask_tickets_question()     │
│     ├─ Inject services (DB, BAML)      │
│     └─ Extract user question            │
│                                         │
│  3. Call BAML TranslateToCypher()       │
│     ├─ Load graph schema                │
│     ├─ Format prompt with examples      │
│     └─ Send to LLM (Ollama)             │
│           │                             │
│           ▼                             │
│  ┌─────────────────────────┐           │
│  │  Gemma3-Cypher-4b LLM   │           │
│  │  (via Ollama)           │           │
│  └────────────┬────────────┘           │
│               │ 4. Return Cypher Query  │
│               ▼                         │
│  MATCH (c:Client)-[:HAS_TICKET]->(t)   │
│  WHERE LOWER(c.client_name)             │
│         CONTAINS LOWER('acme')          │
│  RETURN t.*                             │
│                                         │
│  5. Execute Query on Memgraph           │
│     ├─ Send via Bolt protocol          │
│     └─ Receive Result objects           │
│           │                             │
│           ▼                             │
│  ┌─────────────────────────┐           │
│  │  Memgraph Database      │           │
│  │  - Graph traversal      │           │
│  │  - Return records       │           │
│  └────────────┬────────────┘           │
│               │ 6. Result List          │
│               ▼                         │
│  7. Transform to JSON                   │
│     ├─ Convert Result → dict            │
│     ├─ Serialize datetimes             │
│     └─ Format response                  │
└────────────────┬────────────────────────┘
                 │ 8. MCP Response
                 ▼
          ┌──────────────┐
          │ AI Assistant │
          │  MCP Client  │
          └──────────────┘
```

---

### Ingestion Flow (Ticket Data → Graph)

```
┌──────────────────┐
│  Ticket ETL      │
│  Pipeline        │
└─────────┬────────┘
          │ 1. Publish JSON (compressed)
          ▼
┌──────────────────────────────┐
│    NATS JetStream            │
│  Stream: DATA_INJESTION      │
│  Subject: tickets.created    │
└─────────┬────────────────────┘
          │ 2. Pull Subscription
          ▼
┌──────────────────────────────────────────┐
│    MCP Ticket Server                      │
│                                          │
│  3. NATS Consumer pulls messages         │
│     ├─ Fetch batch (10 msgs)            │
│     └─ Decompress (base64 + gzip)       │
│                                          │
│  4. Message Handler processes data       │
│     ├─ Parse JSON                        │
│     ├─ Normalize null values             │
│     ├─ Generate node IDs                 │
│     └─ Transform to graph format         │
│                                          │
│  5. Batch Insert via MemgraphClient      │
│     ├─ Load Cypher templates             │
│     ├─ Execute CREATE queries            │
│     └─ UNWIND batch (1000 rows)          │
│           │                              │
│           ▼                              │
│  ┌─────────────────────────┐            │
│  │  Memgraph Database      │            │
│  │  - Create Nodes         │            │
│  │  - Create Relationships │            │
│  │  - Update Indexes       │            │
│  └─────────────────────────┘            │
│                                          │
│  6. ACK message to NATS                  │
└──────────────────────────────────────────┘
```

---

## Integration Patterns

### 1. Request-Response (Synchronous)
- **Pattern**: MCP Client → MCP Server → Memgraph
- **Use Case**: Real-time queries (lookup, analytics)
- **Protocol**: MCP over HTTP/SSE

### 2. Publish-Subscribe (Asynchronous)
- **Pattern**: ETL Pipeline → NATS → MCP Server → Memgraph
- **Use Case**: Bulk data ingestion
- **Protocol**: NATS JetStream (pull-based)

### 3. Command-Query Responsibility Segregation (CQRS)
- **Command Side**: Write-heavy ingestion (NATS → Memgraph)
- **Query Side**: Read-heavy queries (MCP Tools → Memgraph)
- **Benefit**: Independent scaling of reads/writes

---

## Deployment Views

### Local Development
```
┌────────────────────────────────────────┐
│       Docker Compose Stack             │
│                                        │
│  ┌──────────────────────────────────┐ │
│  │  mcp-ticket-server               │ │
│  │  - Python 3.13                   │ │
│  │  - FastMCP                       │ │
│  │  - Port: 8000                    │ │
│  └──────────────────────────────────┘ │
│                                        │
│  ┌──────────────────────────────────┐ │
│  │  memgraph                        │ │
│  │  - Memgraph 2.22+                │ │
│  │  - Ports: 7687 (Bolt), 7444 (Lab)│ │
│  └──────────────────────────────────┘ │
│                                        │
│  ┌──────────────────────────────────┐ │
│  │  ollama (optional)               │ │
│  │  - Gemma3-Cypher-4b              │ │
│  │  - Port: 11434                   │ │
│  └──────────────────────────────────┘ │
│                                        │
│  ┌──────────────────────────────────┐ │
│  │  nats (external/shared)          │ │
│  │  - NATS JetStream                │ │
│  │  - Port: 4222                    │ │
│  └──────────────────────────────────┘ │
└────────────────────────────────────────┘
```

### Production (Kubernetes)
```
┌──────────────────────────────────────────────────────┐
│           Kubernetes Cluster                         │
│         Namespace: mcp-ticket-system                 │
│                                                      │
│  ┌────────────────────────────────────────────────┐ │
│  │        Ingress Controller                      │ │
│  │  - TLS termination                             │ │
│  │  - Path: /mcp/ticket/*                         │ │
│  └──────────────────┬─────────────────────────────┘ │
│                     │                                │
│  ┌──────────────────┼─────────────────────────────┐ │
│  │  Service: mcp-ticket-service                   │ │
│  │  - Type: ClusterIP                             │ │
│  │  - Port: 8000                                  │ │
│  └──────────────────┬─────────────────────────────┘ │
│                     │                                │
│  ┌──────────────────┼─────────────────────────────┐ │
│  │  Deployment: mcp-ticket-deployment             │ │
│  │  - Replicas: 3 (auto-scaled)                   │ │
│  │  - Resources:                                  │ │
│  │    - Requests: 500m CPU, 1Gi RAM               │ │
│  │    - Limits: 2000m CPU, 4Gi RAM                │ │
│  │  - Health Checks: /health                      │ │
│  │  ┌────────────────────────────────────────┐   │ │
│  │  │  Pod: mcp-ticket-pod                   │   │ │
│  │  │  - Container: mcp-ticket-server        │   │ │
│  │  │  - Image: mcp-ticket-server:v2.0       │   │ │
│  │  └────────────────────────────────────────┘   │ │
│  └────────────────────────────────────────────────┘ │
│                                                      │
│  ┌────────────────────────────────────────────────┐ │
│  │  StatefulSet: memgraph                         │ │
│  │  - Replicas: 1 (primary)                       │ │
│  │  - PVC: memgraph-data (50Gi)                   │ │
│  │  - Service: memgraph-service (ClusterIP)       │ │
│  └────────────────────────────────────────────────┘ │
│                                                      │
│  ┌────────────────────────────────────────────────┐ │
│  │  Deployment: nats-deployment                   │ │
│  │  - Replicas: 1                                 │ │
│  │  - PVC: nats-data (10Gi)                       │ │
│  │  - Service: nats-service (ClusterIP)           │ │
│  └────────────────────────────────────────────────┘ │
│                                                      │
│  ┌────────────────────────────────────────────────┐ │
│  │  HPA: mcp-ticket-hpa                           │ │
│  │  - Min Replicas: 2                             │ │
│  │  - Max Replicas: 10                            │ │
│  │  - Target CPU: 70%                             │ │
│  └────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────┘
```

---

## Logical Boundaries

### Service Boundaries
1. **MCP Ticket Service**: Tool orchestration + BAML integration
2. **Memgraph Service**: Graph storage + query execution
3. **NATS Service**: Message brokering + stream management
4. **Ollama Service** (optional): LLM inference

### Data Boundaries
1. **Transactional Data**: Real-time ticket queries (Memgraph)
2. **Messaging Data**: Ticket events (NATS JetStream streams)
3. **Configuration Data**: Application config (ConfigMaps, environment variables)

### Security Boundaries
- **Network**: Services communicate via ClusterIP (internal only)
- **Ingress**: External access through single ingress point
- **Secrets**: Credentials stored in Kubernetes Secrets

---

## Scalability Considerations

### Horizontal Scaling
- **MCP Server**: Stateless, scales to N replicas
- **Memgraph**: Single-node (HA requires Enterprise edition)
- **NATS**: Clustered deployment for HA

### Performance Characteristics
- **Query Latency**: <100ms for simple lookups, <500ms for LLM-generated queries
- **Ingestion Throughput**: ~1000 tickets/second (batch mode)
- **Concurrent Users**: 100+ simultaneous MCP connections

---

## Document Version Control
- **Version:** 2.0
- **Last Updated:** October 13, 2025
- **Next Review:** January 13, 2026
- **Change Log**:
  - v2.0 (Oct 13, 2025): Updated for Memgraph migration
  - v1.0 (Sep 26, 2025): Initial architecture with Kuzu
