"""
Tests for NotesExtractionPipeline
"""
import pytest
from unittest.mock import AsyncMock, MagicMock
from datetime import datetime

from services.notes_extraction_pipeline import NotesExtractionPipeline


class TestNotesExtractionPipeline:
    """Test suite for NotesExtractionPipeline"""

    @pytest.fixture
    def mock_memgraph_client(self):
        """Create mock Memgraph client"""
        client = MagicMock()
        client.execute = AsyncMock()
        return client

    @pytest.fixture
    def mock_config(self):
        """Create mock config"""
        config = MagicMock()
        config.servicenow_base_url = "https://test.service-now.com/api/v1"
        config.servicenow_username = "test_user"
        config.servicenow_password = "test_pass"
        config.servicenow_timeout = 30
        config.servicenow_max_concurrent = 5
        return config

    @pytest.fixture
    def pipeline(self, mock_memgraph_client, mock_config):
        """Create pipeline with mocks"""
        return NotesExtractionPipeline(
            memgraph_client=mock_memgraph_client,
            config=mock_config,
        )

    def test_initialization(self, pipeline):
        """Test pipeline initializes correctly"""
        assert pipeline._last_message_time is None
        assert pipeline._is_running is False
        assert pipeline._last_run_time is None

    def test_on_message_processed_updates_timestamp(self, pipeline):
        """Test that on_message_processed updates the timestamp"""
        assert pipeline._last_message_time is None

        pipeline.on_message_processed()
        assert pipeline._last_message_time is not None
        assert isinstance(pipeline._last_message_time, datetime)

    def test_should_trigger_false_when_no_messages(self, pipeline):
        """Test _should_trigger returns False when no messages processed"""
        result = pipeline._should_trigger()
        assert result is False

    def test_should_trigger_false_when_running(self, pipeline):
        """Test _should_trigger returns False when already running"""
        pipeline._is_running = True
        pipeline.on_message_processed()
        result = pipeline._should_trigger()
        assert result is False

    def test_get_status(self, pipeline):
        """Test get_status returns correct status"""
        status = pipeline.get_status()

        assert status["last_run_time"] is None
        assert status["is_running"] is False
        assert status["idle_seconds"] is None

    def test_get_status_after_message(self, pipeline):
        """Test get_status after processing a message"""
        pipeline.on_message_processed()
        status = pipeline.get_status()

        assert status["last_run_time"] is None
        assert status["is_running"] is False
        assert status["idle_seconds"] is not None
        assert status["idle_seconds"] >= 0


class TestNotesExtractionPipelineRun:
    """Test the run() method"""

    @pytest.fixture
    def mock_memgraph_client(self):
        client = MagicMock()
        client.execute = AsyncMock(return_value=[])
        return client

    @pytest.fixture
    def mock_config(self):
        config = MagicMock()
        config.servicenow_base_url = "https://test.service-now.com/api/v1"
        config.servicenow_username = "test_user"
        config.servicenow_password = "test_pass"
        config.servicenow_timeout = 30
        config.servicenow_max_concurrent = 5
        return config

    @pytest.fixture
    def pipeline(self, mock_memgraph_client, mock_config):
        return NotesExtractionPipeline(
            memgraph_client=mock_memgraph_client,
            config=mock_config,
        )

    @pytest.mark.asyncio
    async def test_run_no_tickets(self, pipeline, mock_memgraph_client):
        """Test run() with no resolved tickets"""
        mock_memgraph_client.execute.return_value = []

        await pipeline.run()

        assert pipeline._last_run_time is not None
        assert pipeline._is_running is False
