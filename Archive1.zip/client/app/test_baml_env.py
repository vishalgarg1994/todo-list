import os
import sys

print("=" * 80)
print("STEP 1: Environment variables BEFORE importing baml_client")
print("=" * 80)
print(f"OLLAMA_CYPHER_BASE_URL = {os.environ.get('OLLAMA_CYPHER_BASE_URL', 'NOT SET')}")
print(f"OLLAMA_CYPHER_MODEL = {os.environ.get('OLLAMA_CYPHER_MODEL', 'NOT SET')}")

print("\n" + "=" * 80)
print("STEP 2: Importing baml_client...")
print("=" * 80)

sys.path.insert(0, '/app')
from baml_client import b as baml_client

print("SUCCESS: baml_client imported")

print("\n" + "=" * 80)
print("STEP 3: Testing if BAML can see the environment variables")
print("=" * 80)
print("If this works, BAML should have captured the env vars at import time")

print("\n" + "=" * 80)
print("STEP 4: Calling BAML TranslateToCypher function")
print("=" * 80)
print("This should trigger the same 404 error we saw before")

try:
    result = baml_client.TranslateToCypher(
        question="How many tickets are there?",
        schema_description="Test schema"
    )
    print(f"\nSUCCESS! Result: {result}")
except Exception as e:
    print(f"\nERROR (as expected): {type(e).__name__}")
    print(f"Error message: {str(e)[:500]}")

    # Try to extract the actual URL being used
    error_str = str(e)
    if 'http' in error_str.lower():
        print("\nSearching for URL in error message...")
        import re
        urls = re.findall(r'https?://[^\s]+', error_str)
        if urls:
            print(f"Found URLs in error: {urls}")
        else:
            print("No URLs found in error message")

    print(f"\nFull error (first 1000 chars):\n{str(e)[:1000]}")
