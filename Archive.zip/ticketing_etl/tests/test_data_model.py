from datetime import datetime, timezone
import json
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from classes.data_model import (
    UserInfo,
    MaintenanceWindow,
    ContactInfo,
    VendorInfo,
    ServiceEntity,
    FaultInfo,
    TicketInfo,
    OutageInfo,
    NOCInfo,
    OperationalStatus,
    ClientInfo,
    TicketSummary,
    # New Change-related models
    ChangeFields,
    ChangeTaskInfo,
    CaseTaskInfo,
    ChangeRecord,
    ChangeBatch,
    CHANGE_BATCH_SIZE,
    # TSM-specific models
    IncidentFields,
    CaseFields,
    IncidentTaskInfo,
    ConfigurationItem,
)


class TestKnowledgeGraphNodes:
    """Test the knowledge graph node classes"""

    def test_user_creation(self):
        """Test UserInfo node creation"""
        user = UserInfo(name="john.doe", role="incident_manager")

        assert user.name == "john.doe"
        assert user.role == "incident_manager"

        # Test serialization
        user_dict = user.model_dump()
        assert user_dict["name"] == "john.doe"
        assert user_dict["role"] == "incident_manager"

    def test_contact_info_creation(self):
        """Test ContactInfo node creation"""
        contact = ContactInfo(
            name="Bob Customer",
            email="bob@customer.com",
            phone="555-1234",
            contact_type="customer",
        )

        assert contact.name == "Bob Customer"
        assert contact.email == "bob@customer.com"
        assert contact.phone == "555-1234"
        assert contact.contact_type == "customer"

    def test_vendor_info_creation(self):
        """Test VendorInfo node creation"""
        vendor = VendorInfo(vendor="NetworkCorp", vendor_downtime=2.5)

        assert vendor.vendor == "NetworkCorp"
        assert vendor.vendor_downtime == 2.5

    def test_maintenance_window_creation(self):
        """Test MaintenanceWindow node creation"""
        start_time = datetime(2023, 1, 15, 2, 0, 0, tzinfo=timezone.utc)
        end_time = datetime(2023, 1, 15, 4, 0, 0, tzinfo=timezone.utc)

        window = MaintenanceWindow(
            pw_start=start_time,
            pw_end=end_time,
            pw_duration="2 hours",
            pw_location="Data Center A",
            pw_reason="Fiber upgrade",
        )

        assert window.pw_start == start_time
        assert window.pw_end == end_time
        assert window.pw_duration == "2 hours"
        assert window.pw_location == "Data Center A"
        assert window.pw_reason == "Fiber upgrade"


class TestCoreDataModels:
    """Test the core data model classes"""

    def test_service_entity(self):
        """Test ServiceEntity creation"""
        service = ServiceEntity(
            subcategory="MPLS Connectivity",
            technology="MPLS",
            service_restored_date=datetime.now(timezone.utc),
        )

        assert service.subcategory == "MPLS Connectivity"
        assert service.technology == "MPLS"
        assert isinstance(service.service_restored_date, datetime)

    def test_fault_info_with_diagnostics(self):
        """Test FaultInfo with diagnostic fields"""
        fault = FaultInfo(
            fault_description_ref="INC123456",
            short_description="Network connectivity issue",
            is_customer_impacting=True,
        )

        assert fault.fault_description_ref == "INC123456"
        assert fault.short_description == "Network connectivity issue"
        assert fault.is_customer_impacting is True

    def test_ticket_info_with_users_and_escalation(self):
        """Test TicketInfo with user lifecycle and escalation fields"""
        ticket = TicketInfo(
            ticket_id="INC12345",
            ticket_category="Trouble Ticket",
            ticket_status="investigating",
            priority=1,
            ticket_escalation_level=1,
        )

        assert ticket.ticket_id == "INC12345"
        assert ticket.ticket_category == "Trouble Ticket"
        assert ticket.ticket_status == "investigating"
        assert ticket.priority == 1
        assert ticket.ticket_escalation_level == 1

    def test_outage_info(self):
        """Test OutageInfo creation"""
        outage = OutageInfo(
            customer_resolution="Service restored",
            resolution="Router configuration fixed",
            rfo="Configuration error",
            outage_duration="2 hours",
            internal_mttr="90 minutes",
            mttr=105,
        )

        assert outage.customer_resolution == "Service restored"
        assert outage.resolution == "Router configuration fixed"
        assert outage.outage_duration == "2 hours"
        assert outage.mttr == 105


class TestOperationalStatus:
    """Test OperationalStatus with knowledge graph nodes"""

    def test_operational_status_with_knowledge_graph(self):
        """Test OperationalStatus containing knowledge graph nodes"""
        # Create knowledge graph nodes
        users = [
            UserInfo(name="john.manager", role="incident_manager"),
            UserInfo(name="jane.tech", role="service_desk_engineer"),
        ]

        contacts = [
            ContactInfo(
                name="Bob Customer", email="bob@customer.com", contact_type="customer"
            )
        ]

        vendors = [VendorInfo(vendor="NetworkCorp")]

        maintenance_window = MaintenanceWindow(
            pw_start=datetime(2023, 1, 15, 2, 0, 0, tzinfo=timezone.utc),
            pw_end=datetime(2023, 1, 15, 4, 0, 0, tzinfo=timezone.utc),
            pw_reason="Planned maintenance",
        )

        # Create operational status
        ops_status = OperationalStatus(
            ticket_type="incident",
            service_entity=ServiceEntity(subcategory="MPLS", technology="MPLS"),
            fault_info=FaultInfo(fault_description_ref="INC123"),
            ticket_info=TicketInfo(
                ticket_id="INC123", ticket_category="Trouble Ticket"
            ),
            outage_info=OutageInfo(outage_duration="1 hour", mttr=60),
            noc_info=NOCInfo(default_noc="Main NOC"),
            # Knowledge graph nodes
            users=users,
            contacts=contacts,
            vendors=vendors,
            maintenance_window=maintenance_window,
        )

        assert len(ops_status.users) == 2
        assert ops_status.users[0].name == "john.manager"
        assert ops_status.users[1].role == "service_desk_engineer"

        assert len(ops_status.contacts) == 1
        assert ops_status.contacts[0].name == "Bob Customer"

        assert len(ops_status.vendors) == 1
        assert ops_status.vendors[0].vendor == "NetworkCorp"

        assert ops_status.maintenance_window.pw_reason == "Planned maintenance"

    def test_operational_status_with_ticket_type(self):
        """Test OperationalStatus with ticket_type field"""
        ops_status = OperationalStatus(
            ticket_type="case",
            ticket_sys_id="abc123",
            service_entity=ServiceEntity(subcategory="Fiber"),
            fault_info=FaultInfo(fault_description_ref="CS123"),
            ticket_info=TicketInfo(ticket_id="CS123", ticket_category="Case"),
            outage_info=OutageInfo(outage_duration="1 hour", mttr=60),
            noc_info=NOCInfo(default_noc="Main NOC"),
            case_fields=CaseFields(
                category="Network", subcategory="Fiber Issue", case_type="Standard"
            ),
        )

        assert ops_status.ticket_type == "case"
        assert ops_status.ticket_sys_id == "abc123"
        assert ops_status.case_fields.case_type == "Standard"


class TestTicketSummary:
    """Test complete TicketSummary structure"""

    def test_ticket_summary_complete(self):
        """Test complete TicketSummary with multiple tickets and knowledge graph data"""
        client_info = ClientInfo(client_id=123, client_name="Test Client")

        # Create two operational statuses (tickets)
        ops1 = OperationalStatus(
            ticket_type="incident",
            service_entity=ServiceEntity(subcategory="MPLS"),
            fault_info=FaultInfo(fault_description_ref="INC1001"),
            ticket_info=TicketInfo(
                ticket_id="INC1001", ticket_category="Trouble Ticket"
            ),
            outage_info=OutageInfo(outage_duration="30 minutes", mttr=30),
            noc_info=NOCInfo(default_noc="Main NOC"),
            users=[UserInfo(name="tech1", role="incident_manager")],
        )

        ops2 = OperationalStatus(
            ticket_type="incident",
            service_entity=ServiceEntity(subcategory="Fiber"),
            fault_info=FaultInfo(fault_description_ref="INC1002"),
            ticket_info=TicketInfo(
                ticket_id="INC1002", ticket_category="Maintenance Ticket"
            ),
            outage_info=OutageInfo(outage_duration="45 minutes", mttr=45),
            noc_info=NOCInfo(default_noc="Main NOC"),
            maintenance_window=MaintenanceWindow(pw_reason="Scheduled maintenance"),
        )

        ticket_summary = TicketSummary(
            client_info=client_info, operational_status=[ops1, ops2]
        )

        assert ticket_summary.client_info.client_id == 123
        assert ticket_summary.client_info.client_name == "Test Client"
        assert len(ticket_summary.operational_status) == 2

        # Check first ticket
        assert ticket_summary.operational_status[0].ticket_info.ticket_id == "INC1001"
        assert len(ticket_summary.operational_status[0].users) == 1

        # Check second ticket
        assert ticket_summary.operational_status[1].ticket_info.ticket_id == "INC1002"
        assert (
            ticket_summary.operational_status[1].maintenance_window.pw_reason
            == "Scheduled maintenance"
        )

    def test_ticket_summary_json_serialization(self):
        """Test that TicketSummary can be serialized to JSON"""
        client_info = ClientInfo(client_id=456, client_name="JSON Test Client")

        ops_status = OperationalStatus(
            ticket_type="incident",
            service_entity=ServiceEntity(subcategory="Test"),
            fault_info=FaultInfo(
                fault_description_ref="INC2001", short_description="Test issue"
            ),
            ticket_info=TicketInfo(ticket_id="INC2001", ticket_category="Test Ticket"),
            outage_info=OutageInfo(outage_duration="15 minutes", mttr=15),
            noc_info=NOCInfo(default_noc="Test NOC"),
            users=[UserInfo(name="test.user", role="test_role")],
        )

        ticket_summary = TicketSummary(
            client_info=client_info, operational_status=[ops_status]
        )

        # Should be able to convert to JSON
        json_str = ticket_summary.model_dump_json()
        assert isinstance(json_str, str)

        # Should be valid JSON
        parsed = json.loads(json_str)
        assert parsed["client_info"]["client_id"] == 456
        assert parsed["client_info"]["client_name"] == "JSON Test Client"
        assert len(parsed["operational_status"]) == 1
        assert parsed["operational_status"][0]["users"][0]["name"] == "test.user"


class TestChangeModels:
    """Test the new Change-related models"""

    def test_change_batch_size_default(self):
        """Test CHANGE_BATCH_SIZE has a sensible default"""
        assert CHANGE_BATCH_SIZE == 100

    def test_change_fields_creation(self):
        """Test ChangeFields model creation"""
        change_fields = ChangeFields(
            change_type="Normal",
            work_type="Service Affecting",
            source="Manual",
            planned_start_date=datetime(2026, 1, 15, 2, 0, 0, tzinfo=timezone.utc),
            planned_end_date=datetime(2026, 1, 15, 4, 0, 0, tzinfo=timezone.utc),
            risk="Moderate",
            security_risk=False,
            core_network=True,
            critical_systems=False,
            is_cab_required=True,
            supplier_name="NetworkCorp",
        )

        assert change_fields.change_type == "Normal"
        assert change_fields.work_type == "Service Affecting"
        assert change_fields.core_network is True
        assert change_fields.is_cab_required is True
        assert change_fields.supplier_name == "NetworkCorp"

    def test_change_task_info_creation(self):
        """Test ChangeTaskInfo model creation"""
        task = ChangeTaskInfo(
            task_sys_id="task123",
            task_number="CTASK0001234",
            change_sys_id="change456",
            change_number="CHG0012345",
            short_description="Implement network change",
            state="Work In Progress",
            priority=2,
            change_category="Network",
            fulfillment=True,
            follow_up_needed=False,
            assignment_group="Network Team",
            assigned_to="john.doe",
        )

        assert task.task_sys_id == "task123"
        assert task.task_number == "CTASK0001234"
        assert task.change_sys_id == "change456"
        assert task.fulfillment is True
        assert task.priority == 2

    def test_case_task_info_creation(self):
        """Test CaseTaskInfo model creation"""
        task = CaseTaskInfo(
            task_sys_id="ctask123",
            task_number="CTASK0005678",
            parent_case_sys_id="case789",
            parent_case_number="CS0028143",
            short_description="Follow up with customer",
            state="Pending",
            priority=3,
            service_type="Customer Service",
            third_party_name="External Vendor",
            third_party_ticket="EXT-12345",
            vendor_id="V001",
        )

        assert task.task_sys_id == "ctask123"
        assert task.parent_case_sys_id == "case789"
        assert task.third_party_name == "External Vendor"
        assert task.vendor_id == "V001"

    def test_change_record_creation(self):
        """Test ChangeRecord model creation with nested fields"""
        change_fields = ChangeFields(
            change_type="Emergency", work_type="Service Affecting", core_network=True
        )

        task = ChangeTaskInfo(
            task_sys_id="task1",
            task_number="CTASK001",
            change_sys_id="chg1",
            change_number="CHG001",
        )

        ci = ConfigurationItem(ci_sys_id="ci1", ci_name="Router-01")

        change = ChangeRecord(
            change_sys_id="chg1",
            change_number="CHG0012345",
            short_description="Emergency router replacement",
            description="Full description of the change",
            change_state="Implement",
            category="Hardware",
            change_fields=change_fields,
            tasks=[task],
            configuration_items=[ci],
            assignment_group="Network Team",
            assigned_to="jane.tech",
            created_on=datetime.now(timezone.utc),
        )

        assert change.change_sys_id == "chg1"
        assert change.change_number == "CHG0012345"
        assert change.change_state == "Implement"
        assert change.change_fields.change_type == "Emergency"
        assert change.change_fields.core_network is True
        assert len(change.tasks) == 1
        assert change.tasks[0].task_number == "CTASK001"
        assert len(change.configuration_items) == 1
        assert change.configuration_items[0].ci_name == "Router-01"

    def test_change_batch_creation(self):
        """Test ChangeBatch model creation"""
        change1 = ChangeRecord(change_sys_id="chg1", change_number="CHG001")
        change2 = ChangeRecord(change_sys_id="chg2", change_number="CHG002")

        batch = ChangeBatch(
            changes=[change1, change2],
            batch_number=1,
            total_batches=5,
            total_changes=10,
            extraction_time=datetime.now(timezone.utc),
        )

        assert len(batch.changes) == 2
        assert batch.batch_number == 1
        assert batch.total_batches == 5
        assert batch.total_changes == 10
        assert batch.changes[0].change_number == "CHG001"

    def test_change_batch_json_serialization(self):
        """Test ChangeBatch can be serialized to JSON"""
        change = ChangeRecord(
            change_sys_id="chg1",
            change_number="CHG0012345",
            short_description="Test change",
            change_fields=ChangeFields(
                change_type="Standard", work_type="Non-Service Affecting"
            ),
            tasks=[
                ChangeTaskInfo(
                    task_sys_id="task1",
                    task_number="CTASK001",
                    change_sys_id="chg1",
                    change_number="CHG0012345",
                )
            ],
        )

        batch = ChangeBatch(
            changes=[change],
            batch_number=1,
            total_batches=1,
            total_changes=1,
            extraction_time=datetime(2026, 1, 12, 10, 0, 0, tzinfo=timezone.utc),
        )

        # Should serialize to JSON
        json_str = batch.model_dump_json()
        assert isinstance(json_str, str)

        # Should be valid JSON
        parsed = json.loads(json_str)
        assert parsed["batch_number"] == 1
        assert len(parsed["changes"]) == 1
        assert parsed["changes"][0]["change_number"] == "CHG0012345"
        assert parsed["changes"][0]["change_fields"]["change_type"] == "Standard"
        assert len(parsed["changes"][0]["tasks"]) == 1


class TestTSMSpecificFields:
    """Test TSM-specific field models"""

    def test_incident_fields(self):
        """Test IncidentFields model"""
        fields = IncidentFields(
            category="Hardware",
            subcategory="Router",
            major_incident_state="Active",
            escalation_level=2,
            is_customer_impacted=True,
            related_change_sys_id="chg123",
            related_change_number="CHG001",
            caused_by_change_sys_id="chg456",
            caused_by_change_number="CHG002",
        )

        assert fields.category == "Hardware"
        assert fields.escalation_level == 2
        assert fields.is_customer_impacted is True
        assert fields.related_change_sys_id == "chg123"
        assert fields.caused_by_change_sys_id == "chg456"

    def test_case_fields(self):
        """Test CaseFields model"""
        fields = CaseFields(
            category="Service Request",
            subcategory="Network Access",
            case_type="Standard",
            resolution_code="Completed",
            incident_sys_id="inc123",
            incident_number="INC001",
            caused_by_change_sys_id="chg456",
        )

        assert fields.case_type == "Standard"
        assert fields.incident_sys_id == "inc123"
        assert fields.caused_by_change_sys_id == "chg456"

    def test_incident_task_info(self):
        """Test IncidentTaskInfo model"""
        task = IncidentTaskInfo(
            task_sys_id="task123",
            task_number="TASK0001234",
            task_state="Work In Progress",
            short_description="Implement fix",
            priority=2,
            assigned_to="tech.user",
            assignment_group="Support Team",
        )

        assert task.task_sys_id == "task123"
        assert task.task_number == "TASK0001234"
        assert task.task_state == "Work In Progress"
        assert task.task_type == "task"  # Literal default

    def test_configuration_item(self):
        """Test ConfigurationItem model"""
        ci = ConfigurationItem(
            ci_sys_id="ci123", ci_name="Router-NYC-01", is_manually_added=False
        )

        assert ci.ci_sys_id == "ci123"
        assert ci.ci_name == "Router-NYC-01"
        assert ci.is_manually_added is False
