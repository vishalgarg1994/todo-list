import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum

# Import psutil with fallback for environments where it's not available
try:
    import psutil

    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

logger = logging.getLogger(__name__)


class HealthStatus(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


@dataclass
class ComponentHealth:
    status: HealthStatus
    message: Optional[str] = None
    response_time_ms: Optional[float] = None
    details: Optional[Dict[str, Any]] = None
    last_check: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "status": self.status.value,
            "message": self.message,
            "response_time_ms": self.response_time_ms,
            "details": self.details,
            "last_check": self.last_check.isoformat() if self.last_check else None,
        }


@dataclass
class HealthResponse:
    status: HealthStatus
    timestamp: datetime
    version: str
    uptime_seconds: float
    components: Dict[str, ComponentHealth]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "status": self.status.value,
            "timestamp": self.timestamp.isoformat(),
            "version": self.version,
            "uptime_seconds": self.uptime_seconds,
            "components": {
                name: comp.to_dict() for name, comp in self.components.items()
            },
        }


class HealthService:
    def __init__(
        self,
        connection_manager=None,
        scheduler=None,
        version="1.0.0",
        nats_publisher=None,
        data_pipeline_service=None,
    ):
        self.connection_manager = connection_manager
        self.scheduler = scheduler
        self.nats_publisher = nats_publisher
        self.data_pipeline_service = data_pipeline_service
        self.version = version
        self.start_time = time.time()
        self.logger = logging.getLogger(__name__)

    async def get_health_status(self) -> HealthResponse:
        """Get comprehensive health status of all system components"""
        components = {}
        overall_status = HealthStatus.HEALTHY

        # Check database health
        db_health = await self._check_database_health()
        components["database"] = db_health
        if db_health.status == HealthStatus.UNHEALTHY:
            overall_status = HealthStatus.UNHEALTHY
        elif (
            db_health.status == HealthStatus.DEGRADED
            and overall_status == HealthStatus.HEALTHY
        ):
            overall_status = HealthStatus.DEGRADED

        # Check NATS health
        nats_health = await self._check_nats_health()
        components["nats"] = nats_health
        if nats_health.status == HealthStatus.UNHEALTHY:
            overall_status = HealthStatus.UNHEALTHY
        elif (
            nats_health.status == HealthStatus.DEGRADED
            and overall_status == HealthStatus.HEALTHY
        ):
            overall_status = HealthStatus.DEGRADED

        # Check scheduler health
        scheduler_health = await self._check_scheduler_health()
        components["scheduler"] = scheduler_health
        if (
            scheduler_health.status == HealthStatus.DEGRADED
            and overall_status == HealthStatus.HEALTHY
        ):
            overall_status = HealthStatus.DEGRADED

        # Check system resources
        system_health = await self._check_system_health()
        components["system"] = system_health
        if (
            system_health.status == HealthStatus.DEGRADED
            and overall_status == HealthStatus.HEALTHY
        ):
            overall_status = HealthStatus.DEGRADED

        # Check message publisher health (DLQ and circuit breaker)
        publisher_health = await self._check_publisher_health()
        components["publisher"] = publisher_health
        if (
            publisher_health.status == HealthStatus.DEGRADED
            and overall_status == HealthStatus.HEALTHY
        ):
            overall_status = HealthStatus.DEGRADED

        # Check data quality monitoring
        quality_health = await self._check_data_quality_health()
        components["data_quality"] = quality_health
        if (
            quality_health.status == HealthStatus.DEGRADED
            and overall_status == HealthStatus.HEALTHY
        ):
            overall_status = HealthStatus.DEGRADED

        uptime = time.time() - self.start_time

        return HealthResponse(
            status=overall_status,
            timestamp=datetime.now(timezone.utc),
            version=self.version,
            uptime_seconds=uptime,
            components=components,
        )

    async def _check_database_health(self) -> ComponentHealth:
        """Check database connection and responsiveness"""
        if not self.connection_manager:
            return ComponentHealth(
                status=HealthStatus.UNHEALTHY,
                message="Database connection manager not available",
                last_check=datetime.now(timezone.utc),
            )

        start_time = time.time()
        try:
            pool = self.connection_manager.get_database_pool()
            if not pool:
                return ComponentHealth(
                    status=HealthStatus.UNHEALTHY,
                    message="Database pool not initialized",
                    last_check=datetime.now(timezone.utc),
                )

            # Test database connectivity with a simple query
            async with pool.acquire() as conn:
                await conn.fetchval("SELECT 1")

            response_time = (time.time() - start_time) * 1000

            if response_time > 5000:  # 5 seconds
                status = HealthStatus.DEGRADED
                message = "Database response time is slow"
            elif response_time > 1000:  # 1 second
                status = HealthStatus.DEGRADED
                message = "Database response time is elevated"
            else:
                status = HealthStatus.HEALTHY
                message = "Database is responsive"

            return ComponentHealth(
                status=status,
                message=message,
                response_time_ms=response_time,
                details={"pool_size": pool.get_size()},
                last_check=datetime.now(timezone.utc),
            )

        except Exception as e:
            self.logger.error(f"Database health check failed: {e}")
            return ComponentHealth(
                status=HealthStatus.UNHEALTHY,
                message=f"Database connection failed: {str(e)}",
                response_time_ms=(time.time() - start_time) * 1000,
                last_check=datetime.now(timezone.utc),
            )

    async def _check_nats_health(self) -> ComponentHealth:
        """Check NATS connection and JetStream status"""
        if not self.connection_manager:
            return ComponentHealth(
                status=HealthStatus.UNHEALTHY,
                message="Connection manager not available",
                last_check=datetime.now(timezone.utc),
            )

        start_time = time.time()
        try:
            nats_conn = self.connection_manager.get_nats_connection()
            js = self.connection_manager.get_jetstream_context()

            if not nats_conn:
                return ComponentHealth(
                    status=HealthStatus.UNHEALTHY,
                    message="NATS connection not initialized",
                    last_check=datetime.now(timezone.utc),
                )

            # Safely check connection status
            try:
                is_connected = nats_conn.is_connected
            except Exception:
                is_connected = False

            if not is_connected:
                return ComponentHealth(
                    status=HealthStatus.UNHEALTHY,
                    message="NATS connection is not established",
                    last_check=datetime.now(timezone.utc),
                )

            if not js:
                return ComponentHealth(
                    status=HealthStatus.DEGRADED,
                    message="JetStream context not available",
                    last_check=datetime.now(timezone.utc),
                )

            # Test JetStream by getting account info
            try:
                account_info = await js.account_info()
                response_time = (time.time() - start_time) * 1000

                return ComponentHealth(
                    status=HealthStatus.HEALTHY,
                    message="NATS and JetStream are healthy",
                    response_time_ms=response_time,
                    details={
                        "streams": account_info.streams,
                        "consumers": account_info.consumers,
                    },
                    last_check=datetime.now(timezone.utc),
                )
            except Exception as js_error:
                self.logger.warning(f"JetStream health check failed: {js_error}")
                return ComponentHealth(
                    status=HealthStatus.DEGRADED,
                    message=f"JetStream not responding: {str(js_error)}",
                    response_time_ms=(time.time() - start_time) * 1000,
                    last_check=datetime.now(timezone.utc),
                )

        except Exception as e:
            self.logger.error(f"NATS health check failed: {e}")
            return ComponentHealth(
                status=HealthStatus.UNHEALTHY,
                message=f"NATS connection failed: {str(e)}",
                response_time_ms=(time.time() - start_time) * 1000,
                last_check=datetime.now(timezone.utc),
            )

    async def _check_scheduler_health(self) -> ComponentHealth:
        """Check scheduler status and active jobs"""
        if not self.scheduler:
            return ComponentHealth(
                status=HealthStatus.DEGRADED,
                message="Scheduler not available",
                last_check=datetime.now(timezone.utc),
            )

        try:
            # Check if scheduler is running
            is_running = getattr(self.scheduler, "is_running", False)

            if not is_running:
                return ComponentHealth(
                    status=HealthStatus.DEGRADED,
                    message="Scheduler is not running",
                    last_check=datetime.now(timezone.utc),
                )

            # Get scheduler status if available
            active_jobs = 0
            if hasattr(self.scheduler, "get_jobs"):
                try:
                    jobs = self.scheduler.get_jobs()
                    active_jobs = len(jobs)
                except Exception:
                    pass

            return ComponentHealth(
                status=HealthStatus.HEALTHY,
                message="Scheduler is running",
                details={"active_jobs": active_jobs},
                last_check=datetime.now(timezone.utc),
            )

        except Exception as e:
            self.logger.error(f"Scheduler health check failed: {e}")
            return ComponentHealth(
                status=HealthStatus.DEGRADED,
                message=f"Scheduler status unknown: {str(e)}",
                last_check=datetime.now(timezone.utc),
            )

    async def _check_system_health(self) -> ComponentHealth:
        """Check system resources (CPU, memory, disk)"""
        if not PSUTIL_AVAILABLE:
            return ComponentHealth(
                status=HealthStatus.DEGRADED,
                message="System monitoring not available (psutil not installed)",
                last_check=datetime.now(timezone.utc),
            )

        try:
            # Get system metrics
            cpu_percent = psutil.cpu_percent(interval=0.1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage("/")

            # Determine status based on resource usage
            status = HealthStatus.HEALTHY
            warnings = []

            if cpu_percent > 90:
                status = HealthStatus.DEGRADED
                warnings.append(f"High CPU usage: {cpu_percent}%")
            elif cpu_percent > 80:
                if status == HealthStatus.HEALTHY:
                    status = HealthStatus.DEGRADED
                warnings.append(f"Elevated CPU usage: {cpu_percent}%")

            if memory.percent > 90:
                status = HealthStatus.DEGRADED
                warnings.append(f"High memory usage: {memory.percent}%")
            elif memory.percent > 80:
                if status == HealthStatus.HEALTHY:
                    status = HealthStatus.DEGRADED
                warnings.append(f"Elevated memory usage: {memory.percent}%")

            if disk.percent > 95:
                status = HealthStatus.DEGRADED
                warnings.append(f"High disk usage: {disk.percent}%")
            elif disk.percent > 85:
                if status == HealthStatus.HEALTHY:
                    status = HealthStatus.DEGRADED
                warnings.append(f"Elevated disk usage: {disk.percent}%")

            message = "System resources are healthy"
            if warnings:
                message = "; ".join(warnings)

            return ComponentHealth(
                status=status,
                message=message,
                details={
                    "cpu_percent": cpu_percent,
                    "memory_percent": memory.percent,
                    "disk_percent": disk.percent,
                    "memory_available_gb": round(memory.available / (1024**3), 2),
                    "disk_free_gb": round(disk.free / (1024**3), 2),
                },
                last_check=datetime.now(timezone.utc),
            )

        except Exception as e:
            self.logger.error(f"System health check failed: {e}")
            return ComponentHealth(
                status=HealthStatus.DEGRADED,
                message=f"System health check failed: {str(e)}",
                last_check=datetime.now(timezone.utc),
            )

    async def is_ready(self) -> bool:
        """Simple readiness check - are critical components available?"""
        health = await self.get_health_status()

        # Service is ready if database and NATS are at least degraded (not unhealthy)
        db_ok = (
            health.components.get(
                "database", ComponentHealth(HealthStatus.UNHEALTHY)
            ).status
            != HealthStatus.UNHEALTHY
        )
        nats_ok = (
            health.components.get(
                "nats", ComponentHealth(HealthStatus.UNHEALTHY)
            ).status
            != HealthStatus.UNHEALTHY
        )

        return db_ok and nats_ok

    async def is_alive(self) -> bool:
        """Simple liveness check - is the application responsive?"""
        try:
            # Basic responsiveness test
            await asyncio.sleep(0.001)
            return True
        except Exception as e:
            self.logger.error(f"Liveness check failed: {e}")
            return False

    async def _check_publisher_health(self) -> ComponentHealth:
        """Check NATS publisher health including DLQ and circuit breaker status"""
        if not self.nats_publisher:
            return ComponentHealth(
                status=HealthStatus.DEGRADED,
                message="Publisher not available",
                last_check=datetime.now(timezone.utc),
            )

        try:
            metrics = self.nats_publisher.get_metrics()

            status = HealthStatus.HEALTHY
            warnings = []

            # Check circuit breaker status
            if metrics.get("circuit_breaker_open", False):
                status = HealthStatus.DEGRADED
                warnings.append("Circuit breaker is open")

            # Check failure rates
            total_attempts = metrics.get("published_count", 0) + metrics.get(
                "failed_count", 0
            )
            if total_attempts > 0:
                failure_rate = metrics.get("failed_count", 0) / total_attempts
                if failure_rate > 0.1:  # 10% failure rate
                    status = HealthStatus.DEGRADED
                    warnings.append(f"High failure rate: {failure_rate:.1%}")

            # Check DLQ usage
            dlq_count = metrics.get("dlq_count", 0)
            if dlq_count > 50:  # More than 50 messages in DLQ
                status = HealthStatus.DEGRADED
                warnings.append(f"High DLQ usage: {dlq_count} messages")

            # Check dropped messages
            dropped_count = metrics.get("dropped_count", 0)
            if dropped_count > 0:
                status = HealthStatus.DEGRADED
                warnings.append(f"Messages dropped: {dropped_count}")

            message = "Publisher is healthy"
            if warnings:
                message = "; ".join(warnings)

            return ComponentHealth(
                status=status,
                message=message,
                details={
                    "published_count": metrics.get("published_count", 0),
                    "failed_count": metrics.get("failed_count", 0),
                    "dlq_count": metrics.get("dlq_count", 0),
                    "dropped_count": metrics.get("dropped_count", 0),
                    "circuit_breaker_open": metrics.get("circuit_breaker_open", False),
                    "failure_count": metrics.get("failure_count", 0),
                },
                last_check=datetime.now(timezone.utc),
            )

        except Exception as e:
            self.logger.error(f"Publisher health check failed: {e}")
            return ComponentHealth(
                status=HealthStatus.DEGRADED,
                message=f"Publisher health check failed: {str(e)}",
                last_check=datetime.now(timezone.utc),
            )

    async def _check_data_quality_health(self) -> ComponentHealth:
        """Check data quality monitoring health"""
        if not self.data_pipeline_service:
            return ComponentHealth(
                status=HealthStatus.DEGRADED,
                message="Data pipeline service not available",
                last_check=datetime.now(timezone.utc),
            )

        try:
            quality_monitor = self.data_pipeline_service.get_quality_monitor()
            metrics = quality_monitor.get_quality_metrics()

            status = HealthStatus.HEALTHY
            warnings = []

            # Check average quality score
            avg_quality = metrics.get("average_quality_score", 1.0)
            if avg_quality < 0.8:
                status = HealthStatus.DEGRADED
                warnings.append(f"Low average quality score: {avg_quality:.1%}")
            elif avg_quality < 0.95:
                if status == HealthStatus.HEALTHY:
                    status = HealthStatus.DEGRADED
                warnings.append(f"Moderate quality score: {avg_quality:.1%}")

            # Check critical issues
            critical_issues = metrics.get("critical_issues", 0)
            if critical_issues > 0:
                status = HealthStatus.DEGRADED
                warnings.append(f"Critical quality issues: {critical_issues}")

            # Check error issues
            error_issues = metrics.get("error_issues", 0)
            if error_issues > 5:  # More than 5 error issues
                status = HealthStatus.DEGRADED
                warnings.append(f"High error count: {error_issues}")

            message = "Data quality monitoring is healthy"
            if warnings:
                message = "; ".join(warnings)

            return ComponentHealth(
                status=status,
                message=message,
                details={
                    "total_reports": metrics.get("total_reports", 0),
                    "recent_reports": metrics.get("recent_reports", 0),
                    "average_quality_score": avg_quality,
                    "critical_issues": critical_issues,
                    "error_issues": error_issues,
                    "warning_issues": metrics.get("warning_issues", 0),
                },
                last_check=datetime.now(timezone.utc),
            )

        except Exception as e:
            self.logger.error(f"Data quality health check failed: {e}")
            return ComponentHealth(
                status=HealthStatus.DEGRADED,
                message=f"Data quality health check failed: {str(e)}",
                last_check=datetime.now(timezone.utc),
            )
