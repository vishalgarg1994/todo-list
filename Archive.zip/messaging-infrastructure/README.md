# 🚀 Eva Messaging Infrastructure

**Enterprise-grade messaging backbone for Eva platform applications**

[![NATS](https://img.shields.io/badge/NATS-JetStream-blue)](https://nats.io/)
[![Docker](https://img.shields.io/badge/Docker-Compose-blue)](https://docs.docker.com/compose/)
[![Status](https://img.shields.io/badge/Status-Production%20Ready-green)](/)

## 🎯 Overview

Eva Messaging Infrastructure provides **centralized messaging services** that Eva applications connect to as clients, similar to a shared database service. This design enables:

- **🔄 Loose coupling** between applications
- **📈 Horizontal scaling** of individual services
- **🛡️ Enterprise resilience** with message persistence
- **📊 Centralized monitoring** and operations

```mermaid
graph TB
    subgraph "Eva Applications"
        A[Ticketing App<br/>Port: 8080]
        B[Analytics App<br/>(Future)]
        C[Audit App<br/>(Future)]
    end

    subgraph "Eva Messaging Infrastructure"
        D[NATS JetStream<br/>Port: 4222]
        E[Web Monitor<br/>Port: 8222]
        F[Message UI<br/>Port: 3001]
    end

    A --> D
    B --> D
    C --> D

    D --> E
    D --> F

    style A fill:#e1f5fe
    style D fill:#f3e5f5
    style E fill:#fff3e0
    style F fill:#fff3e0
```

## 🏗️ **Deployment Options**

### **🐳 Docker Compose (Development)**
Quick local development and testing:

```bash
# Start infrastructure
docker-compose up -d

# Access services
# NATS Monitor: http://localhost:8222
# Message UI: http://localhost:3001
# NATS Server: nats://localhost:4222
```

### **☸️ Kubernetes (Production)**
Enterprise-grade production deployment:

```bash
# Deploy to development
cd helm && ./deploy.sh dev

# Deploy to production
cd helm && ./deploy.sh prod --upgrade
```

📚 **[Complete Kubernetes Guide →](KUBERNETES.md)**

---

## Services

### NATS with JetStream
- **Purpose**: High-performance, persistent messaging
- **Use Cases**: Event streaming, microservice communication
- **Features**: Message persistence, delivery guarantees, stream replay
- **Status**: ✅ Available

### Redis (Planned)
- **Purpose**: Caching, session storage, pub/sub
- **Use Cases**: Real-time notifications, caching
- **Status**: 🚧 Planned

### Apache Kafka (Planned)  
- **Purpose**: High-throughput event streaming
- **Use Cases**: Data pipelines, analytics feeds
- **Status**: 🚧 Planned

## ⚡ Quick Start

### 🚀 Step 1: Start Eva Infrastructure
```bash
# From messaging-infrastructure project directory
docker compose up -d

# Streams are automatically initialized on startup
# (eva-stream-init container runs once and exits)
```

### 🔗 Step 2: Verify Infrastructure
```bash
# Check NATS is running
curl http://localhost:8222/varz

# List created streams
docker exec eva-nats nats stream list
```

### 🎛️ Step 3: Access UIs and APIs
- **Stream Management API**: http://localhost:8080/docs (Swagger UI)
- **NATS Monitor**: http://localhost:8222 (infrastructure health)
- **Message Viewer**: http://localhost:3001 (real-time streaming - optional)
- **Connection Test**: `nats --server=nats://localhost:4222 server ping`

### 📱 Step 4: Connect Your Application
```bash
# Application environment variables
NATS_URL=nats://localhost:4222
# Publisher (ticketing_etl, stream-manager)
NATS_PUBLISHER_USER=ticket-app
NATS_PUBLISHER_PASSWORD=ticket-app-2024
# Consumer (mcp_ticket)
NATS_CONSUMER_USER=mcp-consumer
NATS_CONSUMER_PASSWORD=changeme-consumer
JETSTREAM_STREAM_NAME=EVA_TICKETING_STREAM
```

### 🧪 Step 5: Test Integration
```bash
# Send test message
nats --server=nats://localhost:4222 \
     --user=ticket-app \
     --password=ticket-app-2024 \
     pub tickets.test '{"test": "message", "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'"}'

# View in UI: http://localhost:3001
```

## Directory Structure

```
messaging-infrastructure/
├── README.md                 # This file
├── INTEGRATION_GUIDE.md      # Application integration guide
├── NATS_SEPARATION_PLAN.md   # Enterprise separation documentation
├── SESSION_HISTORY.md        # Implementation history
├── nats/                     # NATS service
│   ├── docker-compose.yml    # NATS deployment
│   ├── config/              # NATS configuration
│   ├── scripts/             # Management scripts
│   └── docs/                # NATS documentation
├── simple-ui/               # Message viewer UI
│   ├── docker-compose.yml   # UI deployment
│   ├── server.js            # Backend server
│   ├── public/              # Frontend assets
│   └── README.md            # UI documentation
├── redis/                   # Redis service (future)
├── kafka/                   # Kafka service (future)
└── monitoring/              # Cross-service monitoring
```

## 🔧 Environment Configuration

| Component | Port | Purpose | Access URL | Status |
|-----------|------|---------|------------|--------|
| **NATS Client** | 4222 | Application connections | `nats://localhost:4222` | ✅ Active |
| **Stream Management API** | 8080 | REST API with Swagger | `http://localhost:8080/docs` | ✅ Active |
| **NATS Monitor** | 8222 | Web UI and monitoring | `http://localhost:8222` | ✅ Active |
| **Message Viewer** | 3001 | Real-time message UI | `http://localhost:3001` | 🔄 Optional |
| **NATS Cluster** | 6222 | Inter-node communication | Internal only | 🚧 HA Ready |

### 📋 Pre-configured Streams

| Stream Name | Subjects | Retention | Purpose |
|-------------|----------|-----------|---------|
| `EVA_TICKETING_STREAM` | `tickets.*`, `incidents.*`, `maintenance.*` | 72 hours | Ticketing events |
| `EVA_ANALYTICS_STREAM` | `analytics.*`, `metrics.*`, `reports.*` | 30 days | Business intelligence |

### 🔐 Authentication

| Environment | User | Password | TLS |
|-------------|------|----------|-----|
| **Development** | `ticket-app` | `ticket-app-2024` | ❌ Disabled |
| **Production** | Certificate-based | - | ✅ Required |

## Production Deployment

### Docker Compose
- Development: Single-node deployments
- Production: Use Kubernetes or Docker Swarm for HA

### Security
- Authentication and authorization configured per service
- TLS encryption for production deployments
- Network segmentation and firewall rules

### Monitoring
- Centralized monitoring across all messaging services
- Grafana dashboards and Prometheus metrics
- Health checks and alerting

## 🛠️ Troubleshooting

### Common Issues

#### 🔴 "Connection refused" errors
```bash
# Check if NATS is running
docker ps | grep eva-nats

# Restart infrastructure
docker-compose down && docker-compose up -d

# Check logs
docker logs eva-nats
```

#### 🟡 "Stream not found" errors
```bash
# Restart infrastructure (stream-init will auto-create streams)
docker compose restart

# Or manually run init script
./nats/scripts/init-streams.sh

# Verify streams exist
nats --server=nats://localhost:4222 stream list
```

#### 🟠 Messages not appearing in UI
```bash
# Check message viewer is running
curl http://localhost:3001/api/health

# Restart message viewer
docker-compose restart simple-ui
```

#### 🔵 Authentication failures
```bash
# Test connection with credentials
nats --server=nats://localhost:4222 \
     --user=ticket-app \
     --password=ticket-app-2024 \
     server ping
```

### Health Checks

```bash
# Infrastructure health
curl http://localhost:8222/healthz

# Stream health
nats stream report

# Message flow test
nats pub test.message "Hello Eva" && \
nats sub test.message --count=1
```

### Performance Monitoring

```bash
# Connection stats
curl http://localhost:8222/connz

# Message rates
curl http://localhost:8222/jsz

# Memory usage
curl http://localhost:8222/varz | jq '.mem'
```

## 📚 Documentation

### Architecture & Design
| Guide | Purpose | Audience |
|-------|---------|----------|
| [Architecture Overview](docs/architecture.md) | System design and components | Architects, Developers |
| [Maturity Assessment](docs/maturity-assessment.md) | Production readiness evaluation | Operations, Management |
| [API Reference](docs/api-reference.md) | Complete API documentation | Developers |

### Integration & Operations
| Guide | Purpose | Audience |
|-------|---------|----------|
| [Integration Guide](INTEGRATION_GUIDE.md) | Connect applications to Eva | Developers |
| [Naming Conventions](NAMING_CONVENTIONS.md) | Message subject patterns | Developers |
| [Simple UI README](simple-ui/README.md) | Message viewer setup | Operators |

## 🤝 Contributing

1. Each service should be self-contained in its own directory
2. Follow established patterns for configuration and documentation
3. Include health checks and monitoring for all services
4. Provide both development and production deployment options
5. Update this README when adding new services or features

## 📞 Support

For questions about Eva messaging infrastructure:

- **🐛 Issues**: Create an issue in this repository
- **📖 NATS Documentation**: See `nats/docs/` directory
- **🔧 Integration Help**: See [INTEGRATION_GUIDE.md](INTEGRATION_GUIDE.md)
- **💬 General Questions**: Contact the Eva platform team

---

**🎉 Eva Messaging Infrastructure - Connecting Eva applications with enterprise-grade messaging!**