"""
Unit tests for Ollama Embedding Service
"""
import pytest
from unittest.mock import Mock, patch
from services.embedding_service import EmbeddingService


class TestEmbeddingService:
    """Test suite for EmbeddingService"""

    @pytest.fixture
    def service(self, mock_config):
        """Create EmbeddingService instance with complete mock config"""
        return EmbeddingService(mock_config)

    @pytest.fixture
    def mock_embedding_response(self):
        """Mock successful embedding response from Ollama"""
        return {
            "embedding": [0.1] * 768  # 768-dim vector
        }

    def test_initialization(self, service, mock_config):
        """Test service initialization"""
        assert service.base_url == mock_config.ollama_embedding_base_url
        assert service.model == mock_config.ollama_embedding_model
        assert service.embedding_endpoint == f"{mock_config.ollama_embedding_base_url}/api/embeddings"
        assert service.timeout == mock_config.ollama_embedding_timeout
        assert service.max_concurrent == mock_config.ollama_max_concurrent

    @patch('services.embedding_service.requests.post')
    def test_generate_embedding_success(self, mock_post, service, mock_embedding_response):
        """Test successful embedding generation"""
        # Setup mock
        mock_response = Mock()
        mock_response.json.return_value = mock_embedding_response
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response

        # Test
        text = "Fiber cable cut at Main Street"
        embedding = service.generate_embedding(text)

        # Verify
        assert embedding is not None
        assert len(embedding) == 768
        assert all(isinstance(x, float) for x in embedding)
        mock_post.assert_called_once()

    @patch('services.embedding_service.requests.post')
    def test_generate_embedding_truncates_long_text(self, mock_post, service, mock_embedding_response):
        """Test that long text is truncated to 25K chars"""
        # Setup mock
        mock_response = Mock()
        mock_response.json.return_value = mock_embedding_response
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response

        # Test with very long text
        long_text = "Network outage. " * 2000  # ~34K chars
        embedding = service.generate_embedding(long_text)

        # Verify
        assert embedding is not None
        # Check that the text passed to API was truncated
        call_args = mock_post.call_args
        sent_text = call_args[1]['json']['prompt']
        assert len(sent_text) <= 25000

    @patch('services.embedding_service.requests.post')
    def test_generate_embedding_no_embedding_in_response(self, mock_post, service):
        """Test handling of response without embedding"""
        # Setup mock with invalid response
        mock_response = Mock()
        mock_response.json.return_value = {"error": "something went wrong"}
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response

        # Test
        embedding = service.generate_embedding("test")

        # Verify
        assert embedding is None

    @patch('services.embedding_service.requests.post')
    def test_generate_embedding_wrong_dimension(self, mock_post, service):
        """Test handling of embedding with wrong dimension"""
        # Setup mock with wrong dimension
        mock_response = Mock()
        mock_response.json.return_value = {"embedding": [0.1] * 512}  # Wrong dimension
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response

        # Test
        embedding = service.generate_embedding("test")

        # Verify
        assert embedding is None

    @patch('services.embedding_service.requests.post')
    def test_generate_embedding_timeout(self, mock_post, service):
        """Test handling of timeout"""
        import requests

        # Setup mock to raise timeout
        mock_post.side_effect = requests.exceptions.Timeout()

        # Test
        embedding = service.generate_embedding("test")

        # Verify
        assert embedding is None

    @patch('services.embedding_service.requests.post')
    def test_generate_embedding_http_error(self, mock_post, service):
        """Test handling of HTTP error"""
        import requests

        # Setup mock to raise HTTP error
        mock_post.side_effect = requests.exceptions.RequestException("Connection failed")

        # Test
        embedding = service.generate_embedding("test")

        # Verify
        assert embedding is None

    @pytest.mark.asyncio
    @patch('services.embedding_service.requests.post')
    async def test_generate_embeddings_batch(self, mock_post, service, mock_embedding_response):
        """Test batch embedding generation"""
        # Setup mock
        mock_response = Mock()
        mock_response.json.return_value = mock_embedding_response
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response

        # Test
        texts = [
            "Fiber outage at location A",
            "BGP session down",
            "High latency detected"
        ]
        embeddings = await service.generate_embeddings_batch(texts, batch_size=2)

        # Verify
        assert len(embeddings) == 3
        assert all(emb is not None for emb in embeddings)
        assert all(len(emb) == 768 for emb in embeddings)
        assert mock_post.call_count == 3  # One call per text

    @pytest.mark.asyncio
    @patch('services.embedding_service.requests.post')
    async def test_generate_embeddings_batch_partial_failure(self, mock_post, service, mock_embedding_response):
        """Test batch processing with some failures"""
        # Setup mock to succeed twice, fail once
        mock_response_success = Mock()
        mock_response_success.json.return_value = mock_embedding_response
        mock_response_success.raise_for_status = Mock()

        import requests
        mock_post.side_effect = [
            mock_response_success,
            requests.exceptions.Timeout(),  # Second one fails
            mock_response_success
        ]

        # Test
        texts = ["text1", "text2", "text3"]
        embeddings = await service.generate_embeddings_batch(texts, batch_size=10)

        # Verify - due to parallel processing with asyncio.gather,
        # the exact position of failures may vary
        assert len(embeddings) == 3
        successful = [e for e in embeddings if e is not None]
        failed = [e for e in embeddings if e is None]
        assert len(successful) == 2, f"Expected 2 successful, got {len(successful)}"
        assert len(failed) == 1, f"Expected 1 failed, got {len(failed)}"

    @patch('services.embedding_service.requests.post')
    def test_test_connection_success(self, mock_post, service, mock_embedding_response):
        """Test successful connection test"""
        # Setup mock
        mock_response = Mock()
        mock_response.json.return_value = mock_embedding_response
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response

        # Test
        result = service.test_connection()

        # Verify
        assert result is True

    @patch('services.embedding_service.requests.post')
    def test_test_connection_failure(self, mock_post, service):
        """Test failed connection test"""
        import requests

        # Setup mock to fail
        mock_post.side_effect = requests.exceptions.RequestException("Connection failed")

        # Test
        result = service.test_connection()

        # Verify
        assert result is False

    @patch('services.embedding_service.requests.get')
    def test_get_model_info_success(self, mock_get, service):
        """Test successful model info retrieval"""
        # Setup mock - model name must match service.model base name
        # mock_config sets model to "telecom-nomic-embed:latest"
        mock_response = Mock()
        mock_response.json.return_value = {
            "models": [
                {
                    "name": "telecom-nomic-embed:latest",
                    "size": 147000000,
                    "modified_at": "2025-10-20T10:00:00Z"
                }
            ]
        }
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response

        # Test
        info = service.get_model_info()

        # Verify - should return first match
        assert info["name"] == "telecom-nomic-embed:latest"
        assert info["size"] == 147000000
        assert info["modified_at"] == "2025-10-20T10:00:00Z"

    @patch('services.embedding_service.requests.get')
    def test_get_model_info_not_found(self, mock_get, service):
        """Test model info when model not found"""
        # Setup mock
        mock_response = Mock()
        mock_response.json.return_value = {"models": []}
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response

        # Test
        info = service.get_model_info()

        # Verify
        assert info["status"] == "not_loaded"

    @patch('services.embedding_service.requests.get')
    def test_get_model_info_error(self, mock_get, service):
        """Test model info retrieval error"""
        import requests

        # Setup mock to fail
        mock_get.side_effect = requests.exceptions.RequestException("Connection failed")

        # Test
        info = service.get_model_info()

        # Verify
        assert "error" in info
