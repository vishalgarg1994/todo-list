"""
Test configuration management for Eva NATS Stream Manager
"""

import pytest
import os
from unittest.mock import patch
import sys
from pathlib import Path

# Add stream-manager directory to path so we can import config
sys.path.append(str(Path(__file__).parent.parent / "stream-manager"))

from config import Config


class TestConfig:
    """Test configuration loading and validation"""

    def test_config_initialization(self):
        """Test that Config can be initialized without errors"""
        config = Config()
        assert config is not None

    def test_get_nats_url_default(self):
        """Test NATS URL returns a default value"""
        config = Config()
        nats_url = config.get_nats_url()
        assert nats_url is not None
        assert isinstance(nats_url, str)
        assert "nats://" in nats_url

    @patch.dict(os.environ, {'NATS_URL': 'nats://test-server:4222'})
    def test_get_nats_url_from_env(self):
        """Test NATS URL can be set from environment variable"""
        config = Config()
        nats_url = config.get_nats_url()
        assert nats_url == 'nats://test-server:4222'

    @patch.dict(os.environ, {
        'NATS_URL': 'nats://eva-cluster:4222',
        'NATS_PUBLISHER_USER': 'test-user',
        'NATS_PUBLISHER_PASSWORD': 'test-pass'
    })
    def test_environment_variables_loaded(self):
        """Test that environment variables are properly loaded"""
        config = Config()

        # Test NATS URL
        assert config.get_nats_url() == 'nats://eva-cluster:4222'

        # Test other config methods exist and return reasonable values
        assert hasattr(config, 'load_config')

    def test_config_attributes_exist(self):
        """Test that essential config methods exist"""
        config = Config()

        # Check that essential methods exist
        assert hasattr(config, 'get_nats_url')
        assert hasattr(config, 'load_config')
        assert callable(config.get_nats_url)
        assert callable(config.load_config)