"""
Data Extractor - Queries CMD and TSM tables, merges in Python

UNION approach:
- CMD can exist without TSM (core network tickets)
- TSM can exist without CMD
- When both exist, merge TSM + CMD enrichment

Since we cannot JOIN at the database level, this module:
1. Queries ALL CMD records
2. Queries each TSM table separately
3. Returns all data for Python-side merging
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime


class Extractor:
    """Extracts data from CMD and TSM tables"""

    def __init__(self, db_pool):
        self.db_pool = db_pool
        self.logger = logging.getLogger(__name__)

    async def extract_all(self, since: Optional[datetime] = None) -> Dict[str, Any]:
        """
        Extract ALL CMD records and ALL TSM records

        Args:
            since: Optional datetime filter for incremental loads (uses updated_on)

        Returns:
            Dict with keys:
                - cmd_records: all CMD records
                - cmd_by_sys_id: CMD indexed by servicenow_task_sys_id
                - incidents, cases, problems, requests: TSM records
                - changes: TSM change records (infrastructure-level, no client_id)
                - incident_tasks, case_tasks, problem_tasks, change_tasks: TSM task records
                - tsm_by_sys_id: TSM indexed by sys_id (for dedup)
                - ci_services, ci_by_task_sys_id: CI mappings
                - case_tasks_by_case, change_tasks_by_change: task lookups
        """
        self.logger.info(f"Extracting data since: {since}")

        # Query ALL CMD records
        cmd_records = await self._query_all_cmd(since)

        # Index CMD by sys_id for fast lookup
        cmd_by_sys_id = {
            row["servicenow_task_sys_id"]: row
            for row in cmd_records
            if row.get("servicenow_task_sys_id")
        }

        # Query all TSM tables (client-centric)
        incidents = await self._query_incidents(since)
        cases = await self._query_cases(since)
        problems = await self._query_problems(since)
        requests = await self._query_requests(since)

        # Query TSM tasks
        incident_tasks = await self._query_incident_tasks(since)
        case_tasks = await self._query_case_tasks(since)
        problem_tasks = await self._query_problem_tasks(since)
        change_tasks = await self._query_change_tasks(since)

        # Query infrastructure-level changes (no client_id - separate stream)
        changes = await self._query_changes(since)

        # Query CI service mappings (ticket to configuration item)
        ci_services = await self._query_ci_services(since)

        # Index TSM by sys_id for dedup check
        tsm_by_sys_id: Dict[str, Dict[str, Any]] = {}
        for inc in incidents:
            if inc.get("incident_sys_id"):
                tsm_by_sys_id[inc["incident_sys_id"]] = {
                    "type": "incident",
                    "data": inc,
                }
        for case in cases:
            if case.get("case_sys_id"):
                tsm_by_sys_id[case["case_sys_id"]] = {"type": "case", "data": case}
        for prob in problems:
            if prob.get("problem_sys_id"):
                tsm_by_sys_id[prob["problem_sys_id"]] = {
                    "type": "problem",
                    "data": prob,
                }
        for req in requests:
            if req.get("req_task_sys_id"):
                tsm_by_sys_id[req["req_task_sys_id"]] = {"type": "request", "data": req}

        # Index CI services by task_sys_id (one ticket can have multiple CIs)
        ci_by_task_sys_id: Dict[str, List[Dict[str, Any]]] = {}
        for ci in ci_services:
            task_sys_id = ci.get("task_sys_id")
            if task_sys_id:
                if task_sys_id not in ci_by_task_sys_id:
                    ci_by_task_sys_id[task_sys_id] = []
                ci_by_task_sys_id[task_sys_id].append(ci)

        # Index case tasks by parent_case_sys_id
        case_tasks_by_case: Dict[str, List[Dict[str, Any]]] = {}
        for task in case_tasks:
            parent_sys_id = task.get("parent_case_sys_id")
            if parent_sys_id:
                if parent_sys_id not in case_tasks_by_case:
                    case_tasks_by_case[parent_sys_id] = []
                case_tasks_by_case[parent_sys_id].append(task)

        # Index change tasks by change_sys_id
        change_tasks_by_change: Dict[str, List[Dict[str, Any]]] = {}
        for task in change_tasks:
            change_sys_id = task.get("change_sys_id")
            if change_sys_id:
                if change_sys_id not in change_tasks_by_change:
                    change_tasks_by_change[change_sys_id] = []
                change_tasks_by_change[change_sys_id].append(task)

        self.logger.info(
            f"Extracted: {len(cmd_records)} CMD, "
            f"{len(incidents)} incidents, {len(cases)} cases, "
            f"{len(problems)} problems, {len(requests)} requests, "
            f"{len(changes)} changes, "
            f"{len(incident_tasks)} inc_tasks, {len(case_tasks)} case_tasks, "
            f"{len(problem_tasks)} prob_tasks, {len(change_tasks)} chg_tasks, "
            f"{len(ci_services)} ci_services"
        )

        return {
            # CMD records
            "cmd_records": cmd_records,
            "cmd_by_sys_id": cmd_by_sys_id,
            # TSM client-centric records
            "incidents": incidents,
            "cases": cases,
            "problems": problems,
            "requests": requests,
            # TSM infrastructure records (no client_id)
            "changes": changes,
            # TSM tasks
            "incident_tasks": incident_tasks,
            "case_tasks": case_tasks,
            "problem_tasks": problem_tasks,
            "change_tasks": change_tasks,
            # Lookups
            "tsm_by_sys_id": tsm_by_sys_id,
            "ci_services": ci_services,
            "ci_by_task_sys_id": ci_by_task_sys_id,
            "case_tasks_by_case": case_tasks_by_case,
            "change_tasks_by_change": change_tasks_by_change,
        }

    async def _query_all_cmd(self, since: Optional[datetime]) -> List[Dict[str, Any]]:
        """Query ALL servicenow_cmd_ticket records"""
        query = """
            SELECT
                servicenow_task_sys_id, ticket_id,
                -- Core fields
                client_id, client_name, client_group, client_tier,
                channel, sales_division, market_segment,
                ticket_status, ticket_substatus, priority,
                short_description, ticket_category, subcategory,
                created_on, updated_on, closed_on,
                created_by, closed_by, closed_by_id,
                assigned_to, assigned_to_id,
                is_worked_ticket,
                -- Fault info
                fault_description, fault_occured_date, is_customer_impacting,
                rfo, ticket_rfo_group,
                -- Outage info
                mttr, internal_mttr, outage_duration,
                resolution, customer_resolution, closure_quality,
                service_restored_date,
                first_email_from_customer_on, first_customer_note_on,
                first_supplier_dispatch_event_on, first_tech_dispatch_event_on,
                -- Vendor info
                vendor_id, vendor, vendor_downtime,
                -- Maintenance window
                pw_start, pw_end, pw_duration, pw_location, pw_reason,
                -- Survey info
                score_id, score_reason, survey_score, survey_created_on, survey_ref,
                -- User roles
                incident_manager, incident_manager_id,
                operations_specialist, operations_specialist_id,
                service_desk_engineer, tier2_engineer,
                -- Other
                technology, ci_sys_id, related_circuit_id,
                default_noc, default_noc_queue
            FROM rds.servicenow_cmd_ticket
        """
        if since:
            query += " WHERE updated_on >= $1"
            return await self._execute_query(query, since)
        return await self._execute_query(query)

    async def _query_incidents(self, since: Optional[datetime]) -> List[Dict[str, Any]]:
        """Query snow_tsm_incident table"""
        query = """
            SELECT
                incident_sys_id, incident_number, short_description, description,
                category, subcategory, ci_sys_id, ci_class, ci_name,
                is_customer_impacted, customer_ticket_reference,
                customer_sys_id, customer_name, escalation_level, support_area,
                channel, created_on, created_by, incident_state,
                priority_number, priority, assigned_to_sys_id, is_worked_ticket,
                assignment_group, default_assignment_group, assigned_to,
                due_date, resolved_at, closed_on, closed_by, closed_by_sys_id,
                close_code, customer_close_notes, hold_reason,
                major_incident_state, parent_incident_number, tags, updated_on,
                internal_resolution_note, responsible_party, circuit_id,
                client_id, client_name, customer_group, time_worked_minutes,
                is_stranded, caused_by_change_sys_id, caused_by_change_number,
                related_change_sys_id, related_change_number,
                related_problem_sys_id, related_problem_number,
                related_parent_incident_sys_id, related_parent_incident_number,
                cause, business_impact
            FROM eds.snow_tsm_incident
        """
        if since:
            query += " WHERE updated_on >= $1"
            return await self._execute_query(query, since)
        return await self._execute_query(query)

    async def _query_cases(self, since: Optional[datetime]) -> List[Dict[str, Any]]:
        """Query snow_tsm_case table"""
        query = """
            SELECT
                case_sys_id, case_number, contact_type,
                incident_sys_id, incident_number,
                parent_sys_id, parent_number,
                problem_sys_id, problem_number,
                customer_sys_id, client_id, client_name,
                customer_ticket_reference, description, short_description,
                case_state, assigned_to_sys_id, assigned_to, assigned_on,
                assignment_group, default_assignment_group,
                escalation_number, escalation, priority_number, priority,
                needs_attention, is_worked_ticket, created_on, updated_on, closed_on,
                ci_sys_id, ci_class, ci_name, circuit_id, segment_id,
                related_circuit_id, sys_tags, time_worked_minutes,
                created_by, case_type, snow_release_name,
                category, subcategory, sub_state, due_date,
                caused_by_change_sys_id, caused_by_change_number,
                reassignment_count, first_response_time, is_customer_updated,
                contact_name, contact_sys_id,
                internal_resolution_notes, resolution_code,
                adjusted_business_elapsed_time, responsible_party, close_notes,
                closed_by_sys_id, closed_by
            FROM eds.snow_tsm_case
        """
        if since:
            query += " WHERE updated_on >= $1"
            return await self._execute_query(query, since)
        return await self._execute_query(query)

    async def _query_problems(self, since: Optional[datetime]) -> List[Dict[str, Any]]:
        """Query snow_tsm_problem table"""
        query = """
            SELECT
                problem_sys_id, problem_number, short_description, description,
                category, subcategory, ci_sys_id, ci_class, ci_name,
                circuit_id, segment_id, assigned_to_sys_id, assigned_to,
                assignment_group, default_assignment_group,
                problem_state, is_on_hold, on_hold_reason,
                priority_number, priority, problem_source, problem_type,
                problem_duration, problem_duration_minutes,
                responsible_party, resolution_code,
                created_on, updated_on, closed_on, fixed_on,
                customer_ticket_reference, tags, is_worked_ticket,
                due_date, created_by, closed_by, closed_by_sys_id,
                customer_name, customer_sys_id,
                internal_fix_notes, fix_notes, is_customer_visible,
                client_id, customer_group, time_worked_minutes,
                first_reported_by_task_sys_id, first_reported_by_task_number
            FROM eds.snow_tsm_problem
        """
        if since:
            query += " WHERE updated_on >= $1"
            return await self._execute_query(query, since)
        return await self._execute_query(query)

    async def _query_requests(self, since: Optional[datetime]) -> List[Dict[str, Any]]:
        """Query snow_tsm_request table"""
        query = """
            SELECT
                req_task_sys_id, req_task_number, channel,
                case_sys_id, case_number,
                req_item_sys_id, req_item_number, req_sys_id, req_number,
                request_item_name, request_item_form, request_item_type,
                req_task_state, pending_reason,
                priority_number, priority,
                description, short_description,
                created_on, created_by,
                assigned_to_sys_id, assigned_to,
                assignment_group, default_assignment_group,
                is_worked_ticket, due_date,
                actual_work_start, actual_work_end,
                updated_on, closed_on, closed_by_sys_id, closed_by,
                resolution_code, responsible_party,
                internal_close_notes, close_notes,
                req_task_class, req_task_tags,
                customer_sys_id, customer_name, customer_ticket_reference,
                client_id, client_name, customer_group,
                ci_sys_id, ci_name, ci_class,
                circuit_id, segment_id,
                resolve_time, time_worked_minutes
            FROM eds.snow_tsm_request
        """
        if since:
            query += " WHERE updated_on >= $1"
            return await self._execute_query(query, since)
        return await self._execute_query(query)

    async def _query_incident_tasks(
        self, since: Optional[datetime]
    ) -> List[Dict[str, Any]]:
        """Query snow_tsm_incident_task table"""
        query = """
            SELECT
                incident_task_sys_id, incident_task_number,
                incident_sys_id, incident_number,
                description, short_description, support_area,
                incident_task_type, incident_task_state, pending_reason,
                created_on, created_by, assignment_group,
                assigned_to_sys_id, assigned_to,
                updated_on, closed_on, closed_by_sys_id, closed_by,
                responsible_party, closure_code,
                priority_number, priority, escalation_level, is_worked_ticket,
                third_party_name, third_party_ticket, vendor_id,
                tags, time_worked_minutes
            FROM eds.snow_tsm_incident_task
        """
        if since:
            query += " WHERE updated_on >= $1"
            return await self._execute_query(query, since)
        return await self._execute_query(query)

    async def _query_problem_tasks(
        self, since: Optional[datetime]
    ) -> List[Dict[str, Any]]:
        """Query snow_tsm_problem_task table"""
        query = """
            SELECT
                problem_task_sys_id, problem_task_number,
                problem_sys_id, problem_number,
                description, short_description,
                priority_number, priority,
                problem_task_state, is_pending, pending_reason,
                problem_task_type, assignment_group,
                customer_name, customer_sys_id, is_customer_visible,
                created_on, created_by, assigned_to, assigned_to_sys_id,
                started_on, due_date, is_worked_ticket, updated_on,
                closed_on, closed_by, closed_by_sys_id,
                close_notes, cause_code, cause_notes,
                responsible_party, time_worked_minutes
            FROM eds.snow_tsm_problem_task
        """
        if since:
            query += " WHERE updated_on >= $1"
            return await self._execute_query(query, since)
        return await self._execute_query(query)

    async def _query_ci_services(
        self, since: Optional[datetime]
    ) -> List[Dict[str, Any]]:
        """Query snow_task_cmdb_ci_service table - maps tickets to configuration items"""
        query = """
            SELECT
                ci_sys_id, ci_name, is_manually_added,
                task_number, task_sys_id,
                created_on, updated_on
            FROM eds.snow_task_cmdb_ci_service
        """
        if since:
            query += " WHERE updated_on >= $1"
            return await self._execute_query(query, since)
        return await self._execute_query(query)

    async def _query_changes(self, since: Optional[datetime]) -> List[Dict[str, Any]]:
        """Query snow_tsm_change table - infrastructure-level changes (no client_id)"""
        query = """
            SELECT
                change_sys_id, change_number, source,
                supplier_sys_id, supplier_name, vendor_id, supplier_reference,
                created_by, created_on,
                opened_by_sys_id, opened_by_person_id, opened_by, opened_on,
                change_type, work_type,
                short_description, description,
                implemented_by_sys_ids, implemented_by_names,
                requested_by_sys_id, requested_by,
                impact_duration, impact_duration_minutes,
                planned_start_date, planned_end_date,
                backup_start_date, backup_end_date,
                second_backup_start_date, second_backup_end_date,
                category, subcategory, reason, risk,
                planned_work_reason, implementation_plan, backout_plan,
                country, city, planned_work_location,
                security_risk_y_n, modification_of_access_y_n,
                modification_of_cryptographic_y_n,
                core_nwk_y_n, critical_systems_y_n,
                impacted_services_count, requested_by_date,
                time_worked, time_worked_minutes,
                support_area, contact_type, change_state, is_postponed,
                assignment_group_sys_id, assignment_group,
                assigned_to_sys_id, assigned_to_person_id, assigned_to,
                cab_date_time, is_cab_required,
                is_inside_blackout_schedule, is_suppress_client_notifications,
                justification, risk_impact_analysis, test_plan,
                close_code, close_notes,
                updated_by, updated_on, task_type,
                closed_by_sys_id, closed_by_person_id, closed_by, closed_on
            FROM eds.snow_tsm_change
        """
        if since:
            query += " WHERE updated_on >= $1"
            return await self._execute_query(query, since)
        return await self._execute_query(query)

    async def _query_case_tasks(
        self, since: Optional[datetime]
    ) -> List[Dict[str, Any]]:
        """Query snow_tsm_case_task table - tasks associated with cases"""
        query = """
            SELECT
                case_task_sys_id, case_task_number,
                parent_case_number, parent_case_sys_id,
                short_description, description,
                case_task_type, case_task_state, sub_state,
                created_on, created_by,
                opened_on, opened_by, opened_by_person_id, opened_by_sys_id,
                assignment_group, assignment_group_sys_id,
                assigned_to, assigned_to_sys_id, assigned_to_person_id,
                updated_on, due_date, actual_end,
                closed_on, closed_by, closed_by_sys_id, closed_by_person_id,
                responsible_party, resolution_code, dv_close_notes,
                priority_number, priority, escalation_level,
                customer_sys_id, customer_name, customer_ticket_reference,
                service_type, circuit_id, segment_id, related_circuit_id,
                configuration_item_sys_id, configuration_item_name,
                service_sys_id, service_name,
                third_party_sys_id, third_party_name, third_party_ticket,
                third_party_score, third_party_score_comments,
                vendor_id, case_sys_tags,
                parent_is_worked_ticket, parent_is_customer_updated,
                time_worked_minutes, first_assigned_to, first_assignment_on,
                needs_attention
            FROM eds.snow_tsm_case_task
        """
        if since:
            query += " WHERE updated_on >= $1"
            return await self._execute_query(query, since)
        return await self._execute_query(query)

    async def _query_change_tasks(
        self, since: Optional[datetime]
    ) -> List[Dict[str, Any]]:
        """Query snow_tsm_change_task table - tasks associated with changes"""
        query = """
            SELECT
                change_task_sys_id, change_task_number,
                change_sys_id, change_number,
                parent_sys_id, parent_number,
                case_sys_id, case_number,
                change_category, change_subcategory,
                configuration_item_sys_id, configuration_item_name,
                configuration_item_class_name,
                fulfillment_y_n, change_task_type,
                supplier_sys_id, vendor_id, supplier_name,
                change_task_state, is_on_hold,
                assignment_group_sys_id, assignment_group,
                assigned_to_sys_id, assigned_to_person_id, assigned_to,
                short_description, description,
                change_planned_start_date, change_planned_end_date,
                created_on, created_by,
                opened_on, opened_by_sys_id, opened_by_person_id, opened_by,
                updated_on, updated_by,
                closed_on, closed_by_sys_id, closed_by_person_id, closed_by,
                follow_up_needed_y_n, implemented_in_timeframe_y_n,
                unexpected_consequences_y_n,
                close_notes, close_code,
                closure_responsibility, responsible_team
            FROM eds.snow_tsm_change_task
        """
        if since:
            query += " WHERE updated_on >= $1"
            return await self._execute_query(query, since)
        return await self._execute_query(query)

    async def _execute_query(self, query: str, *params) -> List[Dict[str, Any]]:
        """Execute query and return results as list of dicts"""
        async with self.db_pool.acquire() as conn:
            rows = await conn.fetch(query, *params)
            return [dict(row) for row in rows]
