"""
Graph Reconciliation Service

Runs after NATS ingestion idle timeout, before extraction pipeline.
Two phases:
  1. Relationship reconciliation — create FK edges that failed at ingestion
     because the target ticket wasn't in the graph yet.
  2. Field sync — propagate classification fields from linked tickets
     (e.g. incident category → case, parent incident → child incident).

Pure Cypher operations — no API calls. Runs in seconds.
"""
import asyncio
import logging
from typing import Dict, Any

from data_access.memgraphClient import MemgraphClient


logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Phase 1: Relationship reconciliation
# Uses ticket_id (human-readable, e.g. INC0092245) instead of sys_id,
# since sys_id is often empty (especially on Major Incident cases).
# Only creates edges that don't already exist.
# ---------------------------------------------------------------------------

RECONCILE_RAISED_BY_INCIDENT = """
MATCH (c:Ticket)
WHERE c.ticket_type = 'case'
  AND c.incident_number IS NOT NULL
  AND NOT (c)-[:RAISED_BY_INCIDENT]->()
MATCH (inc:Ticket {ticket_id: c.incident_number})
MERGE (c)-[:RAISED_BY_INCIDENT]->(inc)
RETURN count(*) AS created
"""

RECONCILE_RAISED_BY_PROBLEM = """
MATCH (c:Ticket)
WHERE c.ticket_type = 'case'
  AND c.problem_number IS NOT NULL
  AND NOT (c)-[:RAISED_BY_PROBLEM]->()
MATCH (prob:Ticket {ticket_id: c.problem_number})
MERGE (c)-[:RAISED_BY_PROBLEM]->(prob)
RETURN count(*) AS created
"""

RECONCILE_BELONGS_TO_CASE = """
MATCH (r:Ticket)
WHERE r.ticket_type = 'request'
  AND r.case_number IS NOT NULL
  AND NOT (r)-[:BELONGS_TO_CASE]->()
MATCH (c:Ticket {ticket_id: r.case_number})
MERGE (r)-[:BELONGS_TO_CASE]->(c)
RETURN count(*) AS created
"""

RECONCILE_CHILD_OF = """
MATCH (child:Ticket)
WHERE child.ticket_type = 'incident'
  AND child.parent_incident_number IS NOT NULL
  AND NOT (child)-[:CHILD_OF]->()
MATCH (parent:Ticket {ticket_id: child.parent_incident_number})
MERGE (child)-[:CHILD_OF]->(parent)
RETURN count(*) AS created
"""

RECONCILE_RELATED_TO_PROBLEM = """
MATCH (inc:Ticket)
WHERE inc.ticket_type = 'incident'
  AND inc.related_problem_number IS NOT NULL
  AND NOT (inc)-[:RELATED_TO_PROBLEM]->()
MATCH (prob:Ticket {ticket_id: inc.related_problem_number})
MERGE (inc)-[:RELATED_TO_PROBLEM]->(prob)
RETURN count(*) AS created
"""

RELATIONSHIP_QUERIES = [
    ("RAISED_BY_INCIDENT", RECONCILE_RAISED_BY_INCIDENT),
    ("RAISED_BY_PROBLEM", RECONCILE_RAISED_BY_PROBLEM),
    ("BELONGS_TO_CASE", RECONCILE_BELONGS_TO_CASE),
    ("CHILD_OF", RECONCILE_CHILD_OF),
    ("RELATED_TO_PROBLEM", RECONCILE_RELATED_TO_PROBLEM),
]


# ---------------------------------------------------------------------------
# Phase 2: Field sync from linked tickets
# Ongoing sync — linked ticket is source of truth for classification.
# Straight SET, no COALESCE. Runs every cycle.
# If the source has a value, it propagates. If null, target gets null
# (that's the truth — the field was never set anywhere).
# ---------------------------------------------------------------------------

SYNC_CASE_FROM_INCIDENT = """
MATCH (c:Ticket)-[:RAISED_BY_INCIDENT]->(inc:Ticket)
SET c.ticket_category = inc.ticket_category,
    c.subcategory = inc.subcategory,
    c.service_type = inc.service_type,
    c.responsible_party = inc.responsible_party,
    c.ci_sys_id = inc.ci_sys_id,
    c.ci_name = inc.ci_name
RETURN count(*) AS synced
"""

SYNC_CASE_FROM_PROBLEM = """
MATCH (c:Ticket)-[:RAISED_BY_PROBLEM]->(prob:Ticket)
SET c.ticket_category = prob.ticket_category,
    c.subcategory = prob.subcategory,
    c.service_type = prob.service_type,
    c.responsible_party = prob.responsible_party
RETURN count(*) AS synced
"""

SYNC_REQUEST_FROM_CASE = """
MATCH (r:Ticket)-[:BELONGS_TO_CASE]->(c:Ticket)
SET r.ticket_category = c.ticket_category,
    r.subcategory = c.subcategory,
    r.service_type = c.service_type
RETURN count(*) AS synced
"""

SYNC_CHILD_FROM_PARENT = """
MATCH (child:Ticket)-[:CHILD_OF]->(parent:Ticket)
SET child.ticket_category = parent.ticket_category,
    child.subcategory = parent.subcategory,
    child.service_type = parent.service_type
RETURN count(*) AS synced
"""

SYNC_INCIDENT_FROM_PROBLEM = """
MATCH (inc:Ticket)-[:RELATED_TO_PROBLEM]->(prob:Ticket)
SET inc.ticket_category = prob.ticket_category,
    inc.subcategory = prob.subcategory
RETURN count(*) AS synced
"""

SYNC_QUERIES = [
    ("Case ← Incident", SYNC_CASE_FROM_INCIDENT),
    ("Case ← Problem", SYNC_CASE_FROM_PROBLEM),
    ("Request ← Case", SYNC_REQUEST_FROM_CASE),
    ("Child ← Parent Incident", SYNC_CHILD_FROM_PARENT),
    ("Incident ← Problem", SYNC_INCIDENT_FROM_PROBLEM),
]


class GraphReconciliation:
    """
    Reconciles orphaned relationships and syncs fields from linked tickets.

    Usage:
        reconciliation = GraphReconciliation(memgraph_client)
        await reconciliation.reconcile()
    """

    def __init__(self, memgraph_client: MemgraphClient):
        self.memgraph_client = memgraph_client

    async def _execute(self, query: str) -> int:
        """Execute a reconciliation query and return the count."""
        try:
            result = await self.memgraph_client.execute(query)
            if result and len(result) > 0:
                record = result[0]
                return record.get("created", 0) or record.get("synced", 0) or 0
            return 0
        except Exception as e:
            logger.error(f"Reconciliation query failed: {e}")
            return 0

    async def reconcile_relationships(self) -> int:
        """Phase 1: Create orphaned FK relationships."""
        total = 0
        for name, query in RELATIONSHIP_QUERIES:
            count = await self._execute(query)
            if count > 0:
                logger.info(f"Reconciled {count} {name} relationships")
            total += count
        return total

    async def sync_fields(self) -> int:
        """Phase 2: Sync classification fields from linked tickets."""
        total = 0
        for name, query in SYNC_QUERIES:
            count = await self._execute(query)
            if count > 0:
                logger.info(f"Synced {count} tickets: {name}")
            total += count
        return total

    async def reconcile(self) -> Dict[str, int]:
        """
        Run full reconciliation: relationships first, then field sync.

        Returns dict with counts:
            {"relationships": N, "field_syncs": N}
        """
        logger.info("Starting graph reconciliation...")

        rel_count = await self.reconcile_relationships()
        sync_count = await self.sync_fields()

        if rel_count > 0 or sync_count > 0:
            logger.info(
                f"Reconciliation complete: {rel_count} relationships created, "
                f"{sync_count} field syncs"
            )
        else:
            logger.info("Reconciliation complete: no changes needed")

        return {"relationships": rel_count, "field_syncs": sync_count}
