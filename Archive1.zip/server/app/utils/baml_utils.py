import os
import traceback
import yaml
from typing import Any, Dict, Optional
from pathlib import Path

from baml_py import ClientRegistry

from configs.constants import DEFAULT_BAML_PATH

import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

DEFAULT_MODEL = "llama3.1-cypher:8b"
DEFAULT_BASE_URL = "http://10.250.99.61:11434/v1"  # Must include /v1 for BAML provider
DEFAULT_TEMPERATURE = 0.2


class BAMLService:
    def __init__(self, config_path=DEFAULT_BAML_PATH):
        self.baml_client_registry: Optional[ClientRegistry] = None
        self.config_path = Path(__file__).parent.parent / config_path

    def _load_baml_config(self, baml_file_path=None) -> Dict[str, Any]:
        try:
            config_path = baml_file_path or self.config_path
            with open(config_path, "r") as f:
                return yaml.safe_load(f) or {}
        except FileNotFoundError:
            logging.warning(f"BAML config file not found at {config_path}. Using default values.")
            return {}
        except yaml.YAMLError as e:
            logging.error(f"Error parsing BAML config: {e}")
            return {}

    async def init_baml(self) -> Optional[ClientRegistry]:
        try:
            logging.info("Initializing BAML...")
            baml_config = self._load_baml_config()
            llm_config = baml_config.get("llm", {})
            ollama_config = llm_config.get("ollama", {}) if isinstance(llm_config.get("ollama"), dict) else {}

            llm_model = ollama_config.get("model", DEFAULT_MODEL)
            base_url = ollama_config.get("base_url", DEFAULT_BASE_URL)
            llm_temperature = ollama_config.get("temperature", DEFAULT_TEMPERATURE)

            # BAML requires /v1 endpoint for Ollama compatibility
            base_url_clean = base_url.rstrip('/')
            if not base_url_clean.endswith("/v1"):
                base_url_with_v1 = base_url_clean + "/v1"
            else:
                base_url_with_v1 = base_url_clean

            os.environ["OLLAMA_CYPHER_MODEL"] = llm_model
            os.environ["OLLAMA_CYPHER_BASE_URL"] = base_url_with_v1

            logging.info(f"📡 BAML: {llm_model} @ {base_url_with_v1}")

            registry = ClientRegistry()
            client_name = "OllamaLlama"

            registry.add_llm_client(
                name=client_name,
                provider="openai-generic",
                options={"model": llm_model, "base_url": base_url_with_v1, "temperature": llm_temperature},
            )

            # Note: reset_baml_env_vars is deprecated - env vars are now lazily loaded
            logging.info("✅ BAML initialized")

            return registry

        except ImportError as ie:
            logging.error(f"ImportError during BAML initialization: {str(ie)}")
            traceback.print_exc()
            return None
        except Exception as e:
            logging.error(f"Error initializing BAML: {str(e)}", exc_info=True)
            traceback.print_exc()
            return None
