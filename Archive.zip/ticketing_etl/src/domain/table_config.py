from dataclasses import dataclass
from typing import List, Dict, Optional, Any
import yaml
import logging
from pathlib import Path


@dataclass
class TableConfig:
    """Configuration for a table processing pipeline"""

    name: str
    columns: List[str]
    topic: str
    transformer_class: str
    filters: Optional[Dict[str, Any]] = None
    enabled: bool = True

    def __post_init__(self):
        """Validate configuration after initialization"""
        if not self.name:
            raise ValueError("Table name cannot be empty")
        if not self.columns:
            raise ValueError("Table columns cannot be empty")
        if not self.topic:
            raise ValueError("Topic cannot be empty")
        if not self.transformer_class:
            raise ValueError("Transformer class cannot be empty")


class TableRegistry:
    """Configuration-driven table definitions registry"""

    def __init__(self, config_path: str = "config/tables.yaml"):
        self.config_path = config_path
        self.configs: Dict[str, TableConfig] = {}
        self.logger = logging.getLogger(__name__)
        self._load_table_configs()

    def _load_table_configs(self):
        """Load table configurations from YAML file"""
        try:
            config_file = Path(self.config_path)
            if not config_file.exists():
                self.logger.warning(f"Table config file not found: {self.config_path}")
                self._create_default_config()
                return

            with open(config_file, "r") as f:
                config_data = yaml.safe_load(f)

            if not config_data or "tables" not in config_data:
                raise ValueError(
                    "Invalid config file format - missing 'tables' section"
                )

            self.configs = {}
            for table_name, table_config in config_data["tables"].items():
                try:
                    self.configs[table_name] = TableConfig(
                        name=table_name, **table_config
                    )
                    self.logger.info(f"Loaded configuration for table: {table_name}")
                except Exception as e:
                    self.logger.error(f"Invalid config for table {table_name}: {e}")
                    continue

            self.logger.info(f"Loaded {len(self.configs)} table configurations")

        except Exception as e:
            self.logger.error(f"Failed to load table configurations: {e}")
            self._create_default_config()

    def _create_default_config(self):
        """Create default configuration for ServiceNow ticket table"""
        self.logger.info(
            "Creating default configuration for rds.v_servicenow_cmd_ticket table"
        )
        self.configs = {
            "rds.v_servicenow_cmd_ticket": TableConfig(
                name="rds.v_servicenow_cmd_ticket",
                columns=[
                    # Core ticket information
                    "ticket_id",
                    "ticket_queue",
                    "ticket_status",
                    "ticket_substatus",
                    "ticket_category",
                    "ticket_source",
                    "priority",
                    "type",
                    "is_master_ticket",
                    "master_ticket_id",
                    "linked_ticket_id",
                    "ticket_import_source",
                    # NOC and queue management
                    "default_noc",
                    "default_noc_queue",
                    # Client information
                    "client_id",
                    "client_name",
                    "client_group",
                    "client_tier",
                    "channel",
                    "sales_division",
                    "market_segment",
                    "client_import_source",
                    "client_ticket",
                    # Service/Technology information
                    "subcategory",
                    "technology",
                    "ci_sys_id",
                    "related_circuit_id",
                    "source_system",
                    "problem_type",
                    # Incident information
                    "fault_description",
                    "short_description",
                    "fault_occured_date",
                    "service_restored_date",
                    "is_customer_impacting",
                    # User/Assignment fields
                    "assigned_to",
                    "assigned_to_id",
                    "incident_manager",
                    "incident_manager_id",
                    "operations_specialist",
                    "operations_specialist_id",
                    "service_desk_engineer",
                    "tier2_engineer",
                    "created_by",
                    "closed_by",
                    "closed_by_id",
                    "first_assigned_to",
                    # Timing/Lifecycle fields
                    "created_on",
                    "updated_on",
                    "closed_on",
                    "first_resolved_on",
                    "first_assigned_on",
                    "oldest_resolved_date",
                    # Escalation fields
                    "ticket_escalation_level",
                    "next_action",
                    "next_action_date",
                    "next_action_date_notification_counter",
                    # Resolution/Outage fields
                    "resolution",
                    "customer_resolution",
                    "rfo",
                    "ticket_rfo_group",
                    "outage_duration",
                    "mttr",
                    "internal_mttr",
                    "is_worked_ticket",
                    "closure_quality",
                    # Vendor information
                    "vendor_id",
                    "vendor",
                    "vendor_downtime",
                    # Maintenance window fields
                    "pw_start",
                    "pw_end",
                    "pw_duration",
                    "pw_location",
                    "pw_reason",
                    # Survey/Quality fields
                    "score_id",
                    "score_reason",
                    "survey_score",
                    "survey_created_on",
                    "survey_ref",
                    # Customer communication timeline
                    "first_email_from_customer_on",
                    "first_customer_note_on",
                    "first_supplier_dispatch_event_on",
                    "first_tech_dispatch_event_on",
                    "first_child_ticket_created_on",
                    # Contact information (dummy fields for future implementation)
                    "contact_id",
                    "contact_name",
                    "contact_email",
                    "contact_phone",
                    "contact_type",
                ],
                topic="tickets.created",
                transformer_class="TicketTransformer",
                enabled=True,
            )
        }

    def get_table_config(self, table_name: str) -> Optional[TableConfig]:
        """Get configuration for a specific table"""
        return self.configs.get(table_name)

    def get_all_configs(self) -> Dict[str, TableConfig]:
        """Get all table configurations"""
        return self.configs.copy()

    def get_enabled_configs(self) -> Dict[str, TableConfig]:
        """Get only enabled table configurations"""
        return {name: config for name, config in self.configs.items() if config.enabled}

    def add_table_config(self, config: TableConfig):
        """Add a new table configuration"""
        self.configs[config.name] = config
        self.logger.info(f"Added configuration for table: {config.name}")

    def disable_table(self, table_name: str):
        """Disable processing for a table"""
        if table_name in self.configs:
            self.configs[table_name].enabled = False
            self.logger.info(f"Disabled table: {table_name}")

    def enable_table(self, table_name: str):
        """Enable processing for a table"""
        if table_name in self.configs:
            self.configs[table_name].enabled = True
            self.logger.info(f"Enabled table: {table_name}")

    def reload_configs(self):
        """Reload configurations from file"""
        self.logger.info("Reloading table configurations")
        self._load_table_configs()


# Global table registry instance
table_registry = TableRegistry()
