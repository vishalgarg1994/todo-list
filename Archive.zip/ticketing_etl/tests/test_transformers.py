import pytest
import json
from datetime import datetime, timezone
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from domain.transformers import TicketTransformer
from classes.data_model import CHANGE_BATCH_SIZE


class TestTicketTransformer:
    """Test the TicketTransformer class"""

    @pytest.fixture
    def transformer(self):
        return TicketTransformer()

    @pytest.fixture
    def sample_extracted_data(self):
        """Sample extracted data matching extractor output"""
        return {
            "cmd_records": [
                {
                    "client_id": "123",
                    "client_name": "Test Client",
                    "ticket_id": "INC001",
                    "servicenow_task_sys_id": "sysid001",
                    "ticket_category": "Trouble Ticket",
                    "ticket_status": "Open",
                    "fault_description": "Network issue",
                    "additional_info": "Details here",
                    "subcategory": "Connectivity",
                    "technology": "MPLS",
                    "incident_manager": "john.doe",
                    "service_desk_engineer": "jane.smith",
                    "created_on": datetime(2026, 1, 1, 10, 0, 0, tzinfo=timezone.utc),
                    "created_by": "system",
                }
            ],
            "cmd_by_sys_id": {
                "sysid001": {
                    "client_id": "123",
                    "client_name": "Test Client",
                    "ticket_id": "INC001",
                    "servicenow_task_sys_id": "sysid001",
                }
            },
            "incidents": [
                {
                    "incident_sys_id": "sysid001",
                    "incident_number": "INC001",
                    "incident_state": "Open",
                    "short_description": "Network issue",
                    "client_id": "123",
                    "category": "Hardware",
                    "subcategory": "Router",
                    "created_on": datetime(2026, 1, 1, 10, 0, 0, tzinfo=timezone.utc),
                }
            ],
            "cases": [],
            "problems": [],
            "requests": [],
            "changes": [],
            "incident_tasks": [],
            "case_tasks": [],
            "problem_tasks": [],
            "change_tasks": [],
            "tsm_by_sys_id": {
                "sysid001": {
                    "type": "incident",
                    "data": {
                        "incident_sys_id": "sysid001",
                        "incident_number": "INC001",
                        "incident_state": "Open",
                        "short_description": "Network issue",
                        "client_id": "123",
                    },
                }
            },
            "ci_services": [],
            "ci_by_task_sys_id": {},
            "case_tasks_by_case": {},
            "change_tasks_by_change": {},
        }

    def test_transform_basic(self, transformer, sample_extracted_data):
        """Test basic transformation of extracted data"""
        ticket_messages, fault_messages, processed_count = transformer.transform(
            sample_extracted_data
        )

        # Should produce one message (one client)
        assert len(ticket_messages) >= 1
        assert processed_count >= 1

        # Parse and validate structure
        if ticket_messages:
            ticket_summary = json.loads(ticket_messages[0])
            assert "client_info" in ticket_summary
            assert "operational_status" in ticket_summary

    def test_transform_empty_data(self, transformer):
        """Test transformation with empty data"""
        empty_data = {
            "cmd_records": [],
            "cmd_by_sys_id": {},
            "incidents": [],
            "cases": [],
            "problems": [],
            "requests": [],
            "changes": [],
            "incident_tasks": [],
            "case_tasks": [],
            "problem_tasks": [],
            "change_tasks": [],
            "tsm_by_sys_id": {},
            "ci_services": [],
            "ci_by_task_sys_id": {},
            "case_tasks_by_case": {},
            "change_tasks_by_change": {},
        }

        ticket_messages, fault_messages, processed_count = transformer.transform(
            empty_data
        )
        assert ticket_messages == []
        assert fault_messages == []
        assert processed_count == 0


class TestChangeProcessing:
    """Test the change processing functionality"""

    @pytest.fixture
    def transformer(self):
        return TicketTransformer()

    @pytest.fixture
    def sample_changes_data(self):
        """Sample extracted data with changes"""
        return {
            "cmd_records": [],
            "cmd_by_sys_id": {},
            "incidents": [],
            "cases": [],
            "problems": [],
            "requests": [],
            "changes": [
                {
                    "change_sys_id": "chg001",
                    "change_number": "CHG0012345",
                    "short_description": "Router upgrade",
                    "description": "Full router replacement for capacity upgrade",
                    "change_state": "Implement",
                    "change_type": "Normal",
                    "work_type": "Service Affecting",
                    "category": "Hardware",
                    "assignment_group": "Network Team",
                    "assigned_to": "john.tech",
                    "created_on": datetime(2026, 1, 10, 10, 0, 0, tzinfo=timezone.utc),
                    "planned_start_date": datetime(
                        2026, 1, 15, 2, 0, 0, tzinfo=timezone.utc
                    ),
                    "planned_end_date": datetime(
                        2026, 1, 15, 4, 0, 0, tzinfo=timezone.utc
                    ),
                    "core_network_y_n": "Y",
                    "is_cab_required_y_n": "Y",
                    "security_risk_y_n": "N",
                },
                {
                    "change_sys_id": "chg002",
                    "change_number": "CHG0012346",
                    "short_description": "Emergency patch",
                    "change_state": "Closed",
                    "change_type": "Emergency",
                    "work_type": "Non-Service Affecting",
                    "created_on": datetime(2026, 1, 11, 8, 0, 0, tzinfo=timezone.utc),
                },
            ],
            "change_tasks": [
                {
                    "task_sys_id": "task001",
                    "task_number": "CTASK001",
                    "change_sys_id": "chg001",
                    "change_number": "CHG0012345",
                    "short_description": "Pre-change testing",
                    "state": "Closed",
                    "priority_number": 2,
                    "fulfillment_y_n": "Y",
                }
            ],
            "incident_tasks": [],
            "case_tasks": [],
            "problem_tasks": [],
            "tsm_by_sys_id": {},
            "ci_services": [],
            "ci_by_task_sys_id": {
                "chg001": [
                    {
                        "ci_sys_id": "ci001",
                        "ci_name": "Router-NYC-01",
                        "is_manually_added": False,
                    }
                ]
            },
            "case_tasks_by_case": {},
            "change_tasks_by_change": {
                "chg001": [
                    {
                        "task_sys_id": "task001",
                        "task_number": "CTASK001",
                        "change_sys_id": "chg001",
                        "change_number": "CHG0012345",
                        "short_description": "Pre-change testing",
                        "state": "Closed",
                        "priority_number": 2,
                        "fulfillment_y_n": "Y",
                    }
                ]
            },
        }

    def test_process_changes_basic(self, transformer, sample_changes_data):
        """Test basic change processing"""
        change_messages, change_count = transformer.process_changes(sample_changes_data)

        # Should produce at least one batch
        assert len(change_messages) >= 1
        assert change_count == 2  # Two changes

        # Parse and validate
        batch = json.loads(change_messages[0])
        assert "changes" in batch
        assert "batch_number" in batch
        assert "total_batches" in batch
        assert "total_changes" in batch

        # Check the changes in the batch
        assert len(batch["changes"]) == 2
        assert batch["total_changes"] == 2

        # Verify first change
        chg1 = batch["changes"][0]
        assert chg1["change_sys_id"] == "chg001"
        assert chg1["change_number"] == "CHG0012345"

        # Verify change_fields
        assert chg1["change_fields"] is not None
        assert chg1["change_fields"]["change_type"] == "Normal"
        assert chg1["change_fields"]["work_type"] == "Service Affecting"
        assert chg1["change_fields"]["core_network"] is True
        assert chg1["change_fields"]["is_cab_required"] is True

        # Verify tasks
        assert len(chg1["tasks"]) == 1
        assert chg1["tasks"][0]["task_number"] == "CTASK001"
        assert chg1["tasks"][0]["fulfillment"] is True

        # Verify CIs
        assert len(chg1["configuration_items"]) == 1
        assert chg1["configuration_items"][0]["ci_name"] == "Router-NYC-01"

    def test_process_changes_empty(self, transformer):
        """Test change processing with no changes"""
        empty_data = {
            "changes": [],
            "change_tasks_by_change": {},
            "ci_by_task_sys_id": {},
        }

        change_messages, change_count = transformer.process_changes(empty_data)
        assert change_messages == []
        assert change_count == 0

    def test_process_changes_batching(self, transformer):
        """Test that changes are properly batched"""
        # Create more changes than CHANGE_BATCH_SIZE
        many_changes = []
        for i in range(CHANGE_BATCH_SIZE + 50):
            many_changes.append(
                {
                    "change_sys_id": f"chg{i:05d}",
                    "change_number": f"CHG{i:07d}",
                    "short_description": f"Change {i}",
                    "change_state": "Closed",
                }
            )

        data = {
            "changes": many_changes,
            "change_tasks_by_change": {},
            "ci_by_task_sys_id": {},
        }

        change_messages, change_count = transformer.process_changes(data)

        # Should be batched into 2 batches (100 + 50)
        assert len(change_messages) == 2
        assert change_count == CHANGE_BATCH_SIZE + 50

        # Check batch metadata
        batch1 = json.loads(change_messages[0])
        batch2 = json.loads(change_messages[1])

        assert batch1["batch_number"] == 1
        assert batch1["total_batches"] == 2
        assert len(batch1["changes"]) == CHANGE_BATCH_SIZE

        assert batch2["batch_number"] == 2
        assert batch2["total_batches"] == 2
        assert len(batch2["changes"]) == 50


class TestHelperMethods:
    """Test transformer helper methods"""

    @pytest.fixture
    def transformer(self):
        return TicketTransformer()

    def test_parse_yn_bool_true(self, transformer):
        """Test Y/N parsing for true values"""
        assert transformer._parse_yn_bool("Y") is True
        assert transformer._parse_yn_bool("y") is True
        assert transformer._parse_yn_bool("YES") is True
        assert transformer._parse_yn_bool("yes") is True
        assert transformer._parse_yn_bool("TRUE") is True
        assert transformer._parse_yn_bool("1") is True
        assert transformer._parse_yn_bool(True) is True

    def test_parse_yn_bool_false(self, transformer):
        """Test Y/N parsing for false values"""
        assert transformer._parse_yn_bool("N") is False
        assert transformer._parse_yn_bool("n") is False
        assert transformer._parse_yn_bool("NO") is False
        assert transformer._parse_yn_bool("FALSE") is False
        assert transformer._parse_yn_bool("0") is False
        assert transformer._parse_yn_bool(False) is False

    def test_parse_yn_bool_none(self, transformer):
        """Test Y/N parsing for null values"""
        assert transformer._parse_yn_bool(None) is None
        assert transformer._parse_yn_bool("") is None

    def test_to_int_valid(self, transformer):
        """Test integer conversion with valid values"""
        assert transformer._to_int(123) == 123
        assert transformer._to_int("456") == 456
        assert transformer._to_int(78.9) == 78

    def test_to_int_invalid(self, transformer):
        """Test integer conversion with invalid values"""
        assert transformer._to_int(None) is None
        assert transformer._to_int("") is None
        assert transformer._to_int("not a number") is None

    def test_to_datetime_valid(self, transformer):
        """Test datetime conversion"""
        dt = datetime(2026, 1, 12, 10, 0, 0, tzinfo=timezone.utc)
        assert transformer._to_datetime(dt) == dt

        # String datetime
        dt_str = "2026-01-12 10:00:00"
        result = transformer._to_datetime(dt_str)
        assert result is not None
        assert result.year == 2026

    def test_to_datetime_invalid(self, transformer):
        """Test datetime conversion with invalid values"""
        assert transformer._to_datetime(None) is None
        assert transformer._to_datetime("") is None


class TestBuildChangeRecord:
    """Test building individual ChangeRecord objects"""

    @pytest.fixture
    def transformer(self):
        return TicketTransformer()

    def test_build_change_record_complete(self, transformer):
        """Test building a complete ChangeRecord"""
        change_data = {
            "change_sys_id": "chg001",
            "change_number": "CHG0012345",
            "short_description": "Test change",
            "description": "Full description",
            "change_state": "Implement",
            "category": "Hardware",
            "subcategory": "Network",
            "change_type": "Normal",
            "work_type": "Service Affecting",
            "assignment_group": "Network Team",
            "assigned_to": "john.doe",
            "created_on": datetime(2026, 1, 10, 10, 0, 0, tzinfo=timezone.utc),
            "core_network_y_n": "Y",
            "is_cab_required_y_n": "Y",
            "security_risk_y_n": "N",
            "supplier_name": "Vendor Corp",
        }

        tasks = [
            {
                "task_sys_id": "task001",
                "task_number": "CTASK001",
                "change_sys_id": "chg001",
                "change_number": "CHG0012345",
                "short_description": "Task 1",
                "state": "Closed",
                "fulfillment_y_n": "Y",
            }
        ]

        cis = [
            {"ci_sys_id": "ci001", "ci_name": "Router-01", "is_manually_added": False}
        ]

        record = transformer._build_change_record(change_data, tasks, cis)

        assert record.change_sys_id == "chg001"
        assert record.change_number == "CHG0012345"
        assert record.short_description == "Test change"
        assert record.change_state == "Implement"

        # Check change_fields
        assert record.change_fields.change_type == "Normal"
        assert record.change_fields.work_type == "Service Affecting"
        assert record.change_fields.core_network is True
        assert record.change_fields.is_cab_required is True
        assert record.change_fields.security_risk is False
        assert record.change_fields.supplier_name == "Vendor Corp"

        # Check tasks
        assert len(record.tasks) == 1
        assert record.tasks[0].task_number == "CTASK001"
        assert record.tasks[0].fulfillment is True

        # Check CIs
        assert len(record.configuration_items) == 1
        assert record.configuration_items[0].ci_name == "Router-01"

    def test_build_change_record_minimal(self, transformer):
        """Test building a minimal ChangeRecord"""
        change_data = {
            "change_sys_id": "chg001",
            "change_number": "CHG001",
        }

        record = transformer._build_change_record(change_data, [], [])

        assert record.change_sys_id == "chg001"
        assert record.change_number == "CHG001"
        assert record.tasks == []
        assert record.configuration_items == []
