"""
CMD Service Delivery MCP Server

Exposes an MCP (Model Context Protocol) server for querying CMD service order data
stored in Memgraph (graph) and Milvus (vector). Supports:
  - Order lookup & filtering
  - Segment & vendor queries
  - Task & note queries
  - Semantic search (vector similarity over notes)
  - Relational traversal (graph path queries)
  - Natural language → Cypher queries
  - Analytics & aggregation

ETL ingests data from the CMD server (mock or real) via GraphQL APIs,
using an ai_tasks watermark to poll for newly completed tasks.

Run:
  python server.py                          # Standalone
  uvicorn server:app --host 0.0.0.0 --port 8003  # Production
"""

import asyncio
import inspect
import logging
import os
import sys
from contextlib import asynccontextmanager
from functools import wraps

import nest_asyncio

from fastmcp import FastMCP
from starlette.responses import JSONResponse
from starlette.routing import Route

sys.path.insert(0, os.path.dirname(__file__))

from config import Config
from data_access.memgraph_client import MemgraphClient
from etl.extractor import CMDExtractor
from etl.loader import GraphLoader, VectorLoader
from services.embedding_service import EmbeddingService
from services.semantic_search import SemanticSearchService

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("cmd-mcp")

config = Config()


# ── ETL Orchestrator ─────────────────────────────────────────────────────────

class ETLOrchestrator:
    """
    Manages the extract-transform-load cycle:
      1. Extractor polls CMD for new completed tasks (watermark-based)
      2. GraphLoader writes order data into Memgraph
      3. VectorLoader embeds notes into Milvus
    Can run as a one-shot or as a background poller.
    """

    def __init__(self, config: Config, memgraph_client, semantic_search_service):
        self.config = config
        self.extractor = CMDExtractor(config)
        self.graph_loader = GraphLoader(memgraph_client) if memgraph_client else None
        self.vector_loader = None
        if semantic_search_service:
            embedding_service = EmbeddingService(config)
            self.vector_loader = VectorLoader(semantic_search_service.milvus_client, embedding_service)
        self._poll_task: asyncio.Task = None
        self._running = False
        self.last_poll_stats: dict = {}

    async def run_once(self) -> dict:
        """Single poll + ingest cycle."""
        payloads, stats = await self.extractor.poll()

        if payloads:
            if self.graph_loader:
                await self.graph_loader.load_payloads(payloads)
            if self.vector_loader:
                await self.vector_loader.load_payloads(payloads)

        self.last_poll_stats = stats
        return stats

    async def start_polling(self):
        """Start the background polling loop."""
        if self._running:
            logger.warning("Poller already running")
            return
        self._running = True
        self._poll_task = asyncio.create_task(self._poll_loop(), name="ETL-Poller")
        logger.info("Background ETL poller started (interval=%ds)", self.config.poll_interval_seconds)

    async def stop_polling(self):
        """Stop the background polling loop."""
        self._running = False
        if self._poll_task and not self._poll_task.done():
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
        logger.info("Background ETL poller stopped")

    async def _poll_loop(self):
        """Continuously poll CMD at the configured interval."""
        while self._running:
            try:
                stats = await self.run_once()
                if stats.get("new_orders", 0) > 0:
                    logger.info("Poll ingested %d new orders (watermark: %s)",
                                stats["new_orders"], stats["watermark"])
                else:
                    logger.debug("Poll: no new orders (watermark: %s)", stats.get("watermark"))
            except Exception as e:
                logger.error("Poll cycle failed: %s", e, exc_info=True)

            await asyncio.sleep(self.config.poll_interval_seconds)


# ── Lifecycle ────────────────────────────────────────────────────────────────

async def startup_services():
    logger.info("Starting CMD Service Delivery MCP Server...")

    # Memgraph
    memgraph_client = MemgraphClient(
        uri=config.memgraph_uri,
        user=config.memgraph_user,
        password=config.memgraph_password,
        database=config.memgraph_database,
    )
    try:
        await memgraph_client.connect()
        logger.info("Memgraph connected")
    except Exception as e:
        logger.error("Memgraph connection failed: %s", e)
        memgraph_client = None

    # OpenAI client
    openai_client = None
    if config.openai_api_key:
        from openai import AsyncOpenAI
        openai_client = AsyncOpenAI(api_key=config.openai_api_key)
        logger.info("OpenAI client initialized (model: %s, embeddings: %s)",
                     config.openai_chat_model, config.openai_embedding_model)
    else:
        logger.warning("OPENAI_API_KEY not set — NL queries and semantic search will be limited")

    # Semantic search (Milvus + OpenAI embeddings)
    semantic_search_service = None
    try:
        semantic_search_service = SemanticSearchService(config)
        await semantic_search_service.connect()
        logger.info("Semantic search service connected (Milvus + OpenAI)")
    except Exception as e:
        logger.warning("Semantic search unavailable: %s — vector tools will be disabled", e)
        semantic_search_service = None

    # Load schema description for NL→Cypher
    schema_description = ""
    try:
        with open(config.schema_path, "r") as f:
            schema_description = f.read()
    except Exception as e:
        logger.warning("Could not load schema: %s", e)

    # ETL Orchestrator
    etl = ETLOrchestrator(config, memgraph_client, semantic_search_service)

    # Create graph indexes on startup
    if memgraph_client:
        await GraphLoader(memgraph_client).create_indexes()

    # Auto-start poller if configured
    if config.auto_poll:
        await etl.start_polling()

    return {
        "memgraph_client": memgraph_client,
        "semantic_search_service": semantic_search_service,
        "schema_description": schema_description,
        "openai_client": openai_client,
        "etl": etl,
    }


async def shutdown_services(services):
    logger.info("Shutting down services...")
    etl = services.get("etl")
    if etl:
        await etl.stop_polling()
    if services.get("memgraph_client"):
        await services["memgraph_client"].shutdown()
    if services.get("semantic_search_service"):
        services["semantic_search_service"].disconnect()
    logger.info("All services shut down")


# ── Tool registration helper ────────────────────────────────────────────────

def _wrap_tool(fn, app_ref):
    """Wrap a tool function to inject services from app.state.
    Hides the internal 'services' parameter from the MCP tool schema."""
    sig = inspect.signature(fn)
    visible_params = [p for name, p in sig.parameters.items() if name != "services"]

    @wraps(fn)
    async def wrapper(**kwargs):
        services = app_ref[0].state.services
        return await fn(services=services, **kwargs)

    wrapper.__signature__ = sig.replace(parameters=visible_params)
    return wrapper


# ── App factory ──────────────────────────────────────────────────────────────

def app_factory():
    nest_asyncio.apply()

    mcp = FastMCP(name="CMDServiceDelivery")
    app_ref = [None]

    # ── Register all tools ───────────────────────────────────────────────

    from tools.order_tools import (
        get_order_details, list_orders, get_orders_by_status,
        get_orders_by_client, search_orders_by_field, get_order_summary_stats,
    )
    from tools.segment_tools import (
        get_segment_details, get_segments_by_vendor,
        search_segments_by_company, get_segments_by_location,
    )
    from tools.vendor_tools import (
        get_vendor_details, list_vendors, get_vendor_orders,
        search_vendor_by_name,
    )
    from tools.task_tools import (
        get_order_tasks, get_tasks_by_status, get_tasks_by_type,
        get_task_summary_stats,
    )
    from tools.note_tools import (
        get_order_notes, search_notes_by_subject, search_notes_by_content,
        get_note_count_by_order,
    )
    from tools.semantic_tools import search_similar_notes, find_similar_orders
    from tools.relationship_tools import (
        get_order_relationships, trace_order_to_vendors, get_vendor_impact,
        get_client_order_graph, find_orders_sharing_vendor,
    )
    from tools.analytics_tools import ask_orders_question, get_graph_stats

    tool_fns = [
        get_order_details, list_orders, get_orders_by_status,
        get_orders_by_client, search_orders_by_field, get_order_summary_stats,
        get_segment_details, get_segments_by_vendor,
        search_segments_by_company, get_segments_by_location,
        get_vendor_details, list_vendors, get_vendor_orders,
        search_vendor_by_name,
        get_order_tasks, get_tasks_by_status, get_tasks_by_type,
        get_task_summary_stats,
        get_order_notes, search_notes_by_subject, search_notes_by_content,
        get_note_count_by_order,
        search_similar_notes, find_similar_orders,
        get_order_relationships, trace_order_to_vendors, get_vendor_impact,
        get_client_order_graph, find_orders_sharing_vendor,
        ask_orders_question, get_graph_stats,
    ]

    for fn in tool_fns:
        wrapped = _wrap_tool(fn, app_ref)
        mcp.tool()(wrapped)

    logger.info("Registered %d MCP tools", len(tool_fns))

    # ── HTTP app ─────────────────────────────────────────────────────────

    app = mcp.http_app(stateless_http=True)
    app_ref[0] = app

    original_lifespan = app.router.lifespan_context

    @asynccontextmanager
    async def combined_lifespan(app):
        services = await startup_services()
        app.state.services = services
        async with original_lifespan(app):
            yield
        await shutdown_services(services)

    app.router.lifespan_context = combined_lifespan

    # ── HTTP endpoints ───────────────────────────────────────────────────

    async def health_check(request):
        services = getattr(request.app.state, "services", {})
        etl = services.get("etl")
        return JSONResponse({
            "status": "healthy",
            "service": "cmd_service_delivery_mcp",
            "memgraph_connected": services.get("memgraph_client") is not None,
            "semantic_search_available": services.get("semantic_search_service") is not None,
            "etl_watermark": etl.extractor.watermark if etl else None,
            "etl_orders_ingested": len(etl.extractor.processed_order_ids) if etl else 0,
            "etl_polling": etl._running if etl else False,
        })

    async def etl_poll(request):
        """Trigger a single ETL poll cycle (fetch new tasks → ingest orders)."""
        services = getattr(request.app.state, "services", {})
        etl: ETLOrchestrator = services.get("etl")
        if not etl:
            return JSONResponse({"error": "ETL not initialized"}, status_code=503)
        if not services.get("memgraph_client"):
            return JSONResponse({"error": "Memgraph not connected"}, status_code=503)

        stats = await etl.run_once()
        return JSONResponse({"status": "poll complete", **stats})

    async def etl_start_polling(request):
        """Start the background ETL polling loop."""
        services = getattr(request.app.state, "services", {})
        etl: ETLOrchestrator = services.get("etl")
        if not etl:
            return JSONResponse({"error": "ETL not initialized"}, status_code=503)

        await etl.start_polling()
        return JSONResponse({
            "status": "polling started",
            "interval_seconds": config.poll_interval_seconds,
            "watermark": etl.extractor.watermark,
        })

    async def etl_stop_polling(request):
        """Stop the background ETL polling loop."""
        services = getattr(request.app.state, "services", {})
        etl: ETLOrchestrator = services.get("etl")
        if not etl:
            return JSONResponse({"error": "ETL not initialized"}, status_code=503)

        await etl.stop_polling()
        return JSONResponse({"status": "polling stopped"})

    async def etl_status(request):
        """Get ETL status: watermark, processed orders, graph stats."""
        services = getattr(request.app.state, "services", {})
        etl: ETLOrchestrator = services.get("etl")
        mg = services.get("memgraph_client")

        result = {
            "watermark": etl.extractor.watermark if etl else None,
            "orders_ingested": len(etl.extractor.processed_order_ids) if etl else 0,
            "polling_active": etl._running if etl else False,
            "last_poll": etl.last_poll_stats if etl else {},
        }

        if mg:
            from tools.analytics_tools import get_graph_stats as _stats
            result["graph"] = await _stats(services=services)

        return JSONResponse(result)

    async def etl_set_watermark(request):
        """Manually set the ETL watermark (e.g. to re-ingest from a date)."""
        services = getattr(request.app.state, "services", {})
        etl: ETLOrchestrator = services.get("etl")
        if not etl:
            return JSONResponse({"error": "ETL not initialized"}, status_code=503)

        body = await request.json()
        new_watermark = body.get("watermark")
        reset_processed = body.get("reset_processed", False)

        if not new_watermark:
            return JSONResponse({"error": "watermark field required"}, status_code=400)

        etl.extractor.watermark = new_watermark
        if reset_processed:
            etl.extractor.processed_order_ids.clear()

        return JSONResponse({
            "status": "watermark updated",
            "watermark": etl.extractor.watermark,
            "processed_cleared": reset_processed,
        })

    app.routes.append(Route("/health", health_check, methods=["GET"]))
    app.routes.append(Route("/etl/poll", etl_poll, methods=["POST"]))
    app.routes.append(Route("/etl/start", etl_start_polling, methods=["POST"]))
    app.routes.append(Route("/etl/stop", etl_stop_polling, methods=["POST"]))
    app.routes.append(Route("/etl/status", etl_status, methods=["GET"]))
    app.routes.append(Route("/etl/watermark", etl_set_watermark, methods=["POST"]))

    return app


app = app_factory()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=config.server_host, port=config.server_port)
