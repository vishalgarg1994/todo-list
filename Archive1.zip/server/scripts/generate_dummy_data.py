#!/usr/bin/env python3
"""
Generate realistic dummy test data for mcp_ticket testing.
Creates 20 tickets across 2 clients with various scenarios.
"""

import json
from datetime import datetime, timedelta
import random

# Base date: 30 days ago
BASE_DATE = datetime.now() - timedelta(days=30)

def generate_timestamp(days_offset=0, hours_offset=0):
    """Generate realistic timestamp"""
    dt = BASE_DATE + timedelta(days=days_offset, hours=hours_offset)
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def create_ticket_summary(
    client_id, client_name, ticket_num,
    is_master=False, master_ticket_id=None,
    days_ago=0, status="Open", priority=3,
    has_survey=False, has_maintenance=False, has_vendor=False
):
    """Create a single ticket_summary object"""

    ticket_id = f"INC-{ticket_num:03d}"
    tkt_id = f"tkt_{ticket_id}"

    # User data
    users = []
    if random.random() > 0.3:  # 70% have incident manager
        users.append({
            "user_id": f"user_{random.randint(100, 199)}",
            "name": random.choice(["John Smith", "Jane Doe", "Mike Johnson", "Sarah Williams"]),
            "role": "incident_manager"
        })

    if random.random() > 0.4:  # 60% have ops specialist
        users.append({
            "user_id": f"user_{random.randint(200, 299)}",
            "name": random.choice(["Bob Anderson", "Alice Brown", "Tom Davis", "Emma Wilson"]),
            "role": "operations_specialist"
        })

    # Service desk engineer (no user_id)
    users.append({
        "name": random.choice(["Tech Support Team", "Service Desk L1", "Help Desk"]),
        "role": "service_desk_engineer"
    })

    # Contacts
    contacts = [
        {
            "contact_id": f"contact_{ticket_num}_1",
            "name": f"Customer Contact {ticket_num}",
            "email": f"customer{ticket_num}@example.com",
            "phone": f"+1-555-{random.randint(1000, 9999)}",
            "contact_type": "customer_contact"
        }
    ]

    # Vendors (only some tickets)
    vendors = []
    if has_vendor:
        vendors.append({
            "vendor_id": f"vendor_{random.randint(1, 5)}",
            "vendor": random.choice(["AT&T", "Verizon", "Lumen", "Zayo", "Cogent"]),
            "vendor_downtime": round(random.uniform(0, 240), 2)
        })

    # Maintenance window (only some tickets)
    maintenance_window = None
    if has_maintenance:
        mw_start = generate_timestamp(days_ago + 1, 2)
        mw_end = generate_timestamp(days_ago + 1, 6)
        maintenance_window = {
            "pw_start": mw_start,
            "pw_end": mw_end,
            "pw_duration": "4 hours",
            "pw_location": random.choice(["DC1-Main", "DC2-Backup", "Edge-NY", "Core-LA"]),
            "pw_reason": random.choice([
                "Planned router upgrade",
                "Fiber maintenance",
                "Software patch deployment",
                "Hardware replacement"
            ])
        }

    # Survey (only some tickets)
    survey_info = None
    if has_survey and status == "Closed":
        survey_score = random.randint(1, 5)
        survey_info = {
            "score_id": f"survey_{ticket_id}",
            "score_reason": "Good service" if survey_score >= 4 else "Slow response",
            "survey_score": survey_score,
            "survey_ref": f"SRV-{ticket_num:03d}",
            "survey_created_on": generate_timestamp(days_ago + 2)
        }

    # Assigned to
    assigned_to_id = f"user_{random.randint(300, 399)}"
    assigned_to = random.choice(["Chris Martinez", "Pat Garcia", "Alex Rodriguez", "Morgan Lee"])

    # Closed by (only if closed)
    closed_by = None
    closed_by_id = None
    closed_on = None
    if status == "Closed":
        closed_by_id = f"user_{random.randint(400, 499)}"
        closed_by = random.choice(["Resolver A", "Resolver B", "Resolver C"])
        closed_on = generate_timestamp(days_ago + 1, 8)

    created_on = generate_timestamp(days_ago, 0)

    return {
        "client_info": {
            "cl_id": f"cl_{client_id}",
            "client_id": client_id,
            "client_name": client_name,
            "client_group": "Enterprise" if client_id == "C001" else "SMB",
            "client_tier": "Platinum" if client_id == "C001" else "Gold",
            "channel": "Direct",
            "sales_division": "North America",
            "market_segment": "Technology",
            "client_import_source": "ServiceNow",
            "client_ticket": ticket_id
        },
        "operational_status": [
            {
                "service_entity": {
                    "svc_id": f"svc_{ticket_num:03d}",
                    "subcategory": random.choice(["MPLS", "Internet", "Voice", "SD-WAN", "Private Line"]),
                    "technology": random.choice(["Fiber", "Ethernet", "IP-VPN", "MPLS-VPN", "DWDM"]),
                    "service_restored_date": closed_on if status == "Closed" else None,
                    "related_circuit_id": random.randint(10000, 99999)
                },
                "incident_info": {
                    "inc_id": f"inc_{ticket_id}",
                    "fault_description_ref": f"FD-{ticket_num:03d}",
                    "short_description": random.choice([
                        "Network connectivity issue",
                        "Service degradation",
                        "Complete service outage",
                        "Intermittent packet loss",
                        "High latency detected",
                        "Circuit down"
                    ]),
                    "is_customer_impacting": random.choice([True, False])
                },
                "ticket_info": {
                    "tkt_id": tkt_id,
                    "ticket_source": "Email",
                    "ticket_id": ticket_id,
                    "ticket_category": "Incident",
                    "ticket_queue": "NOC-L2",
                    "ticket_status": status,
                    "ticket_substatus": "Assigned" if status == "Open" else "Resolved",
                    "is_master_ticket": is_master,
                    "master_ticket_id": master_ticket_id,
                    "created_by": "System Auto",
                    "created_on": created_on,
                    "closed_on": closed_on,
                    "source_system": "ServiceNow",
                    "priority": priority,
                    "type": "Reactive",
                    "linked_ticket_id": None,
                    "ticket_import_source": "ticketing_etl",
                    "ticket_escalation_level": random.randint(0, 2),
                    "next_action": "Monitor" if status != "Closed" else None,
                    "next_action_date": generate_timestamp(days_ago - 1) if status != "Closed" else None,
                    "next_action_date_notification_counter": 0,
                    "updated_on": generate_timestamp(days_ago, 12),
                    "closed_by": closed_by,
                    "closed_by_id": closed_by_id,
                    "assigned_to": assigned_to,
                    "assigned_to_id": assigned_to_id,
                    "first_assigned_to": assigned_to,
                    "first_assigned_on": generate_timestamp(days_ago, 1),
                    "first_resolved_on": closed_on,
                    "oldest_resolved_date": closed_on,
                    "first_child_ticket_created_on": None
                },
                "outage_info": {
                    "oi_id": f"oi_{ticket_id}",
                    "customer_resolution": "Service restored" if status == "Closed" else None,
                    "resolution": random.choice([
                        "Rebooted device",
                        "Replaced failed component",
                        "Configuration change",
                        "Vendor resolved issue"
                    ]) if status == "Closed" else None,
                    "rfo": random.choice([
                        "Hardware Failure",
                        "Software Bug",
                        "Configuration Error",
                        "Fiber Cut",
                        "Power Outage"
                    ]),
                    "outage_total": random.randint(0, 10),
                    "outage_duration": f"{random.randint(1, 8)} hours" if status == "Closed" else None,
                    "internal_mttr": f"{random.randint(30, 480)} minutes",
                    "mttr": random.randint(30, 480),
                    "problem_type": "Service Outage",
                    "ticket_rfo_group": "Infrastructure",
                    "is_worked_ticket": True,
                    "closure_quality": "Good" if status == "Closed" else None,
                    "first_email_from_customer_on": created_on,
                    "first_customer_note_on": generate_timestamp(days_ago, 1),
                    "first_supplier_dispatch_event_on": None,
                    "first_tech_dispatch_event_on": None
                },
                "users": users,
                "contacts": contacts,
                "vendors": vendors,
                "maintenance_window": maintenance_window,
                "survey_info": survey_info,
                "noc_info": {
                    "default_noc": "NOC_AMER" if client_id == "C001" else "NOC_EMEA",
                    "default_noc_queue": "L2-Network"
                }
            }
        ]
    }

# Generate 20 tickets
tickets = []
ticket_counter = 1

# Client 1: TechCorp Industries (12 tickets)
client1_id = "C001"
client1_name = "TechCorp Industries"

# Master ticket + 3 children (major network failure scenario)
master_ticket = create_ticket_summary(
    client1_id, client1_name, ticket_counter,
    is_master=True, days_ago=25, status="Closed", priority=1,
    has_vendor=True
)
tickets.append(master_ticket)
ticket_counter += 1

# 3 child tickets for master
for i in range(3):
    child_ticket = create_ticket_summary(
        client1_id, client1_name, ticket_counter,
        master_ticket_id="INC-001", days_ago=25 - i, status="Closed", priority=2
    )
    tickets.append(child_ticket)
    ticket_counter += 1

# 8 more varied tickets for Client 1
for i in range(8):
    days = random.randint(1, 20)
    status = random.choice(["Open", "Closed", "Closed", "In Progress"])
    tickets.append(create_ticket_summary(
        client1_id, client1_name, ticket_counter,
        days_ago=days, status=status, priority=random.randint(2, 4),
        has_survey=(i % 3 == 0), has_maintenance=(i % 4 == 0), has_vendor=(i % 5 == 0)
    ))
    ticket_counter += 1

# Client 2: Global Services Ltd (8 tickets)
client2_id = "C002"
client2_name = "Global Services Ltd"

for i in range(8):
    days = random.randint(1, 28)
    status = random.choice(["Open", "Open", "Closed", "Resolved"])
    tickets.append(create_ticket_summary(
        client2_id, client2_name, ticket_counter,
        days_ago=days, status=status, priority=random.randint(2, 5),
        has_survey=(i % 2 == 0), has_maintenance=(i % 3 == 0), has_vendor=(i % 4 == 0)
    ))
    ticket_counter += 1

# Write to file
output_file = "/Users/aklilugebreyesus/projects/eva/mcp_ticket/server/test_data/dummy_tickets.json"
with open(output_file, 'w') as f:
    json.dump(tickets, f, indent=2)

print(f"✅ Generated {len(tickets)} tickets")
print(f"📁 Saved to: {output_file}")
print(f"📊 Summary:")
print(f"   - Client 1 ({client1_name}): 12 tickets")
print(f"   - Client 2 ({client2_name}): 8 tickets")
print(f"   - Master/Child: 1 master + 3 children")
print(f"   - Date range: Last 30 days")
