import yaml
import asyncio
import httpx
# Removed datetime import as it's no longer used for year inputs
import json
import sys # Import sys for exit

# Configuration - Load from config.yaml (use relative path)
def load_config(config_path="config.yaml"):
# def load_config(config_path="config.yaml"):
    try:
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
            return config or {}
    except FileNotFoundError:
        raise FileNotFoundError(f"Config file not found at {config_path}")
    except yaml.YAMLError as e:
        raise ValueError(f"Error parsing config.yaml: {e}")

config = load_config()
SERVER_CONFIG = config.get("server", {})
if not SERVER_CONFIG or "url" not in SERVER_CONFIG or "timeout" not in SERVER_CONFIG:
    raise ValueError("Missing or incomplete server configuration (url, timeout) in config.yaml")

async def process_json_response(response: httpx.Response):
    """Processes a simple JSON response from the server."""
    try:
        response.raise_for_status() # Raise exception for 4xx/5xx errors
        data = response.json()
        print("--- Server Response ---")
        print(json.dumps(data, indent=2))
        print("-----------------------")
    except httpx.HTTPStatusError as e:
        # Try to get more detail from the response body
        try:
            error_detail = e.response.json()
            print(f"Error from server ({e.response.status_code}): {error_detail.get('detail', e.response.text)}")
        except json.JSONDecodeError:
            print(f"Error from server ({e.response.status_code}): {e.response.text}")
    except json.JSONDecodeError:
        print(f"Error: Could not decode JSON response from server.")
        print(f"Raw response: {response.text}")
    except Exception as e:
        print(f"An unexpected error occurred processing the response: {e}")

async def process_stream_response(response: httpx.Response):
    """Processes a streaming Server-Sent Events (SSE) response."""
    print("--- Server Response (Streaming) ---")
    current_event = "message" # Default event type
    data_buffer = ""
    try:
        async for line in response.aiter_lines():
            if not line: # End of an event
                if data_buffer:
                    try:
                        payload = json.loads(data_buffer)
                        if current_event == "error":
                            print(f"[ERROR] {payload.get('error', 'Unknown error')}")
                            if 'query' in payload:
                                print(f"  Query: {payload['query']}")
                        elif current_event == "info":
                            print(f"[INFO] {payload.get('status', payload.get('message', ''))}")
                            if 'query' in payload:
                                print(f"  Query: {payload['query']}")
                        elif current_event == "done":
                            print(f"[DONE] {payload.get('message', 'Stream finished.')}")
                            break # Stop processing after "done" event
                        else: # Default 'message' event or unknown
                            # Assuming the main data payload is under 'row' key
                            if 'row' in payload:
                                print(json.dumps(payload['row'], indent=2))
                            else:
                                print(json.dumps(payload, indent=2)) # Print full payload if no 'row'
                    except json.JSONDecodeError:
                        print(f"[Warning] Could not decode JSON data: {data_buffer}")
                    # Reset for next event
                    data_buffer = ""
                    current_event = "message"
            elif line.startswith("event:"):
                current_event = line[len("event:"):].strip()
            elif line.startswith("data:"):
                data_buffer += line[len("data:"):].strip()
            # Ignore other lines like comments (starting with ':') or id lines
    except httpx.ReadError as e:
         print(f"\n[Error] Connection closed during streaming: {e}")
    except Exception as e:
        print(f"\n[Error] An unexpected error occurred during streaming: {e}")
    finally:
        print("-----------------------------------")


async def call_api_endpoint(method: str, endpoint: str, payload: dict = None, stream: bool = False):
    """Generic function to call an API endpoint, handling streaming or JSON."""
    url = f"{SERVER_CONFIG['url']}{endpoint}" # Use full endpoint path
    print(f"\nCalling {method.upper()} {url}...")
    # Adjust timeout for potentially long streams
    timeout_duration = SERVER_CONFIG["timeout"] * 5 if stream else SERVER_CONFIG["timeout"]
    timeout_config = httpx.Timeout(timeout_duration, connect=10.0)

    async with httpx.AsyncClient(timeout=timeout_config) as client:
        try:
            if method.upper() == "POST":
                if stream:
                    async with client.stream("POST", url, json=payload) as response:
                        print(f"\nResponse type {response.headers.get("content-type")}...\n")
                        #jenava - updated match to: text/event-stream; charset=utf-8
                        if response.status_code == 200 and response.headers.get("content-type") == "text/event-stream; charset=utf-8":

                            await process_stream_response(response)
                        else:
                            # Handle non-stream error response from a stream request
                            await response.aread() # Read body before processing as JSON
                            await process_json_response(response) # Process potential JSON error body
                else:
                    response = await client.post(url, json=payload)
                    await process_json_response(response)
            elif method.upper() == "GET":
                response = await client.get(url)
                await process_json_response(response)
            else:
                print(f"Unsupported HTTP method: {method}")
                return
        except httpx.RequestError as e:
            print(f"Error connecting to server: {e}")
        except Exception as e:
            print(f"An unexpected error occurred during the request: {e}")


async def call_api_tool(tool_name: str, payload: dict = {}, stream: bool = False):
    """Calls an MCP tool endpoint, potentially streaming."""
    # Use the explicitly defined path structure from the server decorators
    await call_api_endpoint("POST", f"/mcp/tools/{tool_name}", payload, stream=stream)

async def call_get_tickets():
    """Calls the get_contact_names tool."""
    await call_api_tool("get_tickets")

async def call_ask_about_ticketing():
    """Prompts for a question and calls the ask_tickets_question tool (streaming)."""
    question = input("Enter your question about the ticketing data: ").strip()
    if not question:
        print("Question cannot be empty.")
        return
    payload = {"user_query": question}
    # Ensure we call the correct tool name and enable streaming
    await call_api_tool("ask_tickets_question", payload, stream=True)

async def call_load_data():
    """Prompts for a URL and calls the /admin/load-data endpoint."""
    url_input = input("Enter the URL for the ticket.json file: ").strip()
    if not url_input:
        print("URL cannot be empty.")
        return
    payload = {"url": url_input}
    # Call the admin endpoint directly (non-streaming)
    await call_api_endpoint("POST", "/admin/load-data", payload)
    print("Data load request sent. Check server status with 'status' command.")

async def call_get_status():
    """Calls the /admin/status endpoint."""
    await call_api_endpoint("GET", "/admin/status")


async def main():
    print("Ticketing Data Analysis ")
    print("-----------------------------")
    print("Available commands:")
    print("  1. get_tickets  (Get all tickets)")
    print("  3. ask          (Ask a question - streams results)")
    print("  4. load_data    (Load data from a URL into the server)")
    print("  5. status       (Check server/database status)")
    print("  exit")
    print("-----------------------------")

    while True:
        choice = input("Enter command: ").strip().lower()

        if choice == "1" or choice == "get_tickets":
            await call_get_tickets()
        elif choice == "3" or choice == "ask":
            await call_ask_about_ticketing()
        elif choice == "4" or choice == "load_data":
            await call_load_data()
        elif choice == "5" or choice == "status":
            await call_get_status()
        elif choice == "exit":
            break
        else:
            print("Invalid command.")
        print("-" * 30) # Separator between commands

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (ValueError, FileNotFoundError) as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        print("Please ensure config.yaml exists and contains valid server configuration (url, timeout)", file=sys.stderr)
        sys.exit(1) # Use sys.exit
    except KeyboardInterrupt:
        print("\nExiting client.")
        sys.exit(0) # Use sys.exit

