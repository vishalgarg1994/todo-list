"""
Integration tests using real data from the uploaded tar file.
Tests the full transformation pipeline with actual change and task data.
"""
import pytest
import json
import csv
import tarfile
import io
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from domain.transformers import TicketTransformer
from classes.data_model import CHANGE_BATCH_SIZE


# Path to the uploaded tar file with real data
TAR_FILE_PATH = "/Users/aklilugebreyesus/Desktop/tab.tar"


def load_csv_from_tar(tar_path: str, filename_pattern: str) -> list:
    """Load a CSV file from a tar archive"""
    records = []
    try:
        with tarfile.open(tar_path, "r") as tar:
            for member in tar.getmembers():
                # Skip macOS metadata files (._prefix)
                if member.name.startswith("._"):
                    continue
                if filename_pattern in member.name and member.name.endswith(".csv"):
                    f = tar.extractfile(member)
                    if f:
                        raw = f.read()
                        # Try different encodings
                        for encoding in ["utf-16", "utf-8", "latin-1"]:
                            try:
                                content = raw.decode(encoding)
                                reader = csv.DictReader(io.StringIO(content))
                                records = list(reader)
                                if records:  # Only break if we got records
                                    break
                            except (UnicodeDecodeError, UnicodeError):
                                continue
                        break
    except Exception as e:
        print(f"Error loading {filename_pattern}: {e}")
    return records


@pytest.fixture(scope="module")
def real_changes():
    """Load real change data from tar file"""
    return load_csv_from_tar(TAR_FILE_PATH, "snow_tsm_change_")


@pytest.fixture(scope="module")
def real_change_tasks():
    """Load real change task data from tar file"""
    return load_csv_from_tar(TAR_FILE_PATH, "snow_tsm_change_task_")


@pytest.fixture(scope="module")
def real_case_tasks():
    """Load real case task data from tar file"""
    return load_csv_from_tar(TAR_FILE_PATH, "snow_tsm_case_task_")


@pytest.fixture
def transformer():
    return TicketTransformer()


class TestRealDataLoading:
    """Test that we can load the real data files"""

    def test_load_changes(self, real_changes):
        """Test loading change records from tar"""
        if not os.path.exists(TAR_FILE_PATH):
            pytest.skip("Tar file not available")

        assert len(real_changes) > 0, "Should load at least one change record"
        print(f"\nLoaded {len(real_changes)} change records")

        # Check structure
        first_change = real_changes[0]
        assert "change_sys_id" in first_change
        assert "change_number" in first_change

    def test_load_change_tasks(self, real_change_tasks):
        """Test loading change task records from tar"""
        if not os.path.exists(TAR_FILE_PATH):
            pytest.skip("Tar file not available")

        assert len(real_change_tasks) > 0, "Should load at least one change task"
        print(f"\nLoaded {len(real_change_tasks)} change task records")

        # Check structure (actual field names from data)
        first_task = real_change_tasks[0]
        assert "change_task_sys_id" in first_task or "task_sys_id" in first_task
        assert "change_sys_id" in first_task

    def test_load_case_tasks(self, real_case_tasks):
        """Test loading case task records from tar"""
        if not os.path.exists(TAR_FILE_PATH):
            pytest.skip("Tar file not available")

        assert len(real_case_tasks) > 0, "Should load at least one case task"
        print(f"\nLoaded {len(real_case_tasks)} case task records")


class TestRealChangeProcessing:
    """Test processing real change data through the transformer"""

    def test_process_real_changes(self, transformer, real_changes, real_change_tasks):
        """Test processing real change data"""
        if not os.path.exists(TAR_FILE_PATH):
            pytest.skip("Tar file not available")

        if not real_changes:
            pytest.skip("No change data loaded")

        # Index tasks by change_sys_id
        tasks_by_change = {}
        for task in real_change_tasks:
            change_id = task.get("change_sys_id")
            if change_id:
                if change_id not in tasks_by_change:
                    tasks_by_change[change_id] = []
                tasks_by_change[change_id].append(task)

        # Prepare data for transformer
        extracted_data = {
            "changes": real_changes,
            "change_tasks_by_change": tasks_by_change,
            "ci_by_task_sys_id": {},  # CIs not in tar
        }

        # Process changes
        change_messages, change_count = transformer.process_changes(extracted_data)

        # Verify processing - changes with processing errors are logged and skipped
        assert change_count > 0, "Should process at least some changes"
        assert len(change_messages) > 0, "Should produce at least one batch"

        # Should process most changes (allow for some errors)
        valid_changes = [c for c in real_changes if c.get("change_sys_id")]
        assert (
            change_count >= len(valid_changes) * 0.8
        ), f"Should process at least 80% of changes. Got {change_count}/{len(valid_changes)}"

        print(
            f"\nProcessed {change_count} changes into {len(change_messages)} batch(es)"
        )

        # Verify batch structure
        first_batch = json.loads(change_messages[0])
        assert "changes" in first_batch
        assert "batch_number" in first_batch
        assert "total_batches" in first_batch
        assert "total_changes" in first_batch

        # Verify batch metadata
        # total_changes reflects successfully processed changes, not raw input count
        assert first_batch["total_changes"] == change_count
        assert first_batch["batch_number"] == 1

        # Print sample change
        if first_batch["changes"]:
            sample = first_batch["changes"][0]
            print("\nSample change:")
            print(f"  Number: {sample.get('change_number')}")
            print(f"  Description: {sample.get('short_description', 'N/A')[:50]}")
            print(f"  State: {sample.get('change_state')}")
            if sample.get("change_fields"):
                print(f"  Type: {sample['change_fields'].get('change_type')}")
                print(f"  Work Type: {sample['change_fields'].get('work_type')}")

    def test_change_batch_size_compliance(
        self, transformer, real_changes, real_change_tasks
    ):
        """Test that batches respect CHANGE_BATCH_SIZE limit"""
        if not os.path.exists(TAR_FILE_PATH):
            pytest.skip("Tar file not available")

        if not real_changes:
            pytest.skip("No change data loaded")

        tasks_by_change = {}
        for task in real_change_tasks:
            change_id = task.get("change_sys_id")
            if change_id:
                if change_id not in tasks_by_change:
                    tasks_by_change[change_id] = []
                tasks_by_change[change_id].append(task)

        extracted_data = {
            "changes": real_changes,
            "change_tasks_by_change": tasks_by_change,
            "ci_by_task_sys_id": {},
        }

        change_messages, _ = transformer.process_changes(extracted_data)

        for msg in change_messages:
            batch = json.loads(msg)
            assert (
                len(batch["changes"]) <= CHANGE_BATCH_SIZE
            ), f"Batch has {len(batch['changes'])} changes, exceeds limit of {CHANGE_BATCH_SIZE}"

    def test_message_size_compliance(
        self, transformer, real_changes, real_change_tasks
    ):
        """Test that batch messages stay under NATS 1MB limit"""
        if not os.path.exists(TAR_FILE_PATH):
            pytest.skip("Tar file not available")

        if not real_changes:
            pytest.skip("No change data loaded")

        tasks_by_change = {}
        for task in real_change_tasks:
            change_id = task.get("change_sys_id")
            if change_id:
                if change_id not in tasks_by_change:
                    tasks_by_change[change_id] = []
                tasks_by_change[change_id].append(task)

        extracted_data = {
            "changes": real_changes,
            "change_tasks_by_change": tasks_by_change,
            "ci_by_task_sys_id": {},
        }

        change_messages, _ = transformer.process_changes(extracted_data)

        MAX_MESSAGE_SIZE = 1 * 1024 * 1024  # 1MB
        for i, msg in enumerate(change_messages):
            msg_size = len(msg.encode("utf-8"))
            assert (
                msg_size < MAX_MESSAGE_SIZE
            ), f"Batch {i + 1} is {msg_size} bytes, exceeds 1MB limit"
            print(f"Batch {i + 1} size: {msg_size:,} bytes ({msg_size / 1024:.1f} KB)")


class TestYNFieldParsing:
    """Test Y/N field parsing with real data"""

    def test_real_yn_fields(self, transformer, real_changes):
        """Test Y/N field parsing with real change data"""
        if not os.path.exists(TAR_FILE_PATH):
            pytest.skip("Tar file not available")

        if not real_changes:
            pytest.skip("No change data loaded")

        # Find changes with Y/N fields
        yn_fields = [
            "core_network_y_n",
            "security_risk_y_n",
            "is_cab_required_y_n",
            "is_postponed_y_n",
            "modification_of_access_y_n",
            "critical_systems_y_n",
        ]

        yn_values_found = set()
        for change in real_changes:
            for field in yn_fields:
                value = change.get(field)
                if value:
                    yn_values_found.add(value)

        print(f"\nY/N field values found in data: {yn_values_found}")

        # Test parsing each value found
        for value in yn_values_found:
            result = transformer._parse_yn_bool(value)
            assert result is not None or value in (
                "",
                None,
            ), f"Failed to parse Y/N value: {value}"


class TestDataQuality:
    """Test data quality checks"""

    def test_change_number_format(self, real_changes):
        """Test that change numbers follow expected format"""
        if not os.path.exists(TAR_FILE_PATH):
            pytest.skip("Tar file not available")

        if not real_changes:
            pytest.skip("No change data loaded")

        for change in real_changes[:100]:  # Check first 100
            change_number = change.get("change_number")
            if change_number:
                # Change numbers should start with CHG
                assert change_number.startswith(
                    "CHG"
                ), f"Unexpected change number format: {change_number}"

    def test_required_fields_present(self, real_changes):
        """Test that required fields are present"""
        if not os.path.exists(TAR_FILE_PATH):
            pytest.skip("Tar file not available")

        if not real_changes:
            pytest.skip("No change data loaded")

        required_fields = ["change_sys_id", "change_number"]
        for change in real_changes:
            for field in required_fields:
                assert field in change, f"Missing required field: {field}"
                assert change[field], f"Empty required field: {field}"
