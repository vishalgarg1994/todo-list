# Future State Architecture Design - Ticketing Data Processor

## Executive Summary

This document outlines the transformation of the current Ticketing Data Processor from a development prototype into an enterprise-ready, scalable data pipeline system. The future state addresses critical security vulnerabilities, implements operational best practices, and provides a foundation for multi-table data ingestion with topic-based routing to downstream MCP servers.

**Current Status**: ✅ **Phase 1 Complete** - Health monitoring, observability, and knowledge graph features implemented
**Transformation Goal**: Prototype → Enterprise Production-Ready Data Pipeline

---

## Current State Analysis

### ✅ **Implemented Enterprise Features (Complete)**
- **Domain-Driven Design**: Well-implemented DDD patterns with clear bounded contexts
- **Message-Driven Architecture**: Appropriate event-driven design for data pipeline
- **Async Processing**: Proper use of asyncio for non-blocking ETL operations
- **Time-Based Incremental Processing**: Delta extraction strategy
- **✅ Health Monitoring System**: Comprehensive component health checks with HTTP endpoints
- **✅ Knowledge Graph Processing**: Entity extraction for Users, Contacts, Vendors, Maintenance Windows
- **✅ APM Integration**: Prometheus metrics, Kubernetes probes, DataDog/New Relic compatibility
- **✅ Circuit Breaker & Resilience**: Failure prevention and graceful degradation patterns
- **✅ Comprehensive Testing**: Integration, browser, and manual test frameworks

### 🚨 **Critical Issues to Address**
- **SQL Injection Vulnerability**: String interpolation in database queries
- **Exposed Credentials**: Database passwords in docker-compose.yml
- **Broken Scheduling**: TODO logic prevents continuous processing
- **Multiple Connection Anti-pattern**: Redundant DB and NATS connections
- **Configuration Chaos**: Duplicated settings across multiple files
- **Zero Data Governance**: No audit trails, encryption, or compliance controls

---

## Future State Vision

### **Enterprise Data Pipeline Architecture**

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        ENTERPRISE DATA PIPELINE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────┐    ┌─────────────────────┐    ┌─────────────────────┐   │
│  │ PostgreSQL   │────▶│  Secure Data        │────▶│  NATS JetStream     │   │
│  │ Source DB    │    │  Pipeline           │    │  Message Bus        │   │
│  │              │    │                     │    │                     │   │
│  │ • eds.ticket │    │ • Connection Pool   │    │ • tickets.created   │   │
│  │ • eds.survey │    │ • Generic Processor │    │ • surveys.updated   │   │
│  │ • future...  │    │ • Topic Routing     │    │ • notes.processed   │   │
│  └──────────────┘    │ • Audit Logging     │    │ • future.topics     │   │
│                      │ • Data Validation   │    └─────────────────────┘   │
│                      │ • Error Recovery    │                             │
│                      └─────────────────────┘                             │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│  ✅ IMPLEMENTED: Health Monitoring | APM Integration | Knowledge Graph      │
│  🔄 OBSERVABILITY: Structured Logs | Metrics | Health Checks | Audit Trails │
└─────────────────────────────────────────────────────────────────────────────┘
```

### **Core Architectural Principles**

#### 1. **Security-First Design**
- **Zero Trust**: No hardcoded credentials, encrypted connections, input validation
- **Defense in Depth**: Multiple security layers with audit trails
- **Compliance Ready**: GDPR/SOX controls with data classification

#### 2. **Resource Efficiency**
- **Single Connection Pools**: Shared database and NATS connections
- **Memory Management**: Bounded processing with backpressure handling
- **Resource Limits**: Container constraints and monitoring

#### 3. **Operational Excellence**
- **Observability**: Structured logging, metrics, tracing
- **Reliability**: Error recovery, circuit breakers, health monitoring
- **Maintainability**: Clear configuration, comprehensive testing

#### 4. **Scalability & Extensibility**
- **Generic Table Processing**: Configurable ingestion for any table
- **Topic Routing**: Dynamic message routing based on table type
- **Horizontal Scaling**: Stateless design for multi-instance deployment

---

## ✅ Completed Enterprise Features

### **Health Monitoring & Observability System (Implemented)**

#### **Health Service Architecture**
```python
class HealthService:
    """Enterprise-grade health monitoring with component-level checks"""
    
    async def get_health_status(self) -> HealthResponse:
        # Component health aggregation
        components = {
            "database": await self._check_database_health(),
            "nats": await self._check_nats_health(), 
            "scheduler": await self._check_scheduler_health(),
            "system": await self._check_system_health()
        }
        return HealthResponse(components=components)
```

#### **HTTP Health Endpoints (Port 8080)**
- **GET /health** - Comprehensive component health status with JSON response
- **GET /health/live** - Kubernetes liveness probe (200 OK when alive)
- **GET /health/ready** - Kubernetes readiness probe (503 when dependencies unavailable)
- **GET /healthz** - Kubernetes convention alias for liveness
- **GET /health/metrics** - Prometheus-compatible metrics format

#### **APM Platform Integration**
✅ **Prometheus/Grafana** - Native metrics endpoint with time-series data
✅ **DataDog** - HTTP health check monitoring with structured responses
✅ **New Relic** - Infrastructure monitoring via standardized endpoints
✅ **Elastic APM** - Compatible health status format

#### **Knowledge Graph Processing (Implemented)**
```python
# Entity extraction from ticketing data
operational_status = {
    "users": [{"username": "john.manager", "role": "incident_manager"}],
    "contacts": [{"name": "Bob Customer", "email": "bob@customer.com"}],
    "vendors": [{"vendor_name": "NetworkCorp", "supplier_email": "support@networkcorp.com"}],
    "maintenance_window": {"pw_start": "2025-01-15T02:00:00Z"}
}
```

**Extracted Entities**:
- **Users**: Incident managers, service desk engineers, technicians with role classification
- **Contacts**: Customer contacts, site contacts, suppliers with contact information
- **Vendors**: Service providers with supplier details and contact methods
- **Maintenance Windows**: Scheduled maintenance periods with time windows and descriptions

#### **Circuit Breaker & Resilience (Implemented)**
- **Exponential backoff retry** with jitter for external service failures
- **Circuit breaker pattern** to prevent cascade failures during outages
- **Graceful degradation** maintains partial functionality when components fail
- **Connection pool management** with health monitoring and automatic recovery

#### **Comprehensive Test Framework (Implemented)**
- **Integration Tests**: `test_health_integration.py` - Component testing without external dependencies
- **Browser Tests**: `test_health_browser.py` - JSON format validation and browser compatibility
- **Manual Tests**: `test_health_manual.py` - Live 30-second server for manual browser testing
- **pytest Framework**: Async fixtures, manual test markers, and comprehensive coverage

---

## Remaining Future State Components

### **1. Secure Configuration Management**

#### **Current Problems**:
```yaml
# docker-compose.yml - EXPOSED CREDENTIALS
DATABASE_URL: "postgresql://user:password@host:5432/db"
```

#### **Future State Solution**:
```yaml
# docker-compose.yml - SECURE
environment:
  - CONFIG_ENV=production
  - VAULT_ADDR=${VAULT_ADDR}
env_file:
  - .env.${ENV:-local}
```

**Features**:
- **Hierarchical Configuration**: Environment → Secrets Manager → .env → defaults
- **Environment Separation**: Different configs for dev/staging/prod
- **Secret Management Integration**: HashiCorp Vault or Kubernetes secrets
- **Configuration Validation**: Startup validation with clear error messages

### **2. Unified Connection Management**

#### **Current Problems**:
- Multiple database connections: `main.py:33, 58, 154, 179`
- Multiple NATS connections: `main.py:97, 117` + `publisher.py:42`
- Resource leaks and connection overhead

#### **Future State Solution**:
```python
class ConnectionManager:
    """Centralized connection lifecycle management"""
    
    async def initialize(self):
        self.db_pool = await self._create_db_pool()
        self.nats_connection = await self._create_nats_connection()
    
    async def get_db_connection(self):
        return self.db_pool.acquire()
    
    def get_nats_publisher(self):
        return NatsPublisher(self.nats_connection)
```

**Features**:
- **Single Database Pool**: One connection pool shared across all components
- **Shared NATS Connection**: Single connection with multiple publishers/subscribers
- **Health Monitoring**: Connection health checks and automatic recovery
- **Graceful Shutdown**: Proper resource cleanup on application termination

### **3. Generic Multi-Table Processing Framework**

#### **Current State**: Single table (eds.ticket) hardcoded processing

#### **Future State**: Configurable multi-table ingestion

```python
# Table Configuration
table_configs = {
    "eds.ticket": {
        "columns": ["client_id", "ticket_id", "status", ...],
        "topic": "tickets.created",
        "transform_class": "TicketTransformer",
        "schedule_interval": 300
    },
    "eds.survey": {
        "columns": ["survey_id", "client_id", "responses", ...], 
        "topic": "surveys.updated",
        "transform_class": "SurveyTransformer",
        "schedule_interval": 600
    }
}
```

**Architecture**:
```python
class GenericTableProcessor:
    async def process_table(self, table_config: TableConfig):
        # Generic extraction logic
        raw_data = await self.extract_data(table_config)
        
        # Table-specific transformation
        transformer = self.get_transformer(table_config.transform_class)
        transformed_data = await transformer.transform(raw_data)
        
        # Topic-specific publishing
        await self.publish_to_topic(transformed_data, table_config.topic)
```

**Features**:
- **Table Registry**: Configuration-driven table definitions
- **Dynamic Transformers**: Pluggable transformation classes
- **Topic Routing**: Automatic message routing based on table type
- **Independent Scheduling**: Different intervals per table
- **Error Isolation**: Failures in one table don't affect others

### **4. Enhanced Security & Data Governance**

#### **SQL Injection Prevention**:
```python
# BEFORE (Vulnerable)
query += f" WHERE updated_on >= '{time_value}'"

# AFTER (Secure)
query = "SELECT * FROM {} WHERE updated_on >= $1"
result = await connection.fetch(query, time_value)
```

#### **Data Governance Framework**:
```python
class DataGovernanceManager:
    async def audit_data_access(self, table: str, user: str, action: str):
        audit_record = {
            "timestamp": datetime.utcnow(),
            "table": table,
            "user": user, 
            "action": action,
            "correlation_id": self.correlation_id
        }
        await self.audit_store.record(audit_record)
    
    async def classify_data(self, data: Dict) -> DataClassification:
        # PII detection and classification
        return self.classifier.classify(data)
```

**Features**:
- **Audit Trails**: Complete logging of all data operations
- **Data Classification**: Automatic PII and sensitive data detection
- **Encryption**: Field-level encryption for sensitive data
- **Access Controls**: Role-based data access patterns
- **Compliance**: GDPR/SOX compliance controls

### **5. Comprehensive Observability**

#### **Structured Logging**:
```python
logger.info("Processing table data", extra={
    "correlation_id": correlation_id,
    "table_name": table_name,
    "record_count": len(records),
    "processing_time_ms": processing_time,
    "status": "success"
})
```

#### **Metrics & Monitoring**:
```python
# Prometheus metrics
RECORDS_PROCESSED = Counter('records_processed_total', ['table', 'status'])
PROCESSING_TIME = Histogram('processing_duration_seconds', ['table'])
CONNECTION_POOL_USAGE = Gauge('db_pool_connections_active')
```

**Features**:
- **Correlation IDs**: End-to-end request tracking
- **Business Metrics**: Records processed, transformation rates, error counts
- **Technical Metrics**: Connection pools, memory usage, processing times  
- **Health Endpoints**: `/health`, `/ready`, `/metrics` for orchestration
- **Alerting**: Automated alerts for failures and performance degradation

### **6. Resilience & Error Handling**

#### **Circuit Breaker Pattern**:
```python
@circuit_breaker(failure_threshold=5, recovery_timeout=30)
async def fetch_table_data(self, table_config):
    # Database operations with automatic failure detection
```

#### **Dead Letter Queue**:
```python
class MessageProcessor:
    async def handle_failed_message(self, message, error):
        await self.dead_letter_queue.publish({
            "original_message": message,
            "error": str(error),
            "retry_count": message.metadata.get("retry_count", 0),
            "failed_at": datetime.utcnow()
        })
```

**Features**:
- **Retry Logic**: Exponential backoff with jitter
- **Circuit Breakers**: Prevent cascade failures
- **Dead Letter Queues**: Failed message recovery
- **Graceful Degradation**: Partial functionality during outages

---

## Data Flow Architecture

### **Enhanced Processing Pipeline**

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         ENHANCED DATA PIPELINE                              │
└─────────────────────────────────────────────────────────────────────────────┘

1. CONFIGURATION LOADING
   ├── Environment Variables
   ├── Secret Manager (Vault/K8s)
   ├── Table Registry Loading
   └── Validation & Error Reporting

2. CONNECTION INITIALIZATION  
   ├── Database Pool Creation (min=5, max=20)
   ├── NATS Connection with JetStream
   ├── Health Check Validation
   └── Circuit Breaker Setup

3. SCHEDULER STARTUP
   ├── Table-Specific Schedulers
   ├── Independent Interval Management  
   ├── Staggered Execution Prevention
   └── Processing State Persistence

4. TABLE PROCESSING (Per Configured Table)
   ├── Time-Window Query (Parameterized)
   ├── Data Classification & PII Detection
   ├── Table-Specific Transformation
   ├── Data Quality Validation
   ├── Audit Trail Generation
   └── Topic-Based Publishing

5. MESSAGE PUBLISHING
   ├── Compression & Size Validation
   ├── Topic Routing Logic
   ├── JetStream Acknowledgment
   ├── Retry Logic with DLQ
   └── Metrics Recording

6. MONITORING & OBSERVABILITY
   ├── Structured Log Output
   ├── Prometheus Metrics Export
   ├── Health Status Updates
   ├── Correlation ID Tracking
   └── Performance Monitoring
```

### **Multi-Table Processing Example**

```python
# Configuration-driven processing
async def process_all_tables():
    for table_name, config in table_registry.get_all():
        try:
            processor = GenericTableProcessor(
                connection_manager=conn_mgr,
                config=config,
                correlation_id=generate_correlation_id()
            )
            
            await processor.process_with_governance(table_name, config)
            
        except Exception as e:
            await error_handler.handle_table_failure(table_name, e)
            # Continue processing other tables
```

**Topics Generated**:
- `tickets.created` - Ticket data updates
- `surveys.updated` - Survey response data  
- `notes.processed` - Ticket notes and comments
- `incidents.resolved` - Incident management data
- `clients.modified` - Client information changes

---

## Security Model

### **Zero Trust Architecture**

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           SECURITY LAYERS                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  LAYER 1: INFRASTRUCTURE                                                    │
│  ├── TLS 1.3 for all connections                                           │
│  ├── Network segmentation (container networks)                             │
│  ├── Non-root container execution                                          │
│  └── Resource limits and quotas                                            │
│                                                                             │
│  LAYER 2: APPLICATION                                                       │
│  ├── Parameterized queries (SQL injection prevention)                      │
│  ├── Input validation and sanitization                                     │
│  ├── Secret management integration                                         │
│  └── Secure error handling (no information leakage)                        │
│                                                                             │
│  LAYER 3: DATA                                                             │
│  ├── Field-level encryption for PII                                        │
│  ├── Data classification and tagging                                       │
│  ├── Audit trails for all data operations                                  │
│  └── Data retention and deletion policies                                  │
│                                                                             │
│  LAYER 4: OPERATIONAL                                                       │
│  ├── Structured logging (no sensitive data)                                │
│  ├── Access control and authentication                                     │
│  ├── Security monitoring and alerting                                      │
│  └── Compliance reporting and validation                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### **Compliance Framework**

- **GDPR Compliance**: Right to erasure, data portability, consent management
- **SOX Controls**: Financial data handling, audit trails, access logging
- **PCI DSS**: Payment card data protection (if applicable)
- **Industry Standards**: ISO 27001, NIST Cybersecurity Framework

---

## Deployment & Operations

### **Container Architecture**

```yaml
services:
  ticketing-processor:
    image: ticketing-processor:${VERSION}
    environment:
      - CONFIG_ENV=${ENV}
      - VAULT_TOKEN=${VAULT_TOKEN}
    env_file:
      - .env.${ENV}
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    resources:
      limits:
        memory: 512Mi
        cpu: 500m
      requests:
        memory: 256Mi
        cpu: 250m
```

### **Monitoring Stack**

- **Metrics**: Prometheus + Grafana dashboards
- **Logging**: ELK Stack or Splunk integration
- **Tracing**: OpenTelemetry for distributed tracing
- **Alerting**: PagerDuty/Slack integration for critical failures

### **NATS Administration UI**

**Enterprise NATS Management Interface** - Comprehensive web-based administration for Eva messaging infrastructure:

**Core Features**:
- **Stream Management**: Create, edit, delete, and configure JetStream streams
- **User Administration**: Manage NATS users, passwords, and permissions
- **Real-time Message Monitoring**: Live visualization of message flow across topics
- **Consumer Management**: View, create, and manage JetStream consumers
- **Performance Analytics**: Throughput metrics, latency monitoring, storage usage
- **Configuration Management**: Stream settings, retention policies, replica configuration
- **Security Administration**: Authentication setup, authorization rules, TLS certificate management

**Technical Implementation**:
```
┌─────────────────────────────────────────────────────────────────┐
│                    NATS Admin UI Architecture                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Frontend (React/Vue)          Backend API            NATS     │
│  ┌─────────────────┐          ┌─────────────┐       ┌────────┐ │
│  │ • Stream Mgmt   │◄────────►│ • NATS SDK  │◄─────►│ Server │ │
│  │ • User Admin    │          │ • REST API  │       │ Cluster│ │
│  │ • Live Monitor  │          │ • WebSocket │       │        │ │
│  │ • Metrics Dash  │          │ • Auth Layer│       │        │ │
│  └─────────────────┘          └─────────────┘       └────────┘ │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Deployment Integration**:
```yaml
services:
  nats-admin-ui:
    image: eva-nats-admin:latest
    ports:
      - "3000:3000"  # Web interface
    environment:
      - NATS_SERVERS=nats://eva-nats:4222
      - ADMIN_USER=${NATS_ADMIN_USER}
      - ADMIN_PASSWORD=${NATS_ADMIN_PASSWORD}
    networks:
      - eva-messaging
    depends_on:
      - eva-nats
```

**Enterprise Benefits**:
- **Operational Efficiency**: Reduce NATS administration time by 80%
- **Visibility**: Real-time insights into message processing and system health
- **Security**: Centralized user and permission management
- **Troubleshooting**: Live message tracing and performance diagnostics
- **Compliance**: Audit trails for all administrative actions

### **Operational Procedures**

- **Health Monitoring**: Automated health checks and recovery
- **Backup & Recovery**: Processing state persistence and replay capability
- **Scaling**: Horizontal scaling with leader election
- **Deployment**: Blue/green deployments with rollback capability

---

## Migration Strategy

### **✅ Phase 1: Enterprise Monitoring & Observability (COMPLETE)**
1. ✅ Health monitoring system with component-level checks
2. ✅ HTTP health endpoints for Kubernetes and APM integration
3. ✅ Knowledge graph entity extraction from ticketing data  
4. ✅ Circuit breaker and resilience patterns implementation
5. ✅ Comprehensive test framework with integration, browser, and manual tests
6. ✅ APM platform compatibility (Prometheus, DataDog, New Relic, Elastic)

### **Phase 2: Critical Security (Weeks 1-2)**  
7. Fix SQL injection vulnerability
8. Remove exposed credentials
9. Implement secure configuration management
10. Basic audit logging

### **Phase 3: Architecture Improvements (Weeks 3-4)**
11. Connection management consolidation
12. Fix broken scheduler logic
13. Enhanced error handling and monitoring
14. Structured logging implementation

### **Phase 4: Multi-Table Capability (Weeks 5-6)**
15. Generic table processing framework
16. Topic routing implementation
17. Data governance foundation
18. Extended testing coverage

### **Phase 5: Enterprise Hardening (Weeks 7-8)**
19. Advanced monitoring and alerting
20. Performance optimization
21. Security penetration testing
22. Production deployment preparation

### **Phase 6: Administrative UI & Operations (Weeks 9-10)**
23. NATS Administration UI development
24. Stream management interface
25. Real-time message monitoring dashboard
26. User and permission management system
27. Performance analytics and reporting
28. Security administration interface

---

## Success Metrics

### **Security Metrics**
- Zero SQL injection vulnerabilities
- 100% secret management compliance
- Complete audit trail coverage
- Encryption at rest and in transit

### **Operational Metrics** 
- 99.9% uptime SLA
- <5 minute mean time to recovery
- Zero data loss incidents
- <1 second average processing latency

### **Business Metrics**
- ✅ Knowledge graph entity extraction implemented
- ✅ Real-time health monitoring operational
- Multi-table ingestion capability (pending)
- Compliance audit readiness (pending)
- Horizontal scaling verification (pending)

---

This future state design transforms the current prototype into an enterprise-ready data pipeline that maintains its architectural strengths while addressing all critical security, operational, and scalability requirements. The design provides a solid foundation for multi-table ingestion and prepares the system for future growth and compliance needs.