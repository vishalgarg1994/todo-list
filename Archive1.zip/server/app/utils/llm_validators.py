"""
LLM Validators - Phase 1 Architecture

This module provides extensibility points for validating LLM-generated outputs,
particularly Cypher queries, and managing prompts for A/B testing.

Design Philosophy:
- Protocol-based: Easy to add validators (syntax, semantic, security, etc.)
- No-op defaults: Permissive by default (current behavior preserved)
- Confidence scoring: Track validation confidence for monitoring
- Prompt registry: Version and A/B test prompts
- Safety first: Detect dangerous operations

Usage:
    # In ask_questions.py:
    from utils.llm_validators import get_cypher_validator

    cypher_query = await baml_client.TranslateToCypher(...)

    validation = get_cypher_validator().validate(cypher_query, schema)
    if not validation.is_valid:
        raise ToolError(f"Invalid Cypher: {validation.errors}")

    result = memgraph_client.execute(cypher_query)

Future Implementation (Phase 2):
    # In main.py startup:
    if config.llm_validation_enabled:
        from utils.cypher_syntax_validator import CypherSyntaxValidator
        set_cypher_validator(CypherSyntaxValidator())
"""

from typing import Protocol, List, Dict, Any, Optional, runtime_checkable
from dataclasses import dataclass, field
from enum import Enum
import re
import logging

logger = logging.getLogger(__name__)


# ============================================================================
# Validation Result Types
# ============================================================================

class ValidationSeverity(str, Enum):
    """Severity levels for validation issues."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class ValidationIssue:
    """
    Represents a single validation issue.

    Attributes:
        severity: How serious the issue is
        message: Human-readable description
        location: Where in the query the issue occurred (line, character, etc.)
        suggestion: Optional suggestion for fixing the issue
    """
    severity: ValidationSeverity
    message: str
    location: Optional[str] = None
    suggestion: Optional[str] = None


@dataclass
class ValidationResult:
    """
    Result of validating an LLM-generated output.

    Attributes:
        is_valid: Whether the output passes validation
        confidence: Confidence score 0.0-1.0 (how confident validator is)
        errors: List of error-level issues (make is_valid=False)
        warnings: List of warning-level issues (don't block, but logged)
        info: List of informational messages
        metadata: Additional validation metadata
    """
    is_valid: bool
    confidence: float  # 0.0 to 1.0
    errors: List[ValidationIssue] = field(default_factory=list)
    warnings: List[ValidationIssue] = field(default_factory=list)
    info: List[ValidationIssue] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def add_error(self, message: str, location: str = None, suggestion: str = None) -> None:
        """Add an error (makes validation fail)."""
        self.errors.append(ValidationIssue(
            severity=ValidationSeverity.ERROR,
            message=message,
            location=location,
            suggestion=suggestion
        ))
        self.is_valid = False

    def add_warning(self, message: str, location: str = None, suggestion: str = None) -> None:
        """Add a warning (doesn't fail validation, but logged)."""
        self.warnings.append(ValidationIssue(
            severity=ValidationSeverity.WARNING,
            message=message,
            location=location,
            suggestion=suggestion
        ))
        # Reduce confidence for warnings
        self.confidence = max(0.0, self.confidence - 0.1)

    def add_info(self, message: str, location: str = None) -> None:
        """Add informational message."""
        self.info.append(ValidationIssue(
            severity=ValidationSeverity.INFO,
            message=message,
            location=location
        ))

    def get_all_issues(self) -> List[ValidationIssue]:
        """Get all issues (errors + warnings + info) sorted by severity."""
        return sorted(
            self.errors + self.warnings + self.info,
            key=lambda x: ["critical", "error", "warning", "info"].index(x.severity.value)
        )


# ============================================================================
# Cypher Validation Protocol
# ============================================================================

@runtime_checkable
class CypherValidator(Protocol):
    """
    Protocol for validating LLM-generated Cypher queries.

    All Cypher validators must implement this method.
    """

    def validate(self, cypher: str, schema: Optional[Dict[str, Any]] = None) -> ValidationResult:
        """
        Validate a Cypher query.

        Args:
            cypher: The Cypher query string to validate
            schema: Optional schema information for semantic validation

        Returns:
            ValidationResult with validation outcome
        """
        ...


class NoOpCypherValidator:
    """
    Default no-op Cypher validator.

    This validator accepts all queries with 100% confidence. This preserves
    the current behavior where no validation is performed.
    """

    def validate(self, cypher: str, schema: Optional[Dict[str, Any]] = None) -> ValidationResult:
        """Always return valid result."""
        return ValidationResult(
            is_valid=True,
            confidence=1.0,
            metadata={"validator": "noop", "note": "Validation disabled"}
        )


class BasicCypherValidator:
    """
    Basic Cypher validator that checks for common issues.

    This validator performs simple checks without requiring a full Cypher parser:
    - Dangerous operations (DELETE, DROP, REMOVE)
    - Balanced parentheses/brackets/braces
    - Required clauses (MATCH, CREATE, RETURN, etc.)
    - Potential injection patterns
    - Query complexity limits

    This is a lightweight validator suitable for immediate use.
    """

    # Dangerous keywords that should not appear in read-only queries
    DANGEROUS_KEYWORDS = ["DELETE", "DETACH DELETE", "DROP", "REMOVE", "SET"]

    # Required Cypher clauses (at least one must be present)
    REQUIRED_CLAUSES = ["MATCH", "CREATE", "MERGE", "RETURN", "WITH", "UNWIND"]

    def __init__(
        self,
        allow_writes: bool = False,
        max_query_length: int = 10000,
        max_clauses: int = 20
    ):
        """
        Initialize validator.

        Args:
            allow_writes: If False, reject queries with DELETE/REMOVE/etc.
            max_query_length: Maximum query length (prevent DoS)
            max_clauses: Maximum number of clauses (prevent complexity DoS)
        """
        self.allow_writes = allow_writes
        self.max_query_length = max_query_length
        self.max_clauses = max_clauses

    def validate(self, cypher: str, schema: Optional[Dict[str, Any]] = None) -> ValidationResult:
        """Validate Cypher query."""
        result = ValidationResult(is_valid=True, confidence=1.0)

        # Check 1: Query length
        if len(cypher) > self.max_query_length:
            result.add_error(
                f"Query too long: {len(cypher)} chars (max: {self.max_query_length})",
                suggestion=f"Simplify query to under {self.max_query_length} characters"
            )
            return result

        # Check 2: Dangerous operations
        cypher_upper = cypher.upper()
        if not self.allow_writes:
            for keyword in self.DANGEROUS_KEYWORDS:
                if keyword in cypher_upper:
                    result.add_error(
                        f"Dangerous operation detected: {keyword}",
                        suggestion="Read-only queries should only use MATCH and RETURN"
                    )

        # Check 3: Balanced brackets
        if cypher.count("(") != cypher.count(")"):
            result.add_error(
                "Unbalanced parentheses in query",
                suggestion="Check for missing opening or closing parentheses"
            )

        if cypher.count("[") != cypher.count("]"):
            result.add_error(
                "Unbalanced square brackets in query",
                suggestion="Check for missing opening or closing brackets"
            )

        if cypher.count("{") != cypher.count("}"):
            result.add_error(
                "Unbalanced curly braces in query",
                suggestion="Check for missing opening or closing braces"
            )

        # Check 4: Required clauses
        has_required_clause = any(
            clause in cypher_upper for clause in self.REQUIRED_CLAUSES
        )
        if not has_required_clause:
            result.add_error(
                "Query missing required clause (MATCH, CREATE, RETURN, etc.)",
                suggestion="Cypher queries must contain at least one valid clause"
            )

        # Check 5: Injection patterns
        # Look for patterns like '; DROP or ") OR "
        injection_patterns = [
            r"['\"]\s*;\s*\w+",  # '; DROP
            r"\"\s*OR\s*\"",  # " OR "
            r"'\s*OR\s*'",  # ' OR '
        ]
        for pattern in injection_patterns:
            if re.search(pattern, cypher, re.IGNORECASE):
                result.add_warning(
                    f"Potential injection pattern detected: {pattern}",
                    suggestion="Review query for malicious input"
                )

        # Check 6: Complexity (number of clauses)
        clause_count = sum(
            cypher_upper.count(clause) for clause in self.REQUIRED_CLAUSES
        )
        if clause_count > self.max_clauses:
            result.add_warning(
                f"Query complexity high: {clause_count} clauses (max: {self.max_clauses})",
                suggestion="Consider breaking into multiple simpler queries"
            )

        # Check 7: Schema validation (if schema provided)
        if schema and not result.errors:
            self._validate_against_schema(cypher, schema, result)

        # Adjust confidence based on issues found
        if result.warnings:
            result.confidence = max(0.7, result.confidence - (len(result.warnings) * 0.1))

        result.metadata["validator"] = "basic"
        result.metadata["query_length"] = len(cypher)
        result.metadata["clause_count"] = clause_count

        return result

    def _validate_against_schema(
        self,
        cypher: str,
        schema: Dict[str, Any],
        result: ValidationResult
    ) -> None:
        """
        Validate query against schema (basic checks).

        Args:
            cypher: Query string
            schema: Schema dictionary
            result: ValidationResult to add warnings to
        """
        # Extract node labels from query (simple regex)
        # Pattern: (variable:Label) or (:Label)
        label_pattern = r'\((?:\w+:)?(\w+)\)'
        labels_in_query = set(re.findall(label_pattern, cypher))

        # Get valid labels from schema
        valid_labels = set()
        if "nodes" in schema:
            for node_def in schema["nodes"]:
                if isinstance(node_def, dict) and "label" in node_def:
                    valid_labels.add(node_def["label"])
                elif isinstance(node_def, str):
                    valid_labels.add(node_def)

        # Check for labels not in schema
        for label in labels_in_query:
            if label not in valid_labels and label not in ["MATCH", "CREATE", "RETURN"]:
                result.add_warning(
                    f"Label '{label}' not found in schema",
                    suggestion=f"Valid labels: {', '.join(sorted(valid_labels))}"
                )


# Global validator instance (can be replaced at runtime)
_cypher_validator: CypherValidator = NoOpCypherValidator()


def set_cypher_validator(validator: CypherValidator) -> None:
    """
    Set the global Cypher validator.

    Call this during application startup to enable query validation.

    Example:
        from utils.llm_validators import BasicCypherValidator
        set_cypher_validator(BasicCypherValidator(allow_writes=False))
    """
    global _cypher_validator
    _cypher_validator = validator
    logger.info(f"Cypher validator set to: {validator.__class__.__name__}")


def get_cypher_validator() -> CypherValidator:
    """Get the global Cypher validator."""
    return _cypher_validator


# ============================================================================
# Prompt Registry (for A/B Testing)
# ============================================================================

class PromptRegistry:
    """
    Registry for managing prompt versions and A/B testing.

    Allows storing multiple versions of prompts and tracking which version
    is active. Useful for:
    - Versioning prompts as they evolve
    - A/B testing different prompt variations
    - Rolling back to previous prompts if new ones underperform

    Usage:
        registry = get_prompt_registry()

        # Register multiple versions
        registry.register_prompt("cypher_generation", "v1", "Original prompt...")
        registry.register_prompt("cypher_generation", "v2", "Improved prompt...")

        # Set active version
        registry.set_active_version("cypher_generation", "v2")

        # Get prompt (uses active version)
        prompt = registry.get_prompt("cypher_generation")
    """

    def __init__(self):
        # prompts[name][version] = template
        self.prompts: Dict[str, Dict[str, str]] = {}
        # active_versions[name] = version
        self.active_versions: Dict[str, str] = {}
        # usage_stats[name][version] = count
        self.usage_stats: Dict[str, Dict[str, int]] = {}

    def register_prompt(self, name: str, version: str, template: str) -> None:
        """
        Register a prompt version.

        Args:
            name: Prompt name (e.g., "cypher_generation")
            version: Version identifier (e.g., "v1", "v2", "experimental")
            template: The prompt template string
        """
        if name not in self.prompts:
            self.prompts[name] = {}
            self.usage_stats[name] = {}

        self.prompts[name][version] = template
        self.usage_stats[name][version] = 0

        # If this is the first version, make it active
        if name not in self.active_versions:
            self.active_versions[name] = version
            logger.info(f"Registered first prompt version: {name}/{version} (now active)")
        else:
            logger.info(f"Registered prompt version: {name}/{version}")

    def set_active_version(self, name: str, version: str) -> None:
        """
        Set the active version for a prompt.

        Args:
            name: Prompt name
            version: Version to activate

        Raises:
            ValueError: If prompt name or version doesn't exist
        """
        if name not in self.prompts:
            raise ValueError(f"Prompt '{name}' not registered")

        if version not in self.prompts[name]:
            available = ", ".join(self.prompts[name].keys())
            raise ValueError(f"Version '{version}' not found. Available: {available}")

        old_version = self.active_versions.get(name, "none")
        self.active_versions[name] = version
        logger.info(f"Activated prompt version: {name}/{version} (was: {old_version})")

    def get_prompt(self, name: str, version: Optional[str] = None) -> str:
        """
        Get a prompt template.

        Args:
            name: Prompt name
            version: Specific version (if None, uses active version)

        Returns:
            Prompt template string

        Raises:
            ValueError: If prompt not found
        """
        if name not in self.prompts:
            raise ValueError(f"Prompt '{name}' not registered")

        # Use specified version or active version
        use_version = version or self.active_versions.get(name)

        if not use_version or use_version not in self.prompts[name]:
            available = ", ".join(self.prompts[name].keys())
            raise ValueError(
                f"Version '{use_version}' not found for prompt '{name}'. "
                f"Available: {available}"
            )

        # Track usage
        self.usage_stats[name][use_version] += 1

        return self.prompts[name][use_version]

    def list_prompts(self) -> Dict[str, Dict[str, Any]]:
        """
        List all registered prompts with metadata.

        Returns:
            Dictionary of prompt metadata
        """
        result = {}
        for name, versions in self.prompts.items():
            result[name] = {
                "versions": list(versions.keys()),
                "active_version": self.active_versions.get(name),
                "usage_stats": self.usage_stats.get(name, {})
            }
        return result

    def get_usage_stats(self, name: str) -> Dict[str, int]:
        """
        Get usage statistics for a prompt.

        Args:
            name: Prompt name

        Returns:
            Dictionary of version -> usage count
        """
        return self.usage_stats.get(name, {}).copy()


# Global prompt registry
_prompt_registry = PromptRegistry()


def get_prompt_registry() -> PromptRegistry:
    """Get the global prompt registry."""
    return _prompt_registry


# ============================================================================
# Utility Functions
# ============================================================================

def is_validation_enabled() -> bool:
    """
    Check if validation is enabled (i.e., not using NoOp validator).

    Returns:
        True if real validation is configured
    """
    return not isinstance(_cypher_validator, NoOpCypherValidator)


def validate_and_log(
    cypher: str,
    schema: Optional[Dict[str, Any]] = None,
    raise_on_error: bool = True
) -> ValidationResult:
    """
    Convenience function to validate and log result.

    Args:
        cypher: Cypher query to validate
        schema: Optional schema for validation
        raise_on_error: If True, raise exception on validation failure

    Returns:
        ValidationResult

    Raises:
        ValueError: If validation fails and raise_on_error=True
    """
    result = _cypher_validator.validate(cypher, schema)

    # Log validation result
    if result.errors:
        logger.error(f"Cypher validation failed: {len(result.errors)} errors")
        for error in result.errors:
            logger.error(f"  - {error.message}")

    if result.warnings:
        logger.warning(f"Cypher validation warnings: {len(result.warnings)}")
        for warning in result.warnings:
            logger.warning(f"  - {warning.message}")

    # Raise exception if requested
    if not result.is_valid and raise_on_error:
        error_messages = [e.message for e in result.errors]
        raise ValueError(f"Cypher validation failed: {'; '.join(error_messages)}")

    return result
