import logging
import json
import sys
from datetime import datetime


class StructuredFormatter(logging.Formatter):
    """Custom formatter that outputs structured JSON logs"""

    def format(self, record: logging.LogRecord) -> str:
        # Create the base log entry
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }

        # Add correlation ID if available
        correlation_id = getattr(record, "correlation_id", None)
        if correlation_id:
            log_entry["correlation_id"] = correlation_id

        # Add extra fields if present
        if hasattr(record, "extra") and isinstance(record.extra, dict):
            log_entry.update(record.extra)

        # Add exception info if present
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_entry, default=str)


def configure_logging(log_level: str = "INFO", use_structured: bool = True):
    """Configure application logging"""

    # Clear existing handlers
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Set log level
    level = getattr(logging, log_level.upper(), logging.INFO)
    root_logger.setLevel(level)

    # Create console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)

    if use_structured:
        # Use structured JSON formatter
        formatter = StructuredFormatter()
    else:
        # Use standard formatter for development
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )

    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    # Suppress noisy third-party loggers
    logging.getLogger("asyncpg").setLevel(logging.WARNING)
    logging.getLogger("nats").setLevel(logging.INFO)

    return root_logger


class CorrelationLogger:
    """Logger that automatically includes correlation ID"""

    def __init__(self, logger_name: str):
        self.logger = logging.getLogger(logger_name)

    def _log_with_context(
        self, level: int, message: str, correlation_id: str = None, **kwargs
    ):
        """Log with correlation context"""
        extra = kwargs.get("extra", {})
        if correlation_id:
            extra["correlation_id"] = correlation_id

        # Add any additional context
        extra.update({k: v for k, v in kwargs.items() if k != "extra"})

        self.logger.log(level, message, extra=extra)

    def info(self, message: str, correlation_id: str = None, **kwargs):
        self._log_with_context(logging.INFO, message, correlation_id, **kwargs)

    def warning(self, message: str, correlation_id: str = None, **kwargs):
        self._log_with_context(logging.WARNING, message, correlation_id, **kwargs)

    def error(self, message: str, correlation_id: str = None, **kwargs):
        self._log_with_context(logging.ERROR, message, correlation_id, **kwargs)

    def debug(self, message: str, correlation_id: str = None, **kwargs):
        self._log_with_context(logging.DEBUG, message, correlation_id, **kwargs)

    def critical(self, message: str, correlation_id: str = None, **kwargs):
        self._log_with_context(logging.CRITICAL, message, correlation_id, **kwargs)
