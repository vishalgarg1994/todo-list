import asyncio
import nats
import logging
from nats.errors import NoServersError, TimeoutError


class NatsSubscriber:
    def __init__(self, nats_url: str, stream_name: str, subject: str):
        """
        Initialize the NATS JetStream subscriber.
        """
        self.nats_url = nats_url
        self.stream_name = stream_name
        self.subject = subject
        self.conn = None
        self.js = None
        self.sub = None
        self.logger = logging.getLogger(__name__)

    async def connect(self):
        """Establish a connection to the NATS server with JetStream."""
        max_attempts = 5
        attempt = 0

        while attempt < max_attempts:
            try:
                self.conn = await nats.connect(self.nats_url)
                # Access JetStream context directly
                self.js = self.conn.jetstream()
                self.logger.info(f"Connected to NATS server: {self.nats_url}")
                return
            except NoServersError:
                self.logger.error(
                    f"NATS no servers error (attempt {attempt + 1}).", exc_info=True
                )
            except TimeoutError:
                self.logger.error(
                    f"NATS timeout error (attempt {attempt + 1}).", exc_info=True
                )
            except Exception as e:
                self.logger.error(
                    f"Failed to connect to NATS (attempt {attempt + 1}): {e}",
                    exc_info=True,
                )
            attempt += 1
            if attempt < max_attempts:
                await asyncio.sleep(2**attempt)

        self.conn = None
        raise Exception("Failed to connect to NATS after multiple attempts.")

    async def subscribe(self):
        """Subscribe to the JetStream stream and process messages."""
        if self.conn is None or self.js is None:
            await self.connect()

        if self.conn and self.js:
            try:

                async def message_handler(msg):
                    msg_subject = msg.subject
                    stream = msg.stream
                    payload = msg.data.decode()
                    self.logger.info(
                        f"Received message on subject '{msg_subject}' "
                        f"in stream '{stream}': {payload}"
                    )
                    await msg.ack()

                self.sub = await self.js.subscribe(
                    subject=self.subject, stream=self.stream_name, cb=message_handler
                )
                self.logger.info(
                    f"Subscribed to '{self.subject}' " f"on stream '{self.stream_name}'"
                )

            except Exception as e:
                self.logger.error(f"Error subscribing to JetStream: {e}", exc_info=True)

    async def unsubscribe(self):
        """Unsubscribe from the JetStream subscription."""
        if self.sub:
            await self.sub.unsubscribe()
            self.logger.info(f"Unsubscribed from '{self.subject}'")
            self.sub = None

    async def close(self):
        """Close the connection to the NATS server."""
        if self.conn:
            try:
                await self.conn.close()
                self.logger.info("Disconnected from NATS server.")
            except Exception as e:
                self.logger.error(f"Error closing NATS connection: {e}", exc_info=True)
            finally:
                self.conn = None
                self.js = None
                self.sub = None

    async def __aenter__(self):
        """Asynchronous context manager entry."""
        await self.connect()
        await self.subscribe()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Asynchronous context manager exit."""
        await self.unsubscribe()
        await self.close()


# async def main():
#     logging.basicConfig(
#           level=logging.INFO,
#           format='%(asctime)s - %(levelname)s - %(message)s'
#       )
#     logger = logging.getLogger(__name__)

#     nats_url = "nats://nats:4222"
#     stream_name = "your_stream_name"
#     topic = "data_pipeline_topic"

#     try:
#         async with NatsSubscriber(
#           nats_url, stream_name, topic) as subscriber:
#             while True:
#                 await asyncio.sleep(1)
#     except Exception as e:
#         logger.error(f"Subscriber failed: {e}", exc_info=True)

# if __name__ == "__main__":
#     asyncio.run(main())
