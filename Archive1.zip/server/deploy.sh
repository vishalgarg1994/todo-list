#!/bin/bash
# Enhanced MCP Ticket System Deployment Script
# Usage: ./deploy.sh [environment] [action]
# Environments: dev (default), test, prod
# Actions: up, down, logs, status

set -e

# Default values
ENVIRONMENT=${1:-dev}
ACTION=${2:-up}

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Validate environment
case $ENVIRONMENT in
    dev)
        ENVIRONMENT="dev"
        COMPOSE_FILE="docker-compose.yml"
        ENV_FILE=".env.dev"
        ;;
    test)
        ENVIRONMENT="test"
        COMPOSE_FILE="docker-compose.test.yml"
        ENV_FILE=".env.test"
        ;;
    prod)
        ENVIRONMENT="prod"
        COMPOSE_FILE="docker-compose.prod.yml"
        ENV_FILE=".env.prod"
        ;;
    *)
        log_error "Invalid environment: $ENVIRONMENT"
        log_info "Valid environments: dev, test, prod"
        exit 1
        ;;
esac

# Check if environment file exists
if [[ ! -f "$ENV_FILE" ]]; then
    log_error "Environment file not found: $ENV_FILE"
    log_info "Please create the environment file or use .env.example as a template"
    exit 1
fi

log_info "🚀 Enhanced MCP Ticket System - $ENVIRONMENT Environment"
log_info "Using compose file: $COMPOSE_FILE"
log_info "Using environment: $ENV_FILE"

# Execute action
case $ACTION in
    up|start)
        log_info "Starting services..."
        if [[ "$ENVIRONMENT" == "dev" ]]; then
            # Use override for development
            docker-compose -f $COMPOSE_FILE up -d
        else
            # Use specific environment file
            docker-compose -f $COMPOSE_FILE --env-file $ENV_FILE up -d
        fi
        log_success "Services started successfully!"
        ;;
    down|stop)
        log_info "Stopping services..."
        if [[ "$ENVIRONMENT" == "dev" ]]; then
            docker-compose -f $COMPOSE_FILE down
        else
            docker-compose -f $COMPOSE_FILE --env-file $ENV_FILE down
        fi
        log_success "Services stopped successfully!"
        ;;
    restart)
        log_info "Restarting services..."
        $0 $ENVIRONMENT down
        sleep 2
        $0 $ENVIRONMENT up
        ;;
    logs)
        log_info "Showing logs..."
        if [[ "$ENVIRONMENT" == "dev" ]]; then
            docker-compose -f $COMPOSE_FILE logs -f
        else
            docker-compose -f $COMPOSE_FILE --env-file $ENV_FILE logs -f
        fi
        ;;
    status)
        log_info "Service status:"
        if [[ "$ENVIRONMENT" == "dev" ]]; then
            docker-compose -f $COMPOSE_FILE ps
        else
            docker-compose -f $COMPOSE_FILE --env-file $ENV_FILE ps
        fi
        ;;
    health)
        log_info "Running health check..."
        python3 system_health_check.py
        ;;
    build)
        log_info "Building services..."
        if [[ "$ENVIRONMENT" == "dev" ]]; then
            docker-compose -f $COMPOSE_FILE build
        else
            docker-compose -f $COMPOSE_FILE --env-file $ENV_FILE build
        fi
        log_success "Build completed!"
        ;;
    *)
        log_error "Invalid action: $ACTION"
        log_info "Valid actions: up, down, restart, logs, status, health, build"
        exit 1
        ;;
esac

log_success "Operation completed for $ENVIRONMENT environment!"