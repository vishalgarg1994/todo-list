from neo4j import AsyncGraphDatabase
import logging
import time
from typing import Dict, Any, Optional


class MemgraphClient:
    """
    Async Memgraph database client using Neo4j Bolt protocol.
    Provides high-performance non-blocking graph database operations with concurrent access support.
    """

    def __init__(self, uri: str, user: str, password: str, database: str = "memgraph", cyphers_dict: Dict = None):
        self.uri = uri
        self.user = user
        self.password = password
        self.database = database
        self.driver = None
        self.cyphers_dict = cyphers_dict or {}
        self.logger = logging.getLogger(__name__)

    async def connect(self):
        """Create async database connection"""
        try:
            self.logger.info(f"Connecting to Memgraph at: {self.uri}")
            auth = (self.user, self.password) if self.user else None
            self.driver = AsyncGraphDatabase.driver(self.uri, auth=auth)

            # Test connection
            async with self.driver.session(database=self.database) as session:
                result = await session.run("RETURN 1 AS test")
                await result.single()

            self.logger.info("Memgraph connection established successfully.")
        except Exception as e:
            self.logger.error(f"Error connecting to Memgraph: {e}")
            raise

    def clearDatabase(self):
        """
        Removes all data from database.
        Deletes all nodes and relationships in Memgraph.
        """
        try:
            self.logger.info(f"Cleaning Memgraph database...")

            with self.driver.session(database=self.database) as session:
                # Delete all nodes and relationships
                session.run("MATCH (n) DETACH DELETE n")
                self.logger.info("All nodes and relationships deleted.")

        except Exception as e:
            self.logger.error(f"❌ Error cleaning database: {e}")
            raise

    async def closeConnection(self):
        """Close driver connection"""
        self.logger.info("Closing Memgraph connection.")
        try:
            if self.driver:
                await self.driver.close()
                self.logger.info("Connection closed successfully.")
        except Exception as e:
            self.logger.error(f"Warning: Error closing connection: {e}")

    async def checkConnection(self):
        """Test database connection"""
        try:
            async with self.driver.session(database=self.database) as session:
                result = await session.run("RETURN 1 AS test")
                record = await result.single()
                if record["test"] != 1:
                    raise Exception("ERROR: Database connection test failed")
                self.logger.info("✅ Connection test passed")
        except Exception as e:
            self.logger.error(f"Connection test failed: {e}")
            raise

    async def execute(self, query: str, params: Dict[str, Any] = None):
        """
        Executes a Cypher query asynchronously and returns the result as a list of records.

        Args:
            query: Cypher query string
            params: Optional dictionary of query parameters

        Returns:
            List of Neo4j Record objects (consumed within session context)
        """
        async with self.driver.session(database=self.database) as session:
            result = await session.run(query, params or {})
            # Convert to list immediately to consume result within session context
            return [record async for record in result]

    async def executeQuery(self, query: str, params: Dict[str, Any] = None, message: str = "") -> bool:
        """
        Executes a Memgraph query asynchronously with basic error handling.
        Returns True if successful, False if failed.
        NOTE: Transaction handling should be done OUTSIDE this function.
        """
        if message:
            self.logger.info(f"    Executing: {message}...")

        startTime = time.time()

        try:
            # Ensure query ends with semicolon for consistency
            queryToExecute = query.strip()
            if not queryToExecute.endswith(";"):
                queryToExecute += ";"

            async with self.driver.session(database=self.database) as session:
                await session.run(queryToExecute, params or {})

            duration = time.time() - startTime
            if message:
                self.logger.info(f"Success ({duration:.2f}s)")
            return True

        except Exception as e:
            if message:
                self.logger.error("FAILED!")
            # Use original query in error message for clarity
            self.logger.error(f"    Error executing query:\n    Query: {query}\n    Params: {params}\n    Error: {e}")
            return False

    async def shutdown(self):
        """Gracefully shuts down the Memgraph connection."""
        self.logger.info("Shutting down Memgraph client...")
        try:
            if self.driver:
                await self.driver.close()
                self.driver = None
            self.logger.info("Memgraph client shutdown complete.")
        except Exception as e:
            self.logger.error(f"Error during shutdown: {e}")

    def createSchema(self):
        """Executes schema creation queries dynamically (optional for Memgraph)."""

        # Get schema queries from cyphers_dict
        schema_queries = self.cyphers_dict.get("schema_create_nodes_rels_tables_queries", {})

        if not schema_queries:
            self.logger.info("ℹ️  No schema queries provided - skipping (Memgraph uses dynamic schemas)")
            return True

        try:
            with self.driver.session(database=self.database) as session:
                # Start transaction
                tx = session.begin_transaction()

                try:
                    self.logger.info("  Beginning schema transaction...")

                    # Execute schema queries
                    # Split by semicolon if multiple queries
                    queries = [q.strip() for q in schema_queries.split(';') if q.strip()]

                    for query in queries:
                        if query:
                            tx.run(query + ";")

                    # Commit transaction
                    tx.commit()
                    self.logger.info("✅ Schema transaction committed successfully.")
                    return True

                except Exception as e:
                    tx.rollback()
                    self.logger.error(f"  ERROR during schema definition: {e}. Transaction rolled back.")
                    raise

        except Exception as e:
            self.logger.error(f"  ERROR during schema creation: {e}")
            return False

    def execute_with_dataframe(self, dataframe, query_template: str):
        """
        Execute batch insert from Polars DataFrame.
        This is used for bulk loading data using Memgraph's UNWIND clause.

        Args:
            dataframe: Polars DataFrame with data to insert
            query_template: Cypher query template with parameters
        """
        try:
            self.logger.info(f"  Executing batch insert with {len(dataframe)} records...")

            # Convert DataFrame to list of dicts
            records = dataframe.to_dicts()

            with self.driver.session(database=self.database) as session:
                # Use UNWIND for batch insert (Memgraph best practice)
                batch_query = f"""
                UNWIND $batch AS row
                {query_template}
                """

                # Process in batches of 1000 for better performance
                batch_size = 1000
                for i in range(0, len(records), batch_size):
                    batch = records[i:i + batch_size]
                    session.run(batch_query, {"batch": batch})

                self.logger.info(f"  ✅ Inserted {len(records)} records successfully.")

        except Exception as e:
            self.logger.error(f"  ❌ Error during batch insert: {e}")
            raise
