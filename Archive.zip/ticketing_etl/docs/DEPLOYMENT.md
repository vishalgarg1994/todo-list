# Kubernetes Deployment Guide

This guide covers deploying the Ticketing Data Processor to Kubernetes using Helm charts.

## 🏗️ **Architecture Overview**

The application is designed as a **singleton pipeline service** with:
- **Single replica** (replicas: 1) - multiple instances would create duplicate processing
- **Stateless design** - no persistent volumes required
- **Daily batch processing** - cron-based scheduling
- **Health monitoring** - comprehensive health endpoints for Kubernetes

## 📋 **Prerequisites**

- Kubernetes cluster (1.19+)
- Helm 3.0+
- kubectl configured for your cluster
- Docker image built and pushed to registry

## 🚀 **Quick Deployment**

### **Development Environment**
```bash
# Navigate to helm directory
cd helm

# Deploy to development
./deploy.sh dev
```

### **Production Environment**
```bash
# Deploy to production
./deploy.sh prod --upgrade
```

### **Dry Run**
```bash
# Test deployment without actually deploying
./deploy.sh staging --dry-run
```

## 📁 **File Structure**

```
helm/
├── Chart.yaml                 # Helm chart metadata
├── values.yaml               # Default values
├── values-dev.yaml           # Development overrides
├── values-prod.yaml          # Production overrides  
├── deploy.sh                 # Deployment script
└── templates/
    ├── deployment.yaml       # Main deployment
    ├── service.yaml         # Health check service
    ├── secret.yaml          # Credential management
    ├── configmap.yaml       # Table configurations
    └── _helpers.tpl         # Template helpers
```

## ⚙️ **Configuration**

### **Environment Variables**

| Variable | Dev | Prod | Description |
|----------|-----|------|-------------|
| `TLS_ENABLED` | false | true | Master TLS switch |
| `DEBUG_MODE` | true | false | Enable debug logging |
| `RUN_ON_STARTUP` | true | false | Run immediately on startup |
| `INITIAL_LOAD_DAYS` | 3 | 30 | Initial data load period |
| `DAILY_LOAD_HOURS` | 2 | 25 | Daily incremental load period |

### **Resource Allocation**

| Environment | CPU Request | Memory Request | CPU Limit | Memory Limit |
|-------------|-------------|----------------|-----------|--------------|
| **Development** | 100m | 256Mi | 500m | 1Gi |
| **Production** | 500m | 1Gi | 2000m | 4Gi |

### **Health Checks**

The application provides comprehensive health endpoints:

- `/health/live` - Liveness probe (Kubernetes restarts if failing)
- `/health/ready` - Readiness probe (Kubernetes stops traffic if failing)  
- `/health/metrics` - Prometheus metrics endpoint

## 🔐 **Security Configuration**

### **TLS Configuration**

The system supports a **master TLS switch** for easy environment management:

```yaml
# Development (no certificates needed)
env:
  TLS_ENABLED: "false"

# Production (certificates required)
env:
  TLS_ENABLED: "true"
secrets:
  database:
    sslMode: "verify-full"
    sslCert: "/etc/ssl/certs/db-client.pem"
  nats:
    tlsCert: "/etc/ssl/certs/nats-client.pem"
```

### **Secret Management**

For production deployments, use external secret management:

```yaml
# External Secrets Operator example
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: ticketing-data-processor-secrets
spec:
  secretStoreRef:
    name: vault-backend
    kind: SecretStore
  target:
    name: ticketing-data-processor-secrets
  data:
    - secretKey: database-url
      remoteRef:
        key: ticketing-pipeline/database
        property: url
```

## 📊 **Multi-Table Support**

### **Adding New Tables**

1. **Update Configuration** (`config/tables.yaml`):
```yaml
tables:
  "eds.new_table":
    columns:
      - "id"
      - "name"
      - "created_on"
      - "updated_on"
    topic: "newtable.created"
    transformer_class: "NewTableTransformer"
    schedule_interval: 300
    enabled: true
```

2. **Create Transformer** (`src/domain/transformers.py`):
```python
class NewTableTransformer(BaseTransformer):
    async def transform(self, raw_data: List[Dict[str, Any]]) -> List[str]:
        # Transform logic here
        pass
```

3. **Register Transformer**:
```python
transformer_factory.register_transformer("NewTableTransformer", NewTableTransformer)
```

4. **Enable in Environment**:
```yaml
# values-dev.yaml
tableConfigs:
  overrides:
    eds.new_table:
      enabled: true
```

### **Table Management Commands**

```bash
# Enable notes processing
kubectl patch configmap ticketing-pipeline-table-configs -n data-pipeline \\
  --patch '{"data":{"tables.yaml":"...eds.notes:\\n  enabled: true"}}'

# Restart deployment to pick up changes
kubectl rollout restart deployment ticketing-pipeline -n data-pipeline
```

## 🔧 **Operational Commands**

### **Deployment Management**

```bash
# Check deployment status
kubectl get deployment ticketing-pipeline -n data-pipeline

# View logs
kubectl logs -f deployment/ticketing-pipeline -n data-pipeline

# Check health
kubectl exec deployment/ticketing-pipeline -n data-pipeline -- \\
  curl http://localhost:8080/health/live

# Port forward for local access
kubectl port-forward service/ticketing-pipeline 8080:8080 -n data-pipeline
```

### **Monitoring**

```bash
# View health metrics
curl http://localhost:8080/health/metrics

# Check processing state
curl http://localhost:8080/health/processing

# View data quality metrics
curl http://localhost:8080/health/quality
```

### **Troubleshooting**

```bash
# View events
kubectl get events -n data-pipeline --sort-by='.lastTimestamp'

# Check resource usage
kubectl top pod -n data-pipeline

# View detailed pod info
kubectl describe pod -l app.kubernetes.io/name=ticketing-data-processor -n data-pipeline
```

## 📈 **Scaling Considerations**

### **Why Single Replica?**

The pipeline is designed as a singleton service because:
- **Duplicate Processing**: Multiple replicas would process the same data
- **Cron Scheduling**: Multiple schedulers would create conflicts
- **State Management**: Memory-based state would be inconsistent

### **Scaling Through Resources**

Instead of horizontal scaling, scale vertically:
```yaml
resources:
  requests:
    cpu: 1000m      # Increase CPU for faster processing
    memory: 2Gi     # Increase memory for larger datasets
  limits:
    cpu: 4000m      # Higher limits for burst processing
    memory: 8Gi     # Support large data batches
```

### **Scaling Through Time Windows**

Adjust data loading windows for performance:
```yaml
env:
  INITIAL_LOAD_DAYS: "7"   # Smaller initial load
  DAILY_LOAD_HOURS: "12"   # Shorter daily window
```

## 🔄 **GitOps Integration**

### **ArgoCD Application**

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: ticketing-data-processor
spec:
  source:
    repoURL: https://github.com/your-org/ticketing-data-processor
    path: helm
    targetRevision: main
    helm:
      valueFiles:
      - values-prod.yaml
  destination:
    server: https://kubernetes.default.svc
    namespace: data-pipeline-prod
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

### **Flux HelmRelease**

```yaml
apiVersion: helm.toolkit.fluxcd.io/v2beta1
kind: HelmRelease
metadata:
  name: ticketing-data-processor
spec:
  chart:
    spec:
      chart: ./helm
      sourceRef:
        kind: GitRepository
        name: ticketing-data-processor
  values:
    env:
      TLS_ENABLED: "true"
  valuesFrom:
  - kind: Secret
    name: ticketing-secrets
```

## 🚨 **Production Checklist**

Before deploying to production:

- [ ] **Security**: TLS certificates configured and mounted
- [ ] **Secrets**: Database and NATS credentials in external secret store  
- [ ] **Resources**: CPU and memory limits appropriate for data volume
- [ ] **Monitoring**: Prometheus ServiceMonitor configured
- [ ] **Alerting**: Health check alerts configured
- [ ] **Backup**: Configuration backup strategy in place
- [ ] **Testing**: Dry run successful in staging environment
- [ ] **Documentation**: Table schemas analyzed and documented
- [ ] **Access**: Network policies and RBAC configured

## 📞 **Support**

For deployment issues:
1. Check the [troubleshooting section](#troubleshooting)
2. Review pod logs and events
3. Verify health endpoint responses
4. Check resource constraints and limits