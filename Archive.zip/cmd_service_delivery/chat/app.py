"""
Chat UI backend: FastAPI + LangGraph ReAct agent bridged to the MCP server.

Streams agent responses (tokens, tool calls, tool results) back to the frontend
via Server-Sent Events.

Run:
  python app.py
  uvicorn app:app --host 0.0.0.0 --port 8501
"""

import json
import logging
import os
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.memory import MemorySaver

from mcp_bridge import MCPToolBridge

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("chat-ui")

MCP_URL = os.getenv("MCP_URL", "http://localhost:8003/mcp")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

SYSTEM_PROMPT = """You are the CMD Service Delivery AI Assistant. You help users query and analyze
circuit management & delivery (CMD) service orders using specialized tools.

You have access to tools that can:
- Look up specific orders, segments, vendors, tasks, and notes
- Search across orders by status, client, vendor, location, or any field
- Perform semantic searches over order notes (finding similar content)
- Traverse the order graph (relationships between orders, vendors, segments)
- Run analytics queries and natural language questions against the graph database

When responding:
- Use tools to find specific data rather than guessing
- Present results in a clear, organized format
- If a query could match multiple tools, pick the most specific one
- For broad questions, start with get_graph_stats or ask_orders_question
- Always cite the order IDs and data returned by tools

You are talking to a service delivery manager who understands telecom terminology."""


@asynccontextmanager
async def lifespan(app: FastAPI):
    bridge = MCPToolBridge(MCP_URL)
    try:
        await bridge.connect()
        logger.info("MCP bridge connected with %d tools", len(bridge.tools))
    except Exception as e:
        logger.error("Failed to connect MCP bridge: %s", e)
        bridge.tools = []
        bridge.tool_metadata = []

    model = ChatOpenAI(
        model=OPENAI_MODEL,
        api_key=OPENAI_API_KEY,
        streaming=True,
        temperature=0,
    )

    memory = MemorySaver()
    agent = create_react_agent(
        model,
        bridge.tools,
        checkpointer=memory,
        prompt=SYSTEM_PROMPT,
    )

    app.state.bridge = bridge
    app.state.agent = agent
    app.state.memory = memory

    yield

    await bridge.disconnect()


app = FastAPI(title="CMD Chat UI", lifespan=lifespan)


@app.get("/api/tools")
async def list_tools():
    return app.state.bridge.tool_metadata


@app.post("/api/chat")
async def chat(request: Request):
    body = await request.json()
    message = body.get("message", "")
    thread_id = body.get("thread_id") or str(uuid.uuid4())

    if not message.strip():
        return JSONResponse({"error": "Empty message"}, status_code=400)

    agent = app.state.agent

    async def event_stream():
        config = {"configurable": {"thread_id": thread_id}, "recursion_limit": 80}
        input_msg = {"messages": [HumanMessage(content=message)]}

        try:
            async for event in agent.astream_events(
                input_msg, config=config, version="v2"
            ):
                kind = event["event"]

                if kind == "on_chat_model_stream":
                    chunk = event["data"].get("chunk")
                    if chunk and chunk.content:
                        yield f"data: {json.dumps({'type': 'token', 'content': chunk.content})}\n\n"

                elif kind == "on_tool_start":
                    yield f"data: {json.dumps({'type': 'tool_start', 'name': event.get('name', ''), 'args': event['data'].get('input', {})})}\n\n"

                elif kind == "on_tool_end":
                    output = event["data"].get("output", "")
                    if hasattr(output, "content"):
                        output = output.content
                    yield f"data: {json.dumps({'type': 'tool_end', 'name': event.get('name', ''), 'result': str(output)[:4000]})}\n\n"

        except Exception as e:
            logger.error("Agent stream error: %s", e, exc_info=True)
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)})}\n\n"

        yield f"data: {json.dumps({'type': 'done', 'thread_id': thread_id})}\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/api/health")
async def health():
    return {
        "status": "healthy",
        "mcp_connected": len(app.state.bridge.tools) > 0,
        "tools_count": len(app.state.bridge.tools),
    }


static_dir = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


@app.get("/")
async def index():
    return FileResponse(str(static_dir / "index.html"))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8501)
