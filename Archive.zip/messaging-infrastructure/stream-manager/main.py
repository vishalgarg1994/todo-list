#!/usr/bin/env python3
"""
Eva Group NATS Stream Manager
A Python-based tool for managing NATS JetStream streams with CLI and API capabilities
"""

import asyncio
import argparse
import sys
import logging
# Stream manager modules are in the same directory

from stream_manager import NatsStreamManager
from api_server import StreamManagerAPI
from app_provisioner import ApplicationProvisioner
from config import Config

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def create_streams_command(args):
    """Create Eva messaging infrastructure streams"""
    config = Config()
    manager = NatsStreamManager(config)

    try:
        await manager.connect()
        logger.info("🚀 Creating Eva messaging infrastructure streams...")

        # Create all Eva streams
        results = await manager.create_eva_streams()

        success_count = sum(1 for r in results if r['success'])
        total_count = len(results)

        logger.info(f"✅ Stream creation completed: {success_count}/{total_count} successful")

        for result in results:
            status = "✅" if result['success'] else "❌"
            logger.info(f"{status} {result['stream_name']}: {result['message']}")

    except Exception as e:
        logger.error(f"❌ Failed to create streams: {e}")
        sys.exit(1)
    finally:
        await manager.disconnect()


async def list_streams_command(args):
    """List all streams"""
    config = Config()
    manager = NatsStreamManager(config)

    try:
        await manager.connect()
        streams = await manager.list_streams()

        if not streams:
            logger.info("No streams found")
            return

        logger.info(f"Found {len(streams)} streams:")
        for stream in streams:
            logger.info(f"  📋 {stream['name']}: {stream.get('description', 'No description')}")
            logger.info(f"      Subjects: {', '.join(stream.get('subjects', []))}")
            logger.info(f"      Messages: {stream.get('messages', 0)}")

    except Exception as e:
        logger.error(f"❌ Failed to list streams: {e}")
        sys.exit(1)
    finally:
        await manager.disconnect()


async def validate_streams_command(args):
    """Validate required streams exist"""
    config = Config()
    manager = NatsStreamManager(config)

    try:
        await manager.connect()
        validation_results = await manager.validate_required_streams()

        if validation_results['all_valid']:
            logger.info("✅ All required streams are available")
            for stream in validation_results['found_streams']:
                logger.info(f"  ✅ {stream}")
        else:
            logger.error("❌ Missing required streams:")
            for stream in validation_results['missing_streams']:
                logger.error(f"  ❌ {stream}")
            sys.exit(1)

    except Exception as e:
        logger.error(f"❌ Stream validation failed: {e}")
        sys.exit(1)
    finally:
        await manager.disconnect()


async def register_application_command(args):
    """Register a new application and provision its messaging infrastructure"""
    config = Config()
    provisioner = ApplicationProvisioner(config)

    try:
        subjects = args.subjects.split(',') if args.subjects else []
        stream_types = args.stream_types.split(',') if args.stream_types else ["application_stream"]

        logger.info(f"🚀 Registering application '{args.app_name}' with domain '{args.domain}'...")

        result = await provisioner.register_application(
            app_name=args.app_name,
            domain=args.domain,
            description=args.description,
            subjects=subjects,
            stream_types=stream_types,
            owner=args.owner,
            contact=args.contact
        )

        logger.info("✅ Application registration completed!")
        logger.info(f"   Domain: {result['domain']}")
        logger.info(f"   Streams created: {len(result['streams_created'])}")
        logger.info(f"   Valid subjects: {len(result['subjects_registered'])}")

        for stream in result['streams_created']:
            status = "✅" if stream['success'] else "❌"
            logger.info(f"   {status} {stream['stream_name']} ({stream['type']}): {stream['message']}")

        if result['errors']:
            logger.error("❌ Errors encountered:")
            for error in result['errors']:
                logger.error(f"   • {error}")

    except Exception as e:
        logger.error(f"❌ Failed to register application: {e}")
        sys.exit(1)


async def provision_from_template_command(args):
    """Provision infrastructure for application defined in templates"""
    config = Config()
    provisioner = ApplicationProvisioner(config)

    try:
        logger.info(f"🚀 Provisioning infrastructure for '{args.app_name}' from template...")

        result = await provisioner.provision_application_from_template(args.app_name)

        logger.info("✅ Application provisioning completed!")
        logger.info(f"   Domain: {result['domain']}")
        logger.info(f"   Streams created: {len(result['streams_created'])}")

        for stream in result['streams_created']:
            status = "✅" if stream['success'] else "❌"
            logger.info(f"   {status} {stream['stream_name']} ({stream['type']})")

    except Exception as e:
        logger.error(f"❌ Failed to provision application: {e}")
        sys.exit(1)


async def list_applications_command(args):
    """List all registered applications"""
    config = Config()
    provisioner = ApplicationProvisioner(config)

    try:
        applications = await provisioner.list_registered_applications()

        if not applications:
            logger.info("No applications registered")
            return

        logger.info(f"Found {len(applications)} registered applications:")
        for app in applications:
            logger.info(f"  📱 {app['name']} ({app['domain']})")
            logger.info(f"      Description: {app.get('description', 'No description')}")
            logger.info(f"      Owner: {app.get('owner', 'Not specified')}")
            logger.info(f"      Contact: {app.get('contact', 'Not specified')}")
            logger.info(f"      Subjects: {', '.join(app.get('subjects', []))}")

    except Exception as e:
        logger.error(f"❌ Failed to list applications: {e}")
        sys.exit(1)


async def start_api_server(args):
    """Start the REST API server"""
    config = Config()
    api = StreamManagerAPI(config)

    logger.info(f"🌐 Starting NATS Stream Manager API on port {args.port}")
    logger.info(f"📋 API documentation available at http://localhost:{args.port}/docs")

    await api.start_server(host=args.host, port=args.port)


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Eva Group NATS Stream Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Create all Eva streams
  python main.py create-streams

  # List all streams
  python main.py list-streams

  # Validate required streams
  python main.py validate-streams

  # Start API server
  python main.py api --port 8080

  # Register new application
  python main.py register-app myapp MYAPP "My app" --subjects "myapp.created" --owner "team@eva"

  # Provision from template
  python main.py provision-app ticketing

  # List applications
  python main.py list-apps
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Create streams command
    create_parser = subparsers.add_parser('create-streams', help='Create Eva messaging infrastructure streams')
    create_parser.set_defaults(func=create_streams_command)

    # List streams command
    list_parser = subparsers.add_parser('list-streams', help='List all NATS streams')
    list_parser.set_defaults(func=list_streams_command)

    # Validate streams command
    validate_parser = subparsers.add_parser('validate-streams', help='Validate required streams exist')
    validate_parser.set_defaults(func=validate_streams_command)

    # API server command
    api_parser = subparsers.add_parser('api', help='Start REST API server')
    api_parser.add_argument('--host', default='0.0.0.0', help='Host to bind to (default: 0.0.0.0)')
    api_parser.add_argument('--port', type=int, default=8080, help='Port to bind to (default: 8080)')
    api_parser.set_defaults(func=start_api_server)

    # Register application command
    register_parser = subparsers.add_parser(
        'register-app', help='Register new application and provision infrastructure')
    register_parser.add_argument('app_name', help='Application name (alphanumeric, 3-20 chars)')
    register_parser.add_argument('domain', help='Application domain (e.g., BILLING, CRM)')
    register_parser.add_argument('description', help='Application description')
    register_parser.add_argument(
        '--subjects', help='Comma-separated list of subjects (e.g., "app.created,app.updated")')
    register_parser.add_argument(
        '--stream-types', default='application_stream',
        help='Comma-separated stream types (default: application_stream)')
    register_parser.add_argument('--owner', help='Team or person responsible for the application')
    register_parser.add_argument('--contact',
                                 help='Contact email for the application team')
    register_parser.set_defaults(func=register_application_command)

    # Provision from template command
    provision_parser = subparsers.add_parser('provision-app', help='Provision infrastructure from template')
    provision_parser.add_argument('app_name', help='Application name defined in templates')
    provision_parser.set_defaults(func=provision_from_template_command)

    # List applications command
    list_apps_parser = subparsers.add_parser('list-apps', help='List all registered applications')
    list_apps_parser.set_defaults(func=list_applications_command)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Run the async command
    asyncio.run(args.func(args))


if __name__ == "__main__":
    main()
