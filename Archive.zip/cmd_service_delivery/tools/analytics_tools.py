"""
MCP tools for analytics and natural language graph queries.
"""

from typing import Any, Dict, List, Optional
import logging

logger = logging.getLogger(__name__)


async def ask_orders_question(question: str, services: dict) -> Dict[str, Any]:
    """
    Ask a natural language question about CMD orders and get answers from the graph database.
    The question is translated to a Cypher query using the graph schema.

    Examples:
        - "How many orders are completed?"
        - "Which vendors have the most segments?"
        - "Show me all orders for client 19253"
        - "What tasks are still open?"
        - "Which orders involve Retelit?"

    Args:
        question: Natural language question about orders, segments, vendors, tasks, or notes
    """
    mg = services["memgraph_client"]
    schema = services.get("schema_description", "")
    openai_client = services.get("openai_client")

    cypher = await _nl_to_cypher(question, schema, openai_client)
    if not cypher:
        return {"error": "Could not translate question to a graph query", "question": question}

    try:
        results = await mg.execute_and_fetch(cypher)
        return {
            "question": question,
            "cypher": cypher,
            "results": results[:50],
            "result_count": len(results),
        }
    except Exception as e:
        return {
            "error": f"Query execution failed: {str(e)}",
            "question": question,
            "cypher": cypher,
        }


async def _nl_to_cypher(question: str, schema: str, openai_client) -> Optional[str]:
    """Translate a natural language question to Cypher using OpenAI."""
    if not openai_client:
        return _fallback_cypher(question)

    system_prompt = """You are a Cypher query generator for Memgraph. Given a graph schema and a user question, generate ONLY a valid Cypher query. Return ONLY the Cypher query, no explanation, no markdown fences.

IMPORTANT RULES:
- Use MATCH, OPTIONAL MATCH, WHERE, RETURN, ORDER BY, LIMIT
- Node labels: Order, Service, Segment, Vendor, Task, Note, Client
- Relationship types: HAS_SERVICE, HAS_SEGMENT, HAS_A_VENDOR, HAS_Z_VENDOR, HAS_TASK, HAS_NOTE, BELONGS_TO_CLIENT
- Order has: id (int), latest_status, comments, client_id, status_label, status_main
- Service has: id (int), service_type, gtt_foc_ready, foc_status_date
- Segment has: id (int), a_company_name, z_company_name, a_city, z_city, vendor_circuit_id, foc_date
- Vendor has: id (int), name, legal_name
- Task has: task_id (int), status (int: 1=Open,2=InProgress,3=OnHold,4=Cancelled,5=Completed), summary
- Note has: note_id (string), subject, body, order_id
- For text matching use =~ "(?i).*pattern.*" for case-insensitive partial match
- Always LIMIT results to 50 unless counting
- Return meaningful column aliases"""

    user_prompt = f"SCHEMA:\n{schema}\n\nQUESTION: {question}"

    try:
        resp = await openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0,
            max_tokens=500,
        )
        cypher = resp.choices[0].message.content.strip()
        # Clean markdown code fences if present
        if cypher.startswith("```"):
            lines = cypher.split("\n")
            lines = [l for l in lines if not l.startswith("```")]
            cypher = "\n".join(lines).strip()
        if cypher.upper().startswith(("MATCH", "OPTIONAL", "WITH", "CALL")):
            return cypher
    except Exception as e:
        logger.warning("OpenAI NL→Cypher failed: %s", e)

    return _fallback_cypher(question)


def _fallback_cypher(question: str) -> Optional[str]:
    """Pattern-based fallback when LLM is unavailable."""
    q = question.lower()

    if "how many order" in q:
        return "MATCH (o:Order) RETURN count(o) AS total_orders"
    if "completed order" in q or "orders completed" in q:
        return "MATCH (o:Order) WHERE o.status_label = 'Completed' RETURN count(o) AS completed"
    if "vendor" in q and ("most" in q or "top" in q):
        return """MATCH (v:Vendor)<-[:HAS_A_VENDOR|HAS_Z_VENDOR]-(seg:Segment)
                  RETURN v.id AS vendor_id, v.name AS vendor_name, count(seg) AS segments
                  ORDER BY segments DESC LIMIT 10"""
    if "open task" in q:
        return """MATCH (o:Order)-[:HAS_TASK]->(t:Task {status: 1})
                  RETURN o.id AS order_id, t.task_id AS task_id, t.summary AS task LIMIT 50"""
    if "client" in q:
        import re
        match = re.search(r"client\s+(\d+)", q)
        if match:
            cid = match.group(1)
            return f"""MATCH (o:Order)-[:BELONGS_TO_CLIENT]->(c:Client {{id: {cid}}})
                       RETURN o.id AS order_id, o.status_label AS status LIMIT 50"""

    return None


async def get_graph_stats(services: dict) -> Dict[str, Any]:
    """
    Get overall graph database statistics: node counts, relationship counts,
    and data summary.
    """
    mg = services["memgraph_client"]

    node_counts = await mg.execute_and_fetch("""
        MATCH (n)
        RETURN labels(n)[0] AS label, count(n) AS count
        ORDER BY count DESC
    """)

    rel_counts = await mg.execute_and_fetch("""
        MATCH ()-[r]->()
        RETURN type(r) AS relationship, count(r) AS count
        ORDER BY count DESC
    """)

    return {
        "node_counts": node_counts,
        "relationship_counts": rel_counts,
    }
