# Eva Messaging Infrastructure API Reference

**Complete API documentation for Eva messaging infrastructure services**

---

## 🚀 API Overview

Eva Messaging Infrastructure provides REST APIs for stream management, monitoring, and development operations.

### **Base URLs**
- **Stream Management API**: http://localhost:8080
- **Message Viewer API**: http://localhost:3001/api
- **NATS Monitoring**: http://localhost:8222

### **Authentication**
- **Development**: No authentication required
- **Production**: JWT tokens or certificate-based authentication

---

## 🛠️ Stream Management API (Port 8080)

**Technology**: FastAPI with automatic OpenAPI documentation
**Interactive Docs**: http://localhost:8080/docs

### Health Endpoints

#### `GET /health`
**Purpose**: Service health check

**Response**:
```json
{
  "status": "healthy",
  "service": "Eva NATS Stream Manager",
  "timestamp": "2025-09-23T15:30:00Z"
}
```

**Status Codes**:
- `200`: Service healthy
- `503`: Service unhealthy

---

### Stream Management Endpoints

#### `POST /streams/create-all`
**Purpose**: Create all Eva messaging infrastructure streams

**Request**: No body required

**Response**:
```json
[
  {
    "stream_name": "EVA_TICKETING_STREAM",
    "status": "created",
    "subjects": ["tickets.*", "incidents.*", "maintenance.*"],
    "config": {
      "retention": "workqueue",
      "max_age": "72h",
      "max_msgs": 100000,
      "max_bytes": 104857600
    }
  },
  {
    "stream_name": "EVA_ANALYTICS_STREAM",
    "status": "created",
    "subjects": ["analytics.*", "metrics.*", "reports.*"],
    "config": {
      "retention": "limits",
      "max_age": "30d",
      "max_msgs": 1000000,
      "max_bytes": 1073741824
    }
  }
]
```

**Status Codes**:
- `200`: Streams created successfully
- `409`: Streams already exist
- `500`: Creation failed

---

#### `POST /streams/{stream_name}`
**Purpose**: Create a specific stream

**Parameters**:
- `stream_name` (path): Name of the stream to create

**Request Body**:
```json
{
  "subjects": ["myapp.*"],
  "retention": "workqueue",
  "max_age": "24h",
  "max_msgs": 50000,
  "max_bytes": 52428800,
  "description": "Custom application stream"
}
```

**Response**:
```json
{
  "stream_name": "CUSTOM_STREAM",
  "status": "created",
  "config": {
    "subjects": ["myapp.*"],
    "retention": "workqueue",
    "max_age": "24h",
    "max_msgs": 50000,
    "max_bytes": 52428800,
    "storage": "file",
    "replicas": 1
  },
  "state": {
    "messages": 0,
    "bytes": 0,
    "first_seq": 0,
    "last_seq": 0,
    "consumers": 0
  }
}
```

**Status Codes**:
- `201`: Stream created
- `400`: Invalid configuration
- `409`: Stream already exists
- `500`: Creation failed

---

#### `GET /streams`
**Purpose**: List all streams with configuration and state

**Query Parameters**:
- `include_state` (optional): Include stream state information (default: true)

**Response**:
```json
[
  {
    "name": "EVA_TICKETING_STREAM",
    "config": {
      "subjects": ["tickets.*", "incidents.*", "maintenance.*"],
      "retention": "workqueue",
      "max_age": "72h",
      "max_msgs": 100000,
      "storage": "file"
    },
    "state": {
      "messages": 1250,
      "bytes": 2500000,
      "first_seq": 1,
      "last_seq": 1250,
      "consumers": 3,
      "first_time": "2025-09-20T10:00:00Z",
      "last_time": "2025-09-23T15:30:00Z"
    }
  }
]
```

**Status Codes**:
- `200`: Success
- `503`: NATS not connected

---

#### `GET /streams/{stream_name}`
**Purpose**: Get detailed information about a specific stream

**Parameters**:
- `stream_name` (path): Name of the stream

**Response**:
```json
{
  "name": "EVA_TICKETING_STREAM",
  "config": {
    "subjects": ["tickets.*", "incidents.*", "maintenance.*"],
    "retention": "workqueue",
    "max_age": "72h",
    "max_msgs": 100000,
    "max_bytes": 104857600,
    "storage": "file",
    "replicas": 1,
    "discard": "old",
    "duplicate_window": "2m"
  },
  "state": {
    "messages": 1250,
    "bytes": 2500000,
    "first_seq": 1,
    "last_seq": 1250,
    "consumers": 3,
    "first_time": "2025-09-20T10:00:00Z",
    "last_time": "2025-09-23T15:30:00Z"
  },
  "cluster": {
    "name": "eva-messaging",
    "leader": "eva-nats-1",
    "replicas": [
      {
        "name": "eva-nats-1",
        "current": true,
        "active": "2025-09-23T15:30:00Z"
      }
    ]
  }
}
```

**Status Codes**:
- `200`: Success
- `404`: Stream not found
- `503`: NATS not connected

---

#### `GET /streams/validate/required`
**Purpose**: Validate that all required Eva streams exist

**Response**:
```json
{
  "validation_status": "success",
  "required_streams": [
    "EVA_TICKETING_STREAM",
    "EVA_ANALYTICS_STREAM"
  ],
  "existing_streams": [
    "EVA_TICKETING_STREAM",
    "EVA_ANALYTICS_STREAM"
  ],
  "missing_streams": [],
  "validation_time": "2025-09-23T15:30:00Z"
}
```

**Status Codes**:
- `200`: All required streams exist
- `400`: Missing required streams
- `503`: NATS not connected

---

## 📊 Message Viewer API (Port 3001)

**Technology**: Express.js with Socket.IO for real-time features
**Purpose**: Development and debugging tool

### Health Endpoints

#### `GET /api/health`
**Purpose**: Message viewer service health

**Response**:
```json
{
  "status": "ok",
  "nats": {
    "connected": true,
    "url": "nats://localhost:4222"
  },
  "timestamp": "2025-09-23T15:30:00Z"
}
```

---

#### `GET /api/streams`
**Purpose**: Get stream information for message viewing

**Response**:
```json
[
  {
    "name": "EVA_TICKETING_STREAM",
    "subjects": ["tickets.*", "incidents.*", "maintenance.*"],
    "messages": 1250,
    "bytes": 2500000,
    "consumers": 3,
    "last_message": "2025-09-23T15:29:45Z"
  },
  {
    "name": "EVA_ANALYTICS_STREAM",
    "subjects": ["analytics.*", "metrics.*", "reports.*"],
    "messages": 850,
    "bytes": 1700000,
    "consumers": 2,
    "last_message": "2025-09-23T15:28:30Z"
  }
]
```

**Status Codes**:
- `200`: Success
- `503`: NATS not connected

---

### WebSocket API (Socket.IO)

#### Event: `subscribe_to_stream`
**Purpose**: Subscribe to real-time messages from a stream

**Client Request**:
```javascript
socket.emit('subscribe_to_stream', {
  stream: 'EVA_TICKETING_STREAM',
  subjects: ['tickets.*'],  // Optional filter
  consumer_group: 'ui-viewer'
});
```

#### Event: `message_received`
**Purpose**: Real-time message delivery to client

**Server Response**:
```javascript
socket.on('message_received', (data) => {
  console.log(data);
  // {
  //   "stream": "EVA_TICKETING_STREAM",
  //   "subject": "tickets.created",
  //   "sequence": 1251,
  //   "timestamp": "2025-09-23T15:30:00Z",
  //   "data": {
  //     "ticket_id": "T-12345",
  //     "status": "open",
  //     "priority": "high"
  //   }
  // }
});
```

---

## 🔍 NATS Monitoring API (Port 8222)

**Technology**: Built-in NATS server endpoints
**Purpose**: Infrastructure monitoring and metrics

### Server Information

#### `GET /varz`
**Purpose**: Server variables and statistics

**Response** (abbreviated):
```json
{
  "server_id": "NDLS6WXZXFQIVGP7ILXBVGB7YBYGXHXJ",
  "server_name": "eva-nats",
  "version": "2.10.4",
  "proto": 1,
  "go": "go1.21.3",
  "host": "0.0.0.0",
  "port": 4222,
  "max_connections": 65536,
  "ping_interval": 120000000000,
  "ping_max": 2,
  "http_host": "0.0.0.0",
  "http_port": 8222,
  "https_port": 0,
  "auth_timeout": 1,
  "max_control_line": 4096,
  "max_payload": 1048576,
  "cluster": {
    "addr": "0.0.0.0",
    "cluster_port": 6222,
    "auth_timeout": 1
  },
  "tls_timeout": 0.5,
  "start": "2025-09-23T15:25:00Z",
  "now": "2025-09-23T15:30:00Z",
  "uptime": "5m0s",
  "mem": 15728640,
  "cores": 8,
  "gomaxprocs": 8,
  "cpu": 1.5,
  "connections": 5,
  "total_connections": 8,
  "routes": 0,
  "remotes": 0,
  "leafnodes": 0,
  "in_msgs": 1250,
  "out_msgs": 3750,
  "in_bytes": 125000,
  "out_bytes": 375000,
  "slow_consumers": 0
}
```

---

#### `GET /connz`
**Purpose**: Connection information

**Query Parameters**:
- `subs`: Include subscription details
- `offset`: Pagination offset
- `limit`: Results per page

**Response**:
```json
{
  "server_id": "NDLS6WXZXFQIVGP7ILXBVGB7YBYGXHXJ",
  "now": "2025-09-23T15:30:00Z",
  "num_connections": 5,
  "total": 5,
  "offset": 0,
  "limit": 1024,
  "connections": [
    {
      "cid": 1,
      "ip": "172.18.0.3",
      "port": 45678,
      "start": "2025-09-23T15:25:30Z",
      "last_activity": "2025-09-23T15:29:55Z",
      "uptime": "4m25s",
      "idle": "5s",
      "pending_bytes": 0,
      "in_msgs": 250,
      "out_msgs": 0,
      "in_bytes": 25000,
      "out_bytes": 0,
      "subscriptions": 3,
      "name": "ticketing-app",
      "lang": "python",
      "version": "2.2.0"
    }
  ]
}
```

---

#### `GET /jsz`
**Purpose**: JetStream information

**Response**:
```json
{
  "server_id": "NDLS6WXZXFQIVGP7ILXBVGB7YBYGXHXJ",
  "now": "2025-09-23T15:30:00Z",
  "config": {
    "max_memory": 1073741824,
    "max_storage": 10737418240,
    "store_dir": "/data/jetstream"
  },
  "stats": {
    "memory": 15728640,
    "storage": 2500000,
    "accounts": 1,
    "ha_assets": 0,
    "api": {
      "total": 125,
      "errors": 0
    }
  },
  "streams": 4,
  "consumers": 8,
  "messages": 5000,
  "bytes": 10000000,
  "meta_cluster": {
    "name": "eva-messaging",
    "leader": "eva-nats",
    "peer": "eva-nats"
  }
}
```

---

## 🔧 Error Handling

### Standard Error Response Format

```json
{
  "error": {
    "code": "STREAM_NOT_FOUND",
    "message": "Stream 'INVALID_STREAM' does not exist",
    "details": {
      "stream_name": "INVALID_STREAM",
      "available_streams": [
        "EVA_TICKETING_STREAM",
        "EVA_ANALYTICS_STREAM"
      ]
    },
    "timestamp": "2025-09-23T15:30:00Z",
    "request_id": "req_123456789"
  }
}
```

### Common Error Codes

| Code | Description | HTTP Status |
|------|-------------|-------------|
| `NATS_UNAVAILABLE` | NATS server not connected | 503 |
| `STREAM_NOT_FOUND` | Requested stream doesn't exist | 404 |
| `INVALID_CONFIG` | Stream configuration invalid | 400 |
| `STREAM_EXISTS` | Stream already exists | 409 |
| `PERMISSION_DENIED` | Insufficient permissions | 403 |
| `RATE_LIMITED` | Too many requests | 429 |
| `INTERNAL_ERROR` | Server error | 500 |

---

## 📝 API Client Examples

### Python Client Example

```python
import requests
import asyncio
import websockets
import json

class EvaMessagingClient:
    def __init__(self, base_url="http://localhost:8080"):
        self.base_url = base_url

    def health_check(self):
        """Check service health"""
        response = requests.get(f"{self.base_url}/health")
        return response.json()

    def list_streams(self):
        """List all streams"""
        response = requests.get(f"{self.base_url}/streams")
        return response.json()

    def create_stream(self, name, config):
        """Create a new stream"""
        response = requests.post(
            f"{self.base_url}/streams/{name}",
            json=config
        )
        return response.json()

    def get_stream(self, name):
        """Get stream details"""
        response = requests.get(f"{self.base_url}/streams/{name}")
        return response.json()

# Usage
client = EvaMessagingClient()
health = client.health_check()
streams = client.list_streams()
```

### JavaScript Client Example

```javascript
class EvaMessagingClient {
    constructor(baseUrl = 'http://localhost:8080') {
        this.baseUrl = baseUrl;
    }

    async healthCheck() {
        const response = await fetch(`${this.baseUrl}/health`);
        return response.json();
    }

    async listStreams() {
        const response = await fetch(`${this.baseUrl}/streams`);
        return response.json();
    }

    async createStream(name, config) {
        const response = await fetch(`${this.baseUrl}/streams/${name}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(config)
        });
        return response.json();
    }
}

// Usage
const client = new EvaMessagingClient();
const health = await client.healthCheck();
const streams = await client.listStreams();
```

---

## 🔗 Related Documentation

- [Architecture Overview](architecture.md)
- [Integration Guide](../INTEGRATION_GUIDE.md)
- [Deployment Guide](../README.md#quick-start)
- [Interactive API Docs](http://localhost:8080/docs)

---

**API Version**: 1.0.0
**Last Updated**: 2025-09-23
**Interactive Docs**: http://localhost:8080/docs