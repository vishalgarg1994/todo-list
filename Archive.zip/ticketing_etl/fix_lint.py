#!/usr/bin/env python3
"""Auto-fix flake8 lint issues"""
import re
import sys
from pathlib import Path

def fix_file(filepath):
    """Fix lint issues in a single file"""
    with open(filepath, 'r') as f:
        lines = f.readlines()
    
    modified = False
    
    for i, line in enumerate(lines):
        original = line
        
        # Fix F541: Remove 'f' prefix from strings without placeholders
        # Pattern: f"string" or f'string' with no {variables}
        if re.search(r'f["\'](?![^"\']*\{)[^"\']*["\']', line):
            line = re.sub(r'\bf(["\'])(?![^"\']*\{)', r'\1', line)
        
        # Fix E226: Add whitespace around arithmetic operators (*/)
        # But be careful not to break **kwargs or similar
        line = re.sub(r'(\d)\*(\d)', r'\1 * \2', line)
        line = re.sub(r'(\d)/(\d)', r'\1 / \2', line)
        
        # Fix E722: Replace bare except with except Exception
        line = re.sub(r'^(\s+)except\s*:\s*$', r'\1except Exception:\n', line)
        
        # Fix F841: Comment out unused variables instead of removing
        if 'F841' in original or ('SIZE_3MB' in line or 'start_time' in line and '=' in line):
            # Just comment these out for now - user can decide
            pass
        
        if line != original:
            lines[i] = line
            modified = True
    
    if modified:
        with open(filepath, 'w') as f:
            f.writelines(lines)
        print(f"✅ Fixed: {filepath}")
        return True
    return False

def main():
    ticketing_root = Path('/Users/aklilugebreyesus/projects/eva/ticketing_etl')
    
    # Files with issues
    files_to_fix = [
        'src/domain/transformers.py',
        'src/main.py',
        'src/messaging/ticket_publisher.py',
        'src/services/app_service.py',
        'src/services/health_service.py',
        'src/utils/circuit_breaker.py',
        'tests/test_health_manual.py',
    ]
    
    fixed_count = 0
    for file_path in files_to_fix:
        full_path = ticketing_root / file_path
        if full_path.exists():
            if fix_file(full_path):
                fixed_count += 1
    
    print(f"\n✅ Fixed {fixed_count} files")
    print("\nRemaining manual fixes needed:")
    print("1. F841 unused variables - decide if you need them")
    print("2. E501 line too long - break into multiple lines")
    print("3. W503 line breaks - these are Black's style, safe to ignore")

if __name__ == '__main__':
    main()
