"""
Tool Registry for MCP Ticket System
Central registration point for all tools
"""

from typing import Dict, Any, Callable
import logging

logger = logging.getLogger(__name__)


class ToolRegistry:
    """Registry for managing MCP tools across different categories"""

    def __init__(self):
        self._tools: Dict[str, Callable] = {}
        self._tool_descriptions: Dict[str, Dict[str, Any]] = {}

    def register_tool(self, name: str, func: Callable, description: Dict[str, Any]):
        """Register a tool with its function and description"""
        self._tools[name] = func
        self._tool_descriptions[name] = description
        logger.info(f"Registered tool: {name}")

    def get_tool(self, name: str) -> Callable:
        """Get a tool function by name"""
        return self._tools.get(name)

    def get_tool_description(self, name: str) -> Dict[str, Any]:
        """Get tool description by name"""
        return self._tool_descriptions.get(name, {})

    def list_tools(self) -> Dict[str, Dict[str, Any]]:
        """List all registered tools with their descriptions"""
        return self._tool_descriptions.copy()

    def get_tools_by_category(self, category: str) -> Dict[str, Callable]:
        """Get all tools in a specific category"""
        return {
            name: func
            for name, func in self._tools.items()
            if self._tool_descriptions[name].get("category") == category
        }


# Global registry instance
tool_registry = ToolRegistry()
