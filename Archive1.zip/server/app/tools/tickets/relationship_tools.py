"""
Relationship and graph traversal tools for ticket system
Provides navigation through ticket relationships and root cause analysis
"""
import asyncio
import logging
import polars as pl
from typing import Any, Optional
from fastmcp.exceptions import ToolError
from utils.utilities import Helpers


async def get_ticket_relationships(ticket_id: str, services: dict) -> Any:
    """
    Get all related tickets (master, children, linked).

    Shows the complete ticket hierarchy and relationships for understanding
    ticket dependencies and groupings.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_ticket_relationships for ticket: '{ticket_id}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (t:Ticket {ticket_id: $ticket_id})
            OPTIONAL MATCH (t)-[:CHILD_OF]->(master:Ticket)
            OPTIONAL MATCH (child:Ticket)-[:CHILD_OF]->(t)
            OPTIONAL MATCH (t)-[:LINKED_TO]->(linked:Ticket)
            OPTIONAL MATCH (linked_from:Ticket)-[:LINKED_TO]->(t)
            RETURN t.ticket_id as ticket_id,
                   t.is_master_ticket as is_master_ticket,
                   master.ticket_id as master_ticket_id,
                   collect(distinct child.ticket_id) as child_tickets,
                   collect(distinct linked.ticket_id) as linked_to_tickets,
                   collect(distinct linked_from.ticket_id) as linked_from_tickets
        """

        result = await memgraph_client.execute( cypher_query, {"ticket_id": ticket_id})
        response_data = result
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No ticket found with ticket_id: {ticket_id}"}

        return Helpers.recursive_serialize(response_data[0])

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_ticket_relationships: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve ticket relationships: {e}")


async def trace_ticket_root_cause(ticket_id: str, services: dict, max_depth: int = 10) -> Any:
    """
    Trace ticket to root cause by following master_ticket chain.

    Traverses CHILD_OF relationships upward to find the original master ticket
    that spawned this ticket chain. Returns the full path from child to root.
    """
    try:
        logging.info(f"FastMCP Tool Call: trace_ticket_root_cause for ticket: '{ticket_id}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Use variable-length path matching to traverse up the CHILD_OF chain
        # Updated to match current schema from batch_graph_loader.py
        cypher_query = """
            MATCH path = (t:Ticket {ticket_id: $ticket_id})-[:CHILD_OF*0..]->(root:Ticket)
            WHERE NOT (root)-[:CHILD_OF]->()
            WITH path, root, t
            OPTIONAL MATCH (root)-[:HAS_FAULT]->(f:Fault)
            OPTIONAL MATCH (root)-[:HAS_SERVICE]->(s:Service)
            OPTIONAL MATCH (root)-[:HAS_OUTAGE]->(o:Outage_Info)
            RETURN t.ticket_id as starting_ticket,
                   length(path) as hops_to_root,
                   [n in nodes(path) | n.ticket_id] as ticket_chain,
                   root.ticket_id as root_ticket_id,
                   root.created_on as root_created_on,
                   root.ticket_category as root_category,
                   f.short_description as root_description,
                   s.subcategory as service_subcategory,
                   s.technology as service_technology,
                   o.rfo as root_cause_rfo,
                   f.ticket_rfo_group as problem_type
            ORDER BY hops_to_root DESC
            LIMIT 1
        """

        result = await memgraph_client.execute( cypher_query, {"ticket_id": ticket_id})
        response_data = result
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No ticket found with ticket_id: {ticket_id}"}

        root_data = response_data[0]

        # Check if this ticket is itself a root
        if root_data['hops_to_root'] == 0:
            return Helpers.recursive_serialize({
                "ticket_id": ticket_id,
                "is_root_ticket": True,
                "message": "This ticket is already a root ticket (no master ticket)",
                "details": root_data
            })

        return Helpers.recursive_serialize({
            "ticket_id": ticket_id,
            "is_root_ticket": False,
            "root_cause_analysis": root_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in trace_ticket_root_cause: {e}", exc_info=True)
        raise ToolError(f"Failed to trace ticket root cause: {e}")


async def get_vendor_tickets(vendor_name: str, services: dict, limit: Optional[int] = 100) -> Any:
    """
    Get all tickets handled by a specific vendor.

    Returns tickets with vendor involvement, including downtime statistics.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_vendor_tickets for vendor: '{vendor_name}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Updated to match current schema from batch_graph_loader.py
        cypher_query = """
            MATCH (t:Ticket)-[:INVOLVES_VENDOR]->(v:VendorInfo {vendor: $vendor_name})
            MATCH (c:Client)-[:HAS_TICKET]->(t)
            OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
            RETURN c.client_name as client_name,
                   t.ticket_id as ticket_id,
                   t.ticket_status as status,
                   t.ticket_category as category,
                   t.created_on as created_on,
                   t.closed_on as closed_on,
                   v.vendor_downtime as vendor_downtime,
                   o.rfo as rfo,
                   o.mttr as mttr
            ORDER BY t.created_on DESC
        """

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute( cypher_query, {"vendor_name": vendor_name})
        response_data = result
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No tickets found for vendor: {vendor_name}"}

        # Calculate summary statistics
        total_downtime = sum(t.get('vendor_downtime', 0) or 0 for t in response_data)
        avg_mttr = sum(t.get('mttr', 0) or 0 for t in response_data if t.get('mttr')) / len([t for t in response_data if t.get('mttr')]) if any(t.get('mttr') for t in response_data) else 0

        return Helpers.recursive_serialize({
            "vendor_name": vendor_name,
            "ticket_count": len(response_data),
            "total_vendor_downtime": total_downtime,
            "average_mttr": avg_mttr,
            "tickets": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_vendor_tickets: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve vendor tickets: {e}")


async def get_service_outages(
    services: dict,
    technology: Optional[str] = None,
    subcategory: Optional[str] = None,
    limit: Optional[int] = 100
) -> Any:
    """
    Get outages for a specific service type (technology or subcategory).

    Filter by technology (e.g., "Fiber", "Ethernet") or subcategory.
    Returns related tickets with outage statistics.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_service_outages with technology={technology}, subcategory={subcategory}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Build query based on filter criteria
        where_clauses = []
        params = {}

        if technology:
            where_clauses.append("s.technology = $technology")
            params["technology"] = technology

        if subcategory:
            where_clauses.append("s.subcategory = $subcategory")
            params["subcategory"] = subcategory

        where_clause = " AND ".join(where_clauses) if where_clauses else "true"

        # Updated to match current schema from batch_graph_loader.py
        cypher_query = f"""
            MATCH (t:Ticket)-[:HAS_SERVICE]->(s:Service)
            MATCH (c:Client)-[:HAS_TICKET]->(t)
            WHERE {where_clause}
            OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
            OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
            RETURN c.client_name as client_name,
                   t.ticket_id as ticket_id,
                   t.ticket_status as status,
                   t.created_on as created_on,
                   t.closed_on as closed_on,
                   s.technology as technology,
                   s.subcategory as subcategory,
                   f.short_description as description,
                   o.rfo as rfo,
                   o.outage_duration as outage_duration,
                   o.mttr as mttr,
                   f.ticket_rfo_group as problem_type
            ORDER BY t.created_on DESC
        """

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute( cypher_query, params)
        response_data = result
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No outages found for specified service type"}

        # Calculate statistics
        total_outages = len(response_data)
        avg_mttr = sum(t.get('mttr', 0) or 0 for t in response_data if t.get('mttr')) / len([t for t in response_data if t.get('mttr')]) if any(t.get('mttr') for t in response_data) else 0

        return Helpers.recursive_serialize({
            "technology": technology,
            "subcategory": subcategory,
            "total_outages": total_outages,
            "average_mttr": avg_mttr,
            "outages": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_service_outages: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve service outages: {e}")
