import os
import yaml
import logging

from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Set the root directory to 'mcp_ticket' regardless of where the script is run from
ROOT_DIR = Path(__file__).resolve().parents[2]  # Adjust the number based on depth
CONFIG_FILE = ROOT_DIR / "app" / "configs" / "config.yml"
SCHEMA_DESC = ROOT_DIR / "app" / "data_access" / "cyphers" / "ticket_schema_description.yaml"


class Config:
    _instance = None  # Singleton instance

    def __new__(cls):
        """Ensure Config is a singleton (only one instance)."""
        if cls._instance is None:
            cls._instance = super(Config, cls).__new__(cls)
            cls._instance._load_config()
        return cls._instance

    def _load_config(self):
        """Loads values from environment or config file."""
        try:
            with open(CONFIG_FILE, "r") as f:
                config_data = yaml.safe_load(f) or {}
                logging.info("Configuration loaded successfully.")
        except FileNotFoundError:
            logging.warning(f"Config file not found at {CONFIG_FILE}. Using environment variables.")
            config_data = {}
        except yaml.YAMLError as e:
            logging.error(f"Error parsing config file: {e}")
            config_data = {}

        # ✅ Memgraph connection configuration
        self.memgraph_uri = os.environ.get("MEMGRAPH_URI", "bolt://localhost:7687")
        self.memgraph_user = os.environ.get("MEMGRAPH_USER", "")
        self.memgraph_password = os.environ.get("MEMGRAPH_PASSWORD", "")
        self.memgraph_database = os.environ.get("MEMGRAPH_DATABASE", "memgraph")
        logging.info(f"Memgraph URI configured: {self.memgraph_uri}")

        self.llm_temperature = os.environ.get("LLM_TEMPERATURE", config_data.get("llm_temperature", 0.2))
        self.nats_url = os.environ.get("NATS_URL", config_data.get("nats_url", "nats://localhost:4222"))
        self.nats_user = os.environ.get("NATS_CONSUMER_USER", config_data.get("nats_user", ""))
        self.nats_password = os.environ.get("NATS_CONSUMER_PASSWORD", config_data.get("nats_password", ""))

        # ✅ Stream Name
        self.jetstream_stream_name = os.environ.get(
            "JETSTREAM_STREAM_NAME", config_data.get("jetstream_stream_name", "DATA_INJESTION_STREAM")
        )

        # ✅ Stream Publish Subject
        self.ticket_publish_subject = os.environ.get(
            "TICKET_PUBLISH_SUBJECT", config_data.get("ticket_publish_subject", "tickets.created")
        )

        # ✅ Stream Subscribe Subject
        self.ticket_subscribe_subject = os.environ.get(
            "TICKET_SUBSCRIBE_SUBJECT", config_data.get("ticket_subscribe_subject", "tickets.created")
        )

        # ✅ Schema Description File Path
        self.schema_desc_path = SCHEMA_DESC

        # ============================================================================
        # Phase 1 Architecture: Extensibility Hooks Configuration
        # ============================================================================

        # --- Observability Configuration ---
        self.observability_enabled = os.environ.get("OBSERVABILITY_ENABLED", "false").lower() == "true"
        self.metrics_provider = os.environ.get("METRICS_PROVIDER", "noop")  # noop, prometheus, statsd
        self.tracing_provider = os.environ.get("TRACING_PROVIDER", "noop")  # noop, opentelemetry, jaeger
        self.metrics_port = int(os.environ.get("METRICS_PORT", "9090"))
        logging.info(f"Observability: enabled={self.observability_enabled}, "
                    f"metrics={self.metrics_provider}, tracing={self.tracing_provider}")

        # --- Security Configuration ---
        self.auth_enabled = os.environ.get("AUTH_ENABLED", "false").lower() == "true"
        self.auth_provider = os.environ.get("AUTH_PROVIDER", "noop")  # noop, apikey, oauth2, jwt
        self.audit_enabled = os.environ.get("AUDIT_ENABLED", "true").lower() == "true"
        self.audit_log_file = os.environ.get("AUDIT_LOG_FILE", "/app/logs/audit.log")
        logging.info(f"Security: auth={self.auth_enabled} ({self.auth_provider}), audit={self.audit_enabled}")

        # --- Testing Configuration ---
        self.environment = os.environ.get("ENVIRONMENT", "prod")  # dev, test, prod
        self.enable_test_fixtures = os.environ.get("ENABLE_TEST_FIXTURES", "false").lower() == "true"
        self.test_mode = os.environ.get("TEST_MODE", "false").lower() == "true"  # Use synthetic data instead of NATS
        logging.info(f"Environment: {self.environment}, test_fixtures={self.enable_test_fixtures}, test_mode={self.test_mode}")

        # --- Phase 3: Vector Search Configuration ---
        # Milvus Configuration
        self.milvus_host = os.environ.get("MILVUS_HOST", "localhost")
        self.milvus_port = int(os.environ.get("MILVUS_PORT", "19530"))
        self.milvus_user = os.environ.get("MILVUS_USER", "")
        self.milvus_password = os.environ.get("MILVUS_PASSWORD", "")
        self.milvus_collection_name = os.environ.get("MILVUS_COLLECTION_NAME", "fault_descriptions")
        self.milvus_index_type = os.environ.get("MILVUS_INDEX_TYPE", "IVF_FLAT")
        self.milvus_metric_type = os.environ.get("MILVUS_METRIC_TYPE", "COSINE")
        self.milvus_nlist = int(os.environ.get("MILVUS_NLIST", "1024"))  # Number of clusters
        self.milvus_nprobe = int(os.environ.get("MILVUS_NPROBE", "32"))  # Search clusters
        logging.info(f"Milvus: {self.milvus_host}:{self.milvus_port}, collection={self.milvus_collection_name}")

        # Ollama Embedding Configuration
        self.ollama_embedding_base_url = os.environ.get("OLLAMA_EMBEDDING_BASE_URL", "http://localhost:11434")
        self.ollama_embedding_model = os.environ.get("OLLAMA_EMBEDDING_MODEL", "telecom-nomic-embed:latest")
        self.ollama_embedding_timeout = int(os.environ.get("OLLAMA_EMBEDDING_TIMEOUT", "90"))
        self.ollama_max_concurrent = int(os.environ.get("OLLAMA_MAX_CONCURRENT", "20"))
        logging.info(f"Ollama Embedding: {self.ollama_embedding_base_url}, model={self.ollama_embedding_model}")

        # Ollama Extraction Configuration (WS-C: LLM for extraction/audit - 70B for complex reasoning)
        self.ollama_extraction_base_url = os.environ.get("OLLAMA_EXTRACTION_BASE_URL", "http://localhost:11434")
        self.ollama_extraction_model = os.environ.get("OLLAMA_EXTRACTION_MODEL", "llama3.3-instruct:70b")
        self.ollama_extraction_timeout = int(os.environ.get("OLLAMA_EXTRACTION_TIMEOUT", "180"))  # 70B needs more time
        logging.info(f"Ollama Extraction: {self.ollama_extraction_base_url}, model={self.ollama_extraction_model}")

        # Milvus Notes Collection (WS-C)
        self.milvus_notes_collection = os.environ.get("MILVUS_NOTES_COLLECTION", "ticket_notes")
        logging.info(f"Milvus Notes: collection={self.milvus_notes_collection}")

        # --- Memgraph Concurrency Configuration ---
        # No defaults - must be set via docker-compose environment variables
        memgraph_concurrent_str = os.environ.get("MEMGRAPH_MAX_CONCURRENT")
        milvus_concurrent_str = os.environ.get("MILVUS_MAX_CONCURRENT")

        if not memgraph_concurrent_str:
            raise ValueError("MEMGRAPH_MAX_CONCURRENT environment variable must be set (no default)")
        if not milvus_concurrent_str:
            raise ValueError("MILVUS_MAX_CONCURRENT environment variable must be set (no default)")

        self.memgraph_max_concurrent = int(memgraph_concurrent_str)
        self.milvus_max_concurrent = int(milvus_concurrent_str)
        logging.info(f"Memgraph Concurrency: max_concurrent={self.memgraph_max_concurrent}")
        logging.info(f"Milvus Concurrency: max_concurrent={self.milvus_max_concurrent}")

        # --- LLM Validation Configuration ---
        self.llm_validation_enabled = os.environ.get("LLM_VALIDATION_ENABLED", "true").lower() == "true"
        self.llm_validator_type = os.environ.get("LLM_VALIDATOR_TYPE", "basic")  # noop, basic, advanced
        self.allow_write_queries = os.environ.get("ALLOW_WRITE_QUERIES", "false").lower() == "true"
        logging.info(f"LLM Validation: enabled={self.llm_validation_enabled}, "
                    f"type={self.llm_validator_type}, allow_writes={self.allow_write_queries}")

        # --- LLM Observability Configuration ---
        # Note: Team is evaluating Opik vs MLflow - this protocol works with both
        self.llm_observability_enabled = os.environ.get("LLM_OBSERVABILITY_ENABLED", "false").lower() == "true"
        self.llm_observability_provider = os.environ.get("LLM_OBSERVABILITY_PROVIDER", "noop")  # noop, console, opik, mlflow
        self.llm_log_prompts = os.environ.get("LLM_LOG_PROMPTS", "false").lower() == "true"  # Log full prompts (verbose)
        self.llm_log_responses = os.environ.get("LLM_LOG_RESPONSES", "false").lower() == "true"  # Log full responses (verbose)
        logging.info(f"LLM Observability: enabled={self.llm_observability_enabled}, "
                    f"provider={self.llm_observability_provider}")

        # --- ServiceNow API Configuration (WS-C: Notes Fetching) ---
        self.servicenow_base_url = os.environ.get(
            "SERVICENOW_BASE_URL",
            "https://gttdev.service-now.com/api/x_gttm2_gtt_serv_1/v1/gtt_service_management_data_services"
        )
        self.servicenow_username = os.environ.get("SERVICENOW_USERNAME", "")
        self.servicenow_password = os.environ.get("SERVICENOW_PASSWORD", "")
        self.servicenow_client_id = os.environ.get("SERVICENOW_CLIENT_ID", "")
        self.servicenow_client_secret = os.environ.get("SERVICENOW_CLIENT_SECRET", "")
        self.servicenow_timeout = int(os.environ.get("SERVICENOW_TIMEOUT", "30"))
        self.servicenow_max_concurrent = int(os.environ.get("SERVICENOW_MAX_CONCURRENT", "10"))
        logging.info(f"ServiceNow API: {self.servicenow_base_url}")
        logging.info(f"ServiceNow Performance: timeout={self.servicenow_timeout}s, max_concurrent={self.servicenow_max_concurrent}")

    @property
    def memgraph_uri(self):
        return self._memgraph_uri

    @memgraph_uri.setter
    def memgraph_uri(self, value):
        self._memgraph_uri = value

    @property
    def memgraph_user(self):
        return self._memgraph_user

    @memgraph_user.setter
    def memgraph_user(self, value):
        self._memgraph_user = value

    @property
    def memgraph_password(self):
        return self._memgraph_password

    @memgraph_password.setter
    def memgraph_password(self, value):
        self._memgraph_password = value

    @property
    def memgraph_database(self):
        return self._memgraph_database

    @memgraph_database.setter
    def memgraph_database(self, value):
        self._memgraph_database = value

    @property
    def llm_temperature(self):
        return self._llm_temperature

    @llm_temperature.setter
    def llm_temperature(self, value):
        self._llm_temperature = float(value)  # Ensure it's stored as a float

    @property
    def nats_url(self):
        return self._nats_url

    @nats_url.setter
    def nats_url(self, value):
        self._nats_url = value

    @property
    def jetstream_stream_name(self):
        return self._jetstream_stream_name

    @jetstream_stream_name.setter
    def jetstream_stream_name(self, value):
        self._jetstream_stream_name = value

    @property
    def ticket_publish_subject(self):
        return self._ticket_publish_subject

    @ticket_publish_subject.setter
    def ticket_publish_subject(self, value):
        self._ticket_publish_subject = value

    @property
    def ticket_subscribe_subject(self):
        return self._ticket_subscribe_subject

    @ticket_subscribe_subject.setter
    def ticket_subscribe_subject(self, value):
        self._ticket_subscribe_subject = value

    @property
    def schema_desc_path(self):
        return self._schema_desc_path

    @schema_desc_path.setter
    def schema_desc_path(self, value):
        self._schema_desc_path = value

    @property
    def nats_user(self):
        return self._nats_user

    @nats_user.setter
    def nats_user(self, value):
        self._nats_user = value

    @property
    def nats_password(self):
        return self._nats_password

    @nats_password.setter
    def nats_password(self, value):
        self._nats_password = value
