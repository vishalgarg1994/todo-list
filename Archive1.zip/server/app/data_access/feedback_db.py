"""
Feedback Database - SQLite storage for SME feedback and training data

Two-phase write pattern:
  Phase 1 (API call time): INSERT ticket_id + raw context (notes, emails, field_changes)
  Phase 2 (audit/feedback time): UPDATE with AI results + SME corrections

Schema:
  ticket_feedback (
      ticket_id TEXT PRIMARY KEY,
      ticket_sys_id TEXT,
      raw_notes TEXT,
      emails TEXT,
      field_changes TEXT,
      api_fetched_at TEXT,
      ai_summary TEXT,
      chronology TEXT,
      snow_fields TEXT,       -- JSON: {"responsible_party": "Customer", ...}
      ai_fields TEXT,         -- JSON: {"responsible_party": "GTT", ...}
      sme_fields TEXT,        -- JSON: {"responsible_party": "GTT", ...}
      feedback_at TEXT
  )
"""

import json
import logging
import os
import sqlite3
from datetime import datetime
from typing import Dict, Any, Optional, List

logger = logging.getLogger(__name__)

# Default path - bind mounted to host for persistence
DEFAULT_DB_PATH = os.environ.get("FEEDBACK_DB_PATH", "/app/feedback_data/feedback.db")


import os, sqlite3

DEFAULT_DB_PATH = "/app/data/feedback.db"  # make this explicit

def _get_connection(db_path: str = None) -> sqlite3.Connection:
    """Get SQLite connection with WAL mode for better concurrency."""
    path = db_path or DEFAULT_DB_PATH

    # Ensure absolute path
    if not os.path.isabs(path):
        path = os.path.join("/app", path)

    # Ensure parent directory exists
    os.makedirs(os.path.dirname(path), exist_ok=True)

    # Sanity diagnostics
    print("Opening SQLite DB at:", path)
    print("Parent exists:", os.path.exists(os.path.dirname(path)))
    print("Writable:", os.access(os.path.dirname(path), os.W_OK))

    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn

def init_db(db_path: str = None):
    """Initialize the feedback database. Safe to call multiple times."""
    conn = _get_connection(db_path)
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ticket_feedback (
                ticket_id TEXT PRIMARY KEY,
                ticket_sys_id TEXT,
                raw_notes TEXT,
                emails TEXT,
                field_changes TEXT,
                api_fetched_at TEXT,
                ai_summary TEXT,
                chronology TEXT,
                snow_fields TEXT,
                ai_fields TEXT,
                sme_fields TEXT,
                feedback_at TEXT
            )
        """)
        conn.commit()
        logger.info(f"Feedback DB initialized at {db_path or DEFAULT_DB_PATH}")
    finally:
        conn.close()


def insert_raw_context(
    ticket_id: str,
    ticket_sys_id: str,
    raw_notes: str,
    emails: str,
    field_changes: str,
    db_path: str = None,
):
    """
    Phase 1: Store raw ServiceNow context when API is called.
    Uses INSERT OR REPLACE to handle re-fetches cleanly.
    Preserves existing Phase 2 data (ai/sme fields) if present.
    """
    conn = _get_connection(db_path)
    try:
        # Check if row exists with Phase 2 data we need to preserve
        existing = conn.execute(
            "SELECT ai_summary, chronology, snow_fields, ai_fields, sme_fields, feedback_at "
            "FROM ticket_feedback WHERE ticket_id = ?",
            (ticket_id,)
        ).fetchone()

        now = datetime.utcnow().isoformat()

        if existing:
            # Update raw context but preserve Phase 2 data
            conn.execute(
                """UPDATE ticket_feedback
                   SET ticket_sys_id = ?, raw_notes = ?, emails = ?, field_changes = ?,
                       api_fetched_at = ?
                   WHERE ticket_id = ?""",
                (ticket_sys_id, raw_notes, emails, field_changes, now, ticket_id)
            )
        else:
            conn.execute(
                """INSERT INTO ticket_feedback
                   (ticket_id, ticket_sys_id, raw_notes, emails, field_changes, api_fetched_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (ticket_id, ticket_sys_id, raw_notes, emails, field_changes, now)
            )

        conn.commit()
        logger.info(f"Phase 1: Stored raw context for {ticket_id}")
    finally:
        conn.close()


def upsert_audit_results(
    ticket_id: str,
    ai_summary: str,
    chronology: str,
    snow_fields: Dict[str, Any],
    ai_fields: Dict[str, Any],
    db_path: str = None,
):
    """
    Phase 2a: Store AI audit results (called when audit runs).
    Creates row if Phase 1 hasn't run yet (ticket may not have raw context).
    """
    conn = _get_connection(db_path)
    try:
        now = datetime.utcnow().isoformat()
        snow_json = json.dumps(snow_fields) if snow_fields else None
        ai_json = json.dumps(ai_fields) if ai_fields else None

        existing = conn.execute(
            "SELECT ticket_id FROM ticket_feedback WHERE ticket_id = ?",
            (ticket_id,)
        ).fetchone()

        if existing:
            conn.execute(
                """UPDATE ticket_feedback
                   SET ai_summary = ?, chronology = ?, snow_fields = ?, ai_fields = ?
                   WHERE ticket_id = ?""",
                (ai_summary, chronology, snow_json, ai_json, ticket_id)
            )
        else:
            conn.execute(
                """INSERT INTO ticket_feedback
                   (ticket_id, ai_summary, chronology, snow_fields, ai_fields)
                   VALUES (?, ?, ?, ?, ?)""",
                (ticket_id, ai_summary, chronology, snow_json, ai_json)
            )

        conn.commit()
        logger.info(f"Phase 2a: Stored audit results for {ticket_id}")
    finally:
        conn.close()


def submit_sme_feedback(
    ticket_id: str,
    sme_fields: Dict[str, Any],
    db_path: str = None,
):
    """
    Phase 2b: Store SME corrections (called when SME clicks Submit).
    Row must exist from Phase 2a.
    """
    conn = _get_connection(db_path)
    try:
        now = datetime.utcnow().isoformat()
        sme_json = json.dumps(sme_fields)

        result = conn.execute(
            """UPDATE ticket_feedback
               SET sme_fields = ?, feedback_at = ?
               WHERE ticket_id = ?""",
            (sme_json, now, ticket_id)
        )

        if result.rowcount == 0:
            logger.warning(f"No existing record for {ticket_id}, creating one with SME feedback only")
            conn.execute(
                """INSERT INTO ticket_feedback (ticket_id, sme_fields, feedback_at)
                   VALUES (?, ?, ?)""",
                (ticket_id, sme_json, now)
            )

        conn.commit()
        logger.info(f"Phase 2b: Stored SME feedback for {ticket_id}")
    finally:
        conn.close()


def get_feedback(ticket_id: str, db_path: str = None) -> Optional[Dict[str, Any]]:
    """Get feedback record for a ticket."""
    conn = _get_connection(db_path)
    try:
        row = conn.execute(
            "SELECT * FROM ticket_feedback WHERE ticket_id = ?",
            (ticket_id,)
        ).fetchone()

        if not row:
            return None

        result = dict(row)
        # Parse JSON fields
        for field in ('snow_fields', 'ai_fields', 'sme_fields'):
            if result.get(field):
                result[field] = json.loads(result[field])
        return result
    finally:
        conn.close()


def get_all_feedback(with_sme_only: bool = False, db_path: str = None) -> List[Dict[str, Any]]:
    """
    Get all feedback records.

    Args:
        with_sme_only: If True, only return records that have SME feedback
    """
    conn = _get_connection(db_path)
    try:
        if with_sme_only:
            rows = conn.execute(
                "SELECT * FROM ticket_feedback WHERE sme_fields IS NOT NULL ORDER BY feedback_at DESC"
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM ticket_feedback ORDER BY api_fetched_at DESC"
            ).fetchall()

        results = []
        for row in rows:
            record = dict(row)
            for field in ('snow_fields', 'ai_fields', 'sme_fields'):
                if record.get(field):
                    record[field] = json.loads(record[field])
            results.append(record)
        return results
    finally:
        conn.close()


def export_training_data(db_path: str = None) -> List[Dict[str, Any]]:
    """
    Export records with SME feedback as training data.
    Returns list of dicts ready for JSONL export.
    """
    records = get_all_feedback(with_sme_only=True, db_path=db_path)
    training_data = []
    for record in records:
        training_data.append({
            "ticket_id": record["ticket_id"],
            "input": {
                "raw_notes": record.get("raw_notes", ""),
                "emails": record.get("emails", ""),
                "field_changes": record.get("field_changes", ""),
            },
            "snow_original": record.get("snow_fields", {}),
            "ai_suggested": record.get("ai_fields", {}),
            "sme_corrected": record.get("sme_fields", {}),
        })
    return training_data


def get_stats(db_path: str = None) -> Dict[str, int]:
    """Get feedback collection statistics."""
    conn = _get_connection(db_path)
    try:
        total = conn.execute("SELECT COUNT(*) FROM ticket_feedback").fetchone()[0]
        with_context = conn.execute(
            "SELECT COUNT(*) FROM ticket_feedback WHERE raw_notes IS NOT NULL"
        ).fetchone()[0]
        with_audit = conn.execute(
            "SELECT COUNT(*) FROM ticket_feedback WHERE ai_fields IS NOT NULL"
        ).fetchone()[0]
        with_feedback = conn.execute(
            "SELECT COUNT(*) FROM ticket_feedback WHERE sme_fields IS NOT NULL"
        ).fetchone()[0]
        return {
            "total": total,
            "with_raw_context": with_context,
            "with_audit_results": with_audit,
            "with_sme_feedback": with_feedback,
        }
    finally:
        conn.close()
