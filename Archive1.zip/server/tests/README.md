# Enhanced MCP Ticket System - Test Suite

## Overview

Comprehensive test suite for the enhanced MCP ticket system with knowledge graph support using Memgraph. Tests the complete enhanced schema with 11 node types and 18 relationship types.

## Test Structure

```
tests/
├── data/                           # Test data files
│   ├── enhanced_ticket_payload.json   # Complete test data with all entities
│   ├── minimal_ticket_payload.json    # Minimal data (sparse fields)
│   └── edge_case_payload.json         # Edge cases (nulls, empty arrays)
├── integration/                    # Integration tests
│   ├── test_enhanced_ingestion.py     # End-to-end ingestion testing
│   └── test_schema_validation.py      # Schema structure validation
├── run_enhanced_tests.py             # Main test runner
└── README.md                         # This file
```

## Test Suites

### 1. Schema Validation Tests (`test_schema_validation.py`)
- ✅ Enhanced schema creation
- ✅ Node table validation (11 types)
- ✅ Relationship table validation (18 types)
- ✅ Data type validation (STRING, INT64, BOOLEAN, DOUBLE)
- ✅ Sample analytics queries
- ✅ Schema statistics

### 2. Enhanced Ingestion Tests (`test_enhanced_ingestion.py`)
- ✅ Complete ticket ingestion (all knowledge graph entities)
- ✅ Minimal ticket ingestion (sparse data)
- ✅ Edge case ingestion (nulls, empty arrays, invalid data)
- ✅ Node count validation
- ✅ Relationship count validation
- ✅ Data integrity verification

## Quick Start

### Run All Tests
```bash
cd server/app/tests
python run_enhanced_tests.py
```

### Run Specific Test Suite
```bash
# Schema validation only
python run_enhanced_tests.py schema

# Ingestion tests only
python run_enhanced_tests.py ingestion

# Check dependencies only
python run_enhanced_tests.py --check-only
```

### Run Individual Tests
```bash
# Schema validation
python integration/test_schema_validation.py

# Ingestion tests
python integration/test_enhanced_ingestion.py
```

## Test Data

### Enhanced Ticket Payload (`enhanced_ticket_payload.json`)
Complete test data including:
- ✅ Client with enterprise fields (client_group, client_tier, etc.)
- ✅ Service with operational fields (related_circuit_id, source_system, etc.)
- ✅ Incident with impact tracking (is_customer_impacting, short_description)
- ✅ Ticket with lifecycle tracking (priority, escalation_level, dates)
- ✅ Outage with communication timeline (email times, dispatch events)
- ✅ Users array (created_by, assigned_to, first_assigned_to roles)
- ✅ Contacts array (customer, poc_a_end, poc_z_end types)
- ✅ Vendors array (with vendor_downtime floats)
- ✅ Maintenance window (scheduled work details)
- ✅ Survey info (customer satisfaction feedback)
- ✅ NOC info (operations center assignment)

### Minimal Ticket Payload (`minimal_ticket_payload.json`)
Basic test data with:
- ✅ Required fields only
- ✅ Single user
- ✅ No optional knowledge graph entities

### Edge Case Payload (`edge_case_payload.json`)
Edge case scenarios:
- ✅ Null and empty string values
- ✅ Empty arrays and null objects
- ✅ Invalid data type values
- ✅ Missing optional fields

## Expected Results

### Successful Test Run
```
🧪 ENHANCED MCP TICKET SYSTEM - COMPREHENSIVE TEST SUITE
========================================================

🔍 RUNNING SCHEMA VALIDATION TESTS
✅ Enhanced schema created successfully
✅ All 11 expected node tables found
✅ All 18 expected relationship tables found
✅ Node table schemas validated
✅ Sample analytics queries executed
✅ Schema matches expected structure

📊 RUNNING ENHANCED INGESTION TESTS
✅ Enhanced ticket processed successfully
✅ Minimal ticket processed successfully
✅ Edge case ticket processed successfully
✅ All expected node types found
✅ Relationships created successfully
✅ Data integrity verified

🏁 FINAL TEST SUMMARY
Schema Validation              ✅ PASSED
Enhanced Ingestion            ✅ PASSED
Test Suites: 2/2 passed
🎉 ALL TEST SUITES PASSED!
```

## Enhanced Schema Features Tested

### Node Types (11)
1. **Client** - Enterprise client management
2. **Service** - Enhanced service tracking
3. **Incident** - Impact and description tracking
4. **Ticket** - Complete lifecycle management
5. **Outage_Info** - Communication timeline
6. **UserInfo** - User attribution and roles
7. **ContactInfo** - Multi-type contact management
8. **VendorInfo** - Vendor/supplier tracking
9. **MaintenanceWindow** - Scheduled maintenance
10. **SurveyInfo** - Customer satisfaction
11. **NOCInfo** - Operations center assignment

### Relationship Types (18)
- **Core**: HAS_TICKET, HAS_OUTAGE_INFO, TRIGGERED_BY, IMPACTS, CHILD_OF
- **Tickets**: LINKED_TO
- **Users**: CREATED_BY, ASSIGNED_TO, CLOSED_BY, FIRST_ASSIGNED_TO
- **Contacts**: HAS_CONTACT, TICKET_CONTACT
- **Vendors**: HANDLED_BY, SUPPLIED_BY
- **Maintenance**: HAS_MAINTENANCE, DURING_MAINTENANCE
- **Survey**: HAS_SURVEY
- **NOC**: ASSIGNED_TO_NOC, MONITORED_BY_NOC

### Analytics Capabilities Tested
- ✅ User performance analytics
- ✅ Vendor impact analysis
- ✅ Client escalation patterns
- ✅ Contact communication tracking
- ✅ Maintenance impact correlation
- ✅ Survey satisfaction analysis

## Dependencies

Required Python packages:
- ✅ polars (data processing)
- ✅ neo4j (graph database driver for Memgraph)
- ✅ pyyaml (configuration)

## Troubleshooting

### Common Issues

1. **Module Import Errors**
   ```bash
   # Make sure you're in the right directory
   cd server/app/tests

   # Check Python path
   python -c "import sys; print(sys.path)"
   ```

2. **Memgraph Database Errors**
   ```bash
   # Tests connect to Memgraph at bolt://localhost:7687
   # Ensure Memgraph is running
   docker ps | grep memgraph
   ```

3. **Schema Errors**
   ```bash
   # Verify enhanced schema file exists
   ls -la ../data_access/cyphers/load_tickets_cypher.yaml
   ```

4. **Test Data Errors**
   ```bash
   # Verify test data files
   ls -la data/*.json
   ```

### Debug Mode
Add debug prints to test files for detailed troubleshooting:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## Contributing

When adding new tests:
1. ✅ Add test data to `data/` directory
2. ✅ Create test functions in appropriate test file
3. ✅ Update this README with new test descriptions
4. ✅ Ensure tests clean up properly (temp databases)

## Contact

For issues with the test suite, check:
1. ✅ Enhanced schema files are correct
2. ✅ Message handler updates are applied
3. ✅ All dependencies are installed
4. ✅ Test data files are valid JSON