# Eva Simple Message Viewer

A lightweight web UI for viewing real-time messages from Eva messaging infrastructure.

## Features

- 🔴 **Real-time Message Display**: Live streaming of messages from Eva NATS streams
- 🎯 **Stream Filtering**: Filter by specific streams (Ticketing, Analytics, Audit, Notifications)
- 🔍 **Text Search**: Search messages by subject or content
- ⏸️ **Pause/Resume**: Control message flow for detailed inspection
- 🗑️ **Clear Messages**: Clear the display when needed
- 📊 **Connection Status**: Real-time connection status to Eva infrastructure
- 🎨 **Color-coded Streams**: Visual distinction between different stream types

## Quick Start

### Prerequisites
- Eva messaging infrastructure running (NATS with JetStream)
- Eva streams initialized (`EVA_TICKETING`, `EVA_ANALYTICS`)

### Option 1: Docker (Recommended)

```bash
# From the simple-ui directory
docker-compose up -d

# View at: http://localhost:3001
```

### Option 2: Direct Node.js

```bash
# Install dependencies
npm install

# Start the server
npm start

# View at: http://localhost:3001
```

## Configuration

Environment variables:

```bash
NATS_URL=nats://localhost:4222        # Eva NATS URL
NATS_USER=eva-app                     # Eva NATS username
NATS_PASSWORD=eva-app-2024            # Eva NATS password
PORT=3001                             # UI server port
```

## Integration with Eva Infrastructure

This UI automatically connects to your existing Eva streams:

- **EVA_TICKETING**: `eva.tickets.*` subjects
- **EVA_ANALYTICS**: `eva.analytics.*` subjects

## Usage with Ticketing App

1. **Start Eva infrastructure**:
   ```bash
   cd eva/messaging-infrastructure/nats
   docker-compose up -d
   ./scripts/init-streams.sh
   ```

2. **Start Simple UI**:
   ```bash
   cd eva/messaging-infrastructure/simple-ui
   docker-compose up -d
   ```

3. **Start Ticketing App**:
   ```bash
   cd ticketing_data_processor
   docker-compose up -d
   ```

4. **View Messages**: Open http://localhost:3001

## API Endpoints

- `GET /api/health` - Health check
- `GET /api/streams` - List available streams
- `WS /socket.io` - Real-time message streaming

## Message Format

Messages are displayed with:

```json
{
  "timestamp": "2025-09-20T15:30:42.123Z",
  "stream": "EVA_TICKETING",
  "subject": "eva.tickets.created",
  "data": { "ticket_id": "T123", "status": "open" },
  "sequence": 12345
}
```

## Development

The UI is intentionally simple:
- **Frontend**: Pure HTML/CSS/JavaScript (no React/frameworks)
- **Backend**: Node.js + Express + Socket.io
- **Real-time**: WebSocket for live message streaming
- **Deployment**: Single Docker container

## Future Enhancements

When ready for enterprise features:
- Authentication and authorization
- Message publishing capabilities
- Stream management interface
- Advanced filtering and search
- Export capabilities
- Performance metrics

## Troubleshooting

### UI shows "Waiting for messages"
- Verify Eva NATS infrastructure is running
- Check that streams are initialized: `./scripts/init-streams.sh`
- Verify network connectivity between UI and NATS

### Connection issues
- Check NATS URL and credentials in environment variables
- Verify Eva messaging network is accessible
- Check Docker network: `docker network ls | grep eva-messaging`

### No messages appearing
- Verify ticketing app is publishing to Eva streams
- Check stream subjects match expected patterns
- Use NATS CLI to verify messages: `nats stream info EVA_TICKETING`