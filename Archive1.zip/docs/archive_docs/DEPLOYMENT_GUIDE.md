# Deployment Guide

Comprehensive deployment guide for the Enhanced MCP Ticket System with Knowledge Graph (Memgraph) and Vector Database (Milvus) capabilities.

---

## Quick Start (5 minutes)

Get the system running locally in minimal time:

```bash
# Clone and navigate to project
cd /path/to/mcp_ticket/server

# Start all services
docker-compose up -d

# Check status
docker-compose ps

# Verify health
curl http://localhost:8003/health
python system_health_check.py

# View logs
docker-compose logs -f mcp_ticket_server
```

**Access Points:**
- MCP Server: `http://localhost:8003`
- NATS Monitoring: `http://localhost:8222`
- MinIO Console: `http://localhost:9001` (minioadmin/minioadmin)
- Milvus gRPC: `localhost:19530`

---

## Prerequisites

### System Requirements

**Minimum (Development):**
- CPU: 2 cores
- RAM: 4GB available
- Storage: 10GB available
- Docker: 20.10+
- Docker Compose: 2.0+

**Recommended (Production):**
- CPU: 4+ cores
- RAM: 8GB+ available
- Storage: 50GB+ SSD
- Kubernetes: 1.21+ (for K8s deployment)
- kubectl configured with cluster access
- Network: High bandwidth for NATS messaging

### Dependencies

**Required Software:**
- Docker Engine 20.10+
- Docker Compose 2.0+
- Python 3.13+ (for local development)
- Git (for version control)

**Optional (Production):**
- Kubernetes cluster
- kubectl CLI
- Helm 3+ (recommended)
- Container registry access

---

## Local Development

### Docker Compose Setup

The system uses Docker Compose for local development with the following services:

#### Service Stack

**Core Services:**
1. **mcp_ticket_server** - Main application server
2. **memgraph** - Knowledge graph database
3. **nats** - NATS JetStream messaging
4. **milvus-standalone** - Vector similarity search engine

**Milvus Dependencies:**
5. **milvus-etcd** - Metadata storage
6. **milvus-minio** - Object storage for vectors
7. **mcp-ollama** - Embedding generation service

**Optional:**
8. **mcp_dev_tools** - Development utilities (profile: dev)

#### Starting Services

```bash
# Start all production services
docker-compose up -d

# Start with development tools
docker-compose --profile dev up -d

# Start specific services
docker-compose up -d mcp_ticket_server nats memgraph

# Scale application
docker-compose up -d --scale mcp_ticket_server=3
```

#### Stopping Services

```bash
# Graceful shutdown (preserves data)
docker-compose down

# Remove all data volumes
docker-compose down -v

# Stop specific service
docker-compose stop mcp_ticket_server
```

### Environment Variables

Create a `.env` file in the `/server` directory:

```env
# Application Configuration
MEMGRAPH_URI=bolt://memgraph:7687
MEMGRAPH_USER=
MEMGRAPH_PASSWORD=
MEMGRAPH_DATABASE=memgraph

# NATS Configuration
NATS_URL=nats://nats:4222
JETSTREAM_STREAM_NAME=DATA_INJESTION_STREAM
TICKET_PUBLISH_SUBJECT=tickets.created
TICKET_SUBSCRIBE_SUBJECT=tickets.created

# Milvus Configuration
MILVUS_HOST=localhost
MILVUS_PORT=19530
MILVUS_COLLECTION_NAME=fault_descriptions
MILVUS_INDEX_TYPE=IVF_FLAT
MILVUS_METRIC_TYPE=COSINE
MILVUS_NLIST=1024
MILVUS_NPROBE=32

# Ollama Configuration
OLLAMA_EMBEDDING_URL=http://localhost:11434
OLLAMA_EMBEDDING_MODEL=nomic-embed-text

# LLM Configuration
LLM_TEMPERATURE=0.1

# File Paths
CYPHER_FILE_PATH=/app/data_access/cyphers/load_tickets_cypher.yaml
SCHEMA_DESC_PATH=/app/data_access/cyphers/ticket_schema_description.yaml
BAML_ENV_FILE_PATH=/app/.env.baml
```

### Service Configuration

#### Port Mappings

| Service | Internal Port | External Port | Purpose |
|---------|--------------|---------------|---------|
| mcp_ticket_server | 8003 | 8003 | HTTP API |
| memgraph | 7687 | 7687 | Bolt protocol |
| nats | 4222 | 4222 | Client connections |
| nats | 6222 | 6222 | Cluster routing |
| nats | 8222 | 8222 | HTTP monitoring |
| milvus | 19530 | 19530 | gRPC API |
| milvus | 9091 | 9091 | Health check |
| minio | 9000 | 9000 | S3 API |
| minio | 9001 | 9001 | Web console |
| etcd | 2379 | 2379 | Client API |
| ollama | 11434 | 11434 | Embedding API |

#### Volume Mounts

**Persistent Storage:**
- `memgraph_data` - Knowledge graph database
- `nats_data` - JetStream message storage
- `milvus_data` - Vector database runtime
- `etcd_data` - Milvus metadata
- `minio_data` - Vector data files
- `ollama_data` - Embedding model weights (~274MB)
- `app_logs` - Application logs

**Development Mounts:**
```yaml
volumes:
  - ./app:/app  # Hot reload for code changes
  - ./data:/data  # Database files
```

#### Network Configuration

All services communicate via the `mcp_network` bridge network:

```yaml
networks:
  mcp_network:
    driver: bridge
```

For production, services use internal DNS resolution (e.g., `memgraph:7687`).

---

## Service Architecture

### Component Overview

```
┌─────────────────────────────────────────────────────────────┐
│                      MCP Client / User                       │
└──────────────────┬──────────────────────────────────────────┘
                   │ Natural Language Query
                   ▼
┌─────────────────────────────────────────────────────────────┐
│              MCP Ticket Server (FastMCP)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ Query Tools  │  │ Lookup Tools │  │ Search Tools │      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
│         │                 │                  │               │
│         └─────────────────┼──────────────────┘               │
│                          ▼                                   │
│         ┌────────────────────────────────┐                  │
│         │   BAML Query Translation       │                  │
│         └────────────────┬───────────────┘                  │
└──────────────────────────┼──────────────────────────────────┘
                           │
         ┌─────────────────┼─────────────────┐
         │                 │                 │
         ▼                 ▼                 ▼
┌─────────────────┐ ┌─────────────┐ ┌────────────────┐
│   Memgraph      │ │   Milvus    │ │  NATS Stream   │
│ Knowledge Graph │ │ Vector DB   │ │  Message Bus   │
└─────────────────┘ └─────────────┘ └────────────────┘
         │                 │                 │
         │                 │                 ▼
         │                 │         ┌────────────────┐
         │                 │         │ Ticket ETL     │
         │                 │         │ Publisher      │
         │                 │         └────────────────┘
         │                 │
         │                 └──────────┬────────────────
         │                            │
         ▼                            ▼
┌──────────────────────────────────────────────────────┐
│              Data Processing Layer                    │
│  ┌─────────────────┐      ┌─────────────────┐       │
│  │ Message Handler │      │ Embedding Gen   │       │
│  │ (Decompress)    │      │ (Ollama)        │       │
│  └─────────────────┘      └─────────────────┘       │
└──────────────────────────────────────────────────────┘
```

### Service Dependencies

**Startup Order:**
1. **etcd** - Milvus metadata store (no dependencies)
2. **minio** - Milvus object storage (no dependencies)
3. **milvus-standalone** - Vector DB (depends on: etcd, minio)
4. **ollama** - Embedding service (no dependencies)
5. **memgraph** - Knowledge graph (no dependencies)
6. **nats** - Message bus (no dependencies)
7. **mcp_ticket_server** - Main app (depends on: all above)

**Data Flow:**
```
ticket_etl → [gzip+base64] → NATS JetStream →
  → Message Handler → [decompress] → [validate] →
  → Memgraph (structured data) + Milvus (embeddings)

User → MCP Client → FastMCP Server →
  → Memgraph (graph queries) + Milvus (semantic search)
  → Response
```

### Communication Patterns

**Synchronous:**
- HTTP/REST: MCP client ↔ FastMCP server
- Bolt: FastMCP server ↔ Memgraph
- gRPC: FastMCP server ↔ Milvus

**Asynchronous:**
- NATS JetStream: ticket_etl → Message Handler
- Pull-based subscription with ACK/NAK

---

## Production Deployment

### Kubernetes/Helm Setup

#### Directory Structure

```
/app
├── k8s/                               # Kubernetes manifests
│   ├── namespace.yaml                 # mcp-ticket-system namespace
│   ├── configmap.yaml                 # Application configuration
│   ├── secret.yaml                    # Sensitive data (template)
│   ├── pvc.yaml                       # Persistent storage claims
│   ├── rbac.yaml                      # Security permissions
│   ├── nats-deployment.yaml           # NATS JetStream
│   ├── mcp-ticket-deployment.yaml     # Main application
│   ├── ingress.yaml                   # External access
│   ├── hpa.yaml                       # Auto-scaling
│   └── kustomization.yaml             # Kustomize config
└── scripts/
    └── build-and-deploy.sh            # Deployment automation
```

#### Deployment Commands

```bash
# Automated deployment (recommended)
./scripts/build-and-deploy.sh all

# Or step-by-step
./scripts/build-and-deploy.sh build    # Build Docker image
./scripts/build-and-deploy.sh deploy   # Deploy to K8s
./scripts/build-and-deploy.sh status   # Check status

# Manual Kubernetes deployment
kubectl apply -k k8s/

# Deploy individual components
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/secret.yaml
kubectl apply -f k8s/pvc.yaml
kubectl apply -f k8s/rbac.yaml
kubectl apply -f k8s/nats-deployment.yaml
kubectl apply -f k8s/mcp-ticket-deployment.yaml
kubectl apply -f k8s/ingress.yaml
kubectl apply -f k8s/hpa.yaml
```

#### Verification

```bash
# Check all resources
kubectl get all -n mcp-ticket-system

# Check deployment status
kubectl describe deployment mcp-ticket-deployment -n mcp-ticket-system
kubectl describe deployment nats-deployment -n mcp-ticket-system

# View pods
kubectl get pods -n mcp-ticket-system -o wide

# Check services
kubectl get svc -n mcp-ticket-system

# Check persistent volumes
kubectl get pvc -n mcp-ticket-system
```

### Configuration Management

#### ConfigMap

Contains non-sensitive application settings:

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: mcp-ticket-config
  namespace: mcp-ticket-system
data:
  MEMGRAPH_URI: "bolt://memgraph:7687"
  MEMGRAPH_DATABASE: "memgraph"
  NATS_URL: "nats://nats:4222"
  MILVUS_HOST: "milvus-standalone"
  MILVUS_PORT: "19530"
  OLLAMA_EMBEDDING_URL: "http://ollama:11434"
  LLM_TEMPERATURE: "0.1"
```

**Update ConfigMap:**
```bash
# Edit directly
kubectl edit configmap mcp-ticket-config -n mcp-ticket-system

# Apply from file
kubectl apply -f k8s/configmap.yaml

# Restart pods to pick up changes
kubectl rollout restart deployment/mcp-ticket-deployment -n mcp-ticket-system
```

### Secrets Management

#### Creating Secrets

```bash
# Create from literal values
kubectl create secret generic mcp-ticket-secret \
  --from-literal=BAML_API_KEY=your-api-key \
  --from-literal=MEMGRAPH_PASSWORD=your-password \
  -n mcp-ticket-system

# Create from file
kubectl create secret generic mcp-ticket-secret \
  --from-file=.env.baml=/path/to/.env.baml \
  -n mcp-ticket-system

# Create from YAML manifest
kubectl apply -f k8s/secret.yaml
```

#### Secret Template (k8s/secret.yaml)

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: mcp-ticket-secret
  namespace: mcp-ticket-system
type: Opaque
stringData:
  BAML_API_KEY: "replace-with-actual-key"
  MEMGRAPH_PASSWORD: ""
  BAML_ENV_FILE: |
    # BAML configuration
    API_KEY=your-key-here
```

**IMPORTANT:** Never commit actual secrets to version control. Use external secret management:
- HashiCorp Vault
- AWS Secrets Manager
- Azure Key Vault
- Google Secret Manager
- Kubernetes External Secrets Operator

#### Using Secrets in Pods

```yaml
envFrom:
  - secretRef:
      name: mcp-ticket-secret
```

### Resource Requirements

#### Production Resource Limits

```yaml
# MCP Ticket Server
resources:
  requests:
    memory: "512Mi"
    cpu: "250m"
  limits:
    memory: "2Gi"
    cpu: "1000m"

# NATS JetStream
resources:
  requests:
    memory: "256Mi"
    cpu: "100m"
  limits:
    memory: "512Mi"
    cpu: "500m"

# Memgraph
resources:
  requests:
    memory: "1Gi"
    cpu: "500m"
  limits:
    memory: "4Gi"
    cpu: "2000m"

# Milvus
resources:
  requests:
    memory: "2Gi"
    cpu: "1000m"
  limits:
    memory: "8Gi"
    cpu: "4000m"
```

#### Persistent Storage

```yaml
# Memgraph data
- name: memgraph-data-pvc
  size: 10Gi
  storageClass: fast-ssd  # Adjust for your cluster

# NATS data
- name: nats-data-pvc
  size: 5Gi
  storageClass: standard

# Milvus data
- name: milvus-data-pvc
  size: 20Gi
  storageClass: fast-ssd

# Application logs
- name: app-logs-pvc
  size: 2Gi
  storageClass: standard
```

**Adjust storage classes based on your cluster:**
- AWS: `gp3`, `io1`, `io2`
- GCP: `pd-standard`, `pd-ssd`, `pd-balanced`
- Azure: `managed-premium`, `managed-standard`

---

## Database Setup

### Memgraph Configuration

#### Initial Setup

```bash
# Docker Compose
docker-compose up -d memgraph

# Verify connection
docker exec -it mcp_ticket_server python -c "
from data_access.memgraphClient import MemgraphClient
from configs.config import Config
config = Config()
client = MemgraphClient(config.memgraph_uri, config.memgraph_user, config.memgraph_password, config.memgraph_database, {})
client.connect()
result = client.execute('MATCH (n) RETURN count(n) as node_count')
print(f'Node count: {list(result)[0][\"node_count\"]}')
"

# Kubernetes
kubectl exec -it deployment/mcp-ticket-deployment -n mcp-ticket-system -- python -c "..."
```

#### Schema Overview

The system uses an 11-node knowledge graph schema:

**Node Types:**
1. **Ticket** - Core ticket entity
2. **Client** - Customer organizations
3. **Service** - Network services
4. **Incident** - Service incidents
5. **Outage_Info** - Outage details
6. **UserInfo** - System users
7. **ContactInfo** - Contact details
8. **VendorInfo** - Third-party vendors
9. **MaintenanceWindow** - Maintenance schedules
10. **SurveyInfo** - Customer feedback
11. **NOCInfo** - NOC team information

**Relationship Types (19):**
- BELONGS_TO, HAS_TICKET, RELATES_TO
- HAS_OUTAGE_INFO, CREATED_BY, ASSIGNED_TO
- HAS_CONTACT, INVOLVES_VENDOR, HAS_MAINTENANCE
- HAS_SURVEY, MANAGED_BY, and more

#### Schema Initialization

Schema is automatically loaded from:
```
/app/data_access/cyphers/load_tickets_cypher.yaml
```

**Manual verification:**
```bash
# Check loaded schema
docker exec -it mcp_ticket_server python -c "
from configs.config import Config
config = Config()
import yaml
with open(config.cypher_file_path) as f:
    schema = yaml.safe_load(f)
print(f'Schema configs loaded: {len(schema)}')
"
```

### Milvus Vector DB Setup

#### Service Architecture

Milvus requires three supporting services:
1. **etcd** - Stores metadata (collection schemas, index info)
2. **MinIO** - Stores vector data and segment files
3. **milvus-standalone** - Vector search engine

#### Health Checks

```bash
# Milvus health
curl http://localhost:9091/healthz

# MinIO health
curl http://localhost:9000/minio/health/live

# etcd health
docker exec milvus-etcd etcdctl endpoint health

# Verify all services
docker-compose ps
```

#### Collection Configuration

The system creates a `fault_descriptions` collection with:

```python
# Collection schema
{
    "collection_name": "fault_descriptions",
    "dimension": 768,  # nomic-embed-text embedding size
    "index_type": "IVF_FLAT",
    "metric_type": "COSINE",
    "index_params": {
        "nlist": 1024,  # sqrt(1M) for 1M vectors
    },
    "search_params": {
        "nprobe": 32,  # 97% accuracy, ~40ms latency
    }
}
```

**Metadata stored per vector:**
```python
{
    "fault_description_id": "INC123456"  # Links to Memgraph
}
```

#### Embedding Service (Ollama)

**Model:** `nomic-embed-text`
- Dimension: 768
- Model size: ~274MB
- Auto-downloaded on first startup

**Verify Ollama:**
```bash
# Check loaded models
docker exec mcp-ollama ollama list

# Test embedding generation
curl http://localhost:11434/api/embeddings -d '{
  "model": "nomic-embed-text",
  "prompt": "Fiber cable cut causing network outage"
}'
```

#### Data Persistence

All Milvus data persists across restarts:
- `etcd_data` - Metadata
- `minio_data` - Vector files
- `milvus_data` - Runtime data
- `ollama_data` - Model weights

---

## Monitoring & Health Checks

### Health Endpoints

#### Application Health

```bash
# Docker Compose
curl http://localhost:8003/health

# Kubernetes
kubectl port-forward service/mcp-ticket-service 8003:8003 -n mcp-ticket-system
curl http://localhost:8003/health
```

#### System Health Check Script

```bash
# Docker Compose
python system_health_check.py

# Kubernetes
kubectl exec -it deployment/mcp-ticket-deployment -n mcp-ticket-system -- python system_health_check.py
```

**Expected Output:**
```
Core Components Health: 100%
✅ Message Handler: Operational
✅ Memgraph Client: Operational
✅ Cypher Configurations: Loaded (19 configs)
✅ Configuration System: Operational
✅ Utilities: Operational
✅ Main Application: Operational

Dependencies Health: 100%
✅ Memgraph Database: Connected
✅ Milvus Vector DB: Connected
✅ NATS Messaging: Available
```

#### Component-Specific Health

**NATS Monitoring:**
```bash
# Docker Compose
curl http://localhost:8222/varz   # Server info
curl http://localhost:8222/connz  # Connections
curl http://localhost:8222/jsz    # JetStream info

# Kubernetes
kubectl port-forward service/nats-monitor-service 8222:8222 -n mcp-ticket-system
curl http://localhost:8222/varz
```

**Memgraph Health:**
```bash
# Docker Compose
docker exec -it mcp_ticket_server python -c "
from data_access.memgraphClient import MemgraphClient
from configs.config import Config
config = Config()
client = MemgraphClient(config.memgraph_uri, config.memgraph_user, config.memgraph_password, config.memgraph_database, {})
client.connect()
result = client.execute('MATCH (n) RETURN labels(n), count(n) LIMIT 10')
records = [record.data() for record in result]
print(records)
"
```

**Milvus Health:**
```bash
# Health endpoint
curl http://localhost:9091/healthz

# Collection info
docker exec -it milvus-standalone python -c "
from pymilvus import connections, utility
connections.connect(host='localhost', port='19530')
print(f'Collections: {utility.list_collections()}')
"
```

### Logging

#### Application Logs

**Docker Compose:**
```bash
# Follow all logs
docker-compose logs -f

# Follow specific service
docker-compose logs -f mcp_ticket_server
docker-compose logs -f nats
docker-compose logs -f milvus

# Last 100 lines
docker-compose logs --tail=100 mcp_ticket_server

# Access log files
docker exec -it mcp_ticket_server tail -f /app/logs/app.log
```

**Kubernetes:**
```bash
# Follow deployment logs
kubectl logs -f deployment/mcp-ticket-deployment -n mcp-ticket-system

# Follow specific pod
kubectl logs -f <pod-name> -n mcp-ticket-system

# Previous container logs (after crash)
kubectl logs <pod-name> --previous -n mcp-ticket-system

# Access log files
kubectl exec -it deployment/mcp-ticket-deployment -n mcp-ticket-system -- tail -f /app/logs/app.log
```

#### Log Levels

Configure via environment variable:
```env
LOG_LEVEL=INFO  # DEBUG, INFO, WARNING, ERROR, CRITICAL
```

#### Centralized Logging (Production)

**ELK Stack:**
```yaml
# Filebeat sidecar
- name: filebeat
  image: docker.elastic.co/beats/filebeat:8.10.0
  volumeMounts:
    - name: app-logs
      mountPath: /app/logs
```

**Fluentd:**
```yaml
# Fluentd DaemonSet
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: fluentd
spec:
  # ... configuration
```

### Metrics

#### Prometheus Integration (Recommended)

**Expose metrics endpoint:**
```python
# Add to main application
from prometheus_client import start_http_server, Counter, Histogram

# Start metrics server
start_http_server(9090)
```

**Kubernetes ServiceMonitor:**
```yaml
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: mcp-ticket-monitor
  namespace: mcp-ticket-system
spec:
  selector:
    matchLabels:
      app: mcp-ticket-server
  endpoints:
    - port: metrics
      interval: 30s
```

#### Key Metrics to Monitor

**Application:**
- Request count and latency
- Error rate
- Message processing rate
- Database query latency

**Infrastructure:**
- CPU usage
- Memory usage
- Disk I/O
- Network traffic

**Custom Metrics:**
- Tickets processed
- Vector embeddings generated
- Graph queries executed
- NATS message backlog

---

## Troubleshooting

### Common Deployment Issues

#### Issue: Container Won't Start

**Symptoms:**
- Pod in CrashLoopBackOff
- Container exits immediately
- Health check failures

**Diagnosis:**
```bash
# Check logs
docker logs mcp_ticket_server
kubectl describe pod <pod-name> -n mcp-ticket-system
kubectl logs <pod-name> -n mcp-ticket-system

# Check events
kubectl get events -n mcp-ticket-system --sort-by='.lastTimestamp'
```

**Common Causes:**
1. **Missing environment variables**
   ```bash
   # Verify environment
   docker exec mcp_ticket_server env | grep MEMGRAPH
   kubectl exec <pod-name> -n mcp-ticket-system -- env
   ```

2. **Volume mount issues**
   ```bash
   # Check mounts
   docker inspect mcp_ticket_server | grep Mounts -A 20
   kubectl describe pod <pod-name> -n mcp-ticket-system | grep Mounts -A 10
   ```

3. **Database connectivity**
   ```bash
   # Test connectivity
   docker exec mcp_ticket_server nc -zv memgraph 7687
   kubectl exec <pod-name> -n mcp-ticket-system -- nc -zv memgraph 7687
   ```

**Solutions:**
- Verify all required environment variables are set
- Check ConfigMap and Secret resources
- Ensure PVCs are bound
- Verify network connectivity

#### Issue: NATS Connection Failed

**Symptoms:**
- "NATS connection refused"
- Message handler not starting
- No messages being processed

**Diagnosis:**
```bash
# Check NATS health
curl http://localhost:8222/healthz

# Check NATS service
docker-compose ps nats
kubectl get svc nats-service -n mcp-ticket-system

# Test connectivity
docker exec mcp_ticket_server nc -zv nats 4222
kubectl exec <pod-name> -n mcp-ticket-system -- nc -zv nats-service 4222
```

**Common Causes:**
1. **Service discovery issues**
   - DNS not resolving
   - Wrong service name

2. **Network policies blocking traffic**
   ```bash
   # Check network policies
   kubectl get networkpolicies -n mcp-ticket-system
   ```

3. **NATS not ready**
   ```bash
   # Wait for NATS to be ready
   kubectl wait --for=condition=ready pod -l app=nats -n mcp-ticket-system
   ```

**Solutions:**
- Verify NATS URL in configuration
- Check service DNS resolution
- Review network policies
- Increase startup delay for dependent services

#### Issue: Health Check Failing

**Symptoms:**
- Pod marked as unhealthy
- Continuous restarts
- Readiness probe failures

**Diagnosis:**
```bash
# Run health check manually
python system_health_check.py

# Check specific components
docker exec mcp_ticket_server python -c "
from data_access.memgraphClient import MemgraphClient
from configs.config import Config
config = Config()
client = MemgraphClient(config.memgraph_uri, config.memgraph_user, config.memgraph_password, config.memgraph_database, {})
try:
    client.connect()
    print('✅ Memgraph connected')
except Exception as e:
    print(f'❌ Memgraph failed: {e}')
"
```

**Common Causes:**
1. **Memgraph connection refused**
   - Memgraph not started
   - Wrong credentials
   - Network issues

2. **YAML configuration files missing**
   ```bash
   # Verify files exist
   docker exec mcp_ticket_server ls -la /app/data_access/cyphers/
   ```

3. **Import errors**
   ```bash
   # Test imports
   docker exec mcp_ticket_server python -c "
   import sys
   sys.path.append('/app')
   from utils.utilities import Helpers
   print('✅ Import successful')
   "
   ```

**Solutions:**
- Verify all dependencies are running
- Check file mounts and paths
- Review application logs for errors
- Increase health check timeouts

#### Issue: Message Processing Errors

**Symptoms:**
- Messages not being consumed
- NAK/ACK errors
- Backlog building up

**Diagnosis:**
```bash
# Check NATS JetStream status
curl http://localhost:8222/jsz

# Check consumer status
docker exec nats nats consumer info DATA_INJESTION_STREAM tickets_consumer

# View message handler logs
docker-compose logs -f mcp_ticket_server | grep "message_handler"
```

**Common Causes:**
1. **Compression/decompression errors**
   - Invalid gzip data
   - Base64 encoding issues

2. **Schema validation failures**
   - Missing required fields
   - Type mismatches

3. **Database insertion errors**
   - Constraint violations
   - Invalid data types

**Solutions:**
- Validate message format
- Check schema compatibility
- Review error logs for specific issues
- Enable debug logging

#### Issue: Vector Search Not Working

**Symptoms:**
- Empty search results
- Milvus connection errors
- Embedding generation failures

**Diagnosis:**
```bash
# Check Milvus health
curl http://localhost:9091/healthz

# Check Ollama
curl http://localhost:11434/api/tags

# Verify collection exists
docker exec -it milvus-standalone python -c "
from pymilvus import connections, utility
connections.connect(host='localhost', port='19530')
print(f'Collections: {utility.list_collections()}')
"
```

**Common Causes:**
1. **Milvus not ready**
   - etcd or MinIO not started
   - Collection not created

2. **Ollama model not loaded**
   ```bash
   # Pull model manually
   docker exec mcp-ollama ollama pull nomic-embed-text
   ```

3. **Embedding dimension mismatch**
   - Collection expects 768 dimensions
   - Verify model output

**Solutions:**
- Wait for all Milvus dependencies
- Pre-pull Ollama model
- Verify collection schema
- Check embedding generation

### Debug Procedures

#### Enable Debug Logging

**Docker Compose:**
```bash
# Add to docker-compose.override.yml
services:
  mcp_ticket_server:
    environment:
      - LOG_LEVEL=DEBUG
      - PYTHONUNBUFFERED=1
```

**Kubernetes:**
```bash
# Update ConfigMap
kubectl edit configmap mcp-ticket-config -n mcp-ticket-system
# Add: LOG_LEVEL: "DEBUG"

# Restart deployment
kubectl rollout restart deployment/mcp-ticket-deployment -n mcp-ticket-system
```

#### Interactive Debugging

**Docker:**
```bash
# Exec into container
docker exec -it mcp_ticket_server bash

# Run Python REPL
docker exec -it mcp_ticket_server python

# Test specific component
docker exec -it mcp_ticket_server python /app/scripts/test_component.py
```

**Kubernetes:**
```bash
# Exec into pod
kubectl exec -it <pod-name> -n mcp-ticket-system -- bash

# Run health check
kubectl exec -it <pod-name> -n mcp-ticket-system -- python system_health_check.py

# Port forward for local testing
kubectl port-forward <pod-name> 8003:8003 -n mcp-ticket-system
```

#### Network Debugging

```bash
# Test connectivity
docker exec mcp_ticket_server nc -zv memgraph 7687
docker exec mcp_ticket_server nc -zv nats 4222
docker exec mcp_ticket_server nc -zv milvus-standalone 19530

# DNS resolution
docker exec mcp_ticket_server nslookup memgraph
docker exec mcp_ticket_server nslookup nats

# Kubernetes
kubectl exec <pod-name> -n mcp-ticket-system -- nc -zv memgraph-service 7687
kubectl exec <pod-name> -n mcp-ticket-system -- nslookup nats-service
```

#### Performance Profiling

```bash
# CPU profiling
docker exec mcp_ticket_server python -m cProfile -o /tmp/profile.stats /app/main.py

# Memory profiling
docker exec mcp_ticket_server python -m memory_profiler /app/main.py

# Line profiling
docker exec mcp_ticket_server kernprof -l -v /app/main.py
```

---

## Rollback Procedures

### Docker Compose Rollback

**Version Tagging:**
```bash
# Tag working version
docker tag mcp-ticket-server:latest mcp-ticket-server:v1.0

# Build new version
docker-compose build

# Tag as latest
docker tag mcp-ticket-server:latest mcp-ticket-server:v2.0

# If v2.0 fails, rollback
docker tag mcp-ticket-server:v1.0 mcp-ticket-server:latest
docker-compose up -d
```

**Data Rollback:**
```bash
# Stop services
docker-compose down

# Restore volumes from backup
docker run --rm -v memgraph_data:/data -v $(pwd)/backup:/backup \
  alpine sh -c "cd /data && tar xzf /backup/memgraph-backup-2024-01-15.tar.gz"

# Restart services
docker-compose up -d
```

### Kubernetes Rollback

#### Deployment Rollback

```bash
# View rollout history
kubectl rollout history deployment/mcp-ticket-deployment -n mcp-ticket-system

# Rollback to previous version
kubectl rollout undo deployment/mcp-ticket-deployment -n mcp-ticket-system

# Rollback to specific revision
kubectl rollout undo deployment/mcp-ticket-deployment --to-revision=3 -n mcp-ticket-system

# Check rollback status
kubectl rollout status deployment/mcp-ticket-deployment -n mcp-ticket-system
```

#### Configuration Rollback

```bash
# View ConfigMap history (if using git)
git log k8s/configmap.yaml

# Revert to previous version
git checkout <commit-hash> k8s/configmap.yaml
kubectl apply -f k8s/configmap.yaml

# Restart pods
kubectl rollout restart deployment/mcp-ticket-deployment -n mcp-ticket-system
```

#### Database Rollback

**Memgraph:**
```bash
# Stop application
kubectl scale deployment/mcp-ticket-deployment --replicas=0 -n mcp-ticket-system

# Restore from backup (see Maintenance section)
# ... restore procedure ...

# Start application
kubectl scale deployment/mcp-ticket-deployment --replicas=2 -n mcp-ticket-system
```

**Milvus:**
```bash
# Milvus rollback requires MinIO backup restoration
# Contact Milvus documentation for detailed procedures
```

### Version Management

#### Git Tagging

```bash
# Tag releases
git tag -a v1.0.0 -m "Production release 1.0.0"
git push origin v1.0.0

# List tags
git tag -l

# Checkout specific version
git checkout v1.0.0
```

#### Docker Image Versioning

```bash
# Build with version tag
docker build -t mcp-ticket-server:v1.0.0 .
docker tag mcp-ticket-server:v1.0.0 registry.example.com/mcp-ticket-server:v1.0.0

# Push to registry
docker push registry.example.com/mcp-ticket-server:v1.0.0

# Update Kubernetes deployment
kubectl set image deployment/mcp-ticket-deployment \
  mcp-ticket-server=registry.example.com/mcp-ticket-server:v1.0.0 \
  -n mcp-ticket-system
```

#### Helm Chart Versioning (if using Helm)

```bash
# Package chart with version
helm package . --version 1.0.0

# Install specific version
helm install mcp-ticket ./mcp-ticket-chart --version 1.0.0

# Rollback to previous release
helm rollback mcp-ticket 1 -n mcp-ticket-system
```

---

## Maintenance

### Backup/Restore

#### Memgraph Backup

**Docker Compose:**
```bash
# Create backup directory
mkdir -p ./backups/memgraph

# Backup using Docker volume
docker run --rm \
  -v memgraph_data:/source:ro \
  -v $(pwd)/backups/memgraph:/backup \
  alpine tar czf /backup/memgraph-backup-$(date +%Y%m%d-%H%M%S).tar.gz -C /source .

# Automated backup script
cat > backup-memgraph.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="./backups/memgraph"
DATE=$(date +%Y%m%d-%H%M%S)
mkdir -p $BACKUP_DIR
docker run --rm \
  -v memgraph_data:/source:ro \
  -v $(pwd)/$BACKUP_DIR:/backup \
  alpine tar czf /backup/memgraph-$DATE.tar.gz -C /source .
echo "Backup created: $BACKUP_DIR/memgraph-$DATE.tar.gz"
# Keep only last 7 backups
ls -t $BACKUP_DIR/memgraph-*.tar.gz | tail -n +8 | xargs -r rm
EOF
chmod +x backup-memgraph.sh

# Schedule with cron
# 0 2 * * * /path/to/backup-memgraph.sh
```

**Restore:**
```bash
# Stop application
docker-compose stop mcp_ticket_server

# Restore backup
docker run --rm \
  -v memgraph_data:/target \
  -v $(pwd)/backups/memgraph:/backup \
  alpine sh -c "rm -rf /target/* && tar xzf /backup/memgraph-backup-20240115-020000.tar.gz -C /target"

# Restart application
docker-compose up -d
```

**Kubernetes:**
```bash
# Backup using PVC snapshot (if supported)
kubectl create volumesnapshot memgraph-snapshot \
  --volume-snapshot-class=csi-snapshot-class \
  --source=memgraph-data-pvc \
  -n mcp-ticket-system

# Or copy data from pod
kubectl exec deployment/memgraph-deployment -n mcp-ticket-system -- \
  tar czf - /var/lib/memgraph/data > memgraph-backup-$(date +%Y%m%d).tar.gz
```

#### Milvus Backup

**MinIO Data Backup:**
```bash
# Backup MinIO data
docker run --rm \
  -v minio_data:/source:ro \
  -v $(pwd)/backups/minio:/backup \
  alpine tar czf /backup/minio-backup-$(date +%Y%m%d-%H%M%S).tar.gz -C /source .

# Backup etcd metadata
docker run --rm \
  -v etcd_data:/source:ro \
  -v $(pwd)/backups/etcd:/backup \
  alpine tar czf /backup/etcd-backup-$(date +%Y%m%d-%H%M%S).tar.gz -C /source .
```

**Collection Backup (API):**
```python
# Save collection to file
from pymilvus import connections, utility
connections.connect(host='localhost', port='19530')

# Export collection (requires Milvus 2.3+)
# Use milvus-backup tool: https://github.com/zilliztech/milvus-backup
```

#### NATS Backup

```bash
# Backup NATS JetStream data
docker run --rm \
  -v nats_data:/source:ro \
  -v $(pwd)/backups/nats:/backup \
  alpine tar czf /backup/nats-backup-$(date +%Y%m%d-%H%M%S).tar.gz -C /source .
```

#### Application Logs Backup

```bash
# Archive logs
docker run --rm \
  -v app_logs:/source:ro \
  -v $(pwd)/backups/logs:/backup \
  alpine tar czf /backup/logs-backup-$(date +%Y%m%d-%H%M%S).tar.gz -C /source .

# Rotate logs (Docker)
docker-compose logs --no-color > logs/app-$(date +%Y%m%d).log
gzip logs/app-$(date +%Y%m%d).log
```

### Updates

#### Application Updates

**Docker Compose:**
```bash
# Pull latest code
git pull origin main

# Rebuild image
docker-compose build --no-cache mcp_ticket_server

# Restart with new version
docker-compose up -d

# Verify health
curl http://localhost:8003/health
```

**Kubernetes:**
```bash
# Build and push new image
docker build -t registry.example.com/mcp-ticket-server:v1.1.0 .
docker push registry.example.com/mcp-ticket-server:v1.1.0

# Update deployment
kubectl set image deployment/mcp-ticket-deployment \
  mcp-ticket-server=registry.example.com/mcp-ticket-server:v1.1.0 \
  -n mcp-ticket-system

# Monitor rollout
kubectl rollout status deployment/mcp-ticket-deployment -n mcp-ticket-system

# Verify health
kubectl exec deployment/mcp-ticket-deployment -n mcp-ticket-system -- \
  python system_health_check.py
```

#### Dependency Updates

**Python Packages:**
```bash
# Update requirements.txt
pip-compile requirements.in

# Rebuild image
docker-compose build --no-cache

# Test locally
docker-compose up -d
python scripts/test_all.py
```

**Base Image Updates:**
```dockerfile
# Update Dockerfile
FROM python:3.13-slim  # Update version

# Rebuild
docker build -t mcp-ticket-server:latest .
```

#### Database Updates

**Memgraph Schema Migration:**
```python
# Create migration script
# migrations/001_add_new_node_type.py

from data_access.memgraphClient import MemgraphClient

def migrate(client):
    # Add new node type
    client.execute("""
        CREATE (:NewNodeType {
            id: 'test',
            property: 'value'
        })
    """)

# Apply migration
python scripts/run_migrations.py
```

**Milvus Collection Update:**
```python
# Milvus collections are immutable
# To update schema:
# 1. Create new collection with updated schema
# 2. Migrate data from old to new
# 3. Drop old collection
# 4. Rename new collection

from pymilvus import connections, Collection, utility

connections.connect(host='localhost', port='19530')

# Create new collection
# ... create_collection() ...

# Migrate data
old_coll = Collection("fault_descriptions")
new_coll = Collection("fault_descriptions_v2")
# ... migration logic ...

# Swap collections
utility.drop_collection("fault_descriptions")
utility.rename_collection("fault_descriptions_v2", "fault_descriptions")
```

### Monitoring Best Practices

**Set up alerts for:**
- Pod restarts > 5 in 10 minutes
- CPU usage > 80%
- Memory usage > 90%
- Disk usage > 85%
- Error rate > 5%
- Response time > 2 seconds

**Recommended tools:**
- Prometheus + Grafana
- ELK/EFK stack
- Datadog
- New Relic
- Sentry (error tracking)

### Performance Tuning

**Database Optimization:**
```bash
# Memgraph memory limit
docker-compose.yml:
  memgraph:
    command: --memory-limit=4096

# Milvus cache size
environment:
  - MILVUS_CACHE_SIZE=2GB
```

**Application Tuning:**
```env
# Worker processes
WORKERS=4

# Connection pools
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20

# NATS consumer
NATS_MAX_MESSAGES=100
NATS_BATCH_SIZE=10
```

---

## Production Checklist

### Pre-Deployment

- [ ] Update image registry in K8s manifests
- [ ] Configure TLS certificates for ingress
- [ ] Set up monitoring and alerting (Prometheus/Grafana)
- [ ] Configure backup procedures (automated)
- [ ] Test disaster recovery procedures
- [ ] Security scan containers (Trivy, Snyk)
- [ ] Load testing completed (Artillery, k6)
- [ ] Review and update resource limits
- [ ] Configure log aggregation (ELK/EFK)
- [ ] Set up secret management (Vault, etc.)
- [ ] Network policies configured
- [ ] RBAC policies reviewed
- [ ] Documentation updated
- [ ] Runbooks created for common issues

### Deployment

- [ ] Create namespace
- [ ] Apply ConfigMaps and Secrets
- [ ] Create PVCs
- [ ] Deploy supporting services (NATS, Memgraph, Milvus)
- [ ] Wait for services to be ready
- [ ] Deploy application
- [ ] Verify pods are running
- [ ] Check health endpoints
- [ ] Test external access via ingress
- [ ] Verify auto-scaling configuration
- [ ] Check resource usage

### Post-Deployment

- [ ] Verify all pods are running
- [ ] Test external access
- [ ] Validate data persistence (restart pods)
- [ ] Check log aggregation
- [ ] Monitor resource usage (24 hours)
- [ ] Test auto-scaling (load test)
- [ ] Verify backup procedures
- [ ] Test rollback procedures
- [ ] Update documentation with actual config
- [ ] Train operations team
- [ ] Set up on-call rotation
- [ ] Schedule post-deployment review

### Security Hardening

- [ ] Enable Pod Security Standards
- [ ] Configure Network Policies
- [ ] Enable audit logging
- [ ] Set up vulnerability scanning
- [ ] Configure RBAC with least privilege
- [ ] Enable mTLS between services
- [ ] Implement secret rotation
- [ ] Set up WAF for ingress
- [ ] Enable container image signing
- [ ] Configure security contexts

---

## CI/CD Integration

### GitHub Actions

```yaml
name: Deploy MCP Ticket System
on:
  push:
    branches: [main]
    tags:
      - 'v*'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v2

      - name: Login to Container Registry
        uses: docker/login-action@v2
        with:
          registry: ${{ secrets.REGISTRY_URL }}
          username: ${{ secrets.REGISTRY_USERNAME }}
          password: ${{ secrets.REGISTRY_PASSWORD }}

      - name: Extract metadata
        id: meta
        uses: docker/metadata-action@v4
        with:
          images: ${{ secrets.REGISTRY_URL }}/mcp-ticket-server
          tags: |
            type=semver,pattern={{version}}
            type=semver,pattern={{major}}.{{minor}}
            type=sha

      - name: Build and push
        uses: docker/build-push-action@v4
        with:
          context: ./server
          push: true
          tags: ${{ steps.meta.outputs.tags }}
          cache-from: type=registry,ref=${{ secrets.REGISTRY_URL }}/mcp-ticket-server:buildcache
          cache-to: type=registry,ref=${{ secrets.REGISTRY_URL }}/mcp-ticket-server:buildcache,mode=max

      - name: Configure kubectl
        uses: azure/k8s-set-context@v3
        with:
          kubeconfig: ${{ secrets.KUBE_CONFIG }}

      - name: Deploy to Kubernetes
        run: |
          kubectl set image deployment/mcp-ticket-deployment \
            mcp-ticket-server=${{ secrets.REGISTRY_URL }}/mcp-ticket-server:${{ steps.meta.outputs.version }} \
            -n mcp-ticket-system
          kubectl rollout status deployment/mcp-ticket-deployment -n mcp-ticket-system

      - name: Verify deployment
        run: |
          kubectl exec deployment/mcp-ticket-deployment -n mcp-ticket-system -- \
            python system_health_check.py
```

### GitLab CI

```yaml
stages:
  - build
  - test
  - deploy

variables:
  DOCKER_IMAGE: $CI_REGISTRY_IMAGE/mcp-ticket-server
  DOCKER_TAG: $CI_COMMIT_SHA

build:
  stage: build
  image: docker:latest
  services:
    - docker:dind
  script:
    - docker login -u $CI_REGISTRY_USER -p $CI_REGISTRY_PASSWORD $CI_REGISTRY
    - docker build -t $DOCKER_IMAGE:$DOCKER_TAG ./server
    - docker tag $DOCKER_IMAGE:$DOCKER_TAG $DOCKER_IMAGE:latest
    - docker push $DOCKER_IMAGE:$DOCKER_TAG
    - docker push $DOCKER_IMAGE:latest
  only:
    - main
    - tags

test:
  stage: test
  image: $DOCKER_IMAGE:$DOCKER_TAG
  script:
    - python -m pytest tests/
  only:
    - main
    - tags

deploy-production:
  stage: deploy
  image: bitnami/kubectl:latest
  script:
    - kubectl config use-context production
    - kubectl set image deployment/mcp-ticket-deployment
        mcp-ticket-server=$DOCKER_IMAGE:$DOCKER_TAG
        -n mcp-ticket-system
    - kubectl rollout status deployment/mcp-ticket-deployment -n mcp-ticket-system
  only:
    - tags
  when: manual
```

---

## Additional Resources

### Documentation

- **System Architecture:** `/docs/README_SYSTEM_STATUS.md`
- **Docker & Kubernetes:** `/docs/guides/DOCKER_K8S_COMPLETE.md`
- **Milvus Setup:** `/docs/phase3_milvus_setup.md`
- **API Documentation:** Auto-generated FastMCP docs at `/docs`

### Scripts

- **Deployment:** `/scripts/build-and-deploy.sh`
- **Verification:** `/scripts/verify-deployment.sh`
- **Health Check:** `/system_health_check.py`
- **Interactive Testing:** `/scripts/interactive_test.py`

### Support

For issues and questions:
1. Check troubleshooting section above
2. Review system logs
3. Run health check script
4. Consult system status documentation
5. Check GitHub issues (if applicable)

---

**Document Version:** 1.0
**Last Updated:** 2025-10-22
**System Status:** Operational (94.4% Health Score)
