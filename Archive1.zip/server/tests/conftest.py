"""
Pytest configuration and shared fixtures for all tests
"""
import sys
import os
import pytest
import asyncio
from pathlib import Path
from unittest.mock import Mock

# Add app to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "app"))

# Import after sys.path modification (flake8 E402 is expected here)
from configs.config import Config  # noqa: E402


@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def sample_fault_descriptions():
    """Sample fault descriptions for testing"""
    return [
        {
            "fault_description_id": "TEST001",
            "ticket_id": "TEST001",
            "fault_description": "Fiber cable cut at Main Street. Service down for Internet. Estimated repair time: 4 hours.",
            "fault_occured_date": "2025-10-20T10:00:00"
        },
        {
            "fault_description_id": "TEST002",
            "ticket_id": "TEST002",
            "fault_description": "BGP session down between RTR-01 and RTR-02. Routes withdrawn: 150. Investigating peering issues.",
            "fault_occured_date": "2025-10-20T11:00:00"
        },
        {
            "fault_description_id": "TEST003",
            "ticket_id": "TEST003",
            "fault_description": "High latency detected on circuit CKT5678. Current latency: 250ms (normal: <50ms). Customer reports slow application performance.",
            "fault_occured_date": "2025-10-20T12:00:00"
        }
    ]


@pytest.fixture
def sample_fault_description_summary(sample_fault_descriptions):
    """Sample FaultDescriptionSummary message for testing"""
    return {
        "fault_description_summary_id": "TEST_CLIENT_part_1_of_1",
        "client_id": "TEST_CLIENT",
        "part_number": 1,
        "total_parts": 1,
        "fault_descriptions": sample_fault_descriptions
    }


@pytest.fixture(scope="session", autouse=True)
def set_test_env_vars():
    """
    Set required environment variables for all tests.
    This runs once per test session before any tests.

    These env vars are required by Config() for integration tests.
    Without these, Config() will raise ValueError.
    """
    # Set all required environment variables that have no defaults
    os.environ.setdefault("MEMGRAPH_MAX_CONCURRENT", "10")
    os.environ.setdefault("MILVUS_MAX_CONCURRENT", "10")

    yield

    # Cleanup if needed (optional)
    # We leave env vars in place since tests may run in parallel


@pytest.fixture
def mock_config():
    """
    Create a complete mock Config object with ALL required attributes.

    Use this in unit tests instead of creating incomplete mocks.
    This prevents AttributeError when code accesses config attributes.

    Example:
        def test_something(mock_config):
            service = EmbeddingService(mock_config)
            # mock_config has all required attributes
    """
    config = Mock(spec=Config)

    # Ollama Embedding Configuration
    config.ollama_embedding_base_url = "http://localhost:11434"
    config.ollama_embedding_model = "telecom-nomic-embed:latest"
    config.ollama_embedding_timeout = 90
    config.ollama_max_concurrent = 20

    # Milvus Configuration
    config.milvus_host = "localhost"
    config.milvus_port = 19530
    config.milvus_collection_name = "test_fault_descriptions"
    config.milvus_index_type = "IVF_FLAT"
    config.milvus_metric_type = "COSINE"
    config.milvus_nlist = 1024
    config.milvus_nprobe = 32
    config.milvus_max_concurrent = 10
    config.milvus_user = ""
    config.milvus_password = ""

    # Memgraph Configuration
    config.memgraph_max_concurrent = 10
    config.memgraph_uri = "bolt://localhost:7687"
    config.memgraph_user = ""
    config.memgraph_password = ""
    config.memgraph_database = "memgraph"

    # NATS Configuration
    config.nats_url = "nats://localhost:4222"
    config.jetstream_stream_name = "TEST_STREAM"
    config.ticket_publish_subject = "tickets.test"
    config.ticket_subscribe_subject = "tickets.test"

    # LLM Configuration
    config.llm_temperature = 0.2

    # Ollama Extraction Configuration (WS-C)
    config.ollama_extraction_base_url = "http://localhost:11434"
    config.ollama_extraction_model = "llama3.3-instruct:70b"
    config.ollama_extraction_timeout = 120

    # Milvus Notes Collection (WS-C)
    config.milvus_notes_collection = "test_ticket_notes"

    # Corrections Directory (WS-C)
    config.corrections_dir = "/tmp/test_corrections"

    # Test mode
    config.test_mode = True

    return config
