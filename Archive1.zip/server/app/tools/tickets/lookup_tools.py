"""
Direct lookup tools for ticket system
Provides fast, focused retrieval of specific tickets and related data
"""
import asyncio
import logging
import polars as pl
from typing import Any, Optional
from fastmcp.exceptions import ToolError
from utils.utilities import Helpers


async def get_ticket_details(ticket_id: str, services: dict) -> Any:
    """
    Get complete details for a specific ticket including all relationships.

    Returns the full ticket graph: Fault, Service, Outage_Info, Vendors,
    Surveys, Maintenance windows, Tasks, Configuration Items, and related tickets.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_ticket_details with ticket_id: '{ticket_id}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        logging.info(f"DEBUG: Memgraph client verified for ticket {ticket_id}")

        # Cypher query to get complete ticket graph
        # Returns whole nodes (all properties) plus ensures key fields are visible
        cypher_query = """
            MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket {ticket_id: $ticket_id})
            OPTIONAL MATCH (t)-[:HAS_FAULT]->(f:Fault)
            OPTIONAL MATCH (t)-[:HAS_SERVICE]->(s:Service)
            OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
            OPTIONAL MATCH (t)-[:CHILD_OF]->(master:Ticket)
            OPTIONAL MATCH (t)-[:LINKED_TO]->(linked:Ticket)
            OPTIONAL MATCH (t)-[:INVOLVES_VENDOR]->(vendor:VendorInfo)
            OPTIONAL MATCH (t)-[:HAS_SURVEY]->(survey:SurveyInfo)
            OPTIONAL MATCH (t)-[:DURING_MAINTENANCE]->(mw:MaintenanceWindow)
            OPTIONAL MATCH (t)-[:HAS_TASK]->(task:Task)
            OPTIONAL MATCH (t)-[:RELATES_TO_CI]->(ci:ConfigurationItem)
            RETURN
                // Return whole nodes (includes all properties)
                c, t, f, s, o, master, linked, survey, mw,
                collect(distinct vendor) as vendors,
                collect(distinct task) as tasks,
                collect(distinct ci) as config_items,
                // Also return key fields explicitly (ensures they show even if null)
                t.ticket_category as ticket_category,
                t.ticket_queue as ticket_queue,
                t.close_code as close_code,
                t.resolved_at as resolved_at,
                t.assigned_to as assigned_to,
                t.closed_by as closed_by,
                t.ticket_escalation_level as ticket_escalation_level,
                s.category as service_category,
                s.subcategory as service_subcategory,
                o.resolution as resolution,
                o.customer_resolution as customer_resolution,
                o.rfo as outage_rfo
        """

        logging.info(f"DEBUG: Executing Memgraph query for ticket {ticket_id}")
        result = await memgraph_client.execute( cypher_query, {"ticket_id": ticket_id})
        logging.info(f"DEBUG: Query executed, converting to Polars for ticket {ticket_id}")

        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()
        logging.info(f"DEBUG: Polars conversion complete, got {len(response_data)} results for ticket {ticket_id}")

        if not response_data:
            logging.info(f"DEBUG: No data found for ticket {ticket_id}")
            return {"message": f"No ticket found with ticket_id: {ticket_id}"}

        logging.info(f"DEBUG: Serializing response for ticket {ticket_id}")
        serialized_result = Helpers.recursive_serialize(response_data[0])
        logging.info(f"DEBUG: Serialization complete for ticket {ticket_id}, returning result")

        return serialized_result

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_ticket_details: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve ticket details: {e}")


async def get_client_tickets(client_name: str, services: dict, limit: Optional[int] = None) -> Any:
    """
    Get all tickets for a specific client.

    Returns list of tickets with basic information (status, category, dates).
    Optionally limit the number of results.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_client_tickets for client: '{client_name}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        # Build query with optional limit
        cypher_query = """
            MATCH (c:Client {client_name: $client_name})-[:HAS_TICKET]->(t:Ticket)
            OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
            RETURN t.ticket_id as ticket_id,
                   t.ticket_status as status,
                   t.ticket_category as category,
                   t.priority as priority,
                   t.created_on as created_on,
                   t.closed_on as closed_on,
                   o.rfo as rfo,
                   o.mttr as mttr
            ORDER BY t.created_on DESC
        """

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute( cypher_query, {"client_name": client_name})
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No tickets found for client: {client_name}"}

        return Helpers.recursive_serialize({
            "client_name": client_name,
            "ticket_count": len(response_data),
            "tickets": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_client_tickets: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve client tickets: {e}")


async def get_ticket_timeline(ticket_id: str, services: dict) -> Any:
    """
    Get the lifecycle timeline for a specific ticket.

    Returns all important dates: created, assigned, resolved, closed, etc.
    Includes task timeline events (task created, closed dates).
    Provides a chronological view of ticket progression.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_ticket_timeline for ticket: '{ticket_id}'")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (t:Ticket {ticket_id: $ticket_id})
            OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
            OPTIONAL MATCH (t)-[:HAS_TASK]->(task:Task)
            RETURN t.ticket_id as ticket_id,
                   t.ticket_type as ticket_type,
                   t.ticket_status as ticket_status,
                   t.created_on as created_on,
                   t.created_by as created_by,
                   t.first_assigned_on as first_assigned_on,
                   t.first_assigned_to as first_assigned_to,
                   t.first_resolved_on as first_resolved_on,
                   t.oldest_resolved_date as oldest_resolved_date,
                   t.closed_on as closed_on,
                   t.closed_by as closed_by,
                   t.updated_on as last_updated_on,
                   o.first_email_from_customer_on as first_customer_email,
                   o.first_customer_note_on as first_customer_note,
                   o.first_supplier_dispatch_event_on as first_supplier_dispatch,
                   o.first_tech_dispatch_event_on as first_tech_dispatch,
                   o.mttr as mttr,
                   collect(distinct {
                       task_number: task.task_number,
                       task_type: task.task_type,
                       task_state: task.task_state,
                       short_description: task.short_description,
                       assigned_to: task.assigned_to,
                       assignment_group: task.assignment_group,
                       created_on: task.created_on,
                       closed_on: task.closed_on,
                       vendor_name: task.vendor_name,
                       third_party_name: task.third_party_name
                   }) as tasks
        """

        result = await memgraph_client.execute( cypher_query, {"ticket_id": ticket_id})
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": f"No ticket found with ticket_id: {ticket_id}"}

        # Filter out empty task entries (from OPTIONAL MATCH with no tasks)
        timeline_data = response_data[0]
        if timeline_data.get("tasks"):
            timeline_data["tasks"] = [
                t for t in timeline_data["tasks"]
                if t.get("task_number") is not None
            ]
            timeline_data["task_count"] = len(timeline_data["tasks"])

        return Helpers.recursive_serialize(timeline_data)

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_ticket_timeline: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve ticket timeline: {e}")


async def get_sample_tickets(services: dict, limit: Optional[int] = 5) -> Any:
    """
    Get a sample of tickets from the database.

    Fast retrieval of N tickets with basic information. Useful for exploring
    the database or getting examples. Does not require any filters.
    """
    try:
        logging.info(f"FastMCP Tool Call: get_sample_tickets with limit: {limit}")

        memgraph_client = services["memgraph_client"]
        if not memgraph_client:
            raise ToolError("Memgraph client not initialized.")

        cypher_query = """
            MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket)
            OPTIONAL MATCH (t)-[:HAS_OUTAGE]->(o:Outage_Info)
            RETURN c.client_name as client_name,
                   t.ticket_id as ticket_id,
                   t.ticket_type as ticket_type,
                   t.ticket_status as status,
                   t.ticket_category as category,
                   t.priority as priority,
                   t.created_on as created_on,
                   t.closed_on as closed_on,
                   o.rfo as rfo,
                   o.mttr as mttr
            ORDER BY t.created_on DESC
        """

        if limit:
            cypher_query += f" LIMIT {limit}"

        result = await memgraph_client.execute(cypher_query, {})
        records = [record.data() for record in result]
        df = pl.DataFrame(records) if records else pl.DataFrame()
        response_data = df.to_dicts()

        if not response_data:
            return {"message": "No tickets found in database"}

        return Helpers.recursive_serialize({
            "ticket_count": len(response_data),
            "tickets": response_data
        })

    except ToolError:
        raise
    except Exception as e:
        logging.error(f"Error in get_sample_tickets: {e}", exc_info=True)
        raise ToolError(f"Failed to retrieve sample tickets: {e}")
