#!/usr/bin/env python3
"""
Publish generated dummy tickets to NATS for testing batch operations
"""
import asyncio
import json
import gzip
import base64
import nats

async def publish_tickets():
    """Publish dummy tickets from file to NATS"""
    # Load the generated tickets (1000 tickets across 200 clients)
    with open('test_data/dummy_tickets_1000.json', 'r') as f:
        tickets = json.load(f)

    # Connect to NATS
    nc = await nats.connect("nats://localhost:4222")
    js = nc.jetstream()

    print(f"✅ Connected to NATS")
    print(f"📤 Publishing {len(tickets)} client messages (1000 tickets total)...")

    for i, ticket in enumerate(tickets, 1):
        # Compress the ticket using gzip+base64 format
        ticket_json = json.dumps(ticket).encode('utf-8')
        compressed = gzip.compress(ticket_json)
        encoded = base64.b64encode(compressed).decode('utf-8')

        # Wrap in expected format
        message = json.dumps({
            "compressed": True,
            "encoding": "gzip+base64",
            "data": encoded
        }).encode('utf-8')

        # Publish to tickets.created subject
        await js.publish("tickets.created", message)

        # Progress reporting (every 20 messages)
        if i % 20 == 0 or i == len(tickets):
            num_ops = len(ticket['operational_status'])
            print(f"   Published {i}/{len(tickets)} clients (Client: {ticket['client_info']['client_name']}, Tickets: {num_ops})")

    print(f"✅ Published all {len(tickets)} tickets")

    await nc.close()

if __name__ == "__main__":
    asyncio.run(publish_tickets())
