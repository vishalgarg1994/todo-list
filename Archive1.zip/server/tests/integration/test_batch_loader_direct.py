#!/usr/bin/env python3
"""
Direct Batch Loader Test - Tests batch_graph_loader.py directly without NATS
"""

import sys
import os
import json
import asyncio
from pathlib import Path

# Add app directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'app'))

from services.message_handler import TicketMessageHandler  # noqa: E402
from data_access.memgraphClient import MemgraphClient  # noqa: E402
from configs.config import Config  # noqa: E402
from utils.utilities import Helpers  # noqa: E402


class DirectBatchLoaderTest:
    """Test batch graph loader directly"""

    def __init__(self):
        self.memgraph_client = None
        self.message_handler = None
        self.config = None

    async def setup(self):
        """Set up Memgraph connection"""
        print("Setting up test environment...")

        # Initialize config
        self.config = Config()
        memgraph_uri = os.environ.get("MEMGRAPH_URI", "bolt://localhost:7687")

        cyphers_yaml_dict = Helpers.load_cypher_configs(self.config.schema_desc_path)
        self.memgraph_client = MemgraphClient(
            uri=memgraph_uri,
            user=self.config.memgraph_user,
            password=self.config.memgraph_password,
            database=self.config.memgraph_database,
            cyphers_dict=cyphers_yaml_dict
        )
        await self.memgraph_client.connect()
        print(f"Connected to Memgraph: {memgraph_uri}")

        # Initialize message handler
        self.message_handler = TicketMessageHandler(self.memgraph_client, self.config)
        print("Message handler initialized")

    async def clear_database(self):
        """Clear all data"""
        print("Clearing database...")
        await self.memgraph_client.execute("MATCH (n) DETACH DELETE n")
        print("Database cleared")

    async def load_and_process_test_data(self):
        """Load and process TSM test data"""
        print("\n--- LOADING TSM TEST DATA ---")

        # Load test data
        test_file = Path(__file__).parent.parent / "data" / "tsm_ticket_payload.json"
        with open(test_file, 'r') as f:
            test_data = json.load(f)

        client_name = test_data.get("client_info", {}).get("client_name", "Unknown")
        ticket_count = len(test_data.get("operational_status", []))
        print(f"Processing: {client_name} ({ticket_count} tickets)")

        # Process through message handler (which uses batch_graph_loader)
        success = await self.message_handler.process_ticket(test_data)

        if success:
            print("SUCCESS: Test data processed")
        else:
            print("FAILED: Test data processing failed")

        return success

    async def validate_results(self):
        """Validate the graph was created correctly"""
        print("\n--- VALIDATION ---")

        # Node counts
        records = await self.memgraph_client.execute(
            "MATCH (n) RETURN labels(n) AS label, count(n) AS cnt ORDER BY cnt DESC"
        )
        node_counts = [dict(r) for r in records]

        print("\nNode counts:")
        total_nodes = 0
        for row in node_counts:
            print(f"  {row['label']}: {row['cnt']}")
            total_nodes += row['cnt']
        print(f"  TOTAL: {total_nodes}")

        # Relationship counts
        records = await self.memgraph_client.execute(
            "MATCH ()-[r]->() RETURN type(r) AS rel, count(r) AS cnt ORDER BY cnt DESC"
        )
        rel_counts = [dict(r) for r in records]

        print("\nRelationship counts:")
        total_rels = 0
        for row in rel_counts:
            print(f"  {row['rel']}: {row['cnt']}")
            total_rels += row['cnt']
        print(f"  TOTAL: {total_rels}")

        # Ticket types
        records = await self.memgraph_client.execute(
            "MATCH (t:Ticket) RETURN t.ticket_type AS type, t.tkt_id AS id, t.ticket_id AS ticket_id"
        )
        tickets = [dict(r) for r in records]

        if tickets:
            print("\nTickets created:")
            for t in tickets:
                print(f"  {t['ticket_id']} (type: {t['type']})")

        # FK relationships
        print("\nFK relationships:")
        for rel_type in ['RAISED_BY_INCIDENT', 'BELONGS_TO_CASE', 'RELATED_TO_PROBLEM', 'CHILD_OF', 'HAS_TASK']:
            records = await self.memgraph_client.execute(
                f"MATCH (a)-[r:{rel_type}]->(b) RETURN a.tkt_id AS from_id, b.tkt_id AS to_id, b.task_number AS task_num LIMIT 5"
            )
            data = [dict(r) for r in records]
            if data:
                print(f"  {rel_type}:")
                for d in data:
                    if d.get('task_num'):
                        print(f"    {d['from_id']} -> Task {d['task_num']}")
                    else:
                        print(f"    {d['from_id']} -> {d['to_id']}")

        return total_nodes > 0 and total_rels > 0

    async def cleanup(self):
        """Clean up connections"""
        print("\nCleaning up...")
        if self.memgraph_client:
            await self.memgraph_client.shutdown()
        print("Cleanup complete")

    async def run(self):
        """Run the test"""
        print("=" * 60)
        print("DIRECT BATCH LOADER TEST")
        print("=" * 60)

        try:
            await self.setup()
            await self.clear_database()

            success = await self.load_and_process_test_data()
            if not success:
                print("\nTEST FAILED: Data processing failed")
                return False

            valid = await self.validate_results()

            print("\n" + "=" * 60)
            if valid:
                print("TEST PASSED: Batch loader working correctly")
            else:
                print("TEST FAILED: Validation failed")
            print("=" * 60)

            return valid

        except Exception as e:
            print(f"\nTEST FAILED: {e}")
            import traceback
            traceback.print_exc()
            return False

        finally:
            await self.cleanup()


def main():
    # Set required env vars if not present
    os.environ.setdefault("MEMGRAPH_MAX_CONCURRENT", "10")
    os.environ.setdefault("MILVUS_MAX_CONCURRENT", "10")

    test = DirectBatchLoaderTest()
    success = asyncio.run(test.run())
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
