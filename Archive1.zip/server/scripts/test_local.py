#!/usr/bin/env python3
"""
Local test script for mcp_ticket - bypasses NATS, processes JSON directly.
Tests the schema changes with dummy data.

Usage:
    python3 scripts/test_local.py
"""

import asyncio
import json
import logging
import sys
from pathlib import Path

# Add app to path
sys.path.insert(0, str(Path(__file__).parent.parent / "app"))

from services.message_handler import TicketMessageHandler
from data_access.memgraphClient import MemgraphClient
from configs.config import Config

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def main():
    """Load dummy data and process tickets"""

    logger.info("🚀 Starting local test with dummy data")

    # Initialize config and Memgraph client
    config = Config()
    memgraph_client = MemgraphClient(
        uri=config.memgraph_uri,
        user=config.memgraph_user,
        password=config.memgraph_password,
        database=config.memgraph_database
    )

    try:
        # Connect to Memgraph
        logger.info("📡 Connecting to Memgraph...")
        memgraph_client.connect()

        # Clear database (optional - comment out if you want to keep existing data)
        # Check if --clear flag is passed, otherwise default to 'y' for automated runs
        import sys
        if '--no-clear' in sys.argv:
            logger.info("ℹ️  Keeping existing database data")
        else:
            logger.info("🧹 Clearing database...")
            memgraph_client.clearDatabase()

        # Load dummy tickets
        test_data_file = Path(__file__).parent.parent / "test_data" / "dummy_tickets.json"
        logger.info(f"📂 Loading test data from: {test_data_file}")

        with open(test_data_file, 'r') as f:
            ticket_summaries = json.load(f)

        logger.info(f"✅ Loaded {len(ticket_summaries)} tickets")

        # Initialize message handler
        handler = TicketMessageHandler(memgraph_client, config)

        # Process each ticket
        success_count = 0
        error_count = 0

        for i, ticket_summary in enumerate(ticket_summaries, 1):
            ticket_id = ticket_summary.get("operational_status", [{}])[0].get("ticket_info", {}).get("ticket_id", "Unknown")
            client_name = ticket_summary.get("client_info", {}).get("client_name", "Unknown")

            logger.info(f"\n{'='*60}")
            logger.info(f"📝 Processing ticket {i}/{len(ticket_summaries)}: {ticket_id} ({client_name})")
            logger.info(f"{'='*60}")

            try:
                # Call process_ticket directly (bypassing NATS)
                success = await handler.process_ticket(ticket_summary)

                if success:
                    success_count += 1
                    logger.info(f"✅ Ticket {ticket_id} processed successfully")
                else:
                    error_count += 1
                    logger.error(f"❌ Ticket {ticket_id} failed to process")

            except Exception as e:
                error_count += 1
                logger.error(f"❌ Error processing ticket {ticket_id}: {e}")
                import traceback
                logger.error(traceback.format_exc())

        # Final summary
        logger.info(f"\n{'='*60}")
        logger.info(f"📊 FINAL SUMMARY")
        logger.info(f"{'='*60}")
        logger.info(f"✅ Successfully processed: {success_count}/{len(ticket_summaries)}")
        logger.info(f"❌ Failed: {error_count}/{len(ticket_summaries)}")

        # Show database stats
        logger.info(f"\n📈 Database Statistics:")
        records = memgraph_client.execute(
            "MATCH (n) RETURN labels(n) AS node_label, count(n) AS node_count;"
        )
        for record in records:
            data = record.data()
            logger.info(f"   {data['node_label'][0]}: {data['node_count']}")

        logger.info(f"\n🔗 Relationship Statistics:")
        records = memgraph_client.execute(
            "MATCH ()-[r]->() RETURN type(r) AS rel_type, count(r) AS count;"
        )
        for record in records:
            data = record.data()
            logger.info(f"   {data['rel_type']}: {data['count']}")

        logger.info("\n✨ Test completed!")

    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return 1

    finally:
        # Close connection
        logger.info("\n🔌 Closing Memgraph connection...")
        memgraph_client.closeConnection()

    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
