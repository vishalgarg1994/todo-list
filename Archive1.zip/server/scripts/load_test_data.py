#!/usr/bin/env python3
"""
Load Test Data into Memgraph via NATS

Publishes dummy ticket data to NATS JetStream for the mcp_ticket server to consume.
"""

import asyncio
import json
import sys
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

async def load_via_nats():
    """Publish test data to NATS"""
    import nats
    from nats.js.api import StreamConfig

    # Load test data
    data_file = Path(__file__).parent.parent / "tests" / "data" / "dummy_tickets_1000.json"

    if not data_file.exists():
        print(f"ERROR: Test data not found: {data_file}")
        return

    print(f"Loading test data from: {data_file}")
    with open(data_file) as f:
        tickets = json.load(f)

    print(f"Loaded {len(tickets)} tickets")

    # Connect to NATS
    nc = await nats.connect("nats://localhost:4222")
    js = nc.jetstream()

    # Ensure stream exists
    try:
        await js.stream_info("EVA_TICKETING_STREAM")
        print("Stream EVA_TICKETING_STREAM exists")
    except:
        print("Creating stream EVA_TICKETING_STREAM...")
        await js.add_stream(
            name="EVA_TICKETING_STREAM",
            subjects=["tickets.*"]
        )

    # Publish tickets
    print(f"Publishing {len(tickets)} tickets to NATS...")
    for i, ticket in enumerate(tickets):
        msg = json.dumps(ticket).encode()
        await js.publish("tickets.created", msg)
        if (i + 1) % 100 == 0:
            print(f"  Published {i + 1}/{len(tickets)}")

    print(f"Done! Published {len(tickets)} tickets")
    await nc.close()


async def load_direct_to_memgraph():
    """Load test data directly into Memgraph (bypass NATS)"""
    from neo4j import GraphDatabase

    # Load test data
    data_file = Path(__file__).parent.parent / "tests" / "data" / "dummy_tickets_1000.json"

    print(f"Loading test data from: {data_file}")
    with open(data_file) as f:
        tickets = json.load(f)

    print(f"Loaded {len(tickets)} tickets")

    # Connect to Memgraph
    driver = GraphDatabase.driver("bolt://localhost:7687")

    with driver.session() as session:
        # Clear existing data
        print("Clearing existing data...")
        session.run("MATCH (n) DETACH DELETE n")

        # Load clients
        clients = {}
        for t in tickets:
            ci = t.get("client_info", {})
            cl_id = ci.get("cl_id")
            if cl_id and cl_id not in clients:
                clients[cl_id] = ci

        print(f"Loading {len(clients)} clients...")
        for cl in clients.values():
            session.run("""
                MERGE (c:Client {cl_id: $cl_id})
                SET c.client_id = $client_id,
                    c.client_name = $client_name
            """, {
                "cl_id": cl.get("cl_id"),
                "client_id": cl.get("client_id"),
                "client_name": cl.get("client_name")
            })

        # Load tickets with relationships
        print(f"Loading {len(tickets)} tickets...")
        for i, t in enumerate(tickets):
            ci = t.get("client_info", {})
            for op in t.get("operational_status", []):
                svc = op.get("service_entity", {})
                inc = op.get("incident_info", {})
                tkt = op.get("ticket_info", {})
                outage = op.get("outage_info", {})
                fault = op.get("fault_description", {})

                # Normalize status to lowercase
                ticket_status = (tkt.get("ticket_status") or "").lower()
                ticket_type = (tkt.get("ticket_category") or "incident").lower()
                if ticket_type == "incident":
                    ticket_type = "incident"

                # Create ticket
                session.run("""
                    MATCH (c:Client {cl_id: $cl_id})
                    MERGE (t:Ticket {tkt_id: $tkt_id})
                    SET t.ticket_id = $ticket_id,
                        t.ticket_type = $ticket_type,
                        t.ticket_status = $ticket_status,
                        t.ticket_category = $ticket_category,
                        t.ticket_queue = $ticket_queue,
                        t.priority = $priority,
                        t.escalation_level = $escalation_level,
                        t.created_on = $created_on,
                        t.closed_on = $closed_on,
                        t.close_code = $close_code,
                        t.responsible_party = $responsible_party
                    MERGE (c)-[:HAS_TICKET]->(t)
                """, {
                    "cl_id": ci.get("cl_id"),
                    "tkt_id": tkt.get("tkt_id"),
                    "ticket_id": tkt.get("ticket_id"),
                    "ticket_type": ticket_type,
                    "ticket_status": ticket_status,
                    "ticket_category": tkt.get("ticket_category"),
                    "ticket_queue": tkt.get("ticket_queue"),
                    "priority": tkt.get("priority"),
                    "escalation_level": tkt.get("ticket_escalation_level"),
                    "created_on": tkt.get("created_on"),
                    "closed_on": tkt.get("closed_on"),
                    "close_code": tkt.get("close_code"),
                    "responsible_party": tkt.get("responsible_party")
                })

                # Create service
                if svc.get("svc_id"):
                    session.run("""
                        MATCH (t:Ticket {tkt_id: $tkt_id})
                        MERGE (s:Service {svc_id: $svc_id})
                        SET s.subcategory = $subcategory,
                            s.technology = $technology
                        MERGE (t)-[:HAS_SERVICE]->(s)
                    """, {
                        "tkt_id": tkt.get("tkt_id"),
                        "svc_id": svc.get("svc_id"),
                        "subcategory": svc.get("subcategory"),
                        "technology": svc.get("technology")
                    })

                    # Create CI from circuit
                    circuit_id = svc.get("related_circuit_id")
                    if circuit_id:
                        session.run("""
                            MATCH (t:Ticket {tkt_id: $tkt_id})
                            MERGE (ci:ConfigurationItem {ci_sys_id: $ci_sys_id})
                            SET ci.ci_name = $ci_name
                            MERGE (t)-[:AFFECTS_CI]->(ci)
                        """, {
                            "tkt_id": tkt.get("tkt_id"),
                            "ci_sys_id": f"ci_{circuit_id}",
                            "ci_name": f"CIRCUIT-{circuit_id}"
                        })

                # Create outage info
                if outage:
                    session.run("""
                        MATCH (t:Ticket {tkt_id: $tkt_id})
                        MERGE (o:Outage_Info {oi_id: $oi_id})
                        SET o.rfo = $rfo,
                            o.resolution = $resolution,
                            o.outage_duration = $outage_duration,
                            o.mttr = $mttr
                        MERGE (t)-[:HAS_OUTAGE]->(o)
                    """, {
                        "tkt_id": tkt.get("tkt_id"),
                        "oi_id": f"oi_{tkt.get('tkt_id')}",
                        "rfo": outage.get("rfo"),
                        "resolution": outage.get("resolution"),
                        "outage_duration": outage.get("outage_duration"),
                        "mttr": outage.get("mttr")
                    })

                # Create fault
                if fault or inc.get("short_description"):
                    session.run("""
                        MATCH (t:Ticket {tkt_id: $tkt_id})
                        MERGE (f:Fault {fault_id: $fault_id})
                        SET f.short_description = $short_description
                        MERGE (t)-[:HAS_FAULT]->(f)
                    """, {
                        "tkt_id": tkt.get("tkt_id"),
                        "fault_id": inc.get("fault_description_ref") or f"f_{tkt.get('tkt_id')}",
                        "short_description": inc.get("short_description") or fault.get("description", "")
                    })

            if (i + 1) % 100 == 0:
                print(f"  Loaded {i + 1}/{len(tickets)}")

        # Verify
        result = session.run("MATCH (t:Ticket) RETURN count(t) as cnt")
        count = result.single()["cnt"]
        print(f"\nDone! Loaded {count} tickets into Memgraph")

        # Show summary
        result = session.run("""
            MATCH (t:Ticket)
            RETURN t.ticket_type as type, t.ticket_status as status, count(*) as cnt
            ORDER BY cnt DESC LIMIT 10
        """)
        print("\nTicket distribution:")
        for r in result:
            print(f"  {r['type']} / {r['status']}: {r['cnt']}")

    driver.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--method", choices=["nats", "direct"], default="direct",
                       help="Load method: nats (publish to NATS) or direct (load to Memgraph)")
    args = parser.parse_args()

    if args.method == "nats":
        asyncio.run(load_via_nats())
    else:
        asyncio.run(load_direct_to_memgraph())
