import pytest
from unittest.mock import MagicMock, patch
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from utils.retry_handler import (
    RetryHandler,
    RetryError,
    retry_with_backoff,
    DATABASE_RETRY,
    NATS_RETRY,
    HTTP_RETRY,
)


class TestRetryHandler:
    @pytest.fixture
    def retry_handler(self):
        return RetryHandler(
            max_attempts=3,
            base_delay=0.1,  # Short delay for testing
            max_delay=1.0,
            backoff_multiplier=2.0,
            jitter=False,  # Disable jitter for predictable testing
        )

    @pytest.mark.asyncio
    async def test_successful_async_function(self, retry_handler):
        """Test successful execution of async function"""

        async def success_func():
            return "success"

        result = await retry_handler.execute_with_retry(success_func)
        assert result == "success"

    @pytest.mark.asyncio
    async def test_successful_sync_function(self, retry_handler):
        """Test successful execution of sync function"""

        def sync_success_func():
            return "sync_success"

        result = await retry_handler.execute_with_retry(sync_success_func)
        assert result == "sync_success"

    @pytest.mark.asyncio
    async def test_function_with_args_kwargs(self, retry_handler):
        """Test function execution with arguments"""

        async def func_with_args(arg1, arg2, kwarg1=None):
            return f"{arg1}-{arg2}-{kwarg1}"

        result = await retry_handler.execute_with_retry(
            func_with_args, "a", "b", kwarg1="c"
        )
        assert result == "a-b-c"

    @pytest.mark.asyncio
    async def test_retry_on_retryable_exception(self, retry_handler):
        """Test retry behavior on retryable exceptions"""
        call_count = 0

        async def failing_then_success_func():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ConnectionError("Connection failed")
            return "success_after_retries"

        # Should succeed after 2 retries
        result = await retry_handler.execute_with_retry(
            failing_then_success_func, context="test_retry"
        )

        assert result == "success_after_retries"
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_non_retryable_exception_immediate_failure(self, retry_handler):
        """Test that non-retryable exceptions are not retried"""
        call_count = 0

        async def non_retryable_error_func():
            nonlocal call_count
            call_count += 1
            raise KeyError("Non-retryable error")

        # Configure to only retry specific exceptions
        retry_handler.retryable_exceptions = [ConnectionError]

        with pytest.raises(KeyError):
            await retry_handler.execute_with_retry(non_retryable_error_func)

        # Should only be called once (no retries)
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_all_attempts_exhausted(self, retry_handler):
        """Test RetryError when all attempts are exhausted"""
        call_count = 0

        async def always_failing_func():
            nonlocal call_count
            call_count += 1
            raise ValueError("Always fails")

        with pytest.raises(RetryError) as exc_info:
            await retry_handler.execute_with_retry(always_failing_func)

        assert call_count == 3  # max_attempts
        assert exc_info.value.attempts == 3
        assert isinstance(exc_info.value.original_exception, ValueError)
        assert "Always fails" in str(exc_info.value.original_exception)

    @pytest.mark.asyncio
    async def test_delay_calculation(self, retry_handler):
        """Test exponential backoff delay calculation"""
        # Test delay calculation without jitter
        assert retry_handler._calculate_delay(0) == 0.1  # base_delay
        assert retry_handler._calculate_delay(1) == 0.2  # base_delay * 2^1
        assert retry_handler._calculate_delay(2) == 0.4  # base_delay * 2^2

        # Test max_delay limit
        retry_handler.base_delay = 1.0
        retry_handler.max_delay = 2.0
        assert (
            retry_handler._calculate_delay(10) == 2.0
        )  # Should be capped at max_delay

    @pytest.mark.asyncio
    async def test_jitter_adds_randomness(self):
        """Test that jitter adds randomness to delays"""
        retry_handler = RetryHandler(max_attempts=3, base_delay=1.0, jitter=True)

        delays = [retry_handler._calculate_delay(1) for _ in range(10)]

        # All delays should be different due to jitter
        assert len(set(delays)) > 1
        # All delays should be around the base calculation (1.0 * 2^1 = 2.0) with ±10% jitter
        for delay in delays:
            assert 1.8 <= delay <= 2.2

    def test_is_retryable_exception(self, retry_handler):
        """Test exception retryability checking"""
        # Default behavior - all exceptions are retryable
        assert retry_handler._is_retryable_exception(ValueError())
        assert retry_handler._is_retryable_exception(ConnectionError())

        # Custom retryable exceptions
        retry_handler.retryable_exceptions = [ValueError, ConnectionError]
        assert retry_handler._is_retryable_exception(ValueError())
        assert retry_handler._is_retryable_exception(ConnectionError())
        assert not retry_handler._is_retryable_exception(KeyError())

    @pytest.mark.asyncio
    async def test_context_logging(self, retry_handler):
        """Test that context is included in logs"""

        async def failing_func():
            raise ValueError("Test error")

        with patch("utils.retry_handler.logging.getLogger") as mock_logger:
            mock_logger_instance = MagicMock()
            mock_logger.return_value = mock_logger_instance

            retry_handler.logger = mock_logger_instance

            with pytest.raises(RetryError):
                await retry_handler.execute_with_retry(
                    failing_func, context="test_context"
                )

            # Check that context was included in log calls
            debug_calls = mock_logger_instance.debug.call_args_list
            warning_calls = mock_logger_instance.warning.call_args_list

            # Should have debug calls for each attempt
            assert len(debug_calls) == 3
            for call in debug_calls:
                assert "test_context" in str(call)

            # Should have warning calls for retries
            assert (
                len(warning_calls) == 2
            )  # 2 retries (3rd attempt fails with no retry)


class TestRetryDecorator:
    @pytest.mark.asyncio
    async def test_async_decorator_success(self):
        """Test retry decorator with successful async function"""

        @retry_with_backoff(max_attempts=3, base_delay=0.1, context="test_async")
        async def success_func():
            return "decorated_success"

        result = await success_func()
        assert result == "decorated_success"

    @pytest.mark.asyncio
    async def test_sync_decorator_success(self):
        """Test retry decorator with successful sync function"""

        @retry_with_backoff(max_attempts=3, base_delay=0.1, context="test_sync")
        def sync_success_func():
            return "sync_decorated_success"

        # Sync functions decorated with retry become async
        result = await sync_success_func()
        assert result == "sync_decorated_success"

    @pytest.mark.asyncio
    async def test_decorator_with_retries(self):
        """Test decorator behavior with retries"""
        call_count = 0

        @retry_with_backoff(
            max_attempts=3,
            base_delay=0.1,
            retryable_exceptions=[ValueError],
            context="test_retries",
        )
        async def failing_then_success():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("Retry me")
            return "success_after_retries"

        result = await failing_then_success()
        assert result == "success_after_retries"
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_decorator_with_exhausted_retries(self):
        """Test decorator when all retries are exhausted"""

        @retry_with_backoff(max_attempts=2, base_delay=0.1)
        async def always_failing():
            raise ConnectionError("Always fails")

        with pytest.raises(RetryError):
            await always_failing()

    def test_decorator_preserves_function_metadata(self):
        """Test that decorator preserves original function metadata"""

        @retry_with_backoff(max_attempts=3)
        async def original_func():
            """Original docstring"""
            pass

        assert original_func.__name__ == "original_func"
        assert original_func.__doc__ == "Original docstring"


class TestPredefinedRetryConfigurations:
    def test_database_retry_config(self):
        """Test DATABASE_RETRY configuration"""
        assert DATABASE_RETRY.max_attempts == 3
        assert DATABASE_RETRY.base_delay == 2.0
        assert DATABASE_RETRY.max_delay == 30.0
        assert DATABASE_RETRY.backoff_multiplier == 2.0
        assert ConnectionError in DATABASE_RETRY.retryable_exceptions
        assert TimeoutError in DATABASE_RETRY.retryable_exceptions
        assert OSError in DATABASE_RETRY.retryable_exceptions

    def test_nats_retry_config(self):
        """Test NATS_RETRY configuration"""
        assert NATS_RETRY.max_attempts == 5
        assert NATS_RETRY.base_delay == 1.0
        assert NATS_RETRY.max_delay == 15.0
        assert NATS_RETRY.backoff_multiplier == 1.5
        assert ConnectionError in NATS_RETRY.retryable_exceptions
        assert TimeoutError in NATS_RETRY.retryable_exceptions

    def test_http_retry_config(self):
        """Test HTTP_RETRY configuration"""
        assert HTTP_RETRY.max_attempts == 3
        assert HTTP_RETRY.base_delay == 1.0
        assert HTTP_RETRY.max_delay == 10.0
        assert HTTP_RETRY.backoff_multiplier == 2.0
        assert ConnectionError in HTTP_RETRY.retryable_exceptions
        assert TimeoutError in HTTP_RETRY.retryable_exceptions

    @pytest.mark.asyncio
    async def test_predefined_retry_usage(self):
        """Test using predefined retry configurations"""
        call_count = 0

        async def db_operation():
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ConnectionError("DB connection failed")
            return "db_success"

        result = await DATABASE_RETRY.execute_with_retry(
            db_operation, context="test_db_operation"
        )

        assert result == "db_success"
        assert call_count == 2


class TestRetryError:
    def test_retry_error_creation(self):
        """Test RetryError exception creation"""
        original_error = ValueError("Original error")
        retry_error = RetryError("All retries failed", original_error, attempts=3)

        assert str(retry_error) == "All retries failed"
        assert retry_error.original_exception == original_error
        assert retry_error.attempts == 3
        assert isinstance(retry_error, Exception)
