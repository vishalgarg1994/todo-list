# Logical Architecture - Ticketing Data Processor

## Overview

The Ticketing Data Processor is a **reactive event-driven data pipeline** that follows the **Extract-Transform-Load (ETL)** pattern. It continuously monitors a PostgreSQL database for updated ticket records, transforms them into structured JSON messages, and publishes them to a NATS JetStream message bus for downstream consumption.

## High-Level Architecture

```
┌─────────────────┐    ┌─────────────────────┐    ┌─────────────────┐
│   PostgreSQL    │    │  Ticketing Data     │    │  NATS JetStream │
│   Database      │───▶│    Processor        │───▶│  Message Bus    │
│                 │    │                     │    │                 │
│ • Ticket Data   │    │ • Extract           │    │ • Reliable      │
│ • Time-based    │    │ • Transform         │    │   Delivery      │
│   Updates       │    │ • Knowledge Graph   │    │ • Stream        │
│                 │    │ • Health Monitor    │    │   Persistence   │
└─────────────────┘    └─────────────────────┘    └─────────────────┘
                              ↓
                    ┌─────────────────────┐
                    │   Health Monitor    │
                    │    (Port 8080)      │
                    │                     │
                    │ • Component Checks  │
                    │ • APM Integration   │
                    │ • Kubernetes Probes │
                    │ • Prometheus Metrics│
                    └─────────────────────┘
```

## Logical Components

### 1. **Data Source Layer**
- **PostgreSQL Database**: Contains ticket information in the `eds.ticket` table
- **Time-based Filtering**: Uses `updated_on` column to identify recently modified records
- **Connection Pooling**: Maintains async connection pool for efficient database access

### 2. **Scheduler & Orchestration Layer**
- **AsyncIO Scheduler**: Coordinates periodic data processing cycles
- **Configurable Intervals**: Default 5-minute intervals for data polling
- **Graceful Shutdown**: Handles application lifecycle management

### 3. **Data Processing Pipeline**
- **Extraction Service**: Queries database for updated records using time filters
- **Transformation Service**: Converts raw database records into structured domain models
- **Knowledge Graph Engine**: Extracts User, Contact, Vendor, and Maintenance Window entities
- **Validation Service**: Uses Pydantic models for data validation and serialization
- **Compression Service**: Applies GZIP compression to messages before publishing

### 4. **Message Publishing Layer**
- **NATS JetStream Integration**: Provides reliable message delivery with persistence
- **Subject-based Routing**: Uses `tickets.created` subject for message categorization
- **Connection Management**: Maintains persistent connections with automatic reconnection
- **Message Size Validation**: Enforces 1MB message size limits

### 5. **Health Monitoring & Observability Layer**
- **Health Service**: Component-level health checks for database, NATS, scheduler, and system
- **HTTP Health Server**: RESTful health endpoints on port 8080
- **Kubernetes Probes**: Liveness and readiness probe endpoints for container orchestration
- **APM Integration**: Prometheus metrics format for monitoring platform compatibility
- **Circuit Breaker**: Resilience patterns for external dependency failures

## Data Flow Process

### 1. **Initialization Phase**
```
Application Start
      ↓
Wait for Dependencies (PostgreSQL + NATS)
      ↓
Setup JetStream Stream Configuration
      ↓
Initialize Connection Pools
      ↓
Start Health HTTP Server (Port 8080)
      ↓
Start Scheduler
```

### 2. **Processing Cycle**
```
Scheduler Trigger
      ↓
Check Persistent State (Initial vs Incremental Load)
      ↓
Query Database (Time-filtered from state)
      ↓
Transform Records → Pydantic Models
      ↓
Extract Knowledge Graph Entities
      ↓
Group by Client ID
      ↓
Serialize to JSON
      ↓
Compress Message
      ↓
Publish to NATS JetStream (with resilience)
      ↓
Update Persistent State (only on success)
```

### 3. **Data Transformation Logic**
```
Raw Database Record
      ↓
Extract Core Fields
      ↓
Create Domain Objects:
  • ClientInfo
  • ServiceEntity  
  • IncidentInfo
  • TroubleTicketInfo
  • OutageInfo
      ↓
Extract Knowledge Graph Entities:
  • User (incident managers, technicians)
  • ContactInfo (customer contacts, suppliers)
  • VendorInfo (service providers)
  • MaintenanceWindow (scheduled maintenance)
      ↓
Group by Client ID
      ↓
Generate TicketSummary with Knowledge Graph
      ↓
JSON Serialization
```

## Persistent State Management

### **State-Driven Processing Logic**
The system implements **file-based persistent state management** to prevent data gaps and ensure processing continuity across application restarts and NATS outages.

### **State File Structure**
```json
{
  "table_name": {
    "status": "initial_load_complete",
    "initial_load_completed_at": "2025-09-23T14:30:00",
    "last_processed_timestamp": "2025-09-23T14:30:00"
  }
}
```

### **Processing State Logic**
```
First Run
      ↓
Mark: initial_load_in_progress
      ↓
Load Historical Data (configurable days)
      ↓
Publish Successfully?
      ├─ YES → Mark: initial_load_complete
      └─ NO → Keep: initial_load_in_progress (retry full load next run)

Subsequent Runs
      ↓
Check Status: initial_load_complete?
      ├─ YES → Incremental from last_processed_timestamp
      └─ NO → Retry full initial load

NATS Outage During Processing
      ↓
Publishing Fails
      ↓
State NOT Updated (timestamp preserved)
      ↓
Next Run: Processes same time range (no gaps!)
```

### **Gap Prevention Strategy**
- **Conditional State Updates**: State only updated when `published_count > 0`
- **Timestamp Preservation**: Failed runs preserve previous successful timestamp
- **Automatic Recovery**: Next run automatically retries failed time ranges
- **Initial Load Robustness**: Failed initial loads restart completely

### **Docker Volume Integration**
- **State File Location**: `/app/data/processing_state.json` (configurable via `STATE_FILE_PATH`)
- **Volume Mount**: `./data:/app/data` for state persistence across container restarts
- **Fallback Location**: `/tmp/processing_state.json` if volume not mounted

## Configuration Management

### **Environment-based Configuration**
- **Database Connection**: PostgreSQL connection strings
- **NATS Configuration**: Server URLs and JetStream settings
- **Timing Parameters**: Scheduler intervals and lookup windows
- **Debug Settings**: Logging levels and operational modes

### **Configuration Hierarchy**
```
1. Environment Variables (Highest Priority)
2. .env File Configuration
3. Default Values (Fallback)
```

## Error Handling Strategy

### **Resilience Patterns**
- **NATS Event Callbacks**: Graceful handling of connection, disconnection, and error events
- **Background Task Exception Handling**: Global asyncio exception handler for NATS tasks
- **Connection Retry Logic**: Automatic reconnection for both PostgreSQL and NATS
- **Exponential Backoff**: Progressive retry delays for failed operations
- **Circuit Breaker**: Prevents cascade failures through dependency monitoring
- **Graceful Degradation**: Continues operation when non-critical components fail

### **NATS Resilience Architecture**
```
NATS Infrastructure Down
      ↓
Event Callbacks Triggered
  • error_cb: Logs warnings (non-critical)
  • disconnected_cb: Cleans stale connections
      ↓
Publishing Operations
  • Connection health check before publish
  • Skip publishing with warnings if NATS down
  • No state updates → automatic retry next run
      ↓
Background Tasks
  • Global exception handler catches NATS exceptions
  • NATS errors logged as warnings (temporary)
  • Other errors logged as errors (permanent)
      ↓
NATS Infrastructure Restored
      ↓
Reconnection Callback
  • reconnected_cb: Restores JetStream context
  • Automatic resumption of normal operations
```

### **Recovery Mechanisms**
- **Persistent State Management**: File-based state tracking with initial load detection
- **Gap Prevention**: Processing state only updated on successful message publishing
- **Initial Load Recovery**: Failed initial loads restart completely (no partial states)
- **Incremental Recovery**: Resumes from last successful timestamp after outages
- **NATS Resilience**: Graceful handling of messaging infrastructure outages
- **Connection Pool Recovery**: Automatic pool recreation on connection failures

## Scalability Considerations

### **Horizontal Scaling**
- **Stateless Design**: Application instances can be scaled independently
- **Time-based Partitioning**: Multiple instances can process different time windows
- **Message Durability**: JetStream ensures no message loss during scaling events

### **Performance Optimization**
- **Connection Pooling**: Reduces database connection overhead
- **Batch Processing**: Groups multiple tickets per client for efficiency
- **Compression**: Reduces network bandwidth usage
- **Async Operations**: Non-blocking I/O for all external dependencies

## Health Monitoring & Observability

### **Health Endpoint Architecture**
```
Health HTTP Server (Port 8080)
├── GET /health          → Comprehensive component health status
├── GET /health/live     → Kubernetes liveness probe
├── GET /health/ready    → Kubernetes readiness probe
├── GET /healthz         → Alias for liveness (Kubernetes convention)
└── GET /health/metrics  → Prometheus-compatible metrics
```

### **Component Health Checks**
- **Database Health**: Connection pool status, query response times
- **NATS Health**: JetStream connectivity, publisher acknowledgments
- **Scheduler Health**: Active job monitoring, execution success rates
- **System Health**: CPU, memory, disk utilization monitoring
- **Knowledge Graph Health**: Entity extraction performance, transformation rates

### **Health Status Aggregation Logic**
```
Overall Health Status = f(Database, NATS, Scheduler, System)

HEALTHY   = All components healthy
DEGRADED  = Non-critical components unhealthy (system continues)
UNHEALTHY = Critical components failed (database or NATS unavailable)
```

### **APM Integration Patterns**
- **Prometheus Metrics**: Native `/health/metrics` endpoint with time-series data
- **DataDog Integration**: HTTP health check monitoring with custom metrics
- **New Relic Compatibility**: Infrastructure monitoring via health endpoints
- **Elastic APM**: Structured logging with health correlation IDs

### **Logging Strategy**
- **Structured Logging**: JSON-formatted logs with correlation IDs
- **Log Levels**: Configurable verbosity (DEBUG, INFO, WARNING, ERROR)
- **Operational Metrics**: Processing times, record counts, error rates
- **Health Event Logging**: Component status changes, recovery events

### **Monitoring Data Flow**
```
Application Components
      ↓
Health Service Checks
      ↓
HTTP Health Endpoints
      ↓
APM Platform Scraping
      ↓
Dashboards & Alerts
```

## Security Considerations

### **Data Protection**
- **Connection Security**: TLS encryption for database and message bus connections
- **Credential Management**: Environment-based secret management
- **Data Sanitization**: HTML tag removal and JSON escape handling

### **Access Control**
- **Database Permissions**: Read-only access to ticket tables
- **NATS Authorization**: Subject-based publishing permissions
- **Network Segmentation**: Container-based network isolation