import importlib
import sys
from utils.utilities import Helpers

# Define tools by their import paths to avoid circular imports
TOOLS_DETAILS = {
    # Natural language query tool
    "ask_tickets_question": {
        "module": "tools.tickets.ask_questions",
        "function": "ask_tickets_question",
        "name": "ask_tickets_question",
        "description": "ask_tickets_question.txt"
    },

    # Direct lookup tools
    "get_ticket_details": {
        "module": "tools.tickets.lookup_tools",
        "function": "get_ticket_details",
        "name": "get_ticket_details",
        "description": "get_ticket_details.txt"
    },
    "get_client_tickets": {
        "module": "tools.tickets.lookup_tools",
        "function": "get_client_tickets",
        "name": "get_client_tickets",
        "description": "get_client_tickets.txt"
    },
    "get_ticket_timeline": {
        "module": "tools.tickets.lookup_tools",
        "function": "get_ticket_timeline",
        "name": "get_ticket_timeline",
        "description": "get_ticket_timeline.txt"
    },
    "get_sample_tickets": {
        "module": "tools.tickets.lookup_tools",
        "function": "get_sample_tickets",
        "name": "get_sample_tickets",
        "description": "get_sample_tickets.txt"
    },

    # Analytical tools
    "get_client_summary": {
        "module": "tools.tickets.analytical_tools",
        "function": "get_client_summary",
        "name": "get_client_summary",
        "description": "get_client_summary.txt"
    },
    "get_tickets_by_status": {
        "module": "tools.tickets.analytical_tools",
        "function": "get_tickets_by_status",
        "name": "get_tickets_by_status",
        "description": "get_tickets_by_status.txt"
    },
    "get_high_priority_tickets": {
        "module": "tools.tickets.analytical_tools",
        "function": "get_high_priority_tickets",
        "name": "get_high_priority_tickets",
        "description": "get_high_priority_tickets.txt"
    },
    "get_user_performance": {
        "module": "tools.tickets.analytical_tools",
        "function": "get_user_performance",
        "name": "get_user_performance",
        "description": "get_user_performance.txt"
    },
    "get_vendor_impact": {
        "module": "tools.tickets.analytical_tools",
        "function": "get_vendor_impact",
        "name": "get_vendor_impact",
        "description": "get_vendor_impact.txt"
    },
    "get_client_escalations": {
        "module": "tools.tickets.analytical_tools",
        "function": "get_client_escalations",
        "name": "get_client_escalations",
        "description": "get_client_escalations.txt"
    },
    "get_survey_satisfaction": {
        "module": "tools.tickets.analytical_tools",
        "function": "get_survey_satisfaction",
        "name": "get_survey_satisfaction",
        "description": "get_survey_satisfaction.txt"
    },
    "get_maintenance_impact": {
        "module": "tools.tickets.analytical_tools",
        "function": "get_maintenance_impact",
        "name": "get_maintenance_impact",
        "description": "get_maintenance_impact.txt"
    },
    # DISABLED - No contact data in PostgreSQL schema
    # "get_contact_communication_stats": {
    #     "module": "tools.tickets.analytical_tools",
    #     "function": "get_contact_communication_stats",
    #     "name": "get_contact_communication_stats",
    #     "description": "get_contact_communication_stats.txt"
    # },

    # Relationship tools
    "get_ticket_relationships": {
        "module": "tools.tickets.relationship_tools",
        "function": "get_ticket_relationships",
        "name": "get_ticket_relationships",
        "description": "get_ticket_relationships.txt"
    },
    "trace_ticket_root_cause": {
        "module": "tools.tickets.relationship_tools",
        "function": "trace_ticket_root_cause",
        "name": "trace_ticket_root_cause",
        "description": "trace_ticket_root_cause.txt"
    },
    "get_vendor_tickets": {
        "module": "tools.tickets.relationship_tools",
        "function": "get_vendor_tickets",
        "name": "get_vendor_tickets",
        "description": "get_vendor_tickets.txt"
    },
    "get_service_outages": {
        "module": "tools.tickets.relationship_tools",
        "function": "get_service_outages",
        "name": "get_service_outages",
        "description": "get_service_outages.txt"
    },

    # Search tools
    "get_tickets_by_date_range": {
        "module": "tools.tickets.search_tools",
        "function": "get_tickets_by_date_range",
        "name": "get_tickets_by_date_range",
        "description": "get_tickets_by_date_range.txt"
    },
    # DISABLED - No contact data in PostgreSQL schema
    # "get_ticket_contacts": {
    #     "module": "tools.tickets.search_tools",
    #     "function": "get_ticket_contacts",
    #     "name": "get_ticket_contacts",
    #     "description": "get_ticket_contacts.txt"
    # },

    # Vector/Semantic search tools (Phase 3 Task 5)
    "search_similar_faults": {
        "module": "tools.vector.semantic_search_tools",
        "function": "search_similar_faults",
        "name": "search_similar_faults",
        "description": "search_similar_faults.txt"
    },
    "search_similar_tickets": {
        "module": "tools.vector.semantic_search_tools",
        "function": "search_similar_tickets",
        "name": "search_similar_tickets",
        "description": "search_similar_tickets.txt"
    },
    "search_similar_resolutions": {
        "module": "tools.vector.semantic_search_tools",
        "function": "search_similar_resolutions",
        "name": "search_similar_resolutions",
        "description": "search_similar_resolutions.txt"
    },
    "search_similar_services": {
        "module": "tools.vector.semantic_search_tools",
        "function": "search_similar_services",
        "name": "search_similar_services",
        "description": "search_similar_services.txt"
    },
    "search_similar_maintenance_windows": {
        "module": "tools.vector.semantic_search_tools",
        "function": "search_similar_maintenance_windows",
        "name": "search_similar_maintenance_windows",
        "description": "search_similar_maintenance_windows.txt"
    },
    "search_similar_engineers": {
        "module": "tools.vector.semantic_search_tools",
        "function": "search_similar_engineers",
        "name": "search_similar_engineers",
        "description": "search_similar_engineers.txt"
    },
    "search_similar_vendors": {
        "module": "tools.vector.semantic_search_tools",
        "function": "search_similar_vendors",
        "name": "search_similar_vendors",
        "description": "search_similar_vendors.txt"
    },
    "search_similar_client_impacts": {
        "module": "tools.vector.semantic_search_tools",
        "function": "search_similar_client_impacts",
        "name": "search_similar_client_impacts",
        "description": "search_similar_client_impacts.txt"
    },

    # Ticket-based search tools (Nov 6, 2025)
    "find_similar_faults_by_ticket": {
        "module": "tools.vector.semantic_search_tools",
        "function": "find_similar_faults_by_ticket",
        "name": "find_similar_faults_by_ticket",
        "description": "find_similar_faults_by_ticket.txt"
    },
    "get_ticket_resolutions": {
        "module": "tools.vector.semantic_search_tools",
        "function": "get_ticket_resolutions",
        "name": "get_ticket_resolutions",
        "description": "get_ticket_resolutions.txt"
    },

    # TSM-specific tools (Jan 2026)
    "get_tickets_by_type": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_tickets_by_type",
        "name": "get_tickets_by_type",
        "description": "get_tickets_by_type.txt"
    },
    "get_cases_by_incident": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_cases_by_incident",
        "name": "get_cases_by_incident",
        "description": "get_cases_by_incident.txt"
    },
    "get_requests_by_case": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_requests_by_case",
        "name": "get_requests_by_case",
        "description": "get_requests_by_case.txt"
    },
    "get_ticket_tasks": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_ticket_tasks",
        "name": "get_ticket_tasks",
        "description": "get_ticket_tasks.txt"
    },
    "get_related_problem": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_related_problem",
        "name": "get_related_problem",
        "description": "get_related_problem.txt"
    },
    "get_incident_children": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_incident_children",
        "name": "get_incident_children",
        "description": "get_incident_children.txt"
    },
    "get_ticket_hierarchy": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_ticket_hierarchy",
        "name": "get_ticket_hierarchy",
        "description": "get_ticket_hierarchy.txt"
    },

    # CI (Configuration Item) tools (Jan 2026)
    "get_tickets_by_ci": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_tickets_by_ci",
        "name": "get_tickets_by_ci",
        "description": "get_tickets_by_ci.txt"
    },
    "get_ticket_cis": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_ticket_cis",
        "name": "get_ticket_cis",
        "description": "get_ticket_cis.txt"
    },
    "get_ci_ticket_history": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_ci_ticket_history",
        "name": "get_ci_ticket_history",
        "description": "get_ci_ticket_history.txt"
    },

    # Change tools (Jan 2026) - Infrastructure change management
    "get_change_details": {
        "module": "tools.tickets.change_tools",
        "function": "get_change_details",
        "name": "get_change_details",
        "description": "get_change_details.txt"
    },
    "get_change_tasks": {
        "module": "tools.tickets.change_tools",
        "function": "get_change_tasks",
        "name": "get_change_tasks",
        "description": "get_change_tasks.txt"
    },
    "get_tickets_affected_by_change": {
        "module": "tools.tickets.change_tools",
        "function": "get_tickets_affected_by_change",
        "name": "get_tickets_affected_by_change",
        "description": "get_tickets_affected_by_change.txt"
    },
    "get_service_affecting_changes": {
        "module": "tools.tickets.change_tools",
        "function": "get_service_affecting_changes",
        "name": "get_service_affecting_changes",
        "description": "get_service_affecting_changes.txt"
    },
    "get_changes_by_supplier": {
        "module": "tools.tickets.change_tools",
        "function": "get_changes_by_supplier",
        "name": "get_changes_by_supplier",
        "description": "get_changes_by_supplier.txt"
    },
    "get_changes_by_date_range": {
        "module": "tools.tickets.change_tools",
        "function": "get_changes_by_date_range",
        "name": "get_changes_by_date_range",
        "description": "get_changes_by_date_range.txt"
    },
    "get_change_cis": {
        "module": "tools.tickets.change_tools",
        "function": "get_change_cis",
        "name": "get_change_cis",
        "description": "get_change_cis.txt"
    },

    # Normalized field tools (Jan 2026) - Leverage unified field structure
    "get_escalated_tickets": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_escalated_tickets",
        "name": "get_escalated_tickets",
        "description": "get_escalated_tickets.txt"
    },
    "get_tickets_by_resolution": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_tickets_by_resolution",
        "name": "get_tickets_by_resolution",
        "description": "get_tickets_by_resolution.txt"
    },
    "get_change_caused_incidents": {
        "module": "tools.tickets.tsm_tools",
        "function": "get_change_caused_incidents",
        "name": "get_change_caused_incidents",
        "description": "get_change_caused_incidents.txt"
    },

    # Extraction tools - Notes analysis and discrepancy detection
    "get_extraction_discrepancies": {
        "module": "tools.tickets.extraction_tools",
        "function": "get_extraction_discrepancies",
        "name": "get_extraction_discrepancies",
        "description": "get_extraction_discrepancies.txt"
    },
    "get_discrepancy_statistics": {
        "module": "tools.tickets.extraction_tools",
        "function": "get_discrepancy_statistics",
        "name": "get_discrepancy_statistics",
        "description": "get_discrepancy_statistics.txt"
    },
    "get_tickets_by_extracted_fault_type": {
        "module": "tools.tickets.extraction_tools",
        "function": "get_tickets_by_extracted_fault_type",
        "name": "get_tickets_by_extracted_fault_type",
        "description": "get_tickets_by_extracted_fault_type.txt"
    },
    "get_ticket_audit": {
        "module": "tools.tickets.extraction_tools",
        "function": "get_ticket_audit",
        "name": "get_ticket_audit",
        "description": "get_ticket_audit.txt"
    },
}

RESOURCES_DETAILS = {
    # Add resource functions and metadata here if needed
}


class RegisterMCPComponents:
    is_registered = False

    def __init__(self, mcp_app, http_app=None, tools_details=None, resources_details=None):
        self.tools_details = tools_details or {}
        self.resources_details = resources_details or {}
        self.mcp_app = mcp_app
        self.http_app = http_app  # Store reference to the HTTP app
        self.tools_description_base_path = "tools/tools_descriptions"
        self.resources_description_base_path = "resources/resources_descriptions"

    def register(self):
        if not RegisterMCPComponents.is_registered:
            self._register_tools()
            self._register_resources()
            RegisterMCPComponents.is_registered = True

    def _register_tools(self):
        print(f"🔧 Registering {len(self.tools_details)} tools...")
        for tool_name, tool_detail in self.tools_details.items():
            print(f"  📝 Registering tool: {tool_name}")
            # Direct file import to bypass all import path issues
            import importlib.util
            import os

            # Determine base path: use /app in Docker, otherwise use current directory
            base_path = "/app" if os.path.exists("/app") else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            module_path = os.path.join(base_path, f"{tool_detail['module'].replace('.', '/')}.py")

            try:
                spec = importlib.util.spec_from_file_location(tool_detail['module'], module_path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                tool_func = getattr(module, tool_detail["function"])
            except Exception as e:
                print(f"❌ Failed to load {tool_detail['function']}: {e}")
                import traceback
                traceback.print_exc()
                raise

            def make_tool_wrapper(func):
                # Wrapper that preserves original function signature but injects 'services'
                # FastMCP doesn't support **kwargs, so we must maintain the exact signature
                import inspect
                from functools import wraps

                # Get the original function signature
                sig = inspect.signature(func)
                params = list(sig.parameters.values())

                # Remove 'services' parameter from the signature exposed to FastMCP
                params_without_services = [p for p in params if p.name != 'services']
                new_sig = sig.replace(parameters=params_without_services)

                @wraps(func)
                async def wrapper(*args, **kwargs):
                    # Inject services from http_app state
                    if not self.http_app:
                        raise RuntimeError("HTTP app not available. RegisterMCPComponents must be called after http_app() is created.")
                    services = self.http_app.state.services
                    # Call original function with services injected
                    return await func(*args, **kwargs, services=services)

                # Apply the modified signature to the wrapper so FastMCP can introspect it
                wrapper.__signature__ = new_sig
                return wrapper

            try:
                wrapped_func = make_tool_wrapper(tool_func)
                print(f"    ✓ Wrapped {tool_name}, registering with FastMCP...")
                self.mcp_app.tool(
                    name=tool_detail["name"],
                    description=Helpers.get_description_from_file(
                        file_name=tool_detail["description"], base_path=self.tools_description_base_path
                    ),
                )(wrapped_func)
                print(f"    ✅ Successfully registered {tool_name}")
            except Exception as e:
                print(f"    ❌ Failed to register {tool_name}: {e}")
                import traceback
                traceback.print_exc()

    def _register_resources(self):
        for resource_name, resource_detail in self.resources_details.items():
            # Dynamically import the function to avoid circular imports
            module = importlib.import_module(resource_detail["module"])
            resource_func = getattr(module, resource_detail["function"])

            self.mcp_app.resource(
                uri=resource_detail["uri"],
                description=Helpers.get_description_from_file(
                    file_name=resource_detail["description"], base_path=self.resources_description_base_path
                ),
            )(resource_func)