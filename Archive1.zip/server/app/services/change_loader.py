"""
Change Batch Loader
Handles tickets.change messages - infrastructure-level changes (no client_id)

Changes are published in batches and need to be:
1. Decompressed and parsed
2. Loaded into Memgraph as Change nodes with tasks and CIs
3. Linked to affected tickets via AFFECTED_BY_CHANGE relationship
"""
import asyncio
import json
import logging
import traceback
import time
from typing import Dict, Any, List, Optional

from utils.utilities import Helpers
from configs.config import Config
from data_access.memgraphClient import MemgraphClient


def normalize_enum_value(value: Optional[str]) -> Optional[str]:
    """Normalize enum values to lowercase for consistent querying."""
    if value is None:
        return None
    return str(value).lower()


class ChangeLoader:
    """Loader for infrastructure change batches from tickets.change topic"""

    def __init__(self, memgraph_client: MemgraphClient, config: Config = None):
        self.config = config or Config()
        self.memgraph_client = memgraph_client
        self.logger = logging.getLogger(__name__)
        self.max_retries = 5
        self.base_delay = 0.1  # 100ms base delay

    async def handle_change_message(self, msg):
        """
        Process incoming change batch message from JetStream.

        Change batches contain:
        - changes: List of ChangeRecord objects
        - batch_number, total_batches, total_changes
        - extraction_time
        """
        msg_start = time.time()
        try:
            # Decompress and parse
            payload = Helpers.decompress_message(msg.data)

            if not isinstance(payload, dict):
                self.logger.error(f"Unexpected payload type: {type(payload)}")
                await msg.term()
                return

            # Process change batch
            success = await self.process_change_batch(payload)

            if success:
                await msg.ack()
            else:
                self.logger.error("Change batch processing failed")
                await msg.ack()  # ACK to avoid infinite retry
                self.logger.warning("ACK'd failed message to continue processing")

        except json.JSONDecodeError:
            self.logger.error(f"Invalid JSON format in change message: {msg.data}")
            await msg.term()
        except Exception as e:
            self.logger.error(f"Unexpected error in handle_change_message: {type(e).__name__} - {str(e)}")
            self.logger.error(f"Stack Trace:\n{traceback.format_exc()}")
            await msg.ack()  # ACK to avoid infinite retry

    async def process_change_batch(self, batch: Dict[str, Any]) -> bool:
        """
        Process a ChangeBatch and load into Memgraph.

        Creates:
        - Change nodes with change_fields
        - ChangeTask nodes linked to changes
        - ConfigurationItem nodes linked to changes
        - AFFECTED_BY_CHANGE relationships (from tickets that reference this change)
        """
        try:
            changes = batch.get("changes", [])
            batch_number = batch.get("batch_number", 0)
            total_batches = batch.get("total_batches", 0)
            total_changes = batch.get("total_changes", 0)

            if not changes:
                self.logger.warning(f"Empty change batch {batch_number}/{total_batches}")
                return True

            # Normalize null values
            batch = Helpers.normalise_None(batch)

            # Load changes into graph
            change_count = await self._load_changes(changes)

            # Load change tasks
            task_count = await self._load_change_tasks(changes)

            # Load configuration items for changes
            ci_count = await self._load_change_cis(changes)

            # Create AFFECTED_BY_CHANGE relationships
            rel_count = await self._create_affected_by_relationships(changes)

            self.logger.info(
                f"Processed change batch {batch_number}/{total_batches}: "
                f"{change_count} changes, {task_count} tasks, {ci_count} CIs, {rel_count} relationships"
            )

            return True

        except Exception as e:
            self.logger.error(f"Error processing change batch: {e}", exc_info=True)
            return False

    async def _execute_with_retry(self, query: str, params: Dict[str, Any] = None):
        """Execute query with exponential backoff retry for transient errors"""
        for attempt in range(self.max_retries):
            try:
                return await self.memgraph_client.execute(query, params)
            except Exception as e:
                if "TransientError" in str(type(e).__name__) or "transaction" in str(e).lower():
                    if attempt == self.max_retries - 1:
                        raise
                    delay = self.base_delay * (2 ** attempt)
                    self.logger.warning(f"Transient error, retrying in {delay}s (attempt {attempt + 1}/{self.max_retries})")
                    await asyncio.sleep(delay)
                else:
                    raise

    async def _load_changes(self, changes: List[Dict[str, Any]]) -> int:
        """Batch load Change nodes using UNWIND"""
        if not changes:
            return 0

        # Prepare change data
        change_data = []
        for change in changes:
            change_fields = change.get("change_fields", {}) or {}
            change_data.append({
                "change_sys_id": change.get("change_sys_id"),
                "change_number": change.get("change_number"),
                "short_description": change.get("short_description"),
                "description": change.get("description"),
                "change_state": normalize_enum_value(change.get("change_state")),
                "category": normalize_enum_value(change.get("category")),
                "subcategory": normalize_enum_value(change.get("subcategory")),
                "reason": change.get("reason"),
                "assignment_group": change.get("assignment_group"),
                "assigned_to": change.get("assigned_to"),
                "assigned_to_sys_id": change.get("assigned_to_sys_id"),
                "created_on": change.get("created_on"),
                "created_by": change.get("created_by"),
                "updated_on": change.get("updated_on"),
                "closed_on": change.get("closed_on"),
                "closed_by": change.get("closed_by"),
                "close_code": normalize_enum_value(change.get("close_code")),
                "close_notes": change.get("close_notes"),
                "time_worked_minutes": change.get("time_worked_minutes"),
                "support_area": change.get("support_area"),
                "contact_type": normalize_enum_value(change.get("contact_type")),
                # Change-specific fields
                "change_type": normalize_enum_value(change_fields.get("change_type")),
                "work_type": normalize_enum_value(change_fields.get("work_type")),
                "source": normalize_enum_value(change_fields.get("source")),
                "planned_start_date": change_fields.get("planned_start_date"),
                "planned_end_date": change_fields.get("planned_end_date"),
                "backup_start_date": change_fields.get("backup_start_date"),
                "backup_end_date": change_fields.get("backup_end_date"),
                "impact_duration": change_fields.get("impact_duration"),
                "impact_duration_minutes": change_fields.get("impact_duration_minutes"),
                "implementation_plan": change_fields.get("implementation_plan"),
                "backout_plan": change_fields.get("backout_plan"),
                "test_plan": change_fields.get("test_plan"),
                "risk_impact_analysis": change_fields.get("risk_impact_analysis"),
                "justification": change_fields.get("justification"),
                "country": change_fields.get("country"),
                "city": change_fields.get("city"),
                "planned_work_location": change_fields.get("planned_work_location"),
                "risk": normalize_enum_value(change_fields.get("risk")),
                "security_risk": normalize_enum_value(change_fields.get("security_risk")),
                "modification_of_access": change_fields.get("modification_of_access"),
                "core_network": change_fields.get("core_network"),
                "critical_systems": change_fields.get("critical_systems"),
                "cab_date_time": change_fields.get("cab_date_time"),
                "is_cab_required": change_fields.get("is_cab_required"),
                "is_postponed": change_fields.get("is_postponed"),
                "supplier_sys_id": change_fields.get("supplier_sys_id"),
                "supplier_name": change_fields.get("supplier_name"),
                "supplier_reference": change_fields.get("supplier_reference"),
                "vendor_id": change_fields.get("vendor_id"),
                "implemented_by_sys_ids": change_fields.get("implemented_by_sys_ids"),
                "implemented_by_names": change_fields.get("implemented_by_names"),
                "requested_by_sys_id": change_fields.get("requested_by_sys_id"),
                "requested_by": change_fields.get("requested_by"),
                "requested_by_date": change_fields.get("requested_by_date"),
                # Impact metrics
                "impacted_services_count": change_fields.get("impacted_services_count"),
                "planned_work_reason": change_fields.get("planned_work_reason"),
                # Second backup window
                "second_backup_start_date": change_fields.get("second_backup_start_date"),
                "second_backup_end_date": change_fields.get("second_backup_end_date"),
                # Additional flags
                "is_inside_blackout_schedule": change_fields.get("is_inside_blackout_schedule"),
                "is_suppress_client_notifications": change_fields.get("is_suppress_client_notifications"),
                "modification_of_cryptographic": change_fields.get("modification_of_cryptographic"),
            })

        query = """
        UNWIND $changes AS c
        MERGE (change:Change {change_sys_id: c.change_sys_id})
        SET
            change.change_number = c.change_number,
            change.short_description = c.short_description,
            change.description = c.description,
            change.change_state = c.change_state,
            change.category = c.category,
            change.subcategory = c.subcategory,
            change.reason = c.reason,
            change.assignment_group = c.assignment_group,
            change.assigned_to = c.assigned_to,
            change.assigned_to_sys_id = c.assigned_to_sys_id,
            change.created_on = c.created_on,
            change.created_by = c.created_by,
            change.updated_on = c.updated_on,
            change.closed_on = c.closed_on,
            change.closed_by = c.closed_by,
            change.close_code = c.close_code,
            change.close_notes = c.close_notes,
            change.time_worked_minutes = c.time_worked_minutes,
            change.support_area = c.support_area,
            change.contact_type = c.contact_type,
            change.change_type = c.change_type,
            change.work_type = c.work_type,
            change.source = c.source,
            change.planned_start_date = c.planned_start_date,
            change.planned_end_date = c.planned_end_date,
            change.backup_start_date = c.backup_start_date,
            change.backup_end_date = c.backup_end_date,
            change.impact_duration = c.impact_duration,
            change.impact_duration_minutes = c.impact_duration_minutes,
            change.implementation_plan = c.implementation_plan,
            change.backout_plan = c.backout_plan,
            change.test_plan = c.test_plan,
            change.risk_impact_analysis = c.risk_impact_analysis,
            change.justification = c.justification,
            change.country = c.country,
            change.city = c.city,
            change.planned_work_location = c.planned_work_location,
            change.risk = c.risk,
            change.security_risk = c.security_risk,
            change.modification_of_access = c.modification_of_access,
            change.core_network = c.core_network,
            change.critical_systems = c.critical_systems,
            change.cab_date_time = c.cab_date_time,
            change.is_cab_required = c.is_cab_required,
            change.is_postponed = c.is_postponed,
            change.supplier_sys_id = c.supplier_sys_id,
            change.supplier_name = c.supplier_name,
            change.supplier_reference = c.supplier_reference,
            change.vendor_id = c.vendor_id,
            change.implemented_by_sys_ids = c.implemented_by_sys_ids,
            change.implemented_by_names = c.implemented_by_names,
            change.requested_by_sys_id = c.requested_by_sys_id,
            change.requested_by = c.requested_by,
            change.requested_by_date = c.requested_by_date,
            change.impacted_services_count = c.impacted_services_count,
            change.planned_work_reason = c.planned_work_reason,
            change.second_backup_start_date = c.second_backup_start_date,
            change.second_backup_end_date = c.second_backup_end_date,
            change.is_inside_blackout_schedule = c.is_inside_blackout_schedule,
            change.is_suppress_client_notifications = c.is_suppress_client_notifications,
            change.modification_of_cryptographic = c.modification_of_cryptographic
        """

        await self._execute_with_retry(query, {"changes": change_data})
        return len(change_data)

    async def _load_change_tasks(self, changes: List[Dict[str, Any]]) -> int:
        """Batch load ChangeTask nodes and relationships"""
        task_data = []
        for change in changes:
            change_sys_id = change.get("change_sys_id")
            for task in change.get("tasks", []) or []:
                task_data.append({
                    "change_sys_id": change_sys_id,
                    "task_sys_id": task.get("task_sys_id"),
                    "task_number": task.get("task_number"),
                    "change_number": task.get("change_number"),
                    "short_description": task.get("short_description"),
                    "state": normalize_enum_value(task.get("state")),
                    "priority": task.get("priority"),
                    "change_category": normalize_enum_value(task.get("change_category")),
                    "change_subcategory": normalize_enum_value(task.get("change_subcategory")),
                    "fulfillment": task.get("fulfillment"),
                    "follow_up_needed": task.get("follow_up_needed"),
                    "implemented_in_timeframe": task.get("implemented_in_timeframe"),
                    "unexpected_consequences": task.get("unexpected_consequences"),
                    "closure_responsibility": task.get("closure_responsibility"),
                    "responsible_team": task.get("responsible_team"),
                    "assignment_group": task.get("assignment_group"),
                    "assigned_to": task.get("assigned_to"),
                    "assigned_to_sys_id": task.get("assigned_to_sys_id"),
                    "created_on": task.get("created_on"),
                    "created_by": task.get("created_by"),
                    "updated_on": task.get("updated_on"),
                    "closed_on": task.get("closed_on"),
                    "closed_by": task.get("closed_by"),
                })

        if not task_data:
            return 0

        query = """
        UNWIND $tasks AS t
        MERGE (task:ChangeTask {task_sys_id: t.task_sys_id})
        SET
            task.task_number = t.task_number,
            task.change_number = t.change_number,
            task.short_description = t.short_description,
            task.state = t.state,
            task.priority = t.priority,
            task.change_category = t.change_category,
            task.change_subcategory = t.change_subcategory,
            task.fulfillment = t.fulfillment,
            task.follow_up_needed = t.follow_up_needed,
            task.implemented_in_timeframe = t.implemented_in_timeframe,
            task.unexpected_consequences = t.unexpected_consequences,
            task.closure_responsibility = t.closure_responsibility,
            task.responsible_team = t.responsible_team,
            task.assignment_group = t.assignment_group,
            task.assigned_to = t.assigned_to,
            task.assigned_to_sys_id = t.assigned_to_sys_id,
            task.created_on = t.created_on,
            task.created_by = t.created_by,
            task.updated_on = t.updated_on,
            task.closed_on = t.closed_on,
            task.closed_by = t.closed_by
        WITH task, t
        MATCH (change:Change {change_sys_id: t.change_sys_id})
        MERGE (change)-[:HAS_TASK]->(task)
        """

        await self._execute_with_retry(query, {"tasks": task_data})
        return len(task_data)

    async def _load_change_cis(self, changes: List[Dict[str, Any]]) -> int:
        """Batch load ConfigurationItem nodes for changes and relationships"""
        ci_data = []
        for change in changes:
            change_sys_id = change.get("change_sys_id")
            for ci in change.get("configuration_items", []) or []:
                ci_data.append({
                    "change_sys_id": change_sys_id,
                    "ci_sys_id": ci.get("ci_sys_id"),
                    "ci_name": ci.get("ci_name"),
                    "is_manually_added": ci.get("is_manually_added"),
                })

        if not ci_data:
            return 0

        query = """
        UNWIND $cis AS ci
        MERGE (config:ConfigurationItem {ci_sys_id: ci.ci_sys_id})
        SET
            config.ci_name = ci.ci_name,
            config.is_manually_added = ci.is_manually_added
        WITH config, ci
        MATCH (change:Change {change_sys_id: ci.change_sys_id})
        MERGE (change)-[:IMPACTS_CI]->(config)
        """

        await self._execute_with_retry(query, {"cis": ci_data})
        return len(ci_data)

    async def _create_affected_by_relationships(self, changes: List[Dict[str, Any]]) -> int:
        """
        Create AFFECTED_BY_CHANGE relationships from Tickets to Changes.

        Tickets reference changes via:
        - incident_fields.caused_by_change_sys_id
        - incident_fields.related_change_sys_id
        - case_fields.caused_by_change_sys_id
        """
        change_sys_ids = [c.get("change_sys_id") for c in changes if c.get("change_sys_id")]

        if not change_sys_ids:
            return 0

        # Create AFFECTED_BY_CHANGE from tickets that have caused_by_change_sys_id
        query = """
        UNWIND $change_sys_ids AS change_id
        MATCH (change:Change {change_sys_id: change_id})
        OPTIONAL MATCH (ticket:Ticket)
        WHERE ticket.caused_by_change_sys_id = change_id
           OR ticket.related_change_sys_id = change_id
        WITH change, ticket
        WHERE ticket IS NOT NULL
        MERGE (ticket)-[r:AFFECTED_BY_CHANGE]->(change)
        RETURN count(r) as rel_count
        """

        result = await self._execute_with_retry(query, {"change_sys_ids": change_sys_ids})

        # Count relationships created
        rel_count = 0
        if result:
            for record in result:
                rel_count += record.get("rel_count", 0)

        return rel_count
