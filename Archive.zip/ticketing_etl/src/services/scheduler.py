import asyncio
import logging
from datetime import datetime, time
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from services.pipeline_service import DataPipelineService
from utils.config import Config
from utils.correlation import get_correlation_id


class Scheduler:
    def __init__(self, config: Config, pipeline_service: DataPipelineService):
        """Initialize the scheduler to trigger data processing.

        Args:
            config: Application configuration
            pipeline_service: DataPipelineService for extraction and transformation
        """
        self.config = config
        self.pipeline_service = pipeline_service
        self.scheduler = AsyncIOScheduler()
        self.logger = logging.getLogger(__name__)

        # Graceful shutdown tracking
        self.is_shutting_down = False
        self.current_processing_task = None
        self.shutdown_event = asyncio.Event()

        # Get schedule configuration
        self.daily_run_time = self._parse_daily_time(config.get_daily_schedule_time())
        self.run_on_startup = config.get_run_on_startup()
        self.data_source = config.get_data_source()
        self.api_lookback_hours = config.get_api_lookback_hours()

    def _parse_daily_time(self, time_str: str) -> time:
        """Parse daily run time from HH:MM format"""
        try:
            hour, minute = map(int, time_str.split(":"))
            return time(hour=hour, minute=minute)
        except (ValueError, AttributeError):
            self.logger.warning(
                f"Invalid DAILY_SCHEDULE_TIME format '{time_str}', using default 02:00"
            )
            return time(hour=2, minute=0)

    async def start(self):
        """Start scheduled processing based on DATA_SOURCE"""
        if self.data_source in ("api", "both"):
            # API mode: schedule based on API_LOOKBACK_HOURS
            self.logger.info(
                f"API mode - scheduling every {self.api_lookback_hours} hours"
            )
            self.scheduler.add_job(
                self.scheduled_job,
                "interval",
                hours=self.api_lookback_hours,
                id="processing_job",
            )
        else:
            # DB mode: daily cron schedule
            self.logger.info(
                f"DB mode - daily processing scheduled for {self.daily_run_time}"
            )
            self.scheduler.add_job(
                self.scheduled_job,
                "cron",
                hour=self.daily_run_time.hour,
                minute=self.daily_run_time.minute,
                id="processing_job",
            )

        self.scheduler.start()

        if self.data_source in ("api", "both"):
            self.logger.info(
                f"Scheduler started - running every {self.api_lookback_hours} hours "
                f"(DATA_SOURCE={self.data_source})"
            )
        else:
            run_time = self.daily_run_time.strftime("%H:%M")
            self.logger.info(
                f"Scheduler started for daily execution at {run_time} UTC "
                f"(DATA_SOURCE={self.data_source})"
            )

        # Check if we should run immediately on startup
        if self.run_on_startup:
            self.logger.info("Executing initial run on startup")
            await self.scheduled_job()
        else:
            self.logger.info("Startup execution disabled, waiting for scheduled time")

        # Ensure clean shutdown on exit
        loop = asyncio.get_running_loop()
        loop.create_task(self.wait_for_exit())

    async def scheduled_job(self):
        """Process data extraction and transformation."""
        correlation_id = get_correlation_id()
        run_start_time = datetime.now()

        # Check if we're shutting down
        if self.is_shutting_down:
            self.logger.info(
                "Skipping scheduled job - shutdown in progress",
                extra={"correlation_id": correlation_id},
            )
            return

        self.logger.info(
            f"Starting processing run at {run_start_time.isoformat()}",
            extra={"correlation_id": correlation_id},
        )

        # Set current processing task for graceful shutdown
        self.current_processing_task = asyncio.current_task()

        try:
            success = await self.pipeline_service.process()

            total_duration = (datetime.now() - run_start_time).total_seconds()
            status = "completed" if not self.is_shutting_down else "interrupted"

            if success:
                self.logger.info(
                    f"Pipeline {status} successfully (duration: {total_duration:.2f}s)",
                    extra={"correlation_id": correlation_id},
                )
            else:
                self.logger.error(
                    f"Pipeline {status} with errors (duration: {total_duration:.2f}s)",
                    extra={"correlation_id": correlation_id},
                )

            # Log next scheduled run
            if not self.is_shutting_down:
                next_run = self.scheduler.get_job("processing_job")
                if next_run and next_run.next_run_time:
                    self.logger.info(
                        f"Next run scheduled for: {next_run.next_run_time.isoformat()}",
                        extra={"correlation_id": correlation_id},
                    )

        except Exception as e:
            total_duration = (datetime.now() - run_start_time).total_seconds()
            self.logger.error(
                f"Pipeline failed: {e} (duration: {total_duration:.2f}s)",
                extra={"correlation_id": correlation_id},
                exc_info=True,
            )

        finally:
            # Clear current processing task
            self.current_processing_task = None

            # Signal that processing is complete if shutdown was requested
            if self.is_shutting_down:
                self.shutdown_event.set()

    async def wait_for_exit(self):
        """Wait until the event loop is stopping."""
        try:
            await asyncio.Event().wait()  # Hold the event loop
        except asyncio.CancelledError:
            await self.stop()

    async def stop(self):
        """Stop the scheduler gracefully, waiting for current processing to complete."""
        self.logger.info("Initiating graceful scheduler shutdown...")

        # Signal shutdown
        self.is_shutting_down = True

        # If processing is active, wait for it to complete
        if self.current_processing_task and not self.current_processing_task.done():
            self.logger.info("Waiting for current processing to complete...")
            try:
                # Wait up to 30 seconds for processing to complete gracefully
                await asyncio.wait_for(self.shutdown_event.wait(), timeout=30.0)
                self.logger.info("Current processing completed gracefully")
            except asyncio.TimeoutError:
                self.logger.warning(
                    "Processing did not complete within timeout - forcing shutdown"
                )
                if self.current_processing_task:
                    self.current_processing_task.cancel()

        # Shutdown the scheduler
        self.logger.info("Shutting down scheduler...")
        self.scheduler.shutdown(wait=True)
        self.logger.info("Scheduler stopped gracefully.")

    def get_scheduler(self):
        return self.scheduler

    @property
    def is_running(self):
        """Check if scheduler is running (for health checks)"""
        return self.scheduler.running and not self.is_shutting_down
