"""
Cypher queries for NoteInfo nodes
Used to store extracted note attributes in Memgraph.
NoteInfo stores:
- Extracted values (from notes analysis)
- Original ticket values (for comparison)
- Discrepancy tracking (differs_from_ticket, extraction_evidence)
- Reference to Milvus note_id (where embedding + summary live)
"""

# Create or update NoteInfo node with extracted + original values
UPSERT_NOTE_INFO = """
MERGE (ni:NoteInfo {note_info_id: $note_info_id})
SET ni.note_id = $note_id,
    // Extracted values (from notes analysis)
    ni.fault_analysis = $fault_analysis,
    ni.suggested_category = $suggested_category,
    ni.fault_type = $fault_type,
    ni.fault_summary = $fault_summary,
    ni.responsible_party = $responsible_party,
    ni.priority = $priority,
    ni.mttr_minutes = $mttr_minutes,
    ni.root_cause = $root_cause,
    ni.rfo = $rfo,
    // Taxonomy lookup values
    ni.taxonomy_valid = $taxonomy_valid,
    ni.taxonomy_priority = $taxonomy_priority,
    ni.taxonomy_impact = $taxonomy_impact,
    ni.taxonomy_urgency = $taxonomy_urgency,
    ni.taxonomy_sla_hours = $taxonomy_sla_hours,
    ni.taxonomy_sla = $taxonomy_sla,
    // LLM-generated suggestions
    ni.suggested_resolution_notes = $suggested_resolution_notes,
    ni.suggested_internal_notes = $suggested_internal_notes,
    ni.suggested_actual_end_date = $suggested_actual_end_date,
    // Original ticket values (for comparison)
    ni.ticket_fault_type = $ticket_fault_type,
    ni.ticket_responsible_party = $ticket_responsible_party,
    ni.ticket_priority = $ticket_priority,
    ni.ticket_mttr_minutes = $ticket_mttr_minutes,
    // Discrepancy tracking
    ni.differs_from_ticket = $differs_from_ticket,
    ni.confidence = $confidence,
    ni.notes_analyzed = $notes_analyzed,
    ni.emails_analyzed = $emails_analyzed,
    ni.field_changes_analyzed = $field_changes_analyzed,
    // Per-field evidence (why AI suggested each value)
    ni.evidence_priority = $evidence_priority,
    ni.evidence_fault_type = $evidence_fault_type,
    ni.evidence_responsible_party = $evidence_responsible_party,
    ni.evidence_mttr = $evidence_mttr,
    // Computed outage pattern
    ni.is_flapping = $is_flapping,
    ni.flap_cycles = $flap_cycles,
    ni.processed_at = $processed_at
WITH ni
MATCH (t:Ticket {ticket_sys_id: $ticket_sys_id})
MERGE (t)-[:HAS_NOTES]->(ni)
"""

# Get extraction discrepancies - tickets where extracted differs from recorded
GET_EXTRACTION_DISCREPANCIES = """
MATCH (t:Ticket)-[:HAS_NOTES]->(ni:NoteInfo)
WHERE ni.differs_from_ticket = true
  AND ni.confidence >= $min_confidence
RETURN t.ticket_id as ticket_id,
       t.ticket_sys_id as ticket_sys_id,
       ni.suggested_category as extracted_category,
       t.ticket_category as original_category,
       ni.fault_type as extracted_fault,
       ni.ticket_fault_type as original_fault,
       ni.responsible_party as extracted_party,
       ni.ticket_responsible_party as original_party,
       ni.priority as extracted_priority,
       ni.ticket_priority as original_priority,
       ni.mttr_minutes as extracted_mttr,
       ni.ticket_mttr_minutes as original_mttr,
       ni.root_cause as root_cause,
       ni.extraction_evidence as evidence,
       ni.confidence as confidence,
       ni.taxonomy_valid as taxonomy_valid,
       ni.notes_analyzed as notes_analyzed
ORDER BY ni.confidence DESC
LIMIT $limit
"""

# Get extraction discrepancies for a specific ticket
GET_DISCREPANCIES_BY_TICKET = """
MATCH (t:Ticket {number: $ticket_number})-[:HAS_NOTES]->(ni:NoteInfo)
RETURN t.ticket_id as ticket_id,
       t.ticket_sys_id as ticket_sys_id,
       ni.fault_type as extracted_fault,
       ni.ticket_fault_type as original_fault,
       ni.responsible_party as extracted_party,
       ni.ticket_responsible_party as original_party,
       ni.priority as extracted_priority,
       ni.ticket_priority as original_priority,
       ni.mttr_minutes as extracted_mttr,
       ni.ticket_mttr_minutes as original_mttr,
       ni.root_cause as root_cause,
       ni.extraction_evidence as evidence,
       ni.confidence as confidence,
       ni.differs_from_ticket as differs,
       ni.notes_analyzed as notes_analyzed
"""

# Get all NoteInfo nodes for a ticket by sys_id
GET_NOTE_INFO_BY_TICKET = """
MATCH (t:Ticket {ticket_sys_id: $ticket_sys_id})-[:HAS_NOTES]->(ni:NoteInfo)
RETURN ni.note_info_id as note_info_id,
       ni.note_id as note_id,
       ni.fault_analysis as fault_analysis,
       ni.suggested_category as suggested_category,
       ni.fault_type as fault_type,
       ni.fault_summary as fault_summary,
       ni.responsible_party as responsible_party,
       ni.priority as priority,
       ni.mttr_minutes as mttr_minutes,
       ni.root_cause as root_cause,
       ni.taxonomy_valid as taxonomy_valid,
       ni.taxonomy_priority as taxonomy_priority,
       ni.taxonomy_impact as taxonomy_impact,
       ni.taxonomy_urgency as taxonomy_urgency,
       ni.taxonomy_sla_hours as taxonomy_sla_hours,
       ni.taxonomy_sla as taxonomy_sla,
       ni.ticket_fault_type as ticket_fault_type,
       ni.ticket_responsible_party as ticket_responsible_party,
       ni.ticket_priority as ticket_priority,
       ni.ticket_mttr_minutes as ticket_mttr_minutes,
       ni.differs_from_ticket as differs_from_ticket,
       ni.extraction_evidence as extraction_evidence,
       ni.confidence as confidence,
       ni.notes_analyzed as notes_analyzed,
       ni.created_on as created_on
ORDER BY ni.created_on DESC
"""

# Count NoteInfo nodes for a ticket
COUNT_NOTE_INFO_BY_TICKET = """
MATCH (t:Ticket {ticket_sys_id: $ticket_sys_id})-[:HAS_NOTES]->(ni:NoteInfo)
RETURN count(ni) as note_count
"""

# Get summary statistics on extraction discrepancies
GET_DISCREPANCY_STATS = """
MATCH (t:Ticket)-[:HAS_NOTES]->(ni:NoteInfo)
WHERE ni.confidence >= $min_confidence
RETURN count(CASE WHEN ni.differs_from_ticket = true THEN 1 END) as discrepancy_count,
       count(ni) as total_audited,
       avg(ni.confidence) as avg_confidence,
       count(CASE WHEN ni.fault_type <> ni.ticket_fault_type THEN 1 END) as fault_type_mismatches,
       count(CASE WHEN ni.responsible_party <> ni.ticket_responsible_party THEN 1 END) as party_mismatches,
       count(CASE WHEN ni.priority <> ni.ticket_priority THEN 1 END) as priority_mismatches
"""

# Get tickets by extracted fault type (for analysis)
GET_TICKETS_BY_EXTRACTED_FAULT = """
MATCH (t:Ticket)-[:HAS_NOTES]->(ni:NoteInfo {fault_type: $fault_type})
WHERE ni.confidence >= $min_confidence
RETURN DISTINCT t.ticket_id as ticket_id,
       t.ticket_sys_id as ticket_sys_id,
       t.priority as ticket_priority,
       ni.fault_type as extracted_fault,
       ni.confidence as confidence
ORDER BY ni.confidence DESC
LIMIT $limit
"""
