#!/bin/bash
# Open Memgraph Lab in browser
# Memgraph Lab provides a visual interface to explore the graph database

# Default port for Memgraph Lab
MEMGRAPH_LAB_PORT="${1:-7444}"

echo "================================================"
echo "  Memgraph Lab - Graph Database Explorer"
echo "================================================"
echo ""
echo "Opening Memgraph Lab at: http://localhost:$MEMGRAPH_LAB_PORT"
echo ""
echo "Features:"
echo "  ✓ Visual graph exploration"
echo "  ✓ Cypher query editor with syntax highlighting"
echo "  ✓ Real-time query results"
echo "  ✓ Interactive graph visualizations"
echo ""
echo "Example queries to try:"
echo "  MATCH (t:Ticket) RETURN t LIMIT 10"
echo "  MATCH (c:Client)-[:HAS_TICKET]->(t:Ticket) RETURN c, t LIMIT 20"
echo ""
echo "================================================"
echo ""

# Check if Memgraph is running
if ! curl -s -o /dev/null -w "%{http_code}" http://localhost:7687 | grep -q "000"; then
    echo "⚠️  Warning: Memgraph may not be running on port 7687"
    echo "   Start it with: docker-compose up -d memgraph"
    echo ""
fi

# Open browser
if command -v open &> /dev/null; then
    # macOS
    open "http://localhost:$MEMGRAPH_LAB_PORT"
elif command -v xdg-open &> /dev/null; then
    # Linux
    xdg-open "http://localhost:$MEMGRAPH_LAB_PORT"
elif command -v start &> /dev/null; then
    # Windows
    start "http://localhost:$MEMGRAPH_LAB_PORT"
else
    echo "Please open this URL in your browser:"
    echo "http://localhost:$MEMGRAPH_LAB_PORT"
fi
