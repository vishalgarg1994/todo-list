#!/usr/bin/env python3
"""
Check NATS JetStream stream configuration
"""
import asyncio
import nats
from nats.js import JetStreamContext

async def check_stream():
    """Check if EVA_TICKETING_STREAM exists and view its configuration"""
    try:
        nc = await nats.connect("nats://localhost:4222")
        js = nc.jetstream()
        print("✅ Connected to NATS")

        # List all streams
        print("\n" + "="*70)
        print("📊 All JetStream Streams:")
        print("="*70)

        streams = await js.streams_info()
        if not streams:
            print("❌ No streams found!")
        else:
            for stream_info in streams:
                print(f"\nStream: {stream_info.config.name}")
                print(f"  Subjects: {stream_info.config.subjects}")
                print(f"  Messages: {stream_info.state.messages}")
                print(f"  Bytes: {stream_info.state.bytes}")
                print(f"  First Seq: {stream_info.state.first_seq}")
                print(f"  Last Seq: {stream_info.state.last_seq}")

        # Check specifically for EVA_TICKETING_STREAM
        print("\n" + "="*70)
        print("🔍 Checking EVA_TICKETING_STREAM:")
        print("="*70)

        try:
            stream_info = await js.stream_info("EVA_TICKETING_STREAM")
            print(f"✅ Stream exists!")
            print(f"   Subjects: {stream_info.config.subjects}")
            print(f"   Messages: {stream_info.state.messages}")
            print(f"   Retention: {stream_info.config.retention}")
            print(f"   Max Age: {stream_info.config.max_age}")

            # Check if tickets.fault_description is in subjects
            if "tickets.fault_description" in stream_info.config.subjects or "tickets.*" in stream_info.config.subjects:
                print("   ✅ tickets.fault_description subject is configured")
            else:
                print("   ❌ tickets.fault_description subject NOT configured")
                print(f"   Current subjects: {stream_info.config.subjects}")
        except Exception as e:
            print(f"❌ Stream does not exist: {e}")

        await nc.close()

    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    asyncio.run(check_stream())
