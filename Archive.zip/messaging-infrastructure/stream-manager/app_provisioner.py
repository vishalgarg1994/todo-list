"""
Application Provisioning Service for Eva Messaging Infrastructure
Handles stream and subject management for new applications
"""

import yaml
import logging
from typing import Dict, List, Any
from pathlib import Path
from nats.js.api import RetentionPolicy, StorageType

from stream_manager import NatsStreamManager
from config import Config

logger = logging.getLogger(__name__)


class ApplicationProvisioner:
    """Provisions messaging infrastructure for applications"""

    def __init__(self, config: Config):
        self.config = config
        self.stream_manager = NatsStreamManager(config)
        self.templates_path = Path(__file__).parent.parent / "config" / "stream_templates.yaml"
        self.templates = self._load_templates()

    def _load_templates(self) -> Dict[str, Any]:
        """Load stream templates configuration"""
        try:
            with open(self.templates_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load templates: {e}")
            return {}

    def _validate_application_name(self, app_name: str) -> bool:
        """Validate application name follows conventions"""
        if not app_name.isalnum():
            return False
        if len(app_name) < 3 or len(app_name) > 20:
            return False
        return True

    def _validate_subjects(self, subjects: List[str], domain: str) -> List[str]:
        """Validate and filter subjects according to governance policies"""
        valid_subjects = []
        policies = self.templates.get("subject_policies", {})

        # Check naming conventions
        reserved_prefixes = policies.get("reserved_prefixes", [])

        for subject in subjects:
            # Check reserved prefixes
            if any(subject.startswith(prefix) for prefix in reserved_prefixes):
                logger.warning(f"Subject '{subject}' uses reserved prefix - skipped")
                continue

            # Check domain isolation if enforced
            domain_isolation = policies.get("domain_isolation", {})
            if domain_isolation.get("enforce", False):
                if not subject.lower().startswith(domain.lower()):
                    logger.warning(f"Subject '{subject}' doesn't match domain '{domain}' - skipped")
                    continue

            valid_subjects.append(subject)

        return valid_subjects

    def _apply_template(self, template_type: str, domain: str, description: str) -> Dict[str, Any]:
        """Apply template to generate stream configuration"""
        template = self.templates.get("stream_templates", {}).get(template_type)
        if not template:
            raise ValueError(f"Template '{template_type}' not found")

        # Generate stream name
        name_pattern = template["name_pattern"]
        stream_name = name_pattern.format(DOMAIN=domain.upper(), Domain=domain.title())

        # Generate description
        desc_pattern = template["description_pattern"]
        stream_description = desc_pattern.format(Domain=domain.title(), description=description)

        # Get default configuration
        default_config = template["default_config"]

        # Convert retention policy
        retention_map = {
            "WORK_QUEUE": RetentionPolicy.WORK_QUEUE,
            "LIMITS": RetentionPolicy.LIMITS,
            "INTEREST": RetentionPolicy.INTEREST
        }

        # Convert storage type
        storage_map = {
            "FILE": StorageType.FILE,
            "MEMORY": StorageType.MEMORY
        }

        return {
            "name": stream_name,
            "description": stream_description,
            "retention": retention_map.get(default_config["retention"], RetentionPolicy.WORK_QUEUE),
            "storage": storage_map.get(default_config["storage"], StorageType.FILE),
            "max_age": default_config["max_age_hours"] * 3600,  # Convert to seconds
            "max_msgs": default_config["max_msgs"],
            "max_bytes": default_config["max_bytes_mb"] * 1024 * 1024  # Convert to bytes
        }

    async def register_application(
            self, app_name: str, domain: str, description: str,
            subjects: List[str], stream_types: List[str] = None,
            owner: str = None, contact: str = None) -> Dict[str, Any]:
        """Register a new application and provision its messaging infrastructure"""

        if not self._validate_application_name(app_name):
            raise ValueError("Invalid application name. Must be 3-20 alphanumeric characters")

        # Default to application stream if not specified
        if not stream_types:
            stream_types = ["application_stream"]

        # Validate subjects
        validated_subjects = self._validate_subjects(subjects, domain)
        if not validated_subjects:
            raise ValueError("No valid subjects provided after validation")

        results = {
            "application": app_name,
            "domain": domain,
            "streams_created": [],
            "subjects_registered": validated_subjects,
            "errors": []
        }

        try:
            await self.stream_manager.connect()

            for stream_type in stream_types:
                try:
                    # Apply template to generate stream config
                    stream_config = self._apply_template(stream_type, domain, description)

                    # Add subjects to stream configuration
                    stream_config["subjects"] = [f"{domain.lower()}.*"]  # Domain-wide pattern

                    # Create the stream
                    result = await self.stream_manager.create_stream(stream_config)
                    results["streams_created"].append({
                        "stream_name": stream_config["name"],
                        "type": stream_type,
                        "success": result["success"],
                        "message": result["message"]
                    })

                except Exception as e:
                    error_msg = f"Failed to create {stream_type} stream: {str(e)}"
                    logger.error(error_msg)
                    results["errors"].append(error_msg)

            # Update application registry (in production, this would go to a database)
            await self._update_application_registry(
                app_name, domain, description,
                validated_subjects, stream_types,
                owner, contact)

            logger.info(f"Successfully registered application '{app_name}' with domain '{domain}'")
            return results

        except Exception as e:
            logger.error(f"Failed to register application '{app_name}': {e}")
            raise
        finally:
            await self.stream_manager.disconnect()

    async def _update_application_registry(
            self, app_name: str, domain: str,
            description: str, subjects: List[str],
            stream_types: List[str], owner: str = None,
            contact: str = None):
        """Update application registry (placeholder for database implementation)"""
        # In production, this would update a database or configuration store
        logger.info(f"Registry update: {app_name} -> {domain} with {len(subjects)} subjects")

    async def list_registered_applications(self) -> List[Dict[str, Any]]:
        """List all registered applications"""
        # Return applications from template file (in production, from database)
        applications = self.templates.get("applications", {})

        result = []
        for app_name, app_config in applications.items():
            result.append({
                "name": app_name,
                "domain": app_config.get("domain"),
                "description": app_config.get("description"),
                "owner": app_config.get("owner"),
                "contact": app_config.get("contact"),
                "subjects": [
                    subject for stream in app_config.get("streams", [])
                    for subject in stream.get("subjects", [])]
            })

        return result

    async def provision_application_from_template(self, app_name: str) -> Dict[str, Any]:
        """Provision infrastructure for an application already defined in templates"""
        applications = self.templates.get("applications", {})

        if app_name not in applications:
            raise ValueError(f"Application '{app_name}' not found in templates")

        app_config = applications[app_name]
        domain = app_config["domain"]
        description = app_config["description"]

        # Collect all subjects from all streams
        all_subjects = []
        stream_types = []

        for stream_config in app_config.get("streams", []):
            stream_types.append(stream_config["type"])
            all_subjects.extend(stream_config.get("subjects", []))

        return await self.register_application(
            app_name=app_name,
            domain=domain,
            description=description,
            subjects=all_subjects,
            stream_types=list(set(stream_types)),  # Remove duplicates
            owner=app_config.get("owner"),
            contact=app_config.get("contact")
        )

    async def validate_subject_access(self, app_name: str, subject: str) -> bool:
        """Validate if an application can publish to a specific subject"""
        applications = self.templates.get("applications", {})

        if app_name not in applications:
            logger.warning(f"Unknown application '{app_name}' attempting to publish")
            return False

        app_config = applications[app_name]
        domain = app_config["domain"].lower()

        # Check if subject matches the application's domain
        if subject.startswith(domain + "."):
            return True

        # Check if subject is explicitly registered
        registered_subjects = []
        for stream_config in app_config.get("streams", []):
            registered_subjects.extend(stream_config.get("subjects", []))

        return subject in registered_subjects
