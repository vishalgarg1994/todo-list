"""
Test NATS configuration and environment validation
"""

import pytest
import os
import yaml
from pathlib import Path


class TestNatsConfiguration:
    """Test NATS configuration files and environment setup"""

    @pytest.fixture
    def project_root(self):
        """Get the project root directory"""
        return Path(__file__).parent.parent

    def test_environment_files_have_required_variables(self, project_root):
        """Test that environment files contain required JetStream variables"""
        env_files = [
            'nats/.env.dev',
            'nats/.env.test',
            'nats/.env.prod'
        ]

        required_vars = [
            'JETSTREAM_MAX_MSGS',
            'JETSTREAM_MAX_BYTES',
            'JETSTREAM_MAX_AGE',
            'JETSTREAM_RETENTION'
        ]

        for env_file in env_files:
            env_path = project_root / env_file
            if env_path.exists():
                with open(env_path, 'r') as f:
                    content = f.read()

                for var in required_vars:
                    assert var in content, f"Variable {var} should be in {env_file}"

    def test_init_streams_script_exists(self, project_root):
        """Test that stream initialization script exists and is executable"""
        script_path = project_root / 'nats/scripts/init-streams.sh'
        assert script_path.exists(), "init-streams.sh script should exist"

    def test_nats_config_file_exists(self, project_root):
        """Test that NATS server configuration exists"""
        config_path = project_root / 'nats/config/nats-server.conf'
        # This might not exist in all setups, so we make it a soft check
        if config_path.exists():
            assert config_path.is_file()

    def test_helm_values_have_jetstream_config(self, project_root):
        """Test that Helm values files contain JetStream configuration"""
        helm_values_files = [
            'helm/values-dev.yaml',
            'helm/values-prod.yaml',
            'helm/values-test.yaml'
        ]

        for values_file in helm_values_files:
            values_path = project_root / values_file
            if values_path.exists():
                with open(values_path, 'r') as f:
                    try:
                        values = yaml.safe_load(f)

                        # Check for JetStream configuration
                        assert 'nats' in values, f"NATS config should be in {values_file}"
                        if 'jetstream' in values.get('nats', {}):
                            jetstream_config = values['nats']['jetstream']

                            # Check for essential JetStream settings
                            assert 'maxMessages' in jetstream_config or 'maxBytes' in jetstream_config, \
                                f"JetStream limits should be configured in {values_file}"
                    except yaml.YAMLError:
                        pytest.fail(f"Invalid YAML in {values_file}")

    def test_environment_specific_configurations(self, project_root):
        """Test that different environments have appropriate configurations"""
        # Test development environment (should have smaller limits)
        dev_env = project_root / 'nats/.env.dev'
        if dev_env.exists():
            with open(dev_env, 'r') as f:
                dev_content = f.read()

            # Development should have conservative settings
            assert 'JETSTREAM_MAX_BYTES' in dev_content

        # Test production environment (should have larger limits)
        prod_env = project_root / 'nats/.env.prod'
        if prod_env.exists():
            with open(prod_env, 'r') as f:
                prod_content = f.read()

            # Production should have higher capacity settings
            assert 'JETSTREAM_MAX_BYTES' in prod_content