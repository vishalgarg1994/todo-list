"""
Observability Hooks - Phase 1 Architecture

This module provides extensibility points for metrics collection, distributed tracing,
and performance monitoring without requiring immediate implementation.

Design Philosophy:
- Protocol-based: Easy to swap implementations (Prometheus, StatsD, OpenTelemetry, etc.)
- No-op defaults: Works immediately without configuration
- Decorator pattern: Minimal code changes to instrument existing functions
- Global registry: Single point of configuration

Usage:
    # In any service or tool:
    from utils.observability import get_metrics, track_performance

    @track_performance("tickets.lookup")
    async def get_ticket_details(ticket_id: str):
        get_metrics().increment("tickets.lookup.requested")
        # ... existing code
        return result

Future Implementation (Phase 2):
    # In main.py startup:
    if config.metrics_provider == "prometheus":
        from utils.prometheus_metrics import PrometheusMetrics
        set_metrics_collector(PrometheusMetrics())
"""

from typing import Protocol, Dict, Any, Optional, runtime_checkable
from functools import wraps
import time
import asyncio
import logging

logger = logging.getLogger(__name__)


# ============================================================================
# Metrics Collection Protocol
# ============================================================================

@runtime_checkable
class MetricsCollector(Protocol):
    """
    Protocol for metrics collection systems (Prometheus, StatsD, Datadog, etc.)

    All metrics implementations must provide these methods.
    """

    def increment(self, metric: str, value: float = 1.0, tags: Optional[Dict[str, str]] = None) -> None:
        """
        Increment a counter metric.

        Args:
            metric: Metric name (e.g., "tickets.created", "errors.database")
            value: Amount to increment (default: 1.0)
            tags: Optional tags/labels (e.g., {"status": "success", "client": "acme"})
        """
        ...

    def gauge(self, metric: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        """
        Set a gauge metric (point-in-time value).

        Args:
            metric: Metric name (e.g., "queue.size", "memory.usage")
            value: Current value
            tags: Optional tags/labels
        """
        ...

    def histogram(self, metric: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        """
        Record a histogram value (for distributions).

        Args:
            metric: Metric name (e.g., "query.size", "payload.bytes")
            value: Observed value
            tags: Optional tags/labels
        """
        ...

    def timing(self, metric: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        """
        Record a timing/duration metric (in seconds).

        Args:
            metric: Metric name (e.g., "api.latency", "db.query.duration")
            value: Duration in seconds
            tags: Optional tags/labels
        """
        ...


class NoOpMetrics:
    """
    Default no-op metrics implementation.

    This is the default collector that does nothing. Allows code to be instrumented
    immediately without requiring actual metrics infrastructure.
    """

    def increment(self, metric: str, value: float = 1.0, tags: Optional[Dict[str, str]] = None) -> None:
        pass

    def gauge(self, metric: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        pass

    def histogram(self, metric: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        pass

    def timing(self, metric: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        pass


# Global metrics instance (can be replaced at runtime)
_metrics_collector: MetricsCollector = NoOpMetrics()


def set_metrics_collector(collector: MetricsCollector) -> None:
    """
    Set the global metrics collector.

    Call this during application startup to enable real metrics collection.

    Example:
        from utils.prometheus_metrics import PrometheusMetrics
        set_metrics_collector(PrometheusMetrics())
    """
    global _metrics_collector
    _metrics_collector = collector
    logger.info(f"Metrics collector set to: {collector.__class__.__name__}")


def get_metrics() -> MetricsCollector:
    """
    Get the global metrics collector.

    Returns the current metrics collector (NoOp by default).
    """
    return _metrics_collector


# ============================================================================
# Distributed Tracing Protocol
# ============================================================================

@runtime_checkable
class TracingProvider(Protocol):
    """
    Protocol for distributed tracing systems (OpenTelemetry, Jaeger, Zipkin, etc.)

    All tracing implementations must provide these methods.
    """

    def start_span(self, name: str, parent: Any = None) -> Any:
        """
        Start a new tracing span.

        Args:
            name: Span name (e.g., "database.query", "http.request")
            parent: Optional parent span for nested traces

        Returns:
            Span object (implementation-specific)
        """
        ...

    def end_span(self, span: Any) -> None:
        """
        End a tracing span.

        Args:
            span: Span object returned from start_span()
        """
        ...

    def set_span_attribute(self, span: Any, key: str, value: Any) -> None:
        """
        Add an attribute to a span.

        Args:
            span: Span object
            key: Attribute name (e.g., "user.id", "query.type")
            value: Attribute value
        """
        ...

    def set_span_error(self, span: Any, error: Exception) -> None:
        """
        Mark a span as failed with error details.

        Args:
            span: Span object
            error: Exception that occurred
        """
        ...


class NoOpTracing:
    """
    Default no-op tracing implementation.

    This is the default provider that does nothing. Allows code to be instrumented
    immediately without requiring actual tracing infrastructure.
    """

    def start_span(self, name: str, parent: Any = None) -> Any:
        return None

    def end_span(self, span: Any) -> None:
        pass

    def set_span_attribute(self, span: Any, key: str, value: Any) -> None:
        pass

    def set_span_error(self, span: Any, error: Exception) -> None:
        pass


# Global tracing instance (can be replaced at runtime)
_tracing_provider: TracingProvider = NoOpTracing()


def set_tracing_provider(provider: TracingProvider) -> None:
    """
    Set the global tracing provider.

    Call this during application startup to enable real distributed tracing.

    Example:
        from utils.opentelemetry_tracing import OpenTelemetryTracing
        set_tracing_provider(OpenTelemetryTracing())
    """
    global _tracing_provider
    _tracing_provider = provider
    logger.info(f"Tracing provider set to: {provider.__class__.__name__}")


def get_tracing() -> TracingProvider:
    """
    Get the global tracing provider.

    Returns the current tracing provider (NoOp by default).
    """
    return _tracing_provider


# ============================================================================
# Performance Tracking Decorator
# ============================================================================

def track_performance(metric_name: str, track_args: bool = False):
    """
    Decorator to automatically track function performance and errors.

    This decorator:
    - Tracks execution duration (timing metric)
    - Tracks success/failure counts (increment metrics)
    - Creates distributed tracing spans
    - Logs performance warnings for slow operations
    - Works with both sync and async functions

    Args:
        metric_name: Base metric name (e.g., "tickets.lookup")
        track_args: If True, include function arguments in span attributes (default: False)

    Metrics created:
        - {metric_name}.duration - Execution time in seconds
        - {metric_name}.success - Success counter
        - {metric_name}.error - Error counter
        - {metric_name}.slow - Counter for operations > 1 second

    Example:
        @track_performance("tickets.lookup")
        async def get_ticket_details(ticket_id: str):
            # ... code ...
            return result
    """

    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()
            span = _tracing_provider.start_span(f"{func.__module__}.{func.__name__}")

            # Add function arguments to span if requested
            if track_args and span:
                try:
                    _tracing_provider.set_span_attribute(span, "function.args", str(args))
                    _tracing_provider.set_span_attribute(span, "function.kwargs", str(kwargs))
                except Exception as e:
                    logger.debug(f"Failed to add args to span: {e}")

            try:
                result = await func(*args, **kwargs)
                _metrics_collector.increment(f"{metric_name}.success")
                return result
            except Exception as e:
                _metrics_collector.increment(f"{metric_name}.error", tags={"error_type": e.__class__.__name__})
                _tracing_provider.set_span_error(span, e)
                raise
            finally:
                duration = time.time() - start_time
                _metrics_collector.timing(f"{metric_name}.duration", duration)

                # Track slow operations (> 1 second)
                if duration > 1.0:
                    _metrics_collector.increment(f"{metric_name}.slow")
                    logger.warning(f"Slow operation: {func.__name__} took {duration:.2f}s")

                _tracing_provider.end_span(span)

        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            start_time = time.time()
            span = _tracing_provider.start_span(f"{func.__module__}.{func.__name__}")

            # Add function arguments to span if requested
            if track_args and span:
                try:
                    _tracing_provider.set_span_attribute(span, "function.args", str(args))
                    _tracing_provider.set_span_attribute(span, "function.kwargs", str(kwargs))
                except Exception as e:
                    logger.debug(f"Failed to add args to span: {e}")

            try:
                result = func(*args, **kwargs)
                _metrics_collector.increment(f"{metric_name}.success")
                return result
            except Exception as e:
                _metrics_collector.increment(f"{metric_name}.error", tags={"error_type": e.__class__.__name__})
                _tracing_provider.set_span_error(span, e)
                raise
            finally:
                duration = time.time() - start_time
                _metrics_collector.timing(f"{metric_name}.duration", duration)

                # Track slow operations (> 1 second)
                if duration > 1.0:
                    _metrics_collector.increment(f"{metric_name}.slow")
                    logger.warning(f"Slow operation: {func.__name__} took {duration:.2f}s")

                _tracing_provider.end_span(span)

        # Return appropriate wrapper based on function type
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper

    return decorator


# ============================================================================
# Context Manager for Manual Tracing
# ============================================================================

class TraceContext:
    """
    Context manager for manual tracing of code blocks.

    Example:
        with TraceContext("database.batch_insert") as span:
            # ... code ...
            pass
    """

    def __init__(self, name: str, parent: Any = None):
        self.name = name
        self.parent = parent
        self.span = None

    def __enter__(self):
        self.span = _tracing_provider.start_span(self.name, self.parent)
        return self.span

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_val:
            _tracing_provider.set_span_error(self.span, exc_val)
        _tracing_provider.end_span(self.span)


# ============================================================================
# Utility Functions
# ============================================================================

def record_operation(metric_prefix: str, operation: str, success: bool = True,
                     duration: Optional[float] = None, tags: Optional[Dict[str, str]] = None) -> None:
    """
    Convenience function to record an operation's metrics.

    Args:
        metric_prefix: Metric namespace (e.g., "tickets", "database")
        operation: Operation name (e.g., "lookup", "insert")
        success: Whether operation succeeded
        duration: Optional duration in seconds
        tags: Optional metric tags
    """
    status = "success" if success else "error"
    metric_tags = tags or {}
    metric_tags["operation"] = operation
    metric_tags["status"] = status

    _metrics_collector.increment(f"{metric_prefix}.{operation}.{status}", tags=metric_tags)

    if duration is not None:
        _metrics_collector.timing(f"{metric_prefix}.{operation}.duration", duration, tags=metric_tags)


def is_observability_enabled() -> bool:
    """
    Check if observability is enabled (i.e., not using NoOp implementations).

    Returns:
        True if real metrics or tracing is configured
    """
    return not isinstance(_metrics_collector, NoOpMetrics) or not isinstance(_tracing_provider, NoOpTracing)
