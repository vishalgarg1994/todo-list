import time
import asyncio
import logging
from enum import Enum
from typing import Callable, Any, Optional
from functools import wraps


class CircuitState(Enum):
    """Circuit breaker states"""

    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Circuit is open, requests fail fast
    HALF_OPEN = "half_open"  # Testing if service is back


class CircuitBreakerOpenError(Exception):
    """Exception raised when circuit breaker is open"""

    pass


class CircuitBreaker:
    """Circuit breaker implementation for preventing cascade failures"""

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: int = 30,
        expected_exception: type = Exception,
        name: str = "default",
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception
        self.name = name

        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time = None
        self.state = CircuitState.CLOSED

        self.logger = logging.getLogger(f"{__name__}.{name}")

    async def call(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with circuit breaker protection"""

        # Check if circuit is open
        if self.state == CircuitState.OPEN:
            if self._should_attempt_reset():
                self.state = CircuitState.HALF_OPEN
                self.logger.info(
                    f"Circuit breaker {self.name} moved to HALF_OPEN state"
                )
            else:
                self.logger.warning(
                    f"Circuit breaker {self.name} is OPEN - failing fast",
                    extra={
                        "circuit_name": self.name,
                        "state": self.state.value,
                        "failure_count": self.failure_count,
                        "time_since_last_failure": time.time()
                        - (self.last_failure_time or 0),
                    },
                )
                raise CircuitBreakerOpenError(
                    f"Circuit breaker {self.name} is open. Service is unavailable."
                )

        # Execute the function
        try:
            result = (
                await func(*args, **kwargs)
                if asyncio.iscoroutinefunction(func)
                else func(*args, **kwargs)
            )
            self._on_success()
            return result

        except self.expected_exception:
            self._on_failure()
            raise
        except Exception as e:
            # Unexpected exceptions don't count as failures
            self.logger.error(
                f"Unexpected exception in circuit breaker {self.name}",
                extra={"circuit_name": self.name, "error": str(e)},
                exc_info=True,
            )
            raise

    def _should_attempt_reset(self) -> bool:
        """Check if enough time has passed to attempt reset"""
        if self.last_failure_time is None:
            return True
        return time.time() - self.last_failure_time >= self.recovery_timeout

    def _on_success(self):
        """Handle successful execution"""
        self.failure_count = 0

        if self.state == CircuitState.HALF_OPEN:
            self.success_count += 1
            # Reset to closed after a few successful calls
            if self.success_count >= 3:
                self.state = CircuitState.CLOSED
                self.success_count = 0
                self.logger.info(
                    f"Circuit breaker {self.name} reset to CLOSED state",
                    extra={"circuit_name": self.name, "state": self.state.value},
                )

    def _on_failure(self):
        """Handle failed execution"""
        self.failure_count += 1
        self.last_failure_time = time.time()
        self.success_count = 0  # Reset success count on any failure

        if self.failure_count >= self.failure_threshold:
            self.state = CircuitState.OPEN
            self.logger.error(
                f"Circuit breaker {self.name} opened due to failures",
                extra={
                    "circuit_name": self.name,
                    "state": self.state.value,
                    "failure_count": self.failure_count,
                    "failure_threshold": self.failure_threshold,
                },
            )

    def get_state(self) -> CircuitState:
        """Get current circuit breaker state"""
        return self.state

    def get_stats(self) -> dict:
        """Get circuit breaker statistics"""
        return {
            "name": self.name,
            "state": self.state.value,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "failure_threshold": self.failure_threshold,
            "recovery_timeout": self.recovery_timeout,
            "last_failure_time": self.last_failure_time,
            "time_since_last_failure": time.time() - (self.last_failure_time or 0)
            if self.last_failure_time
            else None,
        }

    def reset(self):
        """Manually reset the circuit breaker"""
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time = None
        self.logger.info(
            f"Circuit breaker {self.name} manually reset",
            extra={"circuit_name": self.name, "state": self.state.value},
        )


def circuit_breaker(
    failure_threshold: int = 5,
    recovery_timeout: int = 30,
    expected_exception: type = Exception,
    name: Optional[str] = None,
):
    """Decorator for applying circuit breaker pattern to functions"""

    def decorator(func: Callable) -> Callable:
        breaker_name = name or f"{func.__module__}.{func.__name__}"
        breaker = CircuitBreaker(
            failure_threshold=failure_threshold,
            recovery_timeout=recovery_timeout,
            expected_exception=expected_exception,
            name=breaker_name,
        )

        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            return await breaker.call(func, *args, **kwargs)

        @wraps(func)
        async def sync_wrapper(*args, **kwargs):
            return await breaker.call(func, *args, **kwargs)

        # Store breaker instance on function for monitoring
        wrapper = async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
        wrapper._circuit_breaker = breaker

        return wrapper

    return decorator


class CircuitBreakerRegistry:
    """Registry for managing multiple circuit breakers"""

    def __init__(self):
        self.breakers = {}
        self.logger = logging.getLogger(__name__)

    def register(self, breaker: CircuitBreaker):
        """Register a circuit breaker"""
        self.breakers[breaker.name] = breaker
        self.logger.info(f"Registered circuit breaker: {breaker.name}")

    def get_breaker(self, name: str) -> Optional[CircuitBreaker]:
        """Get a circuit breaker by name"""
        return self.breakers.get(name)

    def get_all_stats(self) -> dict:
        """Get statistics for all registered circuit breakers"""
        return {name: breaker.get_stats() for name, breaker in self.breakers.items()}

    def reset_all(self):
        """Reset all circuit breakers"""
        for breaker in self.breakers.values():
            breaker.reset()
        self.logger.info("Reset all circuit breakers")

    def get_open_breakers(self) -> list:
        """Get list of circuit breakers that are currently open"""
        return [
            name
            for name, breaker in self.breakers.items()
            if breaker.get_state() == CircuitState.OPEN
        ]


# Global registry instance
circuit_breaker_registry = CircuitBreakerRegistry()
