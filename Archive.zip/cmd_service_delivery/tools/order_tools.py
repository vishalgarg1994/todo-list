"""
MCP tools for CMD order queries - lookup, listing, and filtering.
"""

from typing import Any, Dict, List, Optional


async def get_order_details(order_id: int, services: dict) -> Dict[str, Any]:
    """
    Get full details for a specific CMD service order.
    Returns order info, service, segments, vendors, tasks, and notes.

    Args:
        order_id: The service order ID (PON number)
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order {id: $order_id})
        OPTIONAL MATCH (o)-[:HAS_SERVICE]->(s:Service)
        OPTIONAL MATCH (o)-[:BELONGS_TO_CLIENT]->(c:Client)
        OPTIONAL MATCH (o)-[:HAS_SEGMENT]->(seg:Segment)
        OPTIONAL MATCH (seg)-[:HAS_A_VENDOR]->(av:Vendor)
        OPTIONAL MATCH (seg)-[:HAS_Z_VENDOR]->(zv:Vendor)
        OPTIONAL MATCH (o)-[:HAS_TASK]->(t:Task)
        OPTIONAL MATCH (o)-[:HAS_NOTE]->(n:Note)
        RETURN o, s, c,
               collect(DISTINCT {seg: seg, a_vendor: av, z_vendor: zv}) AS segments,
               collect(DISTINCT t) AS tasks,
               collect(DISTINCT n) AS notes
    """, {"order_id": order_id})

    if not records:
        return {"error": f"Order {order_id} not found"}

    r = records[0]
    order_node = r.get("o")
    if not order_node:
        return {"error": f"Order {order_id} not found"}

    order_props = dict(order_node) if hasattr(order_node, '__iter__') else order_node

    service_node = r.get("s")
    client_node = r.get("c")

    result = {
        "order": order_props,
        "service": dict(service_node) if service_node else None,
        "client": dict(client_node) if client_node else None,
        "segments": [],
        "tasks": [],
        "notes": [],
    }

    for seg_info in r.get("segments", []):
        if isinstance(seg_info, dict) and seg_info.get("seg"):
            seg_data = dict(seg_info["seg"]) if hasattr(seg_info["seg"], '__iter__') else seg_info["seg"]
            av = dict(seg_info["a_vendor"]) if seg_info.get("a_vendor") else None
            zv = dict(seg_info["z_vendor"]) if seg_info.get("z_vendor") else None
            result["segments"].append({
                "segment": seg_data,
                "a_vendor": av,
                "z_vendor": zv,
            })

    for t in r.get("tasks", []):
        if t:
            result["tasks"].append(dict(t) if hasattr(t, '__iter__') else t)

    for n in r.get("notes", []):
        if n:
            result["notes"].append(dict(n) if hasattr(n, '__iter__') else n)

    return result


async def list_orders(limit: int = 50, services: dict = None) -> List[Dict[str, Any]]:
    """
    List all CMD service orders with summary info.

    Args:
        limit: Maximum number of orders to return (default 50)
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order)
        OPTIONAL MATCH (o)-[:HAS_SERVICE]->(s:Service)
        OPTIONAL MATCH (o)-[:HAS_SEGMENT]->(seg:Segment)
        RETURN o.id AS order_id,
               o.status_label AS status,
               o.status_main AS status_main,
               o.client_id AS client_id,
               s.service_type AS service_type,
               s.id AS service_id,
               count(DISTINCT seg) AS segment_count
        ORDER BY order_id DESC
        LIMIT $limit
    """, {"limit": limit})

    return records


async def get_orders_by_status(status: str, services: dict) -> List[Dict[str, Any]]:
    """
    Get all orders matching a given status label.

    Args:
        status: Status label to filter by (e.g. "Completed", "In Progress", "Active")
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order)
        WHERE toLower(o.status_label) CONTAINS toLower($status)
           OR toLower(o.status_main) CONTAINS toLower($status)
        OPTIONAL MATCH (o)-[:HAS_SERVICE]->(s:Service)
        RETURN o.id AS order_id,
               o.status_label AS status,
               o.latest_status AS latest_update,
               s.service_type AS service_type
        ORDER BY order_id DESC
    """, {"status": status})

    return records


async def get_orders_by_client(client_id: int, services: dict) -> List[Dict[str, Any]]:
    """
    Get all orders belonging to a specific client.

    Args:
        client_id: The client ID to look up
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order)-[:BELONGS_TO_CLIENT]->(c:Client {id: $client_id})
        OPTIONAL MATCH (o)-[:HAS_SERVICE]->(s:Service)
        OPTIONAL MATCH (o)-[:HAS_SEGMENT]->(seg:Segment)
        RETURN o.id AS order_id,
               o.status_label AS status,
               o.latest_status AS latest_update,
               s.service_type AS service_type,
               count(DISTINCT seg) AS segment_count
        ORDER BY order_id DESC
    """, {"client_id": client_id})

    return records


async def search_orders_by_field(
    field_name: str,
    field_value: str,
    services: dict,
) -> List[Dict[str, Any]]:
    """
    Search orders by any field value using pattern matching.

    Args:
        field_name: The Order property to search (e.g. "latest_status", "comments", "status_label")
        field_value: The value or pattern to match (case-insensitive partial match)
    """
    mg = services["memgraph_client"]

    allowed_fields = {
        "latest_status", "comments", "status_label", "status_main",
        "client_id", "id",
    }
    if field_name not in allowed_fields:
        return [{"error": f"Field '{field_name}' not allowed. Allowed: {allowed_fields}"}]

    if field_name in ("client_id", "id"):
        records = await mg.execute_and_fetch(f"""
            MATCH (o:Order)
            WHERE o.{field_name} = $value
            RETURN o.id AS order_id, o.status_label AS status, o.latest_status AS latest_update
        """, {"value": int(field_value)})
    else:
        records = await mg.execute_and_fetch(f"""
            MATCH (o:Order)
            WHERE toLower(o.{field_name}) CONTAINS toLower($pattern)
            RETURN o.id AS order_id, o.status_label AS status, o.latest_status AS latest_update
        """, {"pattern": field_value})

    return records


async def get_order_summary_stats(services: dict) -> Dict[str, Any]:
    """
    Get aggregate statistics across all orders:
    total count, breakdown by status, service type distribution.
    """
    mg = services["memgraph_client"]

    total = await mg.execute_and_fetch("MATCH (o:Order) RETURN count(o) AS total")

    by_status = await mg.execute_and_fetch("""
        MATCH (o:Order)
        RETURN o.status_label AS status, count(o) AS count
        ORDER BY count DESC
    """)

    by_service = await mg.execute_and_fetch("""
        MATCH (o:Order)-[:HAS_SERVICE]->(s:Service)
        RETURN s.service_type AS service_type, count(o) AS count
        ORDER BY count DESC
    """)

    return {
        "total_orders": total[0]["total"] if total else 0,
        "by_status": by_status,
        "by_service_type": by_service,
    }
