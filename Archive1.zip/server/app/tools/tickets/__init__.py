"""
Ticket-related tools for querying and analyzing tickets
"""

# Import functions are handled by direct imports to avoid circular dependencies
