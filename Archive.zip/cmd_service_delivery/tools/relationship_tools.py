"""
MCP tools for relational / graph traversal queries across CMD data.
"""

from typing import Any, Dict, List


async def get_order_relationships(order_id: int, services: dict) -> Dict[str, Any]:
    """
    Get the full relationship graph for an order: service, segments, vendors, tasks.
    Shows how entities are connected through the order's lifecycle.

    Args:
        order_id: The service order ID
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order {id: $order_id})
        OPTIONAL MATCH (o)-[:HAS_SERVICE]->(s:Service)
        OPTIONAL MATCH (o)-[:HAS_SEGMENT]->(seg:Segment)
        OPTIONAL MATCH (seg)-[:HAS_A_VENDOR]->(av:Vendor)
        OPTIONAL MATCH (seg)-[:HAS_Z_VENDOR]->(zv:Vendor)
        OPTIONAL MATCH (o)-[:HAS_TASK]->(t:Task)
        OPTIONAL MATCH (o)-[:BELONGS_TO_CLIENT]->(c:Client)
        RETURN o.id AS order_id,
               o.status_label AS status,
               s.id AS service_id,
               s.service_type AS service_type,
               c.id AS client_id,
               collect(DISTINCT {
                   segment_id: seg.id,
                   a_company: seg.a_company_name,
                   z_company: seg.z_company_name,
                   a_vendor_id: av.id,
                   a_vendor_name: av.name,
                   z_vendor_id: zv.id,
                   z_vendor_name: zv.name
               }) AS segments,
               collect(DISTINCT {
                   task_id: t.task_id,
                   summary: t.summary,
                   status: t.status
               }) AS tasks
    """, {"order_id": order_id})

    if not records:
        return {"error": f"Order {order_id} not found"}

    return records[0]


async def trace_order_to_vendors(order_id: int, services: dict) -> Dict[str, Any]:
    """
    Trace the full path from an order through its service and segments to all vendors.
    Shows the complete delivery chain.

    Args:
        order_id: The service order ID
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o:Order {id: $order_id})-[:HAS_SEGMENT]->(seg:Segment)
        OPTIONAL MATCH (o)-[:HAS_SERVICE]->(s:Service)
        OPTIONAL MATCH (seg)-[:HAS_A_VENDOR]->(av:Vendor)
        OPTIONAL MATCH (seg)-[:HAS_Z_VENDOR]->(zv:Vendor)
        RETURN o.id AS order_id,
               s.id AS service_id,
               s.service_type AS service_type,
               seg.id AS segment_id,
               seg.a_company_name AS a_end,
               seg.z_company_name AS z_end,
               seg.vendor_circuit_id AS vendor_circuit,
               av.id AS a_vendor_id,
               av.name AS a_vendor_name,
               zv.id AS z_vendor_id,
               zv.name AS z_vendor_name
    """, {"order_id": order_id})

    return {"order_id": order_id, "delivery_chain": records}


async def get_vendor_impact(vendor_id: int, services: dict) -> Dict[str, Any]:
    """
    Analyze a vendor's impact across all orders. Shows all orders and segments
    where this vendor is involved, with status breakdown.

    Args:
        vendor_id: The vendor ID
    """
    mg = services["memgraph_client"]

    # Overall stats
    stats = await mg.execute_and_fetch("""
        MATCH (v:Vendor {id: $vendor_id})<-[:HAS_A_VENDOR|HAS_Z_VENDOR]-(seg:Segment)<-[:HAS_SEGMENT]-(o:Order)
        RETURN v.name AS vendor_name,
               count(DISTINCT o) AS total_orders,
               count(DISTINCT seg) AS total_segments,
               collect(DISTINCT o.status_label) AS order_statuses
    """, {"vendor_id": vendor_id})

    # Per-order breakdown
    orders = await mg.execute_and_fetch("""
        MATCH (v:Vendor {id: $vendor_id})<-[:HAS_A_VENDOR|HAS_Z_VENDOR]-(seg:Segment)<-[:HAS_SEGMENT]-(o:Order)
        RETURN o.id AS order_id,
               o.status_label AS status,
               collect(DISTINCT seg.id) AS segment_ids
        ORDER BY order_id DESC
    """, {"vendor_id": vendor_id})

    return {
        "summary": stats[0] if stats else {},
        "orders": orders,
    }


async def get_client_order_graph(client_id: int, services: dict) -> Dict[str, Any]:
    """
    Get the full relationship graph for a client: all their orders with services,
    segments, and vendors.

    Args:
        client_id: The client ID
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (c:Client {id: $client_id})<-[:BELONGS_TO_CLIENT]-(o:Order)
        OPTIONAL MATCH (o)-[:HAS_SERVICE]->(s:Service)
        OPTIONAL MATCH (o)-[:HAS_SEGMENT]->(seg:Segment)
        OPTIONAL MATCH (seg)-[:HAS_A_VENDOR]->(v:Vendor)
        RETURN o.id AS order_id,
               o.status_label AS status,
               s.service_type AS service_type,
               collect(DISTINCT {
                   segment_id: seg.id,
                   vendor_name: v.name,
                   a_company: seg.a_company_name,
                   z_company: seg.z_company_name
               }) AS segments
        ORDER BY order_id DESC
    """, {"client_id": client_id})

    return {"client_id": client_id, "orders": records}


async def find_orders_sharing_vendor(order_id: int, services: dict) -> List[Dict[str, Any]]:
    """
    Find other orders that share the same vendor(s) as a given order.
    Useful for understanding vendor dependencies and potential impact.

    Args:
        order_id: The reference order ID
    """
    mg = services["memgraph_client"]

    records = await mg.execute_and_fetch("""
        MATCH (o1:Order {id: $order_id})-[:HAS_SEGMENT]->(seg1:Segment)-[:HAS_A_VENDOR|HAS_Z_VENDOR]->(v:Vendor)
        MATCH (v)<-[:HAS_A_VENDOR|HAS_Z_VENDOR]-(seg2:Segment)<-[:HAS_SEGMENT]-(o2:Order)
        WHERE o2.id <> o1.id
        RETURN DISTINCT o2.id AS order_id,
               o2.status_label AS status,
               v.name AS shared_vendor,
               v.id AS vendor_id
        ORDER BY order_id DESC
    """, {"order_id": order_id})

    return records
