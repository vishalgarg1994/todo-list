"""
ServiceNow API Client
Fetches notes, emails, and field_changes for resolved tickets.

Supports ticket types: case, incident, problem, request
Each type uses the same endpoint pattern but with different table names.
"""
import logging
import asyncio
import time
import aiohttp
import xml.etree.ElementTree as ET
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from urllib.parse import urlparse

from configs.config import Config


@dataclass
class NoteRecord:
    """A single note/comment from ServiceNow"""
    note_text: str
    created_on: str
    element_type: str  # work_notes, comments, comms, resolution_notes


@dataclass
class EmailRecord:
    """A single email from ServiceNow"""
    subject: str
    from_address: str
    to_address: str
    body: str
    created_on: str
    email_type: str  # sent, received


@dataclass
class FieldChangeRecord:
    """A single field change from ServiceNow"""
    field_name: str
    old_value: Optional[str]
    new_value: Optional[str]
    created_on: str


@dataclass
class TicketNotesData:
    """Combined notes data for a single ticket"""
    ticket_sys_id: str
    ticket_id: str
    ticket_type: str
    notes: List[NoteRecord] = field(default_factory=list)
    emails: List[EmailRecord] = field(default_factory=list)
    field_changes: List[FieldChangeRecord] = field(default_factory=list)
    fetch_success: bool = True
    error_message: Optional[str] = None


class ServiceNowClient:
    """
    Async client for fetching ticket notes from ServiceNow API.

    Endpoints:
    - /cases/{sys_id}/notes
    - /cases/{sys_id}/emails
    - /cases/{sys_id}/field_changes

    Similar pattern for incidents, problems, requests.
    """

    # Endpoint patterns by ticket type
    ENDPOINT_PATTERNS = {
        "case": {
            "notes": "/cases/{sys_id}/notes",
            "emails": "/cases/{sys_id}/emails",
            "field_changes": "/cases/{sys_id}/field_changes"
        },
        "incident": {
            "notes": "/incidents/{sys_id}/notes",
            "emails": "/incidents/{sys_id}/emails",
            "field_changes": "/incidents/{sys_id}/field_changes"
        },
        "problem": {
            "notes": "/problems/{sys_id}/notes",
            "emails": "/problems/{sys_id}/emails",
            "field_changes": "/problems/{sys_id}/field_changes"
        },
        "request": {
            "notes": "/requests/{sys_id}/notes",
            "emails": "/requests/{sys_id}/emails",
            "field_changes": "/requests/{sys_id}/field_changes"
        }
    }

    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.logger = logging.getLogger(__name__)

        # ServiceNow config (loaded from environment)
        self.base_url = self.config.servicenow_base_url
        self.username = self.config.servicenow_username
        self.password = self.config.servicenow_password
        self.client_id = self.config.servicenow_client_id
        self.client_secret = self.config.servicenow_client_secret
        self.timeout = self.config.servicenow_timeout
        self.max_concurrent = self.config.servicenow_max_concurrent

        self._session: Optional[aiohttp.ClientSession] = None
        self._semaphore: Optional[asyncio.Semaphore] = None
        self._access_token: Optional[str] = None
        self._token_expiry: float = 0

        self._use_oauth = bool(self.client_id and self.client_secret)
        if self._use_oauth:
            self.logger.info("ServiceNow auth: OAuth2 (client_id set)")
        else:
            self.logger.info("ServiceNow auth: Basic Auth")

    async def _fetch_oauth_token(self):
        """Fetch OAuth2 access token from ServiceNow"""
        parsed = urlparse(self.base_url)
        token_url = f"{parsed.scheme}://{parsed.netloc}/oauth_token.do"

        data = {
            "grant_type": "password",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "username": self.username,
            "password": self.password,
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(token_url, data=data) as resp:
                if resp.status != 200:
                    body = await resp.text()
                    raise RuntimeError(f"OAuth2 token request failed ({resp.status}): {body}")
                result = await resp.json()
                self._access_token = result["access_token"]
                expires_in = int(result.get("expires_in", 1800))
                self._token_expiry = time.time() + expires_in - 60
                self.logger.info(f"OAuth2 token acquired, expires in {expires_in}s")

    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session with OAuth2 or Basic Auth"""
        if self._use_oauth:
            if self._access_token is None or time.time() >= self._token_expiry:
                await self._fetch_oauth_token()
            if self._session is not None and not self._session.closed:
                await self._session.close()
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self._session = aiohttp.ClientSession(
                timeout=timeout,
                headers={
                    "Accept": "application/xml",
                    "Authorization": f"Bearer {self._access_token}",
                }
            )
        elif self._session is None or self._session.closed:
            auth = aiohttp.BasicAuth(self.username, self.password)
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self._session = aiohttp.ClientSession(
                auth=auth,
                timeout=timeout,
                headers={"Accept": "application/xml"}
            )
        return self._session

    async def _get_semaphore(self) -> asyncio.Semaphore:
        """Get or create semaphore for concurrency control"""
        if self._semaphore is None:
            self._semaphore = asyncio.Semaphore(self.max_concurrent)
        return self._semaphore

    async def close(self):
        """Close the aiohttp session"""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None

    def _get_endpoints(self, ticket_type: str, sys_id: str) -> Dict[str, str]:
        """Get the API endpoints for a ticket type and sys_id"""
        patterns = self.ENDPOINT_PATTERNS.get(ticket_type)
        if not patterns:
            raise ValueError(f"Unknown ticket type: {ticket_type}")

        return {
            key: self.base_url + pattern.format(sys_id=sys_id)
            for key, pattern in patterns.items()
        }

    async def _fetch_xml(self, url: str) -> Optional[ET.Element]:
        """Fetch XML from a URL and parse it

        Returns:
            ET.Element on success, None on 404 (no data), raises on other errors
        """
        session = await self._get_session()
        semaphore = await self._get_semaphore()

        async with semaphore:
            try:
                async with session.get(url) as response:
                    if response.status == 200:
                        text = await response.text()
                        return ET.fromstring(text)
                    elif response.status == 404:
                        # No data found is not an error
                        self.logger.debug(f"No data found at {url}")
                        return None
                    else:
                        # 400, 401, 403, 500, etc. are real errors
                        self.logger.warning(f"HTTP {response.status} from {url}")
                        raise aiohttp.ClientResponseError(
                            response.request_info,
                            response.history,
                            status=response.status,
                            message=f"HTTP {response.status}"
                        )
            except asyncio.TimeoutError:
                self.logger.error(f"Timeout fetching {url}")
                return None
            except aiohttp.ClientError as e:
                self.logger.error(f"HTTP error fetching {url}: {e}")
                return None
            except ET.ParseError as e:
                self.logger.error(f"XML parse error from {url}: {e}")
                return None

    def _parse_notes(self, xml_root: Optional[ET.Element]) -> List[NoteRecord]:
        """Parse notes XML response"""
        notes = []
        if xml_root is None:
            return notes

        for data in xml_root.findall(".//data"):
            note_text = self._get_text(data, "note")
            created_on = self._get_text(data, "created_on")
            element_type = self._get_text(data, "element") or "work_notes"

            if note_text:
                notes.append(NoteRecord(
                    note_text=note_text,
                    created_on=created_on or "",
                    element_type=element_type
                ))

        return notes

    def _parse_emails(self, xml_root: Optional[ET.Element]) -> List[EmailRecord]:
        """Parse emails XML response"""
        emails = []
        if xml_root is None:
            return emails

        for data in xml_root.findall(".//data"):
            subject = self._get_text(data, "subject")
            from_addr = self._get_text(data, "from")
            to_addr = self._get_text(data, "to")
            body = self._get_text(data, "body")
            created_on = self._get_text(data, "created_on")
            email_type = self._get_text(data, "type") or "sent"

            if body or subject:
                emails.append(EmailRecord(
                    subject=subject or "",
                    from_address=from_addr or "",
                    to_address=to_addr or "",
                    body=body or "",
                    created_on=created_on or "",
                    email_type=email_type
                ))

        return emails

    def _parse_field_changes(self, xml_root: Optional[ET.Element]) -> List[FieldChangeRecord]:
        """Parse field_changes XML response"""
        changes = []
        if xml_root is None:
            return changes

        for data in xml_root.findall(".//data"):
            field_name = self._get_text(data, "field")
            old_value = self._get_text(data, "old_value")
            new_value = self._get_text(data, "new_value")
            created_on = self._get_text(data, "created_on")

            if field_name:
                # Normalize "null" strings to None
                if old_value == "null":
                    old_value = None
                if new_value == "null":
                    new_value = None

                changes.append(FieldChangeRecord(
                    field_name=field_name,
                    old_value=old_value,
                    new_value=new_value,
                    created_on=created_on or ""
                ))

        return changes

    @staticmethod
    def _get_text(element: ET.Element, tag: str) -> Optional[str]:
        """Safely get text content from an XML element"""
        child = element.find(tag)
        if child is not None and child.text:
            return child.text.strip()
        return None

    async def fetch_ticket_notes(
        self,
        ticket_sys_id: str,
        ticket_id: str,
        ticket_type: str
    ) -> TicketNotesData:
        """
        Fetch all notes data for a single ticket.

        Args:
            ticket_sys_id: ServiceNow sys_id
            ticket_id: Human-readable ticket ID (INC*, CS*, etc.)
            ticket_type: One of 'case', 'incident', 'problem', 'request'

        Returns:
            TicketNotesData with notes, emails, and field_changes
        """
        result = TicketNotesData(
            ticket_sys_id=ticket_sys_id,
            ticket_id=ticket_id,
            ticket_type=ticket_type
        )

        try:
            endpoints = self._get_endpoints(ticket_type, ticket_sys_id)
        except ValueError as e:
            result.fetch_success = False
            result.error_message = str(e)
            return result

        try:
            # Fetch all 3 endpoints in parallel
            notes_task = self._fetch_xml(endpoints["notes"])
            emails_task = self._fetch_xml(endpoints["emails"])
            changes_task = self._fetch_xml(endpoints["field_changes"])

            notes_xml, emails_xml, changes_xml = await asyncio.gather(
                notes_task, emails_task, changes_task,
                return_exceptions=True
            )

            # Parse results (handle exceptions from gather)
            if isinstance(notes_xml, Exception):
                self.logger.error(f"Notes fetch error for {ticket_id}: {notes_xml}")
                notes_xml = None
            if isinstance(emails_xml, Exception):
                self.logger.error(f"Emails fetch error for {ticket_id}: {emails_xml}")
                emails_xml = None
            if isinstance(changes_xml, Exception):
                self.logger.error(f"Field changes fetch error for {ticket_id}: {changes_xml}")
                changes_xml = None

            result.notes = self._parse_notes(notes_xml)
            result.emails = self._parse_emails(emails_xml)
            result.field_changes = self._parse_field_changes(changes_xml)

            self.logger.debug(
                f"Fetched {ticket_id}: {len(result.notes)} notes, "
                f"{len(result.emails)} emails, {len(result.field_changes)} field_changes"
            )


        except Exception as e:
            self.logger.error(f"Error fetching notes for {ticket_id}: {e}")
            result.fetch_success = False
            result.error_message = str(e)

        return result

    async def fetch_batch(
        self,
        tickets: List[Dict[str, str]]
    ) -> List[TicketNotesData]:
        """
        Fetch notes for a batch of tickets.

        Args:
            tickets: List of dicts with 'ticket_sys_id', 'ticket_id', 'ticket_type'

        Returns:
            List of TicketNotesData for each ticket
        """
        tasks = [
            self.fetch_ticket_notes(
                ticket["ticket_sys_id"],
                ticket["ticket_id"],
                ticket["ticket_type"]
            )
            for ticket in tickets
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Handle any exceptions
        processed_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                ticket = tickets[i]
                self.logger.error(f"Batch fetch error for {ticket['ticket_id']}: {result}")
                processed_results.append(TicketNotesData(
                    ticket_sys_id=ticket["ticket_sys_id"],
                    ticket_id=ticket["ticket_id"],
                    ticket_type=ticket["ticket_type"],
                    fetch_success=False,
                    error_message=str(result)
                ))
            else:
                processed_results.append(result)

        # Log summary by ticket type
        from collections import defaultdict
        stats = defaultdict(lambda: {"success": 0, "failed": 0, "notes": 0, "emails": 0, "field_changes": 0})

        for r in processed_results:
            t = stats[r.ticket_type]
            if r.fetch_success:
                t["success"] += 1
                t["notes"] += len(r.notes)
                t["emails"] += len(r.emails)
                t["field_changes"] += len(r.field_changes)
            else:
                t["failed"] += 1

        total_success = sum(s["success"] for s in stats.values())
        total_failed = sum(s["failed"] for s in stats.values())

        self.logger.info(f"Batch fetch complete: {total_success} succeeded, {total_failed} failed")
        for ticket_type, s in stats.items():
            self.logger.info(
                f"  {ticket_type}: {s['success']} succeeded, {s['failed']} failed | "
                f"{s['notes']} notes, {s['emails']} emails, {s['field_changes']} field_changes"
            )

        return processed_results

    def combine_for_extraction(self, data: TicketNotesData) -> str:
        """
        Combine notes, emails, and field_changes into a single text for LLM extraction.

        Args:
            data: TicketNotesData from fetch_ticket_notes

        Returns:
            Combined text suitable for LLM context
        """
        sections = []

        # Header
        sections.append(f"=== TICKET: {data.ticket_id} ({data.ticket_type}) ===\n")

        # Notes section
        if data.notes:
            sections.append("--- NOTES ---")
            for note in sorted(data.notes, key=lambda n: n.created_on):
                sections.append(f"[{note.created_on}] ({note.element_type})")
                sections.append(note.note_text)
                sections.append("")

        # Emails section (strip HTML for cleaner text)
        if data.emails:
            sections.append("--- EMAILS ---")
            for email in sorted(data.emails, key=lambda e: e.created_on):
                sections.append(f"[{email.created_on}] {email.email_type.upper()}")
                sections.append(f"Subject: {email.subject}")
                sections.append(f"From: {email.from_address}")
                sections.append(f"To: {email.to_address}")
                # Simple HTML tag stripping
                body = self._strip_html_tags(email.body)
                sections.append(body[:2000] if len(body) > 2000 else body)  # Truncate long emails
                sections.append("")

        # Field changes section (focus on key fields)
        key_fields = {
            "state", "u_alarm_status", "u_alarm_information", "u_alarm_history",
            "resolved_at", "work_end", "u_responsible_party", "resolution_code",
            "close_notes", "assigned_to", "priority"
        }

        if data.field_changes:
            relevant_changes = [
                fc for fc in data.field_changes
                if fc.field_name in key_fields and fc.old_value
            ]

            if relevant_changes:
                sections.append("--- KEY FIELD CHANGES ---")
                for fc in sorted(relevant_changes, key=lambda f: f.created_on):
                    sections.append(
                        f"[{fc.created_on}] {fc.field_name}: "
                        f"{fc.old_value[:100] if fc.old_value else 'null'} → "
                        f"{fc.new_value[:100] if fc.new_value else 'null'}"
                    )
                sections.append("")

        return "\n".join(sections)

    @staticmethod
    def _strip_html_tags(text: str) -> str:
        """Remove HTML tags from text (simple implementation)"""
        import re
        # Remove script/style content
        text = re.sub(r'<(script|style)[^>]*>.*?</\1>', '', text, flags=re.DOTALL | re.IGNORECASE)
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', ' ', text)
        # Clean up whitespace
        text = re.sub(r'\s+', ' ', text)
        return text.strip()
