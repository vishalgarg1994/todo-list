"""
FastAPI REST API server for Eva NATS Stream Manager
Provides HTTP endpoints for stream management operations
"""

import logging
from typing import List, Dict, Any
from fastapi import FastAPI, HTTPException, status
import uvicorn

from stream_manager import NatsStreamManager
from config import Config

logger = logging.getLogger(__name__)


class StreamManagerAPI:
    """REST API server for NATS stream management"""

    def __init__(self, config: Config):
        self.config = config
        self.app = FastAPI(
            title="Eva NATS Stream Manager API",
            description="REST API for managing NATS JetStream streams in Eva messaging infrastructure",
            version="1.0.0"
        )
        self.stream_manager = NatsStreamManager(config)
        self._setup_routes()

    def _setup_routes(self):
        """Setup API routes"""

        @self.app.get("/health", tags=["Health"])
        async def health_check():
            """Health check endpoint"""
            return {"status": "healthy", "service": "Eva NATS Stream Manager"}

        @self.app.post("/streams/create-all", response_model=List[Dict[str, Any]], tags=["Streams"])
        async def create_all_streams():
            """Create all Eva messaging infrastructure streams"""
            try:
                await self.stream_manager.connect()
                results = await self.stream_manager.create_eva_streams()
                return results
            except Exception as e:
                logger.error(f"Failed to create streams: {e}")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to create streams: {str(e)}"
                )
            finally:
                await self.stream_manager.disconnect()

        @self.app.post("/streams/{stream_name}", response_model=Dict[str, Any], tags=["Streams"])
        async def create_stream(stream_name: str):
            """Create a specific stream"""
            # Stream definitions map
            stream_definitions = {
                "EVA_TICKETING_STREAM": {
                    "name": "EVA_TICKETING_STREAM",
                    "subjects": ["tickets.*", "incidents.*", "maintenance.*"],
                    "description": "Eva Group Ticketing - tickets, incidents, and maintenance events",
                    "max_age": 72 * 60 * 60,
                    "max_msgs": 100000,
                    "max_bytes": 104857600,
                },
                "EVA_ANALYTICS_STREAM": {
                    "name": "EVA_ANALYTICS_STREAM",
                    "subjects": ["analytics.*", "metrics.*", "reports.*"],
                    "description": "Eva Group Analytics - metrics, reports, and business intelligence",
                    "max_age": 30 * 24 * 60 * 60,
                    "max_msgs": 1000000,
                    "max_bytes": 1073741824,
                },
            }

            if stream_name not in stream_definitions:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Stream definition not found: {stream_name}"
                )

            try:
                await self.stream_manager.connect()
                result = await self.stream_manager.create_stream(stream_definitions[stream_name])
                return result
            except Exception as e:
                logger.error(f"Failed to create stream {stream_name}: {e}")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to create stream: {str(e)}"
                )
            finally:
                await self.stream_manager.disconnect()

        @self.app.get("/streams", response_model=List[Dict[str, Any]], tags=["Streams"])
        async def list_streams():
            """List all NATS streams"""
            try:
                await self.stream_manager.connect()
                streams = await self.stream_manager.list_streams()
                return streams
            except Exception as e:
                logger.error(f"Failed to list streams: {e}")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to list streams: {str(e)}"
                )
            finally:
                await self.stream_manager.disconnect()

        @self.app.get("/streams/{stream_name}", response_model=Dict[str, Any], tags=["Streams"])
        async def get_stream_info(stream_name: str):
            """Get detailed information about a specific stream"""
            try:
                await self.stream_manager.connect()
                stream_info = await self.stream_manager.get_stream_info(stream_name)
                if not stream_info:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"Stream not found: {stream_name}"
                    )
                return stream_info
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"Failed to get stream info for {stream_name}: {e}")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to get stream info: {str(e)}"
                )
            finally:
                await self.stream_manager.disconnect()

        @self.app.delete("/streams/{stream_name}", response_model=Dict[str, Any], tags=["Streams"])
        async def delete_stream(stream_name: str):
            """Delete a specific stream"""
            try:
                await self.stream_manager.connect()
                success = await self.stream_manager.delete_stream(stream_name)
                if success:
                    return {"message": f"Stream {stream_name} deleted successfully"}
                else:
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail=f"Failed to delete stream: {stream_name}"
                    )
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"Failed to delete stream {stream_name}: {e}")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to delete stream: {str(e)}"
                )
            finally:
                await self.stream_manager.disconnect()

        @self.app.get("/streams/validate/required", response_model=Dict[str, Any], tags=["Validation"])
        async def validate_required_streams():
            """Validate that all required Eva streams exist"""
            try:
                await self.stream_manager.connect()
                validation_results = await self.stream_manager.validate_required_streams()
                return validation_results
            except Exception as e:
                logger.error(f"Stream validation failed: {e}")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Stream validation failed: {str(e)}"
                )
            finally:
                await self.stream_manager.disconnect()

    async def start_server(self, host: str = "0.0.0.0", port: int = 8080):
        """Start the FastAPI server"""
        config = uvicorn.Config(
            self.app,
            host=host,
            port=port,
            log_level="info"
        )
        server = uvicorn.Server(config)
        await server.serve()
