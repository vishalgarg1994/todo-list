#!/usr/bin/env python3
"""
Interactive MCP Tool Tester
Provides a menu-driven interface to test all ticket tools
"""
import httpx
import asyncio
import json
import sys
from typing import Dict, Any


async def call_tool(server_url: str, tool_name: str, params: Dict[str, Any]) -> Dict:
    """Call an MCP tool and return the response"""
    # FastMCP 2.9.x uses Streamable HTTP - direct tool endpoint
    tool_url = f"{server_url}/mcp/tools/{tool_name}"

    print(f"\n{'='*70}")
    print(f"🔧 Calling Tool: {tool_name}")
    print(f"📤 Parameters:")
    print(json.dumps(params, indent=2))
    print(f"{'='*70}")

    # FastMCP HTTP mode requires JSON-RPC format with proper Accept headers
    headers = {"Accept": "application/json, text/event-stream"}

    # Wrap parameters in JSON-RPC format
    jsonrpc_request = {
        "jsonrpc": "2.0",
        "method": "tools/call",
        "params": {
            "name": tool_name,
            "arguments": params
        },
        "id": 1
    }

    # FastMCP returns Server-Sent Events (SSE) format for all tool calls
    is_streaming = True

    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            if is_streaming:
                # Handle streaming response
                print(f"\n📡 Streaming response...\n")

                captured_result = None  # Capture the actual result data

                async with client.stream("POST", tool_url, json=jsonrpc_request, headers=headers) as response:
                    if response.status_code != 200:
                        # Read error response
                        error_text = await response.aread()
                        print(f"❌ HTTP ERROR: {response.status_code}")
                        try:
                            error_data = json.loads(error_text)
                            print(json.dumps(error_data, indent=2))
                        except:
                            print(error_text.decode())
                        return None

                    async for line in response.aiter_lines():
                        if line.startswith("data:"):
                            data_str = line[5:].strip()
                            if data_str:
                                try:
                                    data = json.loads(data_str)
                                    # Handle MCP JSON-RPC response format
                                    if "result" in data:
                                        result = data["result"]
                                        if "isError" in result and result["isError"]:
                                            # Error response
                                            content = result.get("content", [{}])[0]
                                            error_text = content.get("text", str(result))
                                            print(f"❌ ERROR: {error_text}")
                                        elif "content" in result:
                                            # Success response - extract actual data
                                            content = result.get("content", [{}])[0]
                                            result_text = content.get("text", "")
                                            try:
                                                # Try to parse as JSON for pretty printing
                                                result_data = json.loads(result_text)
                                                print(json.dumps(result_data, indent=2))
                                                captured_result = result_data  # Capture for return
                                            except:
                                                # Plain text result
                                                print(result_text)
                                                captured_result = result_text
                                    elif "error" in data:
                                        # JSON-RPC error
                                        print(f"❌ JSON-RPC Error: {data['error'].get('message', data['error'])}")
                                    elif "row" in data:
                                        print(json.dumps(data["row"], indent=2))
                                    elif "message" in data:
                                        print(f"ℹ️  {data['message']}")
                                    elif "status" in data:
                                        print(f"Status: {data['status']}")
                                except json.JSONDecodeError:
                                    print(f"Data: {data_str}")

                print(f"\n✅ Stream completed\n")
                return captured_result if captured_result else {"status": "streamed"}
            else:
                # Handle regular JSON response
                response = await client.post(tool_url, json=jsonrpc_request, headers=headers)
                response.raise_for_status()

                result = response.json()
                print(f"\n✅ SUCCESS\n")
                print(f"📥 Response:")
                print(json.dumps(result, indent=2, default=str))
                return result

    except httpx.HTTPStatusError as e:
        print(f"\n❌ HTTP ERROR: {e.response.status_code}")
        try:
            error_detail = e.response.json()
            print(json.dumps(error_detail, indent=2))
        except:
            print(e.response.text)
        return None
    except Exception as e:
        print(f"\n❌ ERROR: {type(e).__name__}: {e}")
        return None


async def audit_resolution_fields(
    server_url: str,
    ticket_number: str = None,
    min_confidence: float = 0.8
) -> Dict:
    """
    Audit ticket resolution fields - compare extracted vs recorded values.
    Shows discrepancies in priority, MTTR, responsible party, fault type.

    This is a client-side compound function that calls the MCP tool and formats
    the results for easy reading.

    Args:
        server_url: MCP server URL
        ticket_number: Optional specific ticket to audit (e.g., "INC0012345")
        min_confidence: Minimum confidence threshold (0.0-1.0)

    Returns:
        Formatted audit results
    """
    print(f"\n{'='*70}")
    print(f"📋 COMPOUND OPERATION: Audit Resolution Fields")
    if ticket_number:
        print(f"   Ticket: {ticket_number}")
    else:
        print(f"   All tickets with discrepancies")
    print(f"   Min Confidence: {min_confidence}")
    print(f"{'='*70}\n")

    # Call the get_extraction_discrepancies tool
    params = {"min_confidence": min_confidence}
    if ticket_number:
        params["ticket_number"] = ticket_number

    result = await call_tool(server_url, "get_extraction_discrepancies", params)

    if not result:
        print("❌ Failed to get extraction discrepancies")
        return None

    try:
        discrepancies = result.get("discrepancies", [])

        if not discrepancies:
            print(f"\n✅ No discrepancies found (confidence >= {min_confidence})")
            return result

        print(f"\n{'='*70}")
        print(f"📊 AUDIT RESULTS: {len(discrepancies)} ticket(s) with discrepancies")
        print(f"{'='*70}\n")

        for item in discrepancies:
            ticket = item.get("ticket", "Unknown")
            confidence = item.get("confidence", 0)
            evidence = item.get("evidence", "No evidence available")

            print(f"\n{'─'*60}")
            print(f"🎫 Ticket: {ticket}")
            print(f"   Confidence: {confidence:.0%}")
            print(f"{'─'*60}")

            # Show discrepancies
            for disc in item.get("discrepancies", []):
                field = disc.get("field", "unknown")
                extracted = disc.get("extracted", "N/A")
                original = disc.get("original", "N/A")
                print(f"   ⚠️  {field}:")
                print(f"      Extracted: {extracted}")
                print(f"      Original:  {original}")

            # Show evidence
            if evidence:
                print(f"\n   📝 Evidence:")
                for line in evidence.split('\n'):
                    if line.strip():
                        print(f"      {line.strip()}")

        print(f"\n{'='*70}")
        print(f"✅ AUDIT COMPLETE")
        print(f"{'='*70}\n")

        return result

    except Exception as e:
        print(f"❌ Error formatting results: {e}")
        return result


async def find_similar_faults_and_resolutions(
    server_url: str,
    ticket_id: str,
    top_k: int = 10,
    min_score: float = 0.7
) -> Dict:
    """
    Compound client-side function that finds similar faults and their resolutions.

    This calls two atomic MCP tools sequentially:
    1. find_similar_faults_by_ticket - gets similar tickets with fault descriptions
    2. get_ticket_resolutions - gets resolution details for those tickets

    Args:
        server_url: MCP server URL
        ticket_id: The ticket ID to find similar faults for
        top_k: Number of similar tickets to return
        min_score: Minimum similarity score (0.0-1.0)

    Returns:
        Combined result with query ticket, similar faults, and resolutions
    """
    print(f"\n{'='*70}")
    print(f"🔍 COMPOUND OPERATION: Find Similar Faults + Resolutions")
    print(f"   Ticket ID: {ticket_id}")
    print(f"   Top K: {top_k}, Min Score: {min_score}")
    print(f"{'='*70}\n")

    # Step 1: Find similar faults (vector search only)
    print("Step 1/2: Finding similar faults...")
    faults_result = await call_tool(
        server_url,
        "find_similar_faults_by_ticket",
        {"ticket_id": ticket_id, "top_k": top_k, "min_score": min_score}
    )

    if not faults_result:
        print("❌ Failed to find similar faults")
        return None

    # Parse the result (call_tool now returns actual data directly)
    try:
        faults_data = faults_result
        similar_tickets = faults_data.get("similar_tickets", [])
        query_ticket = faults_data.get("query_ticket", {})

        if not similar_tickets:
            print("ℹ️  No similar tickets found")
            return faults_data

        # Extract ticket IDs for resolution lookup
        ticket_ids = [ticket["fault_description_id"] for ticket in similar_tickets]

        print(f"\n✅ Found {len(similar_tickets)} similar tickets")
        print(f"   Ticket IDs: {', '.join(ticket_ids[:5])}{'...' if len(ticket_ids) > 5 else ''}\n")

        # Step 2: Get resolutions for those tickets
        print("Step 2/2: Getting resolution details...")
        resolutions_result = await call_tool(
            server_url,
            "get_ticket_resolutions",
            {"ticket_ids": ticket_ids}
        )

        if not resolutions_result:
            print("⚠️  Failed to get resolutions, returning fault data only")
            return faults_data

        # Parse resolutions result (call_tool returns actual data directly)
        resolutions_data = resolutions_result
        resolutions = resolutions_data.get("resolutions", [])

        print(f"\n✅ Retrieved resolution data for {len(resolutions)} tickets\n")

        # Combine fault data with resolutions
        combined_result = {
            "query_ticket": query_ticket,
            "total_similar_tickets": len(similar_tickets),
            "parameters": {
                "top_k": top_k,
                "min_score": min_score
            },
            "similar_tickets_with_resolutions": resolutions
        }

        print(f"\n{'='*70}")
        print(f"✅ COMPOUND OPERATION COMPLETE")
        print(f"{'='*70}\n")

        return combined_result

    except Exception as e:
        print(f"❌ Error processing results: {e}")
        return faults_result


# Tool definitions with parameter templates
# TSM ticket ID formats: INC (incident), CS (case), PRB (problem), SCTASK (request)
TOOLS = {
    "1": {
        "name": "ask_tickets_question",
        "description": "Natural language query",
        "params": {
            "user_query": "How many open incidents are there?"
        }
    },
    "2": {
        "name": "get_ticket_details",
        "description": "Get complete ticket details (any type)",
        "params": {
            "ticket_id": "INC9002148"
        }
    },
    "3": {
        "name": "get_client_tickets",
        "description": "Get all tickets for a client",
        "params": {
            "client_name": "GTT Network",
            "limit": 10
        }
    },
    "4": {
        "name": "get_client_summary",
        "description": "Get client statistics and summary",
        "params": {
            "client_name": "GTT Network"
        }
    },
    "5": {
        "name": "get_tickets_by_status",
        "description": "Filter tickets by status",
        "params": {
            "status": "Open",
            "limit": 10
        }
    },
    "6": {
        "name": "get_high_priority_tickets",
        "description": "Get urgent/high-priority tickets",
        "params": {
            "priority_threshold": 2,
            "limit": 10
        }
    },
    "7": {
        "name": "get_ticket_timeline",
        "description": "Get ticket lifecycle timeline (includes tasks)",
        "params": {
            "ticket_id": "CS0028143"
        }
    },
    "8": {
        "name": "get_ticket_relationships",
        "description": "Get related tickets (TSM hierarchy)",
        "params": {
            "ticket_id": "INC9002148"
        }
    },
    "9": {
        "name": "trace_ticket_root_cause",
        "description": "Trace ticket to root cause via TSM relationships",
        "params": {
            "ticket_id": "CS0028143"
        }
    },
    "10": {
        "name": "get_vendor_tickets",
        "description": "Get tickets handled by vendor",
        "params": {
            "vendor_name": "Lumen",
            "limit": 10
        }
    },
    "11": {
        "name": "get_service_outages",
        "description": "Get outages by service/technology",
        "params": {
            "technology": "Fiber",
            "limit": 10
        }
    },
    "12": {
        "name": "get_tickets_by_date_range",
        "description": "Get tickets in date range",
        "params": {
            "start_date": "2024-01-01",
            "end_date": "2025-12-31",
            "limit": 10
        }
    },
    "14": {
        "name": "get_sample_tickets",
        "description": "Get sample tickets (FAST - no LLM)",
        "params": {
            "limit": 5
        }
    },
    "15": {
        "name": "get_user_performance",
        "description": "📊 User productivity metrics",
        "params": {
            "status_filter": "Closed",
            "limit": 10
        }
    },
    "16": {
        "name": "get_vendor_impact",
        "description": "🏢 Vendor performance analysis",
        "params": {
            "limit": 10
        }
    },
    "17": {
        "name": "get_client_escalations",
        "description": "⚠️  Client escalation patterns",
        "params": {
            "min_escalation_level": 1,
            "limit": 10
        }
    },
    "18": {
        "name": "get_survey_satisfaction",
        "description": "⭐ Customer satisfaction analytics",
        "params": {
            "limit": 10
        }
    },
    "19": {
        "name": "get_maintenance_impact",
        "description": "🔧 Maintenance window impact",
        "params": {
            "limit": 10
        }
    },
    "20": {
        "name": "search_similar_faults",
        "description": "🔍 Search similar fault descriptions (Vector DB)",
        "params": {
            "query": "fiber cut outage",
            "top_k": 5
        }
    },
    "21": {
        "name": "search_similar_tickets",
        "description": "🔍 Search semantically similar tickets (Vector DB)",
        "params": {
            "query": "network connectivity issue",
            "top_k": 5
        }
    },
    "22": {
        "name": "search_similar_resolutions",
        "description": "🔍 Search similar resolutions (Vector DB)",
        "params": {
            "query": "replaced fiber cable",
            "top_k": 5
        }
    },
    "23": {
        "name": "search_similar_services",
        "description": "🔍 Search similar service impacts (Vector DB + Services)",
        "params": {
            "query": "MPLS circuit high latency",
            "top_k": 5
        }
    },
    "24": {
        "name": "search_similar_maintenance_windows",
        "description": "🔍 Search similar maintenance-related issues (Vector DB + Maintenance)",
        "params": {
            "query": "service degradation during upgrade",
            "top_k": 5
        }
    },
    "25": {
        "name": "search_similar_engineers",
        "description": "🔍 Search by team expertise (Vector DB + Engineers)",
        "params": {
            "query": "complex routing configuration",
            "top_k": 5
        }
    },
    "26": {
        "name": "search_similar_vendors",
        "description": "🔍 Search vendor-involved issues (Vector DB + Vendors)",
        "params": {
            "query": "fiber damage requiring vendor repair",
            "top_k": 5
        }
    },
    "27": {
        "name": "search_similar_client_impacts",
        "description": "🔍 Search client impact patterns (Vector DB + Client/Contacts/Surveys)",
        "params": {
            "query": "major outage business-critical services",
            "top_k": 5
        }
    },
    "28": {
        "name": "find_similar_faults_by_ticket",
        "description": "🔍 Find similar faults by ticket ID (Vector DB only)",
        "params": {
            "ticket_id": "INC9002148",
            "top_k": 10,
            "min_score": 0.7
        }
    },
    "29": {
        "name": "get_ticket_resolutions",
        "description": "📋 Get resolution details for ticket list (Graph DB)",
        "params": {
            "ticket_ids": ["INC9002148", "CS0028143", "PRB0040854"]
        }
    },
    "30": {
        "name": "find_similar_faults_and_resolutions",
        "description": "🎯 COMPOUND: Find similar faults + resolutions (calls #28 + #29)",
        "params": {
            "ticket_id": "INC9002148",
            "top_k": 10,
            "min_score": 0.7
        },
        "is_compound": True
    },
    # TSM-specific tools (Jan 2026)
    "31": {
        "name": "get_tickets_by_type",
        "description": "🎫 Get tickets by type (incident/case/problem/request)",
        "params": {
            "ticket_type": "incident",
            "limit": 10
        }
    },
    "32": {
        "name": "get_cases_by_incident",
        "description": "📁 Get cases raised by an incident",
        "params": {
            "incident_id": "INC9002148"
        }
    },
    "33": {
        "name": "get_requests_by_case",
        "description": "📝 Get requests (SCTASKs) in a case",
        "params": {
            "case_id": "CS0028143"
        }
    },
    "34": {
        "name": "get_ticket_tasks",
        "description": "✅ Get tasks for a ticket (TASK/CSTASK/PTASK/CTASK)",
        "params": {
            "ticket_id": "PRB0040854"
        }
    },
    "35": {
        "name": "get_related_problem",
        "description": "🔗 Get problem related to an incident",
        "params": {
            "incident_id": "INC9002148"
        }
    },
    "36": {
        "name": "get_incident_children",
        "description": "👶 Get child incidents of a major incident",
        "params": {
            "incident_id": "INC9002148"
        }
    },
    "37": {
        "name": "get_ticket_hierarchy",
        "description": "🌳 Get full TSM ticket hierarchy",
        "params": {
            "ticket_id": "CS0028143"
        }
    },
    # Extraction/Audit tools
    "38": {
        "name": "get_extraction_discrepancies",
        "description": "🔍 Audit: Get tickets where extracted differs from recorded",
        "params": {
            "min_confidence": 0.8,
            "limit": 20
        }
    },
    "39": {
        "name": "get_extraction_discrepancies",
        "description": "🔍 Audit: Get discrepancies for specific ticket",
        "params": {
            "ticket_number": "INC9002148"
        }
    },
    "40": {
        "name": "get_discrepancy_statistics",
        "description": "📊 Audit: Get discrepancy statistics",
        "params": {
            "min_confidence": 0.7
        }
    },
    "41": {
        "name": "get_tickets_by_extracted_fault_type",
        "description": "🔍 Audit: Find tickets by AI-extracted fault type",
        "params": {
            "fault_type": "HardDown",
            "min_confidence": 0.8,
            "limit": 50
        }
    },
    "42": {
        "name": "audit_resolution_fields",
        "description": "📋 COMPOUND: Audit resolution fields (calls #38 + formats)",
        "params": {
            "ticket_number": None,
            "min_confidence": 0.8
        },
        "is_compound": True
    },
    "45": {
        "name": "get_ticket_audit",
        "description": "📋 Get ticket audit: original values vs AI-suggested values",
        "params": {
            "ticket_id": "INC9002148"
        }
    },
    # Change Management tools (Feb 2026)
    "43": {
        "name": "get_clients_affected_by_change",
        "description": "🔄 Get all clients affected by a change (via tickets)",
        "params": {
            "change_number": "CHG0031876"
        }
    },
    "44": {
        "name": "get_clients_sharing_ci_with_change",
        "description": "🔄 Get clients sharing CIs with a change (blast radius)",
        "params": {
            "change_number": "CHG0031876"
        }
    }
}


def show_menu():
    """Display the tool selection menu"""
    print("\n" + "="*70)
    print("🎯 MCP TICKET TOOLS - Interactive Tester (TSM Model)")
    print("   Ticket types: INC (incident), CS (case), PRB (problem), SCTASK (request)")
    print("="*70)
    print("\nAvailable Tools:\n")

    for key, tool in TOOLS.items():
        # Add separator before new tools
        if key == "15":
            print("\n  " + "-"*60)
            print("  📊 ANALYTICAL TOOLS")
            print("  " + "-"*60)
        if key == "20":
            print("\n  " + "-"*60)
            print("  🔍 SEMANTIC SEARCH TOOLS")
            print("  " + "-"*60)
        if key == "23":
            print("\n  " + "-"*60)
            print("  🔍 CONTEXTUAL SEMANTIC SEARCH")
            print("  " + "-"*60)
        if key == "28":
            print("\n  " + "-"*60)
            print("  🎯 TICKET-BASED SEARCH")
            print("  " + "-"*60)
        if key == "30":
            print("\n  " + "-"*60)
            print("  🔄 COMPOUND WORKFLOWS (Client-Side)")
            print("  " + "-"*60)
        if key == "31":
            print("\n  " + "-"*60)
            print("  🎫 TSM-SPECIFIC TOOLS (Jan 2026)")
            print("  " + "-"*60)
        if key == "38":
            print("\n  " + "-"*60)
            print("  📋 NOTES EXTRACTION & AUDIT")
            print("  " + "-"*60)
        if key == "45":
            print("\n  " + "-"*60)
            print("  📋 TICKET AUDIT (View AI Suggestions)")
            print("  " + "-"*60)
        if key == "43":
            print("\n  " + "-"*60)
            print("  🔄 CHANGE MANAGEMENT (Feb 2026)")
            print("  " + "-"*60)
        print(f"  {key.rjust(2)}. {tool['description']}")

    print("\n  0. Exit")
    print("\n" + "="*70)


def edit_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """Allow user to edit parameter values"""
    print(f"\n📝 Current parameters:")
    print(json.dumps(params, indent=2))

    print(f"\nDo you want to edit parameters? (y/n): ", end="")
    choice = input().strip().lower()

    if choice != 'y':
        return params

    edited_params = {}
    print("\nEnter new values (press Enter to keep current value):\n")

    for key, value in params.items():
        current_type = type(value).__name__
        if isinstance(value, list):
            print(f"  {key} (current: {value}, type: {current_type})")
            print(f"    Enter as JSON array [\"a\",\"b\"] or comma-separated a,b,c: ", end="")
        else:
            print(f"  {key} (current: {value}, type: {current_type}): ", end="")
        new_value = input().strip()

        if not new_value:
            edited_params[key] = value
        else:
            # Try to convert to the same type as original
            try:
                if isinstance(value, list):
                    # Parse list input - accept JSON format or comma-separated
                    if new_value.startswith('[') and new_value.endswith(']'):
                        edited_params[key] = json.loads(new_value)
                    else:
                        # Comma-separated values
                        edited_params[key] = [v.strip() for v in new_value.split(',')]
                elif isinstance(value, int):
                    edited_params[key] = int(new_value)
                elif isinstance(value, float):
                    edited_params[key] = float(new_value)
                elif isinstance(value, bool):
                    edited_params[key] = new_value.lower() in ('true', 'yes', '1')
                else:
                    edited_params[key] = new_value
            except (ValueError, json.JSONDecodeError):
                edited_params[key] = new_value

    return edited_params


async def interactive_mode(server_url: str):
    """Run interactive tool selection"""

    print(f"\n🌐 Server: {server_url}")
    print("💡 Tip: Edit parameters to use real IDs from your database\n")

    while True:
        show_menu()

        choice = input("\nSelect tool (0-45): ").strip()

        if choice == '0':
            print("\n👋 Goodbye!\n")
            break

        if choice not in TOOLS:
            print("\n❌ Invalid selection. Please choose 0-45.")
            continue

        tool_info = TOOLS[choice]
        tool_name = tool_info["name"]
        params = tool_info["params"].copy()
        is_compound = tool_info.get("is_compound", False)

        # Allow parameter editing
        params = edit_params(params)

        # Call the tool or compound function
        if is_compound:
            # Call compound function directly
            if tool_name == "find_similar_faults_and_resolutions":
                result = await find_similar_faults_and_resolutions(
                    server_url,
                    params["ticket_id"],
                    params.get("top_k", 10),
                    params.get("min_score", 0.7)
                )
                if result:
                    print("\n📊 Result:")
                    print(json.dumps(result, indent=2))
            elif tool_name == "audit_resolution_fields":
                result = await audit_resolution_fields(
                    server_url,
                    params.get("ticket_number"),
                    params.get("min_confidence", 0.8)
                )
                # Result already formatted by the function
        else:
            # Call MCP tool
            await call_tool(server_url, tool_name, params)

        # Ask if user wants to continue
        print("\nPress Enter to continue, or 'q' to quit: ", end="")
        if input().strip().lower() == 'q':
            print("\n👋 Goodbye!\n")
            break


def main():
    """Main entry point"""
    server_url = "http://localhost:8003"

    # Allow server URL override
    if len(sys.argv) > 1:
        server_url = sys.argv[1]

    print(f"\n{'='*70}")
    print("🚀 Starting Interactive Tool Tester")
    print(f"{'='*70}")

    try:
        asyncio.run(interactive_mode(server_url))
    except KeyboardInterrupt:
        print("\n\n👋 Interrupted. Goodbye!\n")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}\n")


if __name__ == "__main__":
    main()
