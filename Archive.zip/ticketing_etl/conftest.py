"""
Pytest configuration and shared fixtures for all tests
"""
import sys
import os
import pytest
import asyncio
from pathlib import Path
from unittest.mock import Mock
from datetime import datetime

# Add src to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), 'src')))

# Import after sys.path modification
from utils.config import Config  # noqa: E402


# Null Object Pattern for Quality Monitoring in Tests
class NullQualitySession:
    """
    No-op quality session for tests that don't care about quality monitoring.
    Implements the same interface as QualitySession but does nothing.
    """
    def record_metric(self, *args, **kwargs):
        """Record metric (no-op)"""
        pass

    def add_issue(self, *args, **kwargs):
        """Add quality issue (no-op)"""
        pass

    def record_processing_stats(self, *args, **kwargs):
        """Record processing statistics (no-op)"""
        pass

    def finalize(self):
        """Finalize session (returns mock report)"""
        return Mock(
            quality_score=1.0,
            status="HEALTHY",
            issues=[],
            metrics={}
        )


@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session", autouse=True)
def set_test_env_vars():
    """
    Set required environment variables for all tests.
    This runs once per test session before any tests.

    These env vars are required by Config() for integration tests.
    Without these, Config() will raise ConfigurationError.
    """
    # Set all required environment variables that have no defaults
    os.environ.setdefault("DATABASE_URL", "postgresql://test:test@localhost:5432/testdb")
    os.environ.setdefault("NATS_URL", "nats://localhost:4222")
    os.environ.setdefault("JETSTREAM_STREAM_NAME", "TEST_STREAM")
    os.environ.setdefault("TICKET_PUBLISH_SUBJECT", "tickets.test")
    os.environ.setdefault("TICKET_SUBSCRIBE_SUBJECT", "tickets.test")

    # Optional settings with defaults
    os.environ.setdefault("TLS_ENABLED", "false")
    os.environ.setdefault("NATS_PUBLISHER_USER", "test-user")
    os.environ.setdefault("NATS_PUBLISHER_PASSWORD", "test-password")
    os.environ.setdefault("INITIAL_LOAD_DAYS", "30")
    os.environ.setdefault("DAILY_LOAD_HOURS", "25")
    os.environ.setdefault("LOOKUP_INTERVAL_MINUTES", "1440")

    yield

    # Cleanup if needed (optional)
    # We leave env vars in place since tests may run in parallel


@pytest.fixture
def mock_quality_session():
    """
    Provide a null quality session for tests.
    Tests don't need to care about quality monitoring.
    """
    return NullQualitySession()


@pytest.fixture
def mock_quality_monitor():
    """
    Provide a mock quality monitor that returns null sessions.
    Use this when creating DataPipelineService in tests.
    """
    monitor = Mock()
    monitor.start_monitoring.return_value = NullQualitySession()
    monitor.get_quality_metrics.return_value = {
        "average_quality_score": 1.0,
        "total_reports": 0,
        "critical_issues": 0,
        "error_issues": 0,
        "warning_issues": 0
    }
    return monitor


@pytest.fixture
def mock_config():
    """
    Create a complete mock Config object with ALL required attributes.

    Use this in unit tests instead of creating incomplete mocks.
    This prevents AttributeError when code accesses config attributes.

    Example:
        def test_something(mock_config):
            service = AppService(mock_config)
            # mock_config has all required attributes
    """
    config = Mock(spec=Config)

    # Database Configuration
    config.get_db_uri.return_value = "postgresql://test:test@localhost:5432/testdb"
    config.get_db_ssl_mode.return_value = "disable"
    config.get_db_ssl_cert.return_value = ""
    config.get_db_ssl_key.return_value = ""
    config.get_db_ssl_ca.return_value = ""

    # NATS Configuration
    config.get_nats_url.return_value = "nats://localhost:4222"
    config.get_nats_user.return_value = "test-user"
    config.get_nats_password.return_value = "test-password"
    config.get_nats_tls_enabled.return_value = False
    config.get_nats_tls_cert.return_value = ""
    config.get_nats_tls_key.return_value = ""
    config.get_nats_tls_ca.return_value = ""
    config.get_nats_tls_verify.return_value = True
    config.get_jetstream_stream_name.return_value = "TEST_STREAM"
    config.get_ticket_publish_subject.return_value = "tickets.test"
    config.get_ticket_subscribe_subject.return_value = "tickets.test"

    # TLS Master Switch
    config.get_tls_enabled.return_value = False

    # Scheduler Configuration
    config.get_scheduler_interval.return_value = 86400
    config.get_daily_schedule_time.return_value = "02:00"
    config.get_run_on_startup.return_value = True
    config.get_testing_mode.return_value = False
    config.get_testing_interval_minutes.return_value = 5

    # Data Processing Configuration
    config.get_lookup_interval_minutes.return_value = 1440  # 24 hours
    config.get_initial_load_days.return_value = 30
    config.get_daily_load_hours.return_value = 25

    # Environment
    config.env = "test"

    return config


@pytest.fixture
def sample_ticket_data():
    """Sample ticket data for testing"""
    return {
        "client_id": "TEST_CLIENT",
        "ticket_id": "INC123456",
        "title": "Test Ticket",
        "status": "Open",
        "priority": "High",
        "created_on": datetime(2025, 11, 18, 10, 0, 0),
        "updated_on": datetime(2025, 11, 18, 12, 0, 0),
        "description": "Test ticket description",
        "incident_manager": "john.doe",
        "service_desk_engineer": "jane.smith",
        "tier2_engineer": "bob.wilson"
    }


@pytest.fixture
def sample_transformed_ticket():
    """Sample transformed ticket message for testing"""
    return {
        "client_id": "TEST_CLIENT",
        "ticket_id": "INC123456",
        "title": "Test Ticket",
        "status": "Open",
        "priority": "High",
        "created_on": "2025-11-18T10:00:00",
        "updated_on": "2025-11-18T12:00:00",
        "description": "Test ticket description"
    }


def pytest_configure(config):
    """Configure pytest with custom markers and settings"""
    config.addinivalue_line(
        "markers", "integration: mark test as integration test requiring external services"
    )
    config.addinivalue_line(
        "markers", "slow: mark test as slow running"
    )
