"""
Semantic search service: combines Milvus vector search with Memgraph enrichment.
"""

import logging
import re
from typing import Any, Dict, List, Optional

from config import Config
from data_access.milvus_client import CMDMilvusClient
from services.embedding_service import EmbeddingService

logger = logging.getLogger(__name__)


class SemanticSearchService:
    def __init__(self, config: Config):
        self.config = config
        self.milvus_client = CMDMilvusClient(config)
        self.embedding_service = EmbeddingService(config)

    async def connect(self):
        self.milvus_client.connect()
        self.milvus_client.load_collection()

    def disconnect(self):
        self.milvus_client.disconnect()

    async def search_notes(
        self,
        query: str,
        top_k: int = 10,
        memgraph_client=None,
    ) -> List[Dict[str, Any]]:
        """
        Semantic search over order notes.
        Optionally enriches results with graph data from Memgraph.
        """
        query_embedding = await self.embedding_service.embed(query)
        results = await self.milvus_client.search(query_embedding, top_k=top_k)

        if memgraph_client and results:
            results = await self._enrich_with_graph(results, memgraph_client)

        return results

    async def _enrich_with_graph(
        self,
        results: List[Dict[str, Any]],
        memgraph_client,
    ) -> List[Dict[str, Any]]:
        """Add order context to vector search results."""
        for result in results:
            note_id = result.get("note_id", "")
            order_id_match = re.match(r"^(\d+)_", note_id)
            if not order_id_match:
                continue

            order_id = int(order_id_match.group(1))
            try:
                records = await memgraph_client.execute_and_fetch("""
                    MATCH (o:Order {id: $order_id})
                    OPTIONAL MATCH (o)-[:HAS_SERVICE]->(s:Service)
                    RETURN o.id AS order_id,
                           o.latest_status AS status,
                           o.status_label AS status_label,
                           s.service_type AS service_type
                """, {"order_id": order_id})
                if records:
                    result["order_id"] = records[0].get("order_id")
                    result["order_status"] = records[0].get("status")
                    result["status_label"] = records[0].get("status_label")
                    result["service_type"] = records[0].get("service_type")
            except Exception as e:
                logger.debug("Graph enrichment failed for %s: %s", note_id, e)

        return results
