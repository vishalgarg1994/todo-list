"""
Security Hooks - Phase 1 Architecture

This module provides extensibility points for authentication, authorization (RBAC),
and audit logging without requiring immediate implementation.

Design Philosophy:
- Protocol-based: Easy to swap implementations (API keys, OAuth2, JWT, etc.)
- No-op defaults: Permissive by default (current behavior preserved)
- Middleware pattern: Transparent integration with FastAPI/Starlette
- Audit trail: Track all access for compliance

Usage:
    # In main.py:
    if config.auth_enabled:
        from utils.security import AuthMiddleware
        app.add_middleware(AuthMiddleware)

    # In any tool:
    from utils.security import require_role, Role

    @require_role(Role.ADMIN)
    async def delete_ticket(ticket_id: str, request):
        principal = request.state.principal
        # ... code ...

Future Implementation (Phase 2):
    # In main.py startup:
    if config.auth_provider == "apikey":
        from utils.apikey_auth import APIKeyAuthenticator
        set_authenticator(APIKeyAuthenticator(api_keys))
"""

from typing import Protocol, Optional, Set, Dict, Any, Callable, runtime_checkable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import logging

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response, JSONResponse
from functools import wraps

logger = logging.getLogger(__name__)


# ============================================================================
# Role-Based Access Control (RBAC)
# ============================================================================

class Role(str, Enum):
    """
    User roles for RBAC.

    Hierarchy (most to least privileged):
    - ADMIN: Full system access, can manage users and configuration
    - USER: Standard user, can use all tools and query data
    - READONLY: Read-only access, cannot modify data
    - SERVICE_ACCOUNT: For machine-to-machine communication
    """
    ADMIN = "admin"
    USER = "user"
    READONLY = "readonly"
    SERVICE_ACCOUNT = "service_account"


@dataclass
class Principal:
    """
    Represents an authenticated user or service.

    Attributes:
        id: Unique identifier (user ID, API key ID, etc.)
        roles: Set of roles assigned to this principal
        metadata: Additional attributes (email, name, organization, etc.)
        authenticated_at: When authentication occurred
    """
    id: str
    roles: Set[Role]
    metadata: Dict[str, Any] = field(default_factory=dict)
    authenticated_at: datetime = field(default_factory=datetime.utcnow)

    def has_role(self, role: Role) -> bool:
        """Check if principal has a specific role."""
        return role in self.roles

    def has_any_role(self, *roles: Role) -> bool:
        """Check if principal has any of the specified roles."""
        return bool(self.roles.intersection(set(roles)))

    def has_all_roles(self, *roles: Role) -> bool:
        """Check if principal has all of the specified roles."""
        return set(roles).issubset(self.roles)


# ============================================================================
# Authentication Protocol
# ============================================================================

@runtime_checkable
class Authenticator(Protocol):
    """
    Protocol for authentication systems (API keys, OAuth2, JWT, etc.)

    All authentication implementations must provide this method.
    """

    async def authenticate(self, token: str) -> Optional[Principal]:
        """
        Authenticate a token and return a Principal if valid.

        Args:
            token: Authentication token (API key, JWT, etc.)

        Returns:
            Principal if authentication succeeds, None otherwise
        """
        ...


class NoOpAuthenticator:
    """
    Default no-op authenticator.

    This is the default authenticator that allows all requests with full admin access.
    This preserves the current behavior where there is no authentication.
    """

    async def authenticate(self, token: str) -> Optional[Principal]:
        """Always return an anonymous admin principal."""
        return Principal(
            id="anonymous",
            roles={Role.ADMIN},
            metadata={"auth_type": "noop", "note": "Authentication disabled"}
        )


# Global authenticator instance (can be replaced at runtime)
_authenticator: Authenticator = NoOpAuthenticator()


def set_authenticator(auth: Authenticator) -> None:
    """
    Set the global authenticator.

    Call this during application startup to enable real authentication.

    Example:
        from utils.apikey_auth import APIKeyAuthenticator
        set_authenticator(APIKeyAuthenticator(api_keys))
    """
    global _authenticator
    _authenticator = auth
    logger.info(f"Authenticator set to: {auth.__class__.__name__}")


def get_authenticator() -> Authenticator:
    """Get the global authenticator."""
    return _authenticator


# ============================================================================
# Authorization Protocol
# ============================================================================

@runtime_checkable
class Authorizer(Protocol):
    """
    Protocol for authorization/RBAC systems.

    All authorization implementations must provide these methods.
    """

    def can_use_tool(self, principal: Principal, tool_name: str) -> bool:
        """
        Check if principal is allowed to use a specific tool.

        Args:
            principal: The authenticated user/service
            tool_name: Name of the MCP tool

        Returns:
            True if access is allowed
        """
        ...

    def can_access_resource(self, principal: Principal, resource_type: str, resource_id: str) -> bool:
        """
        Check if principal is allowed to access a specific resource.

        Args:
            principal: The authenticated user/service
            resource_type: Type of resource (e.g., "ticket", "client")
            resource_id: Resource identifier

        Returns:
            True if access is allowed
        """
        ...


class NoOpAuthorizer:
    """
    Default no-op authorizer.

    This is the default authorizer that allows all actions. This preserves
    the current behavior where there is no authorization checking.
    """

    def can_use_tool(self, principal: Principal, tool_name: str) -> bool:
        """Always allow tool access."""
        return True

    def can_access_resource(self, principal: Principal, resource_type: str, resource_id: str) -> bool:
        """Always allow resource access."""
        return True


# Global authorizer instance (can be replaced at runtime)
_authorizer: Authorizer = NoOpAuthorizer()


def set_authorizer(authz: Authorizer) -> None:
    """
    Set the global authorizer.

    Call this during application startup to enable real authorization.

    Example:
        from utils.rbac_authorizer import RBACAuthorizer
        set_authorizer(RBACAuthorizer(policy_rules))
    """
    global _authorizer
    _authorizer = authz
    logger.info(f"Authorizer set to: {authz.__class__.__name__}")


def get_authorizer() -> Authorizer:
    """Get the global authorizer."""
    return _authorizer


# ============================================================================
# Audit Logging Protocol
# ============================================================================

@dataclass
class AuditEvent:
    """
    Represents an auditable security event.

    Attributes:
        timestamp: When the event occurred
        principal_id: Who performed the action
        action: What action was performed
        resource_type: Type of resource accessed
        resource_id: Specific resource accessed
        result: Outcome (allowed, denied, error)
        metadata: Additional context (IP address, user agent, etc.)
    """
    timestamp: datetime
    principal_id: str
    action: str
    resource_type: str
    resource_id: str
    result: str  # "allowed", "denied", "error"
    metadata: Dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class AuditLogger(Protocol):
    """
    Protocol for audit logging systems.

    All audit logging implementations must provide this method.
    """

    async def log_event(self, event: AuditEvent) -> None:
        """
        Log an audit event.

        Args:
            event: The audit event to log
        """
        ...


class NoOpAuditLogger:
    """
    Default no-op audit logger.

    This is the default audit logger that does nothing. Allows audit logging
    code to exist without requiring actual audit infrastructure.
    """

    async def log_event(self, event: AuditEvent) -> None:
        """Do nothing (no audit logging)."""
        pass


class FileAuditLogger:
    """
    Simple file-based audit logger.

    Logs audit events to a file in JSON format. Useful for development and
    basic production scenarios.
    """

    def __init__(self, log_file: str = "/app/logs/audit.log"):
        self.log_file = log_file
        self.logger = logging.getLogger("audit")
        handler = logging.FileHandler(log_file)
        handler.setFormatter(logging.Formatter('%(message)s'))
        self.logger.addHandler(handler)
        self.logger.setLevel(logging.INFO)

    async def log_event(self, event: AuditEvent) -> None:
        """Log event to file in JSON format."""
        import json
        self.logger.info(json.dumps({
            "timestamp": event.timestamp.isoformat(),
            "principal_id": event.principal_id,
            "action": event.action,
            "resource_type": event.resource_type,
            "resource_id": event.resource_id,
            "result": event.result,
            "metadata": event.metadata
        }))


# Global audit logger instance (can be replaced at runtime)
_audit_logger: AuditLogger = NoOpAuditLogger()


def set_audit_logger(logger: AuditLogger) -> None:
    """
    Set the global audit logger.

    Call this during application startup to enable audit logging.

    Example:
        from utils.security import FileAuditLogger
        set_audit_logger(FileAuditLogger("/app/logs/audit.log"))
    """
    global _audit_logger
    _audit_logger = logger
    logger_name = logger.__class__.__name__
    logging.getLogger(__name__).info(f"Audit logger set to: {logger_name}")


def get_audit_logger() -> AuditLogger:
    """Get the global audit logger."""
    return _audit_logger


# ============================================================================
# Authentication Middleware
# ============================================================================

class AuthMiddleware(BaseHTTPMiddleware):
    """
    Middleware to enforce authentication and authorization.

    This middleware:
    - Extracts authentication token from request
    - Authenticates the token and creates a Principal
    - Stores Principal in request state for tools to access
    - Logs audit events
    - Returns 401 for authentication failures
    - Returns 403 for authorization failures

    Exempt routes (no auth required):
    - /health
    - /metrics
    - /docs (if enabled)
    """

    EXEMPT_PATHS = {"/health", "/metrics", "/docs", "/openapi.json", "/redoc"}

    async def dispatch(self, request: Request, call_next) -> Response:
        """Process each request through authentication/authorization."""

        # Skip authentication for exempt paths
        if request.url.path in self.EXEMPT_PATHS:
            return await call_next(request)

        # Extract token from Authorization header
        auth_header = request.headers.get("Authorization", "")
        token = auth_header.replace("Bearer ", "").strip()

        # If no token provided and auth is required, use empty string
        # (authenticator will decide if this is allowed)
        if not token:
            token = ""

        # Authenticate
        principal = await _authenticator.authenticate(token)

        if not principal:
            # Authentication failed
            await _audit_logger.log_event(AuditEvent(
                timestamp=datetime.utcnow(),
                principal_id="unknown",
                action=request.method,
                resource_type="api",
                resource_id=request.url.path,
                result="denied",
                metadata={
                    "reason": "authentication_failed",
                    "ip": request.client.host if request.client else "unknown"
                }
            ))
            return JSONResponse(
                {"error": "Unauthorized", "message": "Invalid or missing authentication token"},
                status_code=401
            )

        # Store principal in request state for tools to access
        request.state.principal = principal

        # Log successful authentication
        await _audit_logger.log_event(AuditEvent(
            timestamp=datetime.utcnow(),
            principal_id=principal.id,
            action=request.method,
            resource_type="api",
            resource_id=request.url.path,
            result="allowed",
            metadata={
                "roles": [role.value for role in principal.roles],
                "ip": request.client.host if request.client else "unknown"
            }
        ))

        # Proceed with request
        response = await call_next(request)
        return response


# ============================================================================
# Authorization Decorators
# ============================================================================

def require_role(*required_roles: Role):
    """
    Decorator to require specific roles for a function.

    Example:
        @require_role(Role.ADMIN)
        async def delete_ticket(ticket_id: str, request):
            # Only admins can call this
            pass

        @require_role(Role.ADMIN, Role.USER)
        async def view_ticket(ticket_id: str, request):
            # Admins or users can call this
            pass
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Find the request object in args or kwargs
            request = None
            for arg in args:
                if isinstance(arg, Request):
                    request = arg
                    break
            if not request and "request" in kwargs:
                request = kwargs["request"]

            if not request:
                raise ValueError("require_role decorator requires a Request parameter")

            # Get principal from request state
            principal: Optional[Principal] = getattr(request.state, "principal", None)

            if not principal:
                raise ValueError("No principal found in request. Is AuthMiddleware enabled?")

            # Check if principal has any of the required roles
            if not principal.has_any_role(*required_roles):
                await _audit_logger.log_event(AuditEvent(
                    timestamp=datetime.utcnow(),
                    principal_id=principal.id,
                    action=func.__name__,
                    resource_type="function",
                    resource_id=func.__qualname__,
                    result="denied",
                    metadata={
                        "reason": "insufficient_roles",
                        "required_roles": [r.value for r in required_roles],
                        "user_roles": [r.value for r in principal.roles]
                    }
                ))
                raise PermissionError(f"Insufficient permissions. Required roles: {required_roles}")

            # Authorization passed, execute function
            return await func(*args, **kwargs)

        return wrapper

    return decorator


def require_permission(resource_type: str, action: str):
    """
    Decorator to require specific permission for a function.

    Example:
        @require_permission("ticket", "delete")
        async def delete_ticket(ticket_id: str, request):
            # Check if user can delete tickets
            pass
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Find the request object
            request = None
            for arg in args:
                if isinstance(arg, Request):
                    request = arg
                    break
            if not request and "request" in kwargs:
                request = kwargs["request"]

            if not request:
                raise ValueError("require_permission decorator requires a Request parameter")

            # Get principal from request state
            principal: Optional[Principal] = getattr(request.state, "principal", None)

            if not principal:
                raise ValueError("No principal found in request. Is AuthMiddleware enabled?")

            # Use authorizer to check permission
            # For now, we use a simplified check based on roles
            # Phase 2 can implement fine-grained permissions
            allowed = _authorizer.can_use_tool(principal, func.__name__)

            if not allowed:
                await _audit_logger.log_event(AuditEvent(
                    timestamp=datetime.utcnow(),
                    principal_id=principal.id,
                    action=action,
                    resource_type=resource_type,
                    resource_id=func.__name__,
                    result="denied",
                    metadata={"reason": "permission_denied"}
                ))
                raise PermissionError(f"Permission denied for {action} on {resource_type}")

            # Authorization passed, execute function
            return await func(*args, **kwargs)

        return wrapper

    return decorator


# ============================================================================
# Utility Functions
# ============================================================================

def is_authentication_enabled() -> bool:
    """
    Check if authentication is enabled (i.e., not using NoOp authenticator).

    Returns:
        True if real authentication is configured
    """
    return not isinstance(_authenticator, NoOpAuthenticator)


def is_authorization_enabled() -> bool:
    """
    Check if authorization is enabled (i.e., not using NoOp authorizer).

    Returns:
        True if real authorization is configured
    """
    return not isinstance(_authorizer, NoOpAuthorizer)


def is_audit_logging_enabled() -> bool:
    """
    Check if audit logging is enabled (i.e., not using NoOp audit logger).

    Returns:
        True if real audit logging is configured
    """
    return not isinstance(_audit_logger, NoOpAuditLogger)


def get_principal_from_request(request: Request) -> Optional[Principal]:
    """
    Safely extract Principal from request state.

    Args:
        request: Starlette/FastAPI request object

    Returns:
        Principal if authenticated, None otherwise
    """
    return getattr(request.state, "principal", None)
