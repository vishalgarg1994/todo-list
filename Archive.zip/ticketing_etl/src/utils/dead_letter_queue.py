import json
import logging
from datetime import datetime, timezone
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict
from utils.correlation import get_correlation_id


@dataclass
class FailedMessage:
    """Represents a message that failed processing"""

    original_message: Dict[str, Any]
    error_message: str
    error_type: str
    context: Dict[str, Any]
    failed_at: str
    retry_count: int = 0
    table_name: Optional[str] = None
    topic: Optional[str] = None
    correlation_id: Optional[str] = None


class DeadLetterQueue:
    """Dead Letter Queue for handling failed message processing"""

    def __init__(
        self, nats_publisher=None, dlq_topic: str = "dead_letters.failed_processing"
    ):
        self.nats_publisher = nats_publisher
        self.dlq_topic = dlq_topic
        self.logger = logging.getLogger(__name__)
        self.failed_messages = []  # In-memory storage for failed messages
        self.max_stored_messages = 1000  # Limit in-memory storage

    async def send_to_dlq(
        self,
        original_message: Any,
        error: Exception,
        context: Dict[str, Any],
        table_name: Optional[str] = None,
        topic: Optional[str] = None,
    ):
        """
        Send a failed message to the dead letter queue

        Args:
            original_message: The original message that failed
            error: The exception that occurred
            context: Additional context about the failure
            table_name: Name of the table being processed
            topic: Target topic for the message
        """
        try:
            correlation_id = get_correlation_id()

            failed_message = FailedMessage(
                original_message=self._serialize_message(original_message),
                error_message=str(error),
                error_type=type(error).__name__,
                context=context,
                failed_at=datetime.now(timezone.utc).isoformat(),
                retry_count=context.get("retry_count", 0),
                table_name=table_name,
                topic=topic,
                correlation_id=correlation_id,
            )

            # Store in memory (for immediate access)
            await self._store_failed_message(failed_message)

            # Try to publish to NATS DLQ topic if publisher is available
            if self.nats_publisher:
                await self._publish_to_dlq_topic(failed_message)

            self.logger.error(
                "Message sent to dead letter queue",
                extra={
                    "table_name": table_name,
                    "topic": topic,
                    "error_type": failed_message.error_type,
                    "error_message": failed_message.error_message,
                    "retry_count": failed_message.retry_count,
                    "correlation_id": correlation_id,
                },
            )

        except Exception as dlq_error:
            self.logger.critical(
                "Failed to send message to dead letter queue",
                extra={
                    "original_error": str(error),
                    "dlq_error": str(dlq_error),
                    "table_name": table_name,
                    "topic": topic,
                },
                exc_info=True,
            )

    def _serialize_message(self, message: Any) -> Dict[str, Any]:
        """Safely serialize a message for storage"""
        try:
            if isinstance(message, dict):
                return message
            elif isinstance(message, str):
                return {"content": message}
            elif hasattr(message, "__dict__"):
                return message.__dict__
            else:
                return {"content": str(message)}
        except Exception:
            return {"content": "Message serialization failed"}

    async def _store_failed_message(self, failed_message: FailedMessage):
        """Store failed message in memory with size limit"""
        self.failed_messages.append(failed_message)

        # Maintain size limit by removing oldest messages
        if len(self.failed_messages) > self.max_stored_messages:
            removed_count = len(self.failed_messages) - self.max_stored_messages
            self.failed_messages = self.failed_messages[removed_count:]
            self.logger.warning(
                f"DLQ memory limit reached, removed {removed_count} oldest messages"
            )

    async def _publish_to_dlq_topic(self, failed_message: FailedMessage):
        """Publish failed message to NATS DLQ topic"""
        try:
            dlq_payload = asdict(failed_message)
            dlq_json = json.dumps(dlq_payload, default=str)

            # Publish to DLQ topic
            await self.nats_publisher.publish(self.dlq_topic, dlq_json)

            self.logger.debug(
                f"Published failed message to DLQ topic: {self.dlq_topic}",
                extra={
                    "dlq_topic": self.dlq_topic,
                    "correlation_id": failed_message.correlation_id,
                },
            )

        except Exception as e:
            self.logger.error(
                f"Failed to publish to DLQ topic: {self.dlq_topic}",
                extra={"error": str(e), "dlq_topic": self.dlq_topic},
                exc_info=True,
            )
            # Don't raise - we don't want DLQ failures to crash the main process

    def get_failed_messages(
        self,
        table_name: Optional[str] = None,
        error_type: Optional[str] = None,
        limit: int = 100,
    ) -> list:
        """
        Retrieve failed messages with optional filtering

        Args:
            table_name: Filter by table name
            error_type: Filter by error type
            limit: Maximum number of messages to return

        Returns:
            List of failed messages matching criteria
        """
        messages = self.failed_messages

        # Apply filters
        if table_name:
            messages = [msg for msg in messages if msg.table_name == table_name]

        if error_type:
            messages = [msg for msg in messages if msg.error_type == error_type]

        # Return most recent messages first, up to limit
        return list(reversed(messages[-limit:]))

    def get_dlq_stats(self) -> Dict[str, Any]:
        """Get statistics about the dead letter queue"""
        if not self.failed_messages:
            return {
                "total_messages": 0,
                "by_table": {},
                "by_error_type": {},
                "oldest_message": None,
                "newest_message": None,
            }

        # Count by table
        by_table = {}
        by_error_type = {}

        for msg in self.failed_messages:
            # Count by table
            table = msg.table_name or "unknown"
            by_table[table] = by_table.get(table, 0) + 1

            # Count by error type
            error_type = msg.error_type or "unknown"
            by_error_type[error_type] = by_error_type.get(error_type, 0) + 1

        return {
            "total_messages": len(self.failed_messages),
            "by_table": by_table,
            "by_error_type": by_error_type,
            "oldest_message": self.failed_messages[0].failed_at
            if self.failed_messages
            else None,
            "newest_message": self.failed_messages[-1].failed_at
            if self.failed_messages
            else None,
        }

    async def retry_failed_messages(
        self,
        table_name: Optional[str] = None,
        max_retries: int = 3,
        retry_processor=None,
    ) -> Dict[str, int]:
        """
        Retry processing of failed messages

        Args:
            table_name: Only retry messages for specific table
            max_retries: Maximum retry attempts per message
            retry_processor: Function to process retried messages

        Returns:
            Dictionary with retry statistics
        """
        if not retry_processor:
            self.logger.warning("No retry processor provided, cannot retry messages")
            return {"retried": 0, "succeeded": 0, "failed": 0}

        messages_to_retry = [
            msg
            for msg in self.failed_messages
            if (table_name is None or msg.table_name == table_name)
            and msg.retry_count < max_retries
        ]

        retried = 0
        succeeded = 0
        failed = 0

        for failed_message in messages_to_retry:
            try:
                self.logger.info(
                    f"Retrying failed message (attempt {failed_message.retry_count + 1})",
                    extra={
                        "table_name": failed_message.table_name,
                        "retry_count": failed_message.retry_count + 1,
                        "correlation_id": failed_message.correlation_id,
                    },
                )

                # Attempt to process the message again
                await retry_processor(
                    failed_message.original_message, failed_message.context
                )

                # Success - remove from failed messages
                self.failed_messages.remove(failed_message)
                succeeded += 1

                self.logger.info(
                    "Message retry succeeded",
                    extra={
                        "table_name": failed_message.table_name,
                        "correlation_id": failed_message.correlation_id,
                    },
                )

            except Exception as e:
                # Update retry count
                failed_message.retry_count += 1
                failed += 1

                self.logger.error(
                    f"Message retry failed (attempt {failed_message.retry_count})",
                    extra={
                        "table_name": failed_message.table_name,
                        "retry_count": failed_message.retry_count,
                        "error": str(e),
                        "correlation_id": failed_message.correlation_id,
                    },
                )

                # If max retries reached, log as permanently failed
                if failed_message.retry_count >= max_retries:
                    self.logger.error(
                        "Message permanently failed after max retries",
                        extra={
                            "table_name": failed_message.table_name,
                            "max_retries": max_retries,
                            "correlation_id": failed_message.correlation_id,
                        },
                    )

            retried += 1

        self.logger.info(
            "DLQ retry completed",
            extra={
                "retried": retried,
                "succeeded": succeeded,
                "failed": failed,
                "table_name": table_name,
            },
        )

        return {"retried": retried, "succeeded": succeeded, "failed": failed}

    def clear_dlq(self, table_name: Optional[str] = None):
        """Clear failed messages from DLQ"""
        if table_name:
            self.failed_messages = [
                msg for msg in self.failed_messages if msg.table_name != table_name
            ]
            self.logger.info(f"Cleared DLQ messages for table: {table_name}")
        else:
            self.failed_messages.clear()
            self.logger.info("Cleared all DLQ messages")


# Global DLQ instance
dead_letter_queue = DeadLetterQueue()
