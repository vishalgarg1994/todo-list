"""
LLM Observability Hooks - Platform Agnostic

This module provides extensibility points for LLM-specific observability
platforms (Opik, MLflow, LangSmith, Phoenix, etc.) without committing to
a specific vendor.

Design Philosophy:
- Protocol-based: Works with ANY LLM observability platform
- No-op default: Zero overhead when disabled (current behavior)
- Platform agnostic: Switch between Opik/MLflow/etc. with config change
- Decision deferral: Add instrumentation NOW, choose platform LATER

Current Status:
- Team is evaluating: Opik vs MLflow vs others
- This module allows instrumentation without vendor lock-in
- Console logger available for immediate visibility
- Full platform integration in Phase 2 (after decision)

Usage (NOW - with console logging):
    from utils.llm_observability import get_llm_observability, LLMCall

    llm_call = LLMCall(
        prompt="Generate query for...",
        model="llama3.1:8b",
        temperature=0.1,
        response="MATCH (n:Ticket)...",
        tokens_total=45,
        latency_ms=234.5,
        cost_usd=0.0012,
        call_type="cypher_generation"
    )

    get_llm_observability().log_llm_call(llm_call)

Future Usage (Phase 2 - after platform decision):
    # In main.py startup:
    if config.llm_observability_provider == "opik":
        from utils.opik_provider import OpikProvider
        set_llm_observability_provider(OpikProvider(api_key=...))

    elif config.llm_observability_provider == "mlflow":
        from utils.mlflow_provider import MLflowProvider
        set_llm_observability_provider(MLflowProvider(experiment_name=...))
"""

from typing import Protocol, Dict, Any, Optional, Callable, runtime_checkable
from dataclasses import dataclass, field
from datetime import datetime
from functools import wraps
from enum import Enum
import time
import logging

logger = logging.getLogger(__name__)


# ============================================================================
# LLM Call Data Model
# ============================================================================

class LLMCallType(str, Enum):
    """Types of LLM calls in the system."""
    CYPHER_GENERATION = "cypher_generation"
    QUESTION_ANSWERING = "question_answering"
    TEXT_GENERATION = "text_generation"
    SUMMARIZATION = "summarization"
    CLASSIFICATION = "classification"
    OTHER = "other"


@dataclass
class LLMCall:
    """
    Platform-agnostic representation of an LLM call.

    This data structure works with ALL platforms:
    - Opik: Maps to their log() method
    - MLflow: Maps to log_param/log_metric
    - LangSmith: Maps to their trace format
    - Phoenix: Maps to their span format
    - Weights & Biases: Maps to wandb.log()

    Attributes:
        prompt: Input prompt sent to LLM
        model: Model identifier (e.g., "llama3.1:8b", "llama3.1:70b")
        temperature: Sampling temperature used
        response: LLM's output
        tokens_prompt: Number of tokens in prompt
        tokens_completion: Number of tokens in completion
        tokens_total: Total tokens used (prompt + completion)
        latency_ms: Time taken for call in milliseconds
        cost_usd: Estimated cost in USD
        call_type: Type of LLM operation
        success: Whether call succeeded
        error_message: Error details if failed
        timestamp: When call was made
        tags: Key-value tags for filtering/grouping
        metadata: Additional context (schema, user, etc.)
    """
    # Request details
    prompt: str
    model: str
    temperature: float

    # Response details
    response: str

    # Token metrics
    tokens_prompt: int = 0
    tokens_completion: int = 0
    tokens_total: int = 0

    # Performance metrics
    latency_ms: float = 0.0
    cost_usd: float = 0.0

    # Call context
    call_type: LLMCallType = LLMCallType.OTHER
    success: bool = True
    error_message: Optional[str] = None

    # Metadata
    timestamp: datetime = field(default_factory=datetime.utcnow)
    tags: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


# ============================================================================
# LLM Observability Protocol
# ============================================================================

@runtime_checkable
class LLMObservabilityProvider(Protocol):
    """
    Protocol for LLM observability platforms.

    Any platform (Opik, MLflow, LangSmith, Phoenix, etc.) must implement
    these methods to be compatible with the system.
    """

    def log_llm_call(self, call: LLMCall) -> None:
        """
        Log a single LLM call with full context.

        Args:
            call: LLMCall object with all metrics and metadata
        """
        ...

    def start_trace(self, name: str, metadata: Optional[Dict[str, Any]] = None) -> Any:
        """
        Start a trace for multi-step LLM workflows.

        Args:
            name: Trace name (e.g., "ticket_analysis_workflow")
            metadata: Optional trace-level metadata

        Returns:
            Trace ID or context object (platform-specific)
        """
        ...

    def end_trace(self, trace_id: Any) -> None:
        """
        End a trace.

        Args:
            trace_id: Trace identifier returned from start_trace()
        """
        ...

    def log_feedback(self, call_id: str, feedback: Dict[str, Any]) -> None:
        """
        Log user feedback on an LLM call (for RLHF, quality tracking).

        Args:
            call_id: Identifier for the LLM call
            feedback: Feedback data (rating, corrections, etc.)
        """
        ...


# ============================================================================
# No-Op Implementation (Default)
# ============================================================================

class NoOpLLMObservability:
    """
    Default no-op implementation.

    This is the default provider that does nothing. Allows code to be
    instrumented immediately without requiring actual LLM observability
    infrastructure or platform decision.

    Zero overhead - all methods are inline no-ops.
    """

    def log_llm_call(self, call: LLMCall) -> None:
        """Do nothing (no logging)."""
        pass

    def start_trace(self, name: str, metadata: Optional[Dict[str, Any]] = None) -> Any:
        """Return None (no tracing)."""
        return None

    def end_trace(self, trace_id: Any) -> None:
        """Do nothing (no tracing)."""
        pass

    def log_feedback(self, call_id: str, feedback: Dict[str, Any]) -> None:
        """Do nothing (no feedback tracking)."""
        pass


# ============================================================================
# Console Logger (Immediate Use)
# ============================================================================

class ConsoleLLMObservability:
    """
    Simple console logger for LLM calls.

    This provides immediate visibility into LLM operations without requiring
    external platforms. Useful for:
    - Development and debugging
    - Testing LLM behavior
    - Temporary solution while platform decision is pending
    - Understanding LLM usage patterns before committing to a platform

    Logs to standard logging system (can be captured by log aggregation).
    """

    def __init__(self, log_prompts: bool = False, log_responses: bool = False):
        """
        Initialize console logger.

        Args:
            log_prompts: If True, include full prompts in logs (can be verbose)
            log_responses: If True, include full responses in logs (can be verbose)
        """
        self.log_prompts = log_prompts
        self.log_responses = log_responses
        self.logger = logging.getLogger("llm_observability")

    def log_llm_call(self, call: LLMCall) -> None:
        """Log call to console."""
        status = "✓" if call.success else "✗"

        # Summary line
        self.logger.info(
            f"{status} LLM Call: {call.call_type.value} | "
            f"Model: {call.model} | "
            f"Tokens: {call.tokens_total} "
            f"(prompt: {call.tokens_prompt}, completion: {call.tokens_completion}) | "
            f"Latency: {call.latency_ms:.0f}ms | "
            f"Cost: ${call.cost_usd:.4f} | "
            f"Temp: {call.temperature}"
        )

        # Optional: Log prompt (can be verbose)
        if self.log_prompts and call.prompt:
            prompt_preview = call.prompt[:200] + "..." if len(call.prompt) > 200 else call.prompt
            self.logger.debug(f"  Prompt: {prompt_preview}")

        # Optional: Log response (can be verbose)
        if self.log_responses and call.response:
            response_preview = call.response[:200] + "..." if len(call.response) > 200 else call.response
            self.logger.debug(f"  Response: {response_preview}")

        # Log tags if present
        if call.tags:
            self.logger.debug(f"  Tags: {call.tags}")

        # Log errors
        if not call.success:
            self.logger.error(f"  Error: {call.error_message}")

    def start_trace(self, name: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """Log trace start."""
        self.logger.info(f"🔍 Trace started: {name}")
        if metadata:
            self.logger.debug(f"  Metadata: {metadata}")
        return name

    def end_trace(self, trace_id: Any) -> None:
        """Log trace end."""
        self.logger.info(f"✓ Trace completed: {trace_id}")

    def log_feedback(self, call_id: str, feedback: Dict[str, Any]) -> None:
        """Log feedback."""
        self.logger.info(f"📝 Feedback received for call {call_id}: {feedback}")


# ============================================================================
# Global Registry
# ============================================================================

# Global LLM observability instance (can be replaced at runtime)
_llm_observability: LLMObservabilityProvider = NoOpLLMObservability()


def set_llm_observability_provider(provider: LLMObservabilityProvider) -> None:
    """
    Set the global LLM observability provider.

    Call this during application startup to enable LLM observability.

    Examples:
        # Console logging (immediate use):
        set_llm_observability_provider(ConsoleLLMObservability())

        # Opik (Phase 2):
        from utils.opik_provider import OpikProvider
        set_llm_observability_provider(OpikProvider(api_key=...))

        # MLflow (Phase 2):
        from utils.mlflow_provider import MLflowProvider
        set_llm_observability_provider(MLflowProvider(experiment_name=...))
    """
    global _llm_observability
    _llm_observability = provider
    logger.info(f"LLM observability provider set to: {provider.__class__.__name__}")


def get_llm_observability() -> LLMObservabilityProvider:
    """
    Get the global LLM observability provider.

    Returns the current provider (NoOp by default).
    """
    return _llm_observability


# ============================================================================
# Decorator for Automatic Tracking
# ============================================================================

def track_llm_call(call_type: LLMCallType = LLMCallType.OTHER):
    """
    Decorator to automatically track LLM calls.

    The decorated function should either:
    1. Return an LLMCall object (will be logged automatically)
    2. Return any value (decorator will create basic LLMCall)

    Args:
        call_type: Type of LLM call

    Example:
        @track_llm_call(LLMCallType.CYPHER_GENERATION)
        async def generate_cypher(question: str):
            # ... call LLM ...

            return LLMCall(
                prompt=prompt,
                model="llama3.1:8b",
                temperature=0.1,
                response=cypher_query,
                call_type=call_type
            )
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()

            try:
                result = await func(*args, **kwargs)

                # If function returns LLMCall, enhance and log it
                if isinstance(result, LLMCall):
                    if result.latency_ms == 0.0:
                        result.latency_ms = (time.time() - start_time) * 1000
                    if result.call_type == LLMCallType.OTHER:
                        result.call_type = call_type
                    _llm_observability.log_llm_call(result)

                return result

            except Exception as e:
                # Log failed call
                error_call = LLMCall(
                    prompt="<error - see logs>",
                    model="<error>",
                    temperature=0.0,
                    response="<error>",
                    call_type=call_type,
                    success=False,
                    error_message=str(e),
                    latency_ms=(time.time() - start_time) * 1000
                )
                _llm_observability.log_llm_call(error_call)
                raise

        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            start_time = time.time()

            try:
                result = func(*args, **kwargs)

                # If function returns LLMCall, enhance and log it
                if isinstance(result, LLMCall):
                    if result.latency_ms == 0.0:
                        result.latency_ms = (time.time() - start_time) * 1000
                    if result.call_type == LLMCallType.OTHER:
                        result.call_type = call_type
                    _llm_observability.log_llm_call(result)

                return result

            except Exception as e:
                # Log failed call
                error_call = LLMCall(
                    prompt="<error - see logs>",
                    model="<error>",
                    temperature=0.0,
                    response="<error>",
                    call_type=call_type,
                    success=False,
                    error_message=str(e),
                    latency_ms=(time.time() - start_time) * 1000
                )
                _llm_observability.log_llm_call(error_call)
                raise

        # Return appropriate wrapper based on function type
        import asyncio
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper

    return decorator


# ============================================================================
# Context Manager for Traces
# ============================================================================

class LLMTrace:
    """
    Context manager for tracing multi-step LLM workflows.

    Example:
        with LLMTrace("ticket_analysis") as trace:
            # Step 1: Generate Cypher
            cypher = await generate_cypher(question)

            # Step 2: Execute query
            results = execute_query(cypher)

            # Step 3: Summarize results
            summary = await summarize(results)
    """

    def __init__(self, name: str, metadata: Optional[Dict[str, Any]] = None):
        self.name = name
        self.metadata = metadata or {}
        self.trace_id = None

    def __enter__(self):
        self.trace_id = _llm_observability.start_trace(self.name, self.metadata)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        _llm_observability.end_trace(self.trace_id)


# ============================================================================
# Utility Functions
# ============================================================================

def is_llm_observability_enabled() -> bool:
    """
    Check if LLM observability is enabled (i.e., not using NoOp).

    Returns:
        True if real observability is configured
    """
    return not isinstance(_llm_observability, NoOpLLMObservability)


def estimate_tokens(text: str) -> int:
    """
    Rough estimate of token count (before actual API response).

    Uses simple heuristic: ~4 characters per token.
    Replace with tiktoken for accurate counting when needed.

    Args:
        text: Text to estimate tokens for

    Returns:
        Estimated token count
    """
    return len(text) // 4


def estimate_cost(model: str, tokens_prompt: int, tokens_completion: int) -> float:
    """
    Estimate cost in USD for an LLM call.

    Uses approximate pricing as of 2025. Update these values periodically.

    Args:
        model: Model identifier
        tokens_prompt: Prompt tokens
        tokens_completion: Completion tokens

    Returns:
        Estimated cost in USD
    """
    # For self-hosted Ollama models, no cost applies
    # This function returns 0.0 for local inference
    return 0.0


def create_llm_call_from_baml_response(
    prompt: str,
    response: str,
    model: str,
    temperature: float,
    call_type: LLMCallType,
    latency_ms: float,
    **kwargs
) -> LLMCall:
    """
    Helper to create LLMCall from BAML response.

    Args:
        prompt: Input prompt
        response: LLM response
        model: Model used
        temperature: Temperature used
        call_type: Type of call
        latency_ms: Latency in milliseconds
        **kwargs: Additional metadata

    Returns:
        Populated LLMCall object
    """
    tokens_prompt = estimate_tokens(prompt)
    tokens_completion = estimate_tokens(response)
    tokens_total = tokens_prompt + tokens_completion
    cost_usd = estimate_cost(model, tokens_prompt, tokens_completion)

    return LLMCall(
        prompt=prompt,
        model=model,
        temperature=temperature,
        response=response,
        tokens_prompt=tokens_prompt,
        tokens_completion=tokens_completion,
        tokens_total=tokens_total,
        latency_ms=latency_ms,
        cost_usd=cost_usd,
        call_type=call_type,
        success=True,
        metadata=kwargs
    )
