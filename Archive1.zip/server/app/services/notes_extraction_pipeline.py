"""
Notes Extraction Pipeline

Runs after NATS consumption completes (detected via idle timeout).
Processes resolved tickets every cycle, not just once per day.

Flow:
0. Reconcile graph — create orphaned FK edges + sync classification fields
1. Query Memgraph for resolved tickets
2. Fetch notes/emails/field_changes from ServiceNow API
3. Single LLM call per ticket for audit
4. Store/update NoteInfo in Memgraph (upsert)
"""
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any

from services.resolved_tickets_service import ResolvedTicketsService, ResolvedTicket
from services.servicenow_client import ServiceNowClient, TicketNotesData
from services.notes_processor import NotesProcessor
from services.graph_reconciliation import GraphReconciliation
from data_access.milvus_notes_client import MilvusNotesClient
from data_access.milvusClient import MilvusClient
from configs.config import Config

# Module-level singleton guard
_background_checker_started = False


class NotesExtractionPipeline:
    """
    Orchestrates notes extraction after NATS consumption completes.

    Uses idle timeout: if no messages processed for IDLE_THRESHOLD seconds,
    assumes consumption is complete and triggers pipeline.

    Runs every cycle (with cooldown) to pick up new notes on resolved tickets.
    """

    IDLE_THRESHOLD_SECONDS = 60   # 1 minute idle before triggering
    CHECK_INTERVAL_SECONDS = 15   # Check every 15 seconds

    def __init__(
        self,
        memgraph_client,
        config: Config,
    ):
        self.memgraph_client = memgraph_client
        self.config = config
        self.logger = logging.getLogger(__name__)

        # State tracking
        self._last_message_time: Optional[datetime] = None
        self._last_run_time: Optional[datetime] = None  # Track last run time, not date
        self._is_running: bool = False

        # Services (lazy init)
        self._reconciliation: Optional[GraphReconciliation] = None
        self._resolved_tickets_service: Optional[ResolvedTicketsService] = None
        self._servicenow_client: Optional[ServiceNowClient] = None
        self._notes_processor: Optional[NotesProcessor] = None
        self._milvus_client: Optional[MilvusNotesClient] = None
        self._fault_milvus_client: Optional[MilvusClient] = None

    @property
    def reconciliation(self) -> GraphReconciliation:
        if self._reconciliation is None:
            self._reconciliation = GraphReconciliation(self.memgraph_client)
        return self._reconciliation

    @property
    def resolved_tickets_service(self) -> ResolvedTicketsService:
        if self._resolved_tickets_service is None:
            self._resolved_tickets_service = ResolvedTicketsService(
                self.memgraph_client, self.config
            )
        return self._resolved_tickets_service

    @property
    def servicenow_client(self) -> ServiceNowClient:
        if self._servicenow_client is None:
            self._servicenow_client = ServiceNowClient(self.config)
        return self._servicenow_client

    @property
    def milvus_client(self) -> MilvusNotesClient:
        if self._milvus_client is None:
            self._milvus_client = MilvusNotesClient(self.config)
        return self._milvus_client

    @property
    def notes_processor(self) -> NotesProcessor:
        if self._notes_processor is None:
            self._notes_processor = NotesProcessor(
                self.memgraph_client, self.config, self.milvus_client
            )
        return self._notes_processor

    @property
    def fault_milvus_client(self) -> MilvusClient:
        if self._fault_milvus_client is None:
            self._fault_milvus_client = MilvusClient(self.config, connection_alias="pipeline_fault")
            self._fault_milvus_client.connect()
            self._fault_milvus_client.load_collection()
        return self._fault_milvus_client

    def on_message_processed(self):
        """Called after each NATS message is processed"""
        self._last_message_time = datetime.now()

    def _should_trigger(self) -> bool:
        """Check if notes_pipeline should run based on idle timeout"""
        # Don't run if already running
        if self._is_running:
            return False

        # Don't run if no messages processed yet
        if self._last_message_time is None:
            return False

        # Check idle timeout - run if no new messages for a while
        idle_seconds = (datetime.now() - self._last_message_time).total_seconds()
        return idle_seconds >= self.IDLE_THRESHOLD_SECONDS

    async def start_background_checker(self):
        """Background task - checks every 60 seconds if notes_pipeline should run"""
        global _background_checker_started

        if _background_checker_started:
            self.logger.warning("Notes pipeline: background checker already running, skipping")
            return

        _background_checker_started = True
        self.logger.info(f"Notes pipeline: background checker started (idle timeout={self.IDLE_THRESHOLD_SECONDS}s)")

        while True:
            await asyncio.sleep(self.CHECK_INTERVAL_SECONDS)

            if self._should_trigger():
                self.logger.info("Notes pipeline: idle timeout reached, starting extraction")
                await self.run()

    async def run(self):
        """Execute the notes extraction pipeline"""
        self._is_running = True
        start_time = datetime.now()

        try:
            # Step 0: Reconcile graph — create orphaned FK edges + sync fields
            await self.reconciliation.reconcile()

            # Step 1: Query resolved tickets from Memgraph
            # (Resolved auto-closes in 48 hours, so this is naturally bounded)
            tickets = await self.resolved_tickets_service.get_resolved_tickets()

            if not tickets:
                self.logger.info("Notes pipeline: no resolved tickets pending extraction")
                self._last_run_time = datetime.now()
                return

            self.logger.info(f"Notes pipeline: found {len(tickets)} resolved tickets")

            # Step 2: Fetch notes from ServiceNow API
            notes_data = await self._fetch_all_notes(tickets)
            successful_fetches = sum(1 for d in notes_data if d.fetch_success)
            failed_fetches = len(notes_data) - successful_fetches

            self.logger.info(
                f"Notes pipeline: fetched {successful_fetches} tickets, "
                f"{failed_fetches} failed"
            )

            # Step 3: LLM audit and store to Memgraph
            if successful_fetches > 0:
                # Initialize processor (tests LLM connection)
                await self.notes_processor.initialize()

                try:
                    # Build metadata map for comparison
                    ticket_metadata_map = await self._fetch_ticket_metadata(tickets)

                    # WS-B/C integration: batch-fetch fault description summaries from Milvus
                    try:
                        ticket_ids = [t.ticket_id for t in tickets]
                        summaries = await self.fault_milvus_client.get_summaries_batch(ticket_ids)
                        # Merge summaries into metadata (keyed by ticket_id, metadata keyed by sys_id)
                        for t in tickets:
                            if t.ticket_id in summaries and t.ticket_sys_id in ticket_metadata_map:
                                ticket_metadata_map[t.ticket_sys_id]['fault_description_summary'] = summaries[t.ticket_id]
                        self.logger.info(f"Fetched {len(summaries)} fault description summaries from Milvus")
                    except Exception as e:
                        self.logger.warning(f"Failed to fetch fault description summaries: {e}")

                    # Process all notes
                    totals = await self.notes_processor.process_batch(
                        notes_data,
                        ticket_metadata_map
                    )

                    self.logger.info(
                        f"Notes pipeline: processed {totals['tickets_processed']} tickets, "
                        f"{totals['tickets_with_content']} with content, "
                        f"{totals['audits_stored']} audits stored, "
                        f"{totals.get('timelines_embedded', 0)} timelines embedded"
                    )

                finally:
                    await self.notes_processor.close()
                    # Disconnect fault Milvus client if it was initialized
                    if self._fault_milvus_client:
                        self._fault_milvus_client.disconnect()
                        self._fault_milvus_client = None

            # Mark complete
            self._last_run_time = datetime.now()
            elapsed = (datetime.now() - start_time).total_seconds()

            self.logger.info(f"Notes pipeline: complete in {elapsed:.1f}s")

        except Exception as e:
            self.logger.error(f"Notes pipeline: failed - {e}", exc_info=True)
        finally:
            self._is_running = False
            # Reset message time so we only trigger on NEW NATS messages
            self._last_message_time = None
            self.logger.debug("Notes pipeline: reset _last_message_time, waiting for new NATS messages")

    async def _fetch_all_notes(self, tickets: List[ResolvedTicket]) -> List[TicketNotesData]:
        """Fetch notes for all tickets from ServiceNow API"""
        ticket_dicts = [
            {
                "ticket_sys_id": t.ticket_sys_id,
                "ticket_id": t.ticket_id,
                "ticket_type": t.ticket_type
            }
            for t in tickets
        ]

        try:
            return await self.servicenow_client.fetch_batch(ticket_dicts)
        finally:
            await self.servicenow_client.close()

    async def _fetch_ticket_metadata(
        self,
        tickets: List[ResolvedTicket]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Fetch ticket metadata from Memgraph for comparison during audit.

        Returns dict mapping ticket_sys_id to metadata.
        """
        if not tickets:
            return {}

        # Build list of sys_ids
        sys_ids = [t.ticket_sys_id for t in tickets]

        query = """
        MATCH (t:Ticket)
        WHERE t.ticket_sys_id IN $sys_ids
        RETURN t.ticket_sys_id AS ticket_sys_id,
               t.ticket_id AS ticket_id,
               t.ticket_type AS ticket_type,
               t.ticket_category AS ticket_category,
               t.priority AS priority,
               t.fault_type AS fault_type,
               t.responsible_party AS responsible_party,
               t.mttr AS mttr_minutes,
               t.resolution_code AS resolution_code,
               t.resolution_notes AS resolution_notes,
               t.short_description AS short_description,
               t.ticket_status AS ticket_status
        """

        try:
            records = await self.memgraph_client.execute(query, {"sys_ids": sys_ids})

            metadata_map = {}
            for record in records:
                sys_id = record["ticket_sys_id"]
                metadata_map[sys_id] = {
                    "ticket_id": record.get("ticket_id"),
                    "ticket_type": record.get("ticket_type"),
                    "ticket_category": record.get("ticket_category"),
                    "priority": record.get("priority"),
                    "fault_type": record.get("fault_type"),
                    "responsible_party": record.get("responsible_party"),
                    "mttr_minutes": record.get("mttr_minutes"),
                    "resolution_code": record.get("resolution_code"),
                    "resolution_notes": record.get("resolution_notes"),
                    "short_description": record.get("short_description"),
                    "ticket_status": record.get("ticket_status"),
                }

            self.logger.info(f"Fetched metadata for {len(metadata_map)} tickets")
            return metadata_map

        except Exception as e:
            self.logger.error(f"Error fetching ticket metadata: {e}")
            return {}

    def get_status(self) -> Dict[str, Any]:
        """Get current pipeline status"""
        now = datetime.now()
        idle_seconds = None

        if self._last_message_time:
            idle_seconds = (now - self._last_message_time).total_seconds()

        return {
            "last_run_time": self._last_run_time.isoformat() if self._last_run_time else None,
            "is_running": self._is_running,
            "idle_seconds": idle_seconds,
            "will_trigger_in": max(0, self.IDLE_THRESHOLD_SECONDS - (idle_seconds or 0)) if idle_seconds else None
        }
